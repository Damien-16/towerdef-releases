var Ch=Object.defineProperty;var Ah=(i,e,t)=>e in i?Ch(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var j=(i,e,t)=>Ah(i,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();const ua=["blood_moon","crystal_rain","ether_storm"],To={blood_moon:{id:"blood_moon",name:"Lune de Sang",short:"LUNE DE SANG",icon:"🩸",color:"#ff4f6d",desc:"Ennemis +20 % vitesse · Butin & récompense de vague ×2 !"},crystal_rain:{id:"crystal_rain",name:"Pluie de Cristaux",short:"PLUIE CRISTAUX",icon:"💎",color:"#4ef2e8",desc:"De nouveaux filons de Pierre & Cristaux tombent sur la carte !"},ether_storm:{id:"ether_storm",name:"Tempête d’Éther",short:"TEMPÊTE ÉTHER",icon:"⚡",color:"#b87aff",desc:"Tourelles +25 % cadence · Ennemis +15 % PV !"}},sr=["guardian","engineer","archmage","ranger","summoner"],Mt={guardian:{id:"guardian",name:"Gardien d’Éther",short:"GARDIEN",color:"#4ef2e8",desc:"Équilibré · [ESP] Ruée tranchante · [E] Cri de Bastion (+cadence tours) · [R] Jugement d’Éther (5 éclairs).",spriteKey:"hero",hpMult:1,spdMult:1,dmgMult:1,rateMult:1,range:108,buildDiscountBonus:0,repairPowerBonus:0,dashSym:"»",dashTip:"Ruée tranchante (Espace)",rallySym:"⚔",rallyTip:"Cri de Bastion (E) : surcharge tours + étourdit",ultSym:"⚡",ultTip:"Jugement d’Éther (R) : 5 éclairs arcaniques"},engineer:{id:"engineer",name:"Ingénieur de Siège",short:"INGÉNIEUR",color:"#ffbe3b",desc:"−12 % coût bât. & +50 % répar. · [ESP] Bond Réparateur · [E] Surcharge + Bouclier secteur · [R] Automate de Siège (14 s).",spriteKey:"hero_engineer",hpMult:1.15,spdMult:.95,dmgMult:.92,rateMult:1,range:102,buildDiscountBonus:.12,repairPowerBonus:.5,dashSym:"▲",dashTip:"Bond Réparateur (Espace) : dash + répare les structures proches",rallySym:"⚙",rallyTip:"Surcharge de Secteur (E) : cadence + soin + bouclier",ultSym:"✦",ultTip:"Automate de Siège (R) : tourelle temporaire 14 s"},archmage:{id:"archmage",name:"Archimage Runique",short:"ARCHIMAGE",color:"#b87aff",desc:"Éclairs en chaîne & portée +26 % · [ESP] Téléportation au curseur · [E] Nova de Stase (brise-armure) · [R] Cataclysme anti-boss.",spriteKey:"hero_archmage",hpMult:.82,spdMult:1.08,dmgMult:1.18,rateMult:1.08,range:136,buildDiscountBonus:0,repairPowerBonus:0,dashSym:"✧",dashTip:"Téléportation Runique (Espace) : téléporte vers le curseur",rallySym:"❄",rallyTip:"Nova de Stase (E) : étourdit + brise-armure",ultSym:"☄",ultTip:"Cataclysme d’Éther (R) : 3 piliers massifs sur boss/élites"},ranger:{id:"ranger",name:"Rôdeur d’Émeraude",short:"RÔDEUR",color:"#5ef28c",desc:"Ultra-rapide (+24 % vit.), portée max & 30 % Coups Critiques ×2,2 · [ESP] Pas de l’Ombre explosif · [E] Œil de Faucon (brise-armure) · [R] Pluie de 8 Flèches Critiques.",spriteKey:"hero_ranger",unlockAdvLevel:10,unlockEssenceCost:15,hpMult:.9,spdMult:1.24,dmgMult:1.15,rateMult:.88,range:148,buildDiscountBonus:0,repairPowerBonus:0,dashSym:"➶",dashTip:"Pas de l’Ombre (Espace) : esquive rapide + piège explosif",rallySym:"◎",rallyTip:"Œil de Faucon (E) : surcharge tours + marque brise-armure",ultSym:"➹",ultTip:"Pluie de Flèches (R) : 8 flèches critiques perforantes sur les cibles prioritaires"},summoner:{id:"summoner",name:"Invocateur Astral",short:"INVOC.",color:"#38bdf8",desc:"Orbes perforants & armée de Sentinelles d’Éther · [ESP] Transfert Spectral (prolonge sentinelles) · [E] Pacte d’Essence (bouclier Citadelle + surcharge) · [R] Légion de 3 Sentinelles (18 s).",spriteKey:"hero_summoner",unlockAdvLevel:25,unlockEssenceCost:35,hpMult:.88,spdMult:1.05,dmgMult:.95,rateMult:.95,range:126,buildDiscountBonus:.04,repairPowerBonus:.15,dashSym:"✦",dashTip:"Transfert Spectral (Espace) : téléporte + étourdit + prolonge tes sentinelles",rallySym:"❖",rallyTip:"Pacte d’Essence (E) : bouclier Citadelle + surcharge tourelles et sentinelles",ultSym:"✧",ultTip:"Légion d’Éther (R) : invoque 3 Sentinelles d’Éther autonomes (18 s)"}},rr={archer_tower:{A:{id:"A",name:"Salve Triple",short:"Salve ×3",desc:"Tire 3 flèches en éventail à chaque salve pour décimer les nuées.",color:"#5ef28c"},B:{id:"B",name:"Tireur d’Élite",short:"Sniper",desc:"+55 % dégâts, +25 % portée et +4 perce-armure par flèche.",color:"#ffbe3b"}},ballista:{A:{id:"A",name:"Harpon Perforant",short:"Harpon",desc:"+3 perforation, +35 % dégâts et +4 perce-armure contre les colosses.",color:"#ff7e33"},B:{id:"B",name:"Arbalète Rapide",short:"Rafale",desc:"+40 % cadence de tir soutenue.",color:"#4ef2e8"}},flak_tower:{A:{id:"A",name:"Obus Shrapnel",short:"Shrapnel",desc:"+45 % rayon d’explosion anti-aérienne pour raser les essaims.",color:"#7ce8ff"},B:{id:"B",name:"Canon Intercepteur",short:"Interc.",desc:"+35 % cadence de tir et +30 % dégâts directs.",color:"#ffbe3b"}},arcane_tower:{A:{id:"A",name:"Tempête en Chaîne",short:"Chaîne +4",desc:"+4 cibles supplémentaires touchées par chaque éclair en chaîne.",color:"#b87aff"},B:{id:"B",name:"Foudre Concentrée",short:"Voltage",desc:"+55 % dégâts d’éclair et +4 perce-armure.",color:"#ff4f6d"}},frost_tower:{A:{id:"A",name:"Blizzard Éternel",short:"Blizzard",desc:"+35 % portée et +2 s de ralentissement glacial.",color:"#7ce8ff"},B:{id:"B",name:"Gel Cassant",short:"Brise-Arm.",desc:"+50 % dégâts de givre et brise l’armure ennemie pendant 4 s.",color:"#38bdf8"}},alch_mortar:{A:{id:"A",name:"Vague Corrosive",short:"Déluge",desc:"+40 % rayon d’impact et flaques acides +2 s plus longues.",color:"#a3e635"},B:{id:"B",name:"Acide Concentré",short:"Vitriol",desc:"+60 % dégâts d’impact et de poison corrosif.",color:"#ffbe3b"}},solar_tower:{A:{id:"A",name:"Supernova",short:"Supernova",desc:"Charge du rayon ×2 plus rapide et +35 % dégâts.",color:"#ffe066"},B:{id:"B",name:"Prisme Double",short:"2× Rayon",desc:"Réfracte le rayon solaire sur une 2e cible proche simultanément !",color:"#ff7e33"}},catapult:{A:{id:"A",name:"Météore de Siège",short:"Météore",desc:"+45 % dégâts et +35 % rayon d’explosion.",color:"#ff4f6d"},B:{id:"B",name:"Pluie de Roches",short:"Barrage",desc:"+40 % cadence de bombardement.",color:"#ffbe3b"}},tesla_spire:{A:{id:"A",name:"Bobine Surchargée",short:"Stun ×1,6",desc:"+3 cibles en chaîne et durée d’étourdissement ×1,6.",color:"#38bdf8"},B:{id:"B",name:"Arc Haute Tension",short:"H.Tension",desc:"+55 % dégâts électriques et +4 perce-armure.",color:"#ffe066"}},chrono_obelisk:{A:{id:"A",name:"Singularité",short:"Singul.",desc:"+30 % portée et +2,5 s de ralentissement temporel.",color:"#b87aff"},B:{id:"B",name:"Faille Temporelle",short:"Faille",desc:"+55 % dégâts et étourdissement de zone (0,45 s).",color:"#ff4f6d"}}},U=16,Le=42,He=30,Ft=Le*U,Ot=He*U,_n=19,ln=13,ht=3,Es=["easy","normal","hard","extreme","impossible"],Wt={easy:{id:"easy",label:"Facile",color:"#5ef28c",desc:"0,75× PV/dégâts ennemis · +20 % ressources · Préparation longue (34 s).",hpMult:.75,dmgMult:.75,spdMult:.92,countMult:.82,armorBonus:0,resourceMult:1.2,prepDuration:34,minFlanks:1,extraFlankWaves:0,waveShift:-1,bossInterval:5,bossEscortCount:0,respawnMult:.8,costMult:.9},normal:{id:"normal",label:"Normal",color:"#4ef2e8",desc:"Expérience équilibrée : assauts progressifs et économie standard.",hpMult:1,dmgMult:1,spdMult:1,countMult:1,armorBonus:0,resourceMult:1,prepDuration:26,minFlanks:1,extraFlankWaves:0,waveShift:0,bossInterval:5,bossEscortCount:1,respawnMult:1,costMult:1},hard:{id:"hard",label:"Difficile",color:"#ffbe3b",desc:"1,35× PV · 1,25× dégâts · +12 % vitesse · Brise-murs et sapeurs plus tôt.",hpMult:1.35,dmgMult:1.25,spdMult:1.12,countMult:1.2,armorBonus:0,resourceMult:.95,prepDuration:22,minFlanks:2,extraFlankWaves:1,waveShift:1,bossInterval:5,bossEscortCount:2,respawnMult:1.15,costMult:1.08},extreme:{id:"extreme",label:"Extrême",color:"#ff7e33",desc:"1,8× PV · 1,5× dégâts · +20 % vitesse · Armure +1 · Boss toutes les 4 vagues.",hpMult:1.8,dmgMult:1.5,spdMult:1.2,countMult:1.38,armorBonus:1,resourceMult:.9,prepDuration:18,minFlanks:2,extraFlankWaves:2,waveShift:2,bossInterval:4,bossEscortCount:4,respawnMult:1.35,costMult:1.15},impossible:{id:"impossible",label:"Impossible",color:"#ff4f6d",desc:"4 flancs dès la vague 1 · 2,6× PV · 2,0× dégâts · +30 % vitesse · Armure +2 · Escortes lourdes.",hpMult:2.6,dmgMult:2,spdMult:1.3,countMult:1.6,armorBonus:2,resourceMult:.85,prepDuration:15,minFlanks:4,extraFlankWaves:4,waveShift:3,bossInterval:3,bossEscortCount:6,respawnMult:1.6,costMult:1.22}},xr=["wall","gate","obsidian_wall","sky_wall","spike_trap","rune_mine","archer_tower","ballista","flak_tower","arcane_tower","frost_tower","alch_mortar","solar_tower","tesla_spire","catapult","chrono_obelisk","quarry","crystal_rig","ether_forge","sanctuary","shield_gen","war_banner"],We={wall:{id:"wall",name:"Mur de Pierre",short:"Mur",category:"defense",desc:"Rempart solide (1×1). Canalise les ennemis vers les zones piégées.",w:1,h:1,stoneCost:10,crystalCost:0,hp:220,armor:2,walkable:!1,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:1,hotkey:"1",color:"#95a5b8"},gate:{id:"gate",name:"Porte Fortifiée",short:"Porte",category:"defense",desc:"Passage sécurisé (1×1). Le Héros traverse librement, les ennemis sont bloqués.",w:1,h:1,stoneCost:15,crystalCost:0,hp:185,armor:2,walkable:!0,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:1,hotkey:"2",color:"#c9935b"},archer_tower:{id:"archer_tower",name:"Tour d’Archers",short:"Archers",category:"turret",desc:"Tourelle rapide (1×1, portée 96). Efficace contre ennemis rapides et volants.",w:1,h:1,stoneCost:22,crystalCost:0,hp:140,armor:1,walkable:!1,blocksEnemies:!0,range:96,dmg:14,fireRate:.55,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:1,hotkey:"3",color:"#5ef28c"},ballista:{id:"ballista",name:"Tour Baliste",short:"Baliste",category:"turret",desc:"Tir perforant lourd (1×1, portée 116). Perce 3 ennemis alignés.",w:1,h:1,stoneCost:30,crystalCost:0,hp:160,armor:1,walkable:!1,blocksEnemies:!0,range:116,dmg:32,fireRate:1.35,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:1,hotkey:"4",color:"#ffbe3b"},spike_trap:{id:"spike_trap",name:"Piège à Pics",short:"Pics",category:"trap",desc:"Piège au sol (1×1). Blesse et ralentit les troupes au sol dans les goulets.",w:1,h:1,stoneCost:12,crystalCost:0,hp:110,armor:0,walkable:!0,blocksEnemies:!1,range:12,dmg:14,fireRate:.75,splash:0,slow:1.2,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:1,hotkey:"5",color:"#d97f54"},quarry:{id:"quarry",name:"Carrière de Pierre",short:"Carrière",category:"economy",desc:"Produit +3 Pierre / 4,5 s. Bonus ×2 si posée sur ou à côté d’un filon de Pierre ! Coût croissant.",w:1,h:1,stoneCost:30,crystalCost:0,hp:130,armor:1,walkable:!1,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:3,prodCrystal:0,prodInterval:4.5,reqCitadel:1,hotkey:"6",color:"#aeb9c7"},crystal_rig:{id:"crystal_rig",name:"Extracteur d’Éther",short:"Extract.",category:"economy",desc:"Produit +2 Cristaux / 5,5 s (Cit. Niv.2). Bonus ×2 sur ou à côté d’un gisement d’Éther ! Coût croissant.",w:1,h:1,stoneCost:35,crystalCost:10,hp:130,armor:1,walkable:!1,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:2,prodInterval:5.5,reqCitadel:2,hotkey:"7",color:"#4ef2e8"},arcane_tower:{id:"arcane_tower",name:"Tour Arcanique",short:"Arcanes",category:"turret",desc:"Éclairs en chaîne sur 4 cibles (1×1, portée 104, Citadelle Niv.2).",w:1,h:1,stoneCost:30,crystalCost:18,hp:150,armor:1,walkable:!1,blocksEnemies:!0,range:104,dmg:22,fireRate:1,splash:0,slow:0,chains:4,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"8",color:"#b87aff"},frost_tower:{id:"frost_tower",name:"Obélisque de Givre",short:"Givre",category:"turret",desc:"Pulse une aura glaciale (−45 % vitesse) sur 72 px (Citadelle Niv.2).",w:1,h:1,stoneCost:25,crystalCost:18,hp:165,armor:2,walkable:!1,blocksEnemies:!0,range:72,dmg:10,fireRate:1.25,splash:72,slow:2.2,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"9",color:"#7ce8ff"},rune_mine:{id:"rune_mine",name:"Mine Runique",short:"Mine",category:"trap",desc:"Explosion arcanique de zone puis réarmement 12 s (Citadelle Niv.2).",w:1,h:1,stoneCost:15,crystalCost:8,hp:100,armor:0,walkable:!0,blocksEnemies:!1,range:28,dmg:75,fireRate:12,splash:34,slow:1.5,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"0",color:"#ff4f6d"},catapult:{id:"catapult",name:"Trébuchet Lourd",short:"Trébuchet",category:"turret",desc:"Artillerie 2×2 (portée 170, Citadelle Niv.2). Rochers AoE anti-blindés.",w:2,h:2,stoneCost:55,crystalCost:18,hp:260,armor:2,walkable:!1,blocksEnemies:!0,range:170,dmg:58,fireRate:2.4,splash:32,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"-",color:"#ff7e33"},sanctuary:{id:"sanctuary",name:"Sanctuaire Runique",short:"Sanct.",category:"support",desc:"Soutien 2×2 (Citadelle Niv.3). Répare (+8 PV/s) et accélère (+20 %) dans 84 px.",w:2,h:2,stoneCost:50,crystalCost:32,hp:280,armor:3,walkable:!1,blocksEnemies:!0,range:84,dmg:0,fireRate:1,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:3,hotkey:"=",color:"#ffe066"},obsidian_wall:{id:"obsidian_wall",name:"Rempart d’Obsidienne",short:"Obsid.",category:"defense",desc:"Rempart runique (1×1, Cit. Niv.3). PV/armure massifs et renvoie 30 %+ des dégâts de mêlée.",w:1,h:1,stoneCost:38,crystalCost:12,hp:620,armor:6,walkable:!1,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:3,hotkey:"",color:"#7c5cbf"},sky_wall:{id:"sky_wall",name:"Mur Anti-Aérien",short:"Anti-Air",category:"defense",desc:"Barrière Ciel-Éther (1×1, Cit. Niv.2). Bloque les volants (Harpies, Wyvernes, Dragon) ! Posable seul OU directement par-dessus un mur existant pour l’améliorer (+140 PV, +2 Arm.).",w:1,h:1,stoneCost:22,crystalCost:12,hp:340,armor:4,walkable:!0,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"",color:"#38bdf8"},flak_tower:{id:"flak_tower",name:"Tour Flak Runique",short:"Flak AA",category:"turret",desc:"Anti-aérien (1×1, Cit. Niv.2). Obus explosifs ×2,4 dégâts contre les volants !",w:1,h:1,stoneCost:32,crystalCost:14,hp:155,armor:2,walkable:!1,blocksEnemies:!0,range:132,dmg:20,fireRate:.72,splash:26,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"",color:"#7ce8ff"},alch_mortar:{id:"alch_mortar",name:"Mortier Alchimique",short:"Alchimie",category:"turret",desc:"Flaques acides (1×1, Cit. Niv.2). Inflige dégâts sur la durée et réduit fortement l’armure ennemie.",w:1,h:1,stoneCost:38,crystalCost:20,hp:150,armor:1,walkable:!1,blocksEnemies:!0,range:136,dmg:22,fireRate:2.1,splash:28,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,hotkey:"",color:"#a3e635"},solar_tower:{id:"solar_tower",name:"Tour Solaire",short:"Solaire",category:"turret",desc:"Rayon d’Éther continu (1×1, Cit. Niv.3). Dégâts croissants jusqu’à ×4,5+, perce 60 % d’armure !",w:1,h:1,stoneCost:45,crystalCost:30,hp:170,armor:2,walkable:!1,blocksEnemies:!0,range:118,dmg:12,fireRate:.15,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:3,hotkey:"",color:"#ffe066"},shield_gen:{id:"shield_gen",name:"Générateur de Bouclier",short:"Bouclier",category:"support",desc:"Soutien 2×2 (Cit. Niv.3). Projette un bouclier absorbant (−20 % dégâts) sur les structures proches.",w:2,h:2,stoneCost:55,crystalCost:38,hp:260,armor:3,walkable:!1,blocksEnemies:!0,range:92,dmg:0,fireRate:1,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:3,hotkey:"",color:"#38bdf8"},tesla_spire:{id:"tesla_spire",name:"Flèche Tesla",short:"Tesla",category:"turret",desc:"Tourelle électrique (Arbre Bastion). Envoie un éclair sur 4 cibles (sol/air) avec micro-étourdissement !",w:1,h:1,stoneCost:55,crystalCost:30,hp:165,armor:3,walkable:!1,blocksEnemies:!0,range:112,dmg:24,fireRate:1.05,splash:0,slow:0,chains:4,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,reqMetaNode:"def_turret_rate",hotkey:"",color:"#38bdf8"},ether_forge:{id:"ether_forge",name:"Forge d’Éther",short:"Forge",category:"economy",desc:"Complexe 2×2 (Arbre Économie). Produit +6 Pierre ET +4 Cristaux / 5 s sans filon requis. Coût croissant.",w:2,h:2,stoneCost:85,crystalCost:40,hp:240,armor:3,walkable:!1,blocksEnemies:!0,range:0,dmg:0,fireRate:0,splash:0,slow:0,chains:0,prodStone:6,prodCrystal:4,prodInterval:5,reqCitadel:3,reqMetaNode:"eco_prod",hotkey:"",color:"#ffbe3b"},war_banner:{id:"war_banner",name:"Bannière de Guerre",short:"Bannière",category:"support",desc:"Soutien 1×1 (Arbre Héros). Accélère en continu les tourelles proches (+cadence) et soigne le Héros.",w:1,h:1,stoneCost:50,crystalCost:25,hp:170,armor:2,walkable:!1,blocksEnemies:!0,range:96,dmg:0,fireRate:2.4,splash:0,slow:0,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:2,reqMetaNode:"hero_aura",hotkey:"",color:"#ff7e33"},chrono_obelisk:{id:"chrono_obelisk",name:"Obélisque Chrono",short:"Chrono",category:"turret",desc:"Monolithe 2×2 (Arbre Éther). Onde de stase en zone : fort ralentissement, brise-armure et dégâts sol/air.",w:2,h:2,stoneCost:95,crystalCost:55,hp:260,armor:4,walkable:!1,blocksEnemies:!0,range:105,dmg:32,fireRate:2.2,splash:105,slow:2.8,chains:0,prodStone:0,prodCrystal:0,prodInterval:0,reqCitadel:3,reqMetaNode:"eth_citadel_shield",hotkey:"",color:"#b87aff"}},ha=[{id:"citadel_lvl",category:"base",name:"Élever la Citadelle",desc:"Palier suivant (+250 PV max & soin complet). Débloque de nouveaux bâtiments et technologies.",maxLvl:4,stoneBase:90,crystalBase:30,costScale:1.75,reqCitadel:1,icon:"citadel"},{id:"citadel_armor",category:"base",name:"Bastion de Granit",desc:"+3 armure permanente et +120 PV max pour la Citadelle.",maxLvl:4,stoneBase:40,crystalBase:10,costScale:1.6,reqCitadel:1,icon:"shield"},{id:"citadel_guard",category:"base",name:"Garde Arcanique",desc:"La Citadelle tire des salves d’Éther défensives plus rapides et puissantes.",maxLvl:3,stoneBase:35,crystalBase:20,costScale:1.65,reqCitadel:2,icon:"arcane"},{id:"citadel_heal",category:"base",name:"Restauration d’Urgence",desc:"Répare immédiatement +250 PV sur la Citadelle.",maxLvl:99,stoneBase:35,crystalBase:12,costScale:1.15,reqCitadel:1,repeatable:!0,icon:"heal"},{id:"wall_hp",category:"build",name:"Maçonnerie Renforcée",desc:"+25 % PV max pour tous les Murs, Remparts d’Obsidienne et Portes Fortifiées.",maxLvl:4,stoneBase:32,crystalBase:0,costScale:1.55,reqCitadel:1,icon:"wall"},{id:"turret_dmg",category:"build",name:"Pointes & Runes Létales",desc:"+18 % dégâts pour toutes les tourelles et pièges.",maxLvl:5,stoneBase:36,crystalBase:14,costScale:1.6,reqCitadel:1,icon:"ballista"},{id:"turret_rate",category:"build",name:"Mécanismes Huilés",desc:"Cadence de tir +12 % pour toutes les tourelles.",maxLvl:4,stoneBase:40,crystalBase:18,costScale:1.65,reqCitadel:2,icon:"gear"},{id:"build_cost",category:"build",name:"Logistique d’Architecte",desc:"Réduit de 10 % le coût en ressources de toutes les constructions.",maxLvl:3,stoneBase:45,crystalBase:20,costScale:1.7,reqCitadel:2,icon:"hammer"},{id:"hero_harvest",category:"prod",name:"Pioche Runique",desc:"Vitesse et rendement de récolte sur les filons +35 % par rang.",maxLvl:4,stoneBase:24,crystalBase:0,costScale:1.5,reqCitadel:1,icon:"pick"},{id:"prod_yield",category:"prod",name:"Extraction Intensive",desc:"Carrières et Extracteurs d’Éther produisent +25 % par rang.",maxLvl:4,stoneBase:38,crystalBase:16,costScale:1.6,reqCitadel:1,icon:"quarry"},{id:"loot_bonus",category:"prod",name:"Pillage Organisé",desc:"Les ennemis vaincus lâchent +25 % de Pierre et de Cristaux.",maxLvl:3,stoneBase:35,crystalBase:15,costScale:1.6,reqCitadel:2,icon:"crystal"},{id:"hero_dmg",category:"combat",name:"Lame d’Éther Affûtée",desc:"+22 % dégâts pour les attaques et compétences du Héros.",maxLvl:5,stoneBase:28,crystalBase:12,costScale:1.55,reqCitadel:1,icon:"sword"},{id:"hero_rate",category:"combat",name:"Frappe Célérité",desc:"Vitesse d’attaque automatique du Héros +15 % par rang.",maxLvl:4,stoneBase:30,crystalBase:14,costScale:1.6,reqCitadel:1,icon:"bolt"},{id:"hero_pierce",category:"combat",name:"Onde Transperçante",desc:"+1 ennemi perforé et +1 projectile en éventail au rang 2.",maxLvl:3,stoneBase:40,crystalBase:22,costScale:1.7,reqCitadel:2,icon:"arcane"},{id:"skill_cdr",category:"combat",name:"Médaillon Tactique",desc:"Recharge de Ruée, Cri de Bastion et Jugement −14 % par rang.",maxLvl:3,stoneBase:36,crystalBase:24,costScale:1.65,reqCitadel:2,icon:"ult"},{id:"hero_hp",category:"surv",name:"Cuirasse du Gardien",desc:"+40 PV max et régénération passive pour le Héros.",maxLvl:4,stoneBase:25,crystalBase:8,costScale:1.5,reqCitadel:1,icon:"heart"},{id:"hero_spd",category:"surv",name:"Bottes de Vent",desc:"+10 % vitesse de déplacement du Héros par rang.",maxLvl:3,stoneBase:24,crystalBase:8,costScale:1.55,reqCitadel:1,icon:"boot"},{id:"hero_respawn",category:"surv",name:"Ancre d’Âme",desc:"Réduit le temps de réapparition à la Citadelle de 1,5 s par rang.",maxLvl:3,stoneBase:32,crystalBase:18,costScale:1.6,reqCitadel:1,icon:"respawn"},{id:"hero_repair",category:"surv",name:"Maître Maçon",desc:"Réparation directe [F] +40 % plus rapide et moins chère en Pierre.",maxLvl:3,stoneBase:28,crystalBase:10,costScale:1.5,reqCitadel:1,icon:"hammer"}],Zn={goblin:{id:"goblin",name:"Pillard Gobelin",role:"classic",desc:"Éclaireur agile cherchant les brèches dans les remparts.",r:5,hp:26,spd:40,dmg:8,wallDmgMult:.9,range:10,fireRate:.9,armor:0,stoneDrop:3,crystalDrop:0,art:"goblin",col:"#5ef28c",flying:!1,minWave:1},orc:{id:"orc",name:"Fantassin Orc",role:"classic",desc:"Guerrier robuste avançant en formation vers la Citadelle.",r:6,hp:58,spd:30,dmg:14,wallDmgMult:1.1,range:11,fireRate:1.1,armor:1,stoneDrop:5,crystalDrop:1,art:"orc",col:"#a3d977",flying:!1,minWave:1},shadow_wolf:{id:"shadow_wolf",name:"Loup d’Ombre",role:"flanker",desc:"Rapide et furtif, contourne les murs pour frapper les points faibles.",r:5,hp:34,spd:62,dmg:12,wallDmgMult:.8,range:10,fireRate:.7,armor:0,stoneDrop:4,crystalDrop:1,art:"shadow_wolf",col:"#b87aff",flying:!1,minWave:2},ram_brute:{id:"ram_brute",name:"Bélier Blindé",role:"breaker",desc:"Brise-murs lourd infligeant ×2,6 dégâts aux remparts pour ouvrir des brèches.",r:8,hp:155,spd:23,dmg:22,wallDmgMult:2.6,range:13,fireRate:1.4,armor:3,stoneDrop:9,crystalDrop:2,art:"ram_brute",col:"#d97f54",flying:!1,minWave:3},archer_skel:{id:"archer_skel",name:"Archer Squelette",role:"ranged",desc:"Tire des flèches par-dessus les murailles sur le Héros et les tourelles.",r:5,hp:38,spd:33,dmg:10,wallDmgMult:1,range:84,fireRate:1.75,armor:0,stoneDrop:4,crystalDrop:2,art:"archer_skel",col:"#e2e8f0",flying:!1,minWave:3},sapper:{id:"sapper",name:"Sapeur d’Ombre",role:"sapper",desc:"Cible prioritairement vos tourelles et extracteurs puis explose au contact !",r:6,hp:46,spd:54,dmg:70,wallDmgMult:1.4,range:11,fireRate:.5,armor:0,stoneDrop:5,crystalDrop:3,art:"sapper",col:"#ff4f6d",flying:!1,minWave:4},harpy:{id:"harpy",name:"Harpie Sombre",role:"flyer",desc:"Créature volante ignorant les remparts pour attaquer extracteurs et Citadelle.",r:6,hp:54,spd:50,dmg:14,wallDmgMult:1,range:12,fireRate:1,armor:0,stoneDrop:4,crystalDrop:3,art:"harpy",col:"#7ce8ff",flying:!0,minWave:5},pyro_mage:{id:"pyro_mage",name:"Pyromancien",role:"ranged",desc:"Projette des boules de feu explosives sur les défenses groupées.",r:6,hp:78,spd:29,dmg:18,wallDmgMult:1.3,range:96,fireRate:2.3,armor:1,stoneDrop:6,crystalDrop:4,art:"pyro_mage",col:"#ff7e33",flying:!1,minWave:6},siege_golem:{id:"siege_golem",name:"Golem de Siège",role:"breaker",desc:"Colosse blindé de pierre détruisant les murailles à grands coups.",r:9,hp:290,spd:20,dmg:32,wallDmgMult:3,range:14,fireRate:1.6,armor:5,stoneDrop:14,crystalDrop:5,art:"siege_golem",col:"#94a3b8",flying:!1,minWave:7},bastion_assassin:{id:"bastion_assassin",name:"Assassin Anti-Artillerie",role:"assassin",desc:"Traque prioritairement les Trébuchets, Sanctuaires, Tours Solaires et Extracteurs coûteux.",r:6,hp:92,spd:64,dmg:28,wallDmgMult:1.5,range:12,fireRate:.65,armor:2,stoneDrop:8,crystalDrop:4,art:"bastion_assassin",col:"#ff4f6d",flying:!1,minWave:6},wyvern_swarm:{id:"wyvern_swarm",name:"Wyverne d’Éther",role:"flyer",desc:"Vole en essaim rapide par-dessus les remparts pour détruire l’économie et la Citadelle.",r:6,hp:72,spd:62,dmg:18,wallDmgMult:1.1,range:12,fireRate:.85,armor:1,stoneDrop:5,crystalDrop:4,art:"wyvern_swarm",col:"#ffbe3b",flying:!0,minWave:6},necromancer:{id:"necromancer",name:"Nécromancien d’Ombre",role:"summoner",desc:"Reste à distance et invoque continuellement des squelettes et sapeurs tant qu’il survit.",r:6,hp:115,spd:26,dmg:14,wallDmgMult:1,range:112,fireRate:2.2,armor:1,stoneDrop:9,crystalDrop:5,art:"necromancer",col:"#b87aff",flying:!1,minWave:7},rune_colossus:{id:"rune_colossus",name:"Colosse Runique",role:"juggernaut",desc:"Armure massive et résistant aux explosions AoE (−65 %). Exige Rayon Solaire, Acide ou Balistes.",r:10,hp:460,spd:19,dmg:42,wallDmgMult:2.8,range:15,fireRate:1.5,armor:10,splashResist:.65,stoneDrop:18,crystalDrop:8,art:"rune_colossus",col:"#4ef2e8",flying:!1,minWave:8},boss_troll:{id:"boss_troll",name:"Ravageur de Fer",role:"boss",desc:"Seigneur de guerre brise-remparts maniant un marteau sismique.",r:14,hp:1450,spd:24,dmg:45,wallDmgMult:3.2,range:18,fireRate:1.5,armor:4,stoneDrop:45,crystalDrop:25,art:"boss_troll",col:"#ffbe3b",flying:!1,minWave:5},boss_behemoth:{id:"boss_behemoth",name:"Béhémoth de Siège",role:"boss",desc:"Titan cuirassé invocant des sapeurs et bombardant les remparts.",r:16,hp:3400,spd:22,dmg:60,wallDmgMult:3.5,range:20,fireRate:1.6,armor:6,stoneDrop:75,crystalDrop:45,art:"boss_behemoth",col:"#ff7e33",flying:!1,minWave:10},boss_dragon:{id:"boss_dragon",name:"Dragon d’Obsidienne",role:"boss",desc:"Wyrm ailé survolant les murs en crachant des pluies de feu arcanique.",r:16,hp:6200,spd:34,dmg:70,wallDmgMult:2.5,range:95,fireRate:1.8,armor:5,stoneDrop:110,crystalDrop:70,art:"boss_dragon",col:"#ff4f6d",flying:!0,minWave:15}},Zr=[{id:"wave_1",name:"Premier Rempart",desc:"Repousse la première vague d’assaut."},{id:"wave_5",name:"Garde d’Acier",desc:"Survis et triomphe de la vague 5."},{id:"wave_10",name:"Seigneur du Bastion",desc:"Atteins et survis à la vague 10."},{id:"wave_15",name:"Légende d’Éther",desc:"Atteins la vague 15 face au Dragon."},{id:"citadel_3",name:"Donjon Majeur",desc:"Élève la Citadelle au niveau 3."},{id:"citadel_5",name:"Forteresse Suprême",desc:"Élève la Citadelle au niveau 5."},{id:"architect_25",name:"Architecte Royal",desc:"Construis 25 structures en une seule bataille."},{id:"upgrades_10",name:"Maître Forgeron",desc:"Achète 10 améliorations en une partie."},{id:"boss_kill",name:"Tueur de Titans",desc:"Terrasse un Boss de siège."},{id:"kills_250",name:"Lame Infatigable",desc:"Élimine 250 ennemis en une bataille."},{id:"respawn_win",name:"Revenu des Cendres",desc:"Réapparais à la Citadelle et finis la vague."},{id:"bonus_rig",name:"Veine d’Or",desc:"Place une Carrière ou Extracteur avec bonus ×2 sur filon."}],Kd="bastion_ether_save_v1",Ca="bastion_ether_run_v1",Zd=[];function Rh(i){Zd.push(i)}function Rn(i){for(const e of Zd)e(i)}function Lh(){return{easy:0,normal:0,hard:0,extreme:0,impossible:0}}function Jd(){return{version:1,selectedDifficulty:"normal",selectedClass:"guardian",unlockedClasses:["guardian","engineer","archmage"],bestWave:0,bestWaveByDiff:Lh(),bestKills:0,totalGames:0,totalKills:0,totalBuilt:0,essence:0,totalEssenceEarned:0,metaUpgrades:{},adventure:{highestUnlocked:1,completedLevels:[],levelStars:{},vaultStone:60,vaultCrystal:0},tutorialDone:!1,seenEnemies:[],killedEnemies:{},achs:[],settings:{sfx:.7,music:.55,crt:!0,shake:!0,theme:"textured"}}}let J=Ph();function Ph(){var e,t,n,s,r,a,o,l;const i=Jd();try{const c=localStorage.getItem(Kd);if(!c)return i;const d=JSON.parse(c),p=d.selectedDifficulty&&Es.includes(d.selectedDifficulty)?d.selectedDifficulty:i.selectedDifficulty,u=d.selectedClass&&sr.includes(d.selectedClass)?d.selectedClass:i.selectedClass,h={...i.bestWaveByDiff,...d.bestWaveByDiff||{}};return!d.bestWaveByDiff&&typeof d.bestWave=="number"&&d.bestWave>0&&(h.normal=Math.max(h.normal,d.bestWave)),{...i,...d,selectedDifficulty:p,selectedClass:u,unlockedClasses:Array.isArray(d.unlockedClasses)?Array.from(new Set(["guardian","engineer","archmage",...d.unlockedClasses.filter(v=>sr.includes(v))])):i.unlockedClasses,bestWaveByDiff:h,essence:typeof d.essence=="number"&&d.essence>=0?d.essence:0,totalEssenceEarned:typeof d.totalEssenceEarned=="number"&&d.totalEssenceEarned>=0?d.totalEssenceEarned:0,metaUpgrades:d.metaUpgrades&&typeof d.metaUpgrades=="object"?{...d.metaUpgrades}:{},adventure:{highestUnlocked:typeof((e=d.adventure)==null?void 0:e.highestUnlocked)=="number"&&d.adventure.highestUnlocked>=1?Math.min(100,Math.floor(d.adventure.highestUnlocked)):i.adventure.highestUnlocked,completedLevels:Array.isArray((t=d.adventure)==null?void 0:t.completedLevels)?d.adventure.completedLevels.filter(v=>typeof v=="number"&&v>=1&&v<=100):i.adventure.completedLevels,levelStars:(n=d.adventure)!=null&&n.levelStars&&typeof d.adventure.levelStars=="object"?{...d.adventure.levelStars}:{},vaultStone:typeof((s=d.adventure)==null?void 0:s.vaultStone)=="number"&&d.adventure.vaultStone>=0?Math.floor(d.adventure.vaultStone):i.adventure.vaultStone,vaultCrystal:typeof((r=d.adventure)==null?void 0:r.vaultCrystal)=="number"&&d.adventure.vaultCrystal>=0?Math.floor(d.adventure.vaultCrystal):i.adventure.vaultCrystal},tutorialDone:!!d.tutorialDone,achs:Array.isArray(d.achs)?d.achs:i.achs,seenEnemies:Array.isArray(d.seenEnemies)?d.seenEnemies:i.seenEnemies,killedEnemies:{...i.killedEnemies,...d.killedEnemies||{}},settings:{...i.settings,...d.settings||{},theme:((a=d.settings)==null?void 0:a.theme)==="pixel"||((o=d.settings)==null?void 0:o.theme)==="textured"||((l=d.settings)==null?void 0:l.theme)==="3d"?d.settings.theme:i.settings.theme}}}catch{return i}}function Vt(){try{localStorage.setItem(Kd,JSON.stringify(J))}catch{}}function Dh(){J=Jd(),Vt(),ns()}function fr(i){if(!(!i.active||i.modal==="over"||i.citadel.hp<=0))try{const e={...i,paused:!1,modal:"none",dragStart:null,dragEnd:null,particles:[],texts:[],arcs:[],pendingBanner:void 0,pendingHint:void 0},t={version:1,savedAt:Date.now(),state:e};localStorage.setItem(Ca,JSON.stringify(t))}catch{}}function ns(){try{localStorage.removeItem(Ca)}catch{}}function Ih(){var i;try{const e=localStorage.getItem(Ca);if(!e)return null;const t=JSON.parse(e);if(!t||t.version!==1||!t.state)return null;const n=t.state;return!n.active||!n.citadel||n.citadel.hp<=0?null:{mode:n.mode==="adventure"?"adventure":"survival",adventureLevel:(i=n.adventure)==null?void 0:i.level,wave:n.wave||1,difficulty:Es.includes(n.difficulty)?n.difficulty:"normal",heroClass:sr.includes(n.heroClass)?n.heroClass:"guardian",savedAt:typeof t.savedAt=="number"?t.savedAt:Date.now()}}catch{return null}}function Uh(i){try{const e=localStorage.getItem(Ca);if(!e)return null;const t=JSON.parse(e);if(!t||t.version!==1||!t.state)return null;const n=t.state;if(!n.active||!n.citadel||n.citadel.hp<=0)return null;if(n.mode!=="adventure"&&n.mode!=="survival"&&(n.mode="survival"),n.paused=!1,n.modal="none",n.dragStart=null,n.dragEnd=null,n.particles=[],n.texts=[],n.arcs=[],n.pathDirty=!1,n.stats&&typeof n.stats.essenceEarned!="number"&&(n.stats.essenceEarned=0),Array.isArray(n.buildings))for(const s of n.buildings)typeof s.kills!="number"&&(s.kills=0),typeof s.totalDmg!="number"&&(s.totalDmg=0);return i.recompute(n),n}catch{return null}}function ti(i){const e=Mt[i];return e?!!(!e.unlockAdvLevel&&!e.unlockEssenceCost||J.unlockedClasses.includes(i)||e.unlockAdvLevel&&J.adventure.completedLevels.includes(e.unlockAdvLevel)):!1}function Co(i,e=!1){const t=Mt[i];if(!t||ti(i))return!1;if(e){const n=t.unlockEssenceCost||0;if(n<=0||J.essence<n)return!1;J.essence-=n}return J.unlockedClasses.includes(i)||J.unlockedClasses.push(i),Rn({title:`Nouveau Héros débloqué : ${t.name} !`,sub:"Sélectionne-le depuis le Menu Principal pour l’essayer.",col:t.color}),Vt(),!0}function Yn(i){if(J.achs.includes(i))return!1;const e=Zr.find(t=>t.id===i);return e?(J.achs.push(i),Rn({title:`Succès : ${e.name}`,sub:e.desc,col:"#ffbe3b"}),Vt(),!0):!1}function Qd(i){J.seenEnemies.includes(i)||J.seenEnemies.push(i)}function Nh(i){Qd(i),J.killedEnemies[i]=(J.killedEnemies[i]||0)+1}function El(i){if(J.totalGames+=1,J.totalKills+=i.stats.kills,J.totalBuilt+=i.stats.builtCount,i.mode!=="adventure"){const e=i.wave;e>J.bestWave&&(J.bestWave=e);const t=J.bestWaveByDiff[i.difficulty]||0;e>t&&(J.bestWaveByDiff[i.difficulty]=e)}i.stats.kills>J.bestKills&&(J.bestKills=i.stats.kills),Vt()}const he={ctx:null,master:null,sfxBus:null,musBus:null,lp:null,noiseBuf:null,last:{},mode:"menu",ducked:!0,step:0,bar:0,nextNote:0,timer:null};function _r(i){return 440*Math.pow(2,(i-69)/12)}const Bh=[50,52,53,55,57,59,60,62],Fh=[50,52,53,55,57,58,60,62],Oh=[50,51,55,57,58,61,62,65],Hh=[0,2,4,2,5,4,3,-1,4,2,1,-1,0,-1,2,-1],Gh=[0,-1,2,4,3,2,4,-1,5,4,3,2,1,-1,0,-1],zh=[0,1,3,4,5,4,3,1,6,5,4,3,1,0,-1,0];function Qe(){if(he.ctx){he.ctx.state==="suspended"&&he.ctx.resume().catch(()=>{});return}try{const i=window.AudioContext||window.webkitAudioContext;if(!i)return;const e=new i;he.ctx=e;const t=e.createDynamicsCompressor();t.threshold.value=-14,t.ratio.value=5,t.attack.value=.005,t.release.value=.18,he.master=e.createGain(),he.master.gain.value=.85,he.lp=e.createBiquadFilter(),he.lp.type="lowpass",he.lp.frequency.value=he.ducked?1200:14e3,he.lp.Q.value=.4,he.sfxBus=e.createGain(),he.musBus=e.createGain(),he.sfxBus.connect(he.lp),he.musBus.connect(he.lp),he.lp.connect(t),t.connect(he.master),he.master.connect(e.destination);const n=e.createBuffer(1,Math.floor(e.sampleRate*1),e.sampleRate),s=n.getChannelData(0);for(let r=0;r<s.length;r++)s[r]=Math.random()*2-1;he.noiseBuf=n,Ao(),he.nextNote=e.currentTime+.08,he.timer=window.setInterval(Vh,35),e.state==="suspended"&&e.resume().catch(()=>{})}catch{he.ctx=null}}function Ao(){!he.ctx||!he.sfxBus||!he.musBus||(he.sfxBus.gain.value=J.settings.sfx*.9,he.musBus.gain.value=J.settings.music*.58)}function mc(i){i.mode!==void 0&&(he.mode=i.mode),i.ducked!==void 0&&(he.ducked=i.ducked,he.ctx&&he.lp&&he.lp.frequency.setTargetAtTime(he.ducked?1100:14e3,he.ctx.currentTime,.08))}function gt(i,e,t,n,s,r,a=he.ctx.currentTime,o=.005){const l=he.ctx,c=l.createOscillator(),d=l.createGain();c.type=s,c.frequency.setValueAtTime(Math.max(30,e),a),t!==e&&c.frequency.exponentialRampToValueAtTime(Math.max(30,t),a+n),d.gain.setValueAtTime(1e-4,a),d.gain.linearRampToValueAtTime(r,a+o),d.gain.exponentialRampToValueAtTime(1e-4,a+n),c.connect(d),d.connect(i),c.start(a),c.stop(a+n+.02)}function bi(i,e,t,n,s,r=he.ctx.currentTime){const a=he.ctx;if(!he.noiseBuf)return;const o=a.createBufferSource();o.buffer=he.noiseBuf;const l=a.createBiquadFilter();l.type="highpass",l.frequency.value=t;const c=a.createBiquadFilter();c.type="lowpass",c.frequency.value=n;const d=a.createGain();d.gain.setValueAtTime(s,r),d.gain.exponentialRampToValueAtTime(1e-4,r+e),o.connect(l),l.connect(c),c.connect(d),d.connect(i),o.start(r),o.stop(r+e+.02)}function Vh(){if(!he.ctx||!he.musBus||he.ctx.state!=="running"||J.settings.music<=.01)return;const i=he.ctx,t=60/(he.mode==="boss"?148:he.mode==="wave"?132:98)/4;for(he.nextNote<i.currentTime-.3&&(he.nextNote=i.currentTime+.04);he.nextNote<i.currentTime+.14;){const n=he.nextNote,s=he.step%16,r=he.mode==="boss"?Oh:he.mode==="wave"?Fh:Bh,a=he.mode==="boss"?zh:he.mode==="wave"?Gh:Hh;if(he.mode==="wave"||he.mode==="boss"?((s%4===0||he.mode==="boss"&&s===14)&&gt(he.musBus,115,38,.12,"triangle",.28,n),(s===4||s===12)&&bi(he.musBus,.09,750,4800,.12,n),s%2===1&&bi(he.musBus,.03,5200,1e4,.045,n)):s%8===0&&gt(he.musBus,90,42,.12,"triangle",.14,n),s%2===0){const l=he.bar%4===3?3:he.bar%2===1?4:0,c=r[l%r.length]-12;gt(he.musBus,_r(c),_r(c),t*1.6,he.mode==="boss"?"sawtooth":"triangle",he.mode==="prep"||he.mode==="menu"?.09:.14,n)}const o=a[s];if(o>=0&&(he.mode!=="menu"||s%2===0)){const l=r[o%r.length]+12;gt(he.musBus,_r(l),_r(l),t*(he.mode==="prep"||he.mode==="menu"?1.8:1.1),he.mode==="prep"||he.mode==="menu"?"triangle":"square",he.ducked?.04:.07,n)}he.step+=1,he.step%16===0&&(he.bar+=1),he.nextNote+=t}}function W(i){if(!he.ctx||!he.sfxBus||J.settings.sfx<=.01)return;he.ctx.state==="suspended"&&he.ctx.resume().catch(()=>{});const e=performance.now(),t={bow:65,sword:75,arcane:85,frost:140,pickup:35,mine:140,repair:150,hurt:140,flak:85,laser:180,acid:140,shield:220};if(e-(he.last[i]||0)<(t[i]||20))return;he.last[i]=e;const n=he.sfxBus,s=he.ctx.currentTime;switch(i){case"build":gt(n,220,120,.09,"triangle",.2,s),bi(n,.06,400,2200,.14,s);break;case"upgrade":[440,587,880].forEach((r,a)=>gt(n,r,r,.11,"square",.11,s+a*.05));break;case"repair":gt(n,520,390,.07,"square",.09,s);break;case"mine":gt(n,340,180,.06,"triangle",.12,s),bi(n,.04,1200,4e3,.08,s);break;case"sell":gt(n,880,1174,.1,"triangle",.14,s);break;case"bow":gt(n,560,210,.06,"triangle",.09,s);break;case"catapult":bi(n,.22,80,900,.22,s),gt(n,130,38,.22,"triangle",.22,s);break;case"arcane":gt(n,1180,440,.09,"sawtooth",.1,s);break;case"frost":gt(n,920,620,.16,"sine",.12,s);break;case"sword":gt(n,680,280,.06,"square",.08,s);break;case"dash":bi(n,.11,750,4800,.13,s),gt(n,440,220,.1,"triangle",.11,s);break;case"rally":[392,493,587,784].forEach((r,a)=>gt(n,r,r,.14,"sawtooth",.1,s+a*.06));break;case"ult":bi(n,.25,200,2600,.2,s),[784,659,988,1174].forEach((r,a)=>gt(n,r,r*.85,.15,"square",.11,s+a*.05));break;case"wave_start":gt(n,293,392,.25,"sawtooth",.14,s),gt(n,392,587,.28,"sawtooth",.12,s+.15);break;case"boss_warn":for(let r=0;r<3;r++)gt(n,360,190,.22,"sawtooth",.18,s+r*.28);break;case"hurt":gt(n,175,65,.16,"sawtooth",.2,s);break;case"death":gt(n,260,58,.4,"sawtooth",.22,s);break;case"respawn":[440,554,659,880].forEach((r,a)=>gt(n,r,r,.14,"triangle",.15,s+a*.06));break;case"pickup":gt(n,720,1020,.05,"triangle",.08,s);break;case"click":gt(n,700,500,.035,"square",.07,s);break;case"error":gt(n,180,130,.1,"square",.12,s);break;case"flak":bi(n,.08,600,3200,.16,s),gt(n,380,120,.07,"square",.11,s);break;case"laser":gt(n,920,1380,.12,"sawtooth",.08,s);break;case"acid":bi(n,.14,900,2600,.11,s),gt(n,280,190,.14,"triangle",.11,s);break;case"shield":gt(n,520,780,.15,"sine",.09,s);break}}const zt=Math.PI*2;function Se(i,e,t){return i<e?e:i>t?t:i}function Wh(i,e,t,n){const s=t-i,r=n-e;return s*s+r*r}function Re(i,e,t,n){return Math.hypot(t-i,n-e)}function Ct(i,e){return i+Math.random()*(e-i)}function fa(i,e){return Math.floor(Ct(i,e+1))}function $h(i){const e=Math.max(0,Math.floor(i)),t=Math.floor(e/60),n=e%60;return`${String(t).padStart(2,"0")}:${String(n).padStart(2,"0")}`}function jd(i,e,t,n,s,r,a,o,l,c=2.5,d=0){i.particles.length>=650||i.particles.push({x:e,y:t,vx:n,vy:s,life:r,maxLife:r,size:a,size2:o,color:l,drag:c,grav:d})}function _t(i,e,t,n,s,r,a=.4,o=3){for(let l=0;l<n;l++){const c=Math.random()*zt,d=Ct(r*.3,r);jd(i,e,t,Math.cos(c)*d,Math.sin(c)*d,Ct(a*.6,a),o,1,s,3.2,0)}}function pn(i,e,t,n,s="#ffbe3b"){const r=Math.min(18,Math.max(6,Math.round(n*.4))),a=["#ffffff","#fff078",s,"#ff7e33","#6f7f94"];for(let o=0;o<r;o++){const l=Math.random()*zt,c=Ct(15,n*2.1),d=a[Math.floor(Math.random()*a.length)];jd(i,e+Ct(-4,4),t+Ct(-4,4),Math.cos(l)*c,Math.sin(l)*c,Ct(.22,.5),Ct(2,4),1,d,4.5,10)}i.zonesFx.push({uid:i.nextUid++,kind:"explosion",x:e,y:t,r:n,dmg:0,life:.22,maxLife:.22,color:s,fromPlayer:!0,hitDone:!0})}function Ke(i,e,t,n,s="#f2f5fa",r=!1){i.texts.length>90&&i.texts.shift(),i.texts.push({x:e+Ct(-4,4),y:t-6,vy:r?-28:-20,text:n,color:s,life:r?.9:.68,maxLife:r?.9:.68,crit:r})}function Jr(i,e,t,n,s,r="#b87aff",a=1.5){const l=[{x:e,y:t}],c=n-e,d=s-t,p=-d,u=c,h=Math.hypot(c,d)||1;for(let v=1;v<4;v++){const f=v/4,m=Ct(-6,6);l.push({x:e+c*f+p/h*m,y:t+d*f+u/h*m})}l.push({x:n,y:s}),i.arcs.push({pts:l,color:r,life:.16,maxLife:.16,width:a})}function nr(i,e){J.settings.shake&&(i.shake=Se(Math.max(i.shake,e),0,12))}function Ha(i,e){for(let t=i.particles.length-1;t>=0;t--){const n=i.particles[t];if(n.life-=e,n.life<=0){i.particles.splice(t,1);continue}const s=Math.exp(-n.drag*e);n.vx*=s,n.vy=n.vy*s+n.grav*e,n.x+=n.vx*e,n.y+=n.vy*e}for(let t=i.texts.length-1;t>=0;t--){const n=i.texts[t];if(n.life-=e,n.life<=0){i.texts.splice(t,1);continue}n.y+=n.vy*e,n.vy*=Math.exp(-2.6*e)}for(let t=i.arcs.length-1;t>=0;t--)i.arcs[t].life-=e,i.arcs[t].life<=0&&i.arcs.splice(t,1);i.shake=Math.max(0,i.shake-e*26),i.hurtFlash=Math.max(0,i.hurtFlash-e*2.5),i.screenFlash=Math.max(0,i.screenFlash-e*3)}const yr={defense:{id:"defense",name:"Bastion & Tourelles",short:"BASTION",color:"#5ef28c",desc:"Renforce la Citadelle, les remparts et la puissance de feu des tourelles."},economy:{id:"economy",name:"Économie & Ingénierie",short:"ÉCONOMIE",color:"#ffbe3b",desc:"Accélère le démarrage, réduit les coûts et enrichit la carte en filons."},hero:{id:"hero",name:"Héros & Pouvoirs",short:"HÉROS",color:"#ff7e33",desc:"Transforme ton Gardien en colosse et fait grandir ta puissance à chaque vague."},ether:{id:"ether",name:"Maîtrise de l’Éther",short:"ÉTHER",color:"#b87aff",desc:"Multiplie les Essences gagnées et débloque la survie pour les vagues avancées."}},eu={easy:.5,normal:1,hard:1.5,extreme:2.2,impossible:3.5},wl=[{id:"def_citadel_hp",tree:"defense",name:"Bastion Renforcé",desc:"+12 % PV max & +1 Armure pour la Citadelle par rang.",maxRank:5,baseCost:2,costStep:2,row:0,col:1,requires:[],effectLabel:i=>`+${i*12}% PV · +${i} Arm.`},{id:"def_turret_dmg",tree:"defense",name:"Artillerie Lourde",desc:"+10 % dégâts pour toutes les tourelles et pièges par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:0,requires:[{id:"def_citadel_hp",rank:1}],effectLabel:i=>`+${i*10}% Dégâts`},{id:"def_wall_hp",tree:"defense",name:"Remparts de Granit",desc:"+15 % PV max & +1 Armure pour tous les murs et portes par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:2,requires:[{id:"def_citadel_hp",rank:1}],effectLabel:i=>`+${i*15}% PV · +${i} Arm.`},{id:"def_turret_rate",tree:"defense",name:"Cadence Runique",desc:"+7 % cadence de tir & +6 % portée des tourelles par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:0,requires:[{id:"def_turret_dmg",rank:2}],effectLabel:i=>`+${i*7}% Cad. · +${i*6}% Port.`,unlocksBuilding:"tesla_spire"},{id:"def_regen",tree:"defense",name:"Auto-Réparation",desc:"Les murs et la Citadelle régénèrent +0,8 % de leurs PV max / s par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:2,requires:[{id:"def_wall_hp",rank:2}],effectLabel:i=>`+${(i*.8).toFixed(1)}% PV/s`},{id:"def_ult_pierce",tree:"defense",name:"Perce-Armure Éthérique",desc:"Ultime : les tourelles ignorent +2 armure ennemie et infligent +15 % aux Boss par rang.",maxRank:3,baseCost:12,costStep:10,row:3,col:1,requires:[{id:"def_turret_rate",rank:2},{id:"def_regen",rank:2}],effectLabel:i=>`+${i*2} Perc. · +${i*15}% Boss`},{id:"eco_start_res",tree:"economy",name:"Réserves Royales",desc:"Commence chaque partie avec +35 Pierre & +12 Cristaux par rang.",maxRank:5,baseCost:2,costStep:2,row:0,col:1,requires:[],effectLabel:i=>`+${i*35}🪨 +${i*12}💎`},{id:"eco_build_disc",tree:"economy",name:"Plans Optimisés",desc:"-4 % au coût de construction et d’amélioration des structures par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:0,requires:[{id:"eco_start_res",rank:1}],effectLabel:i=>`-${i*4}% Coût`},{id:"eco_prod",tree:"economy",name:"Extraction Intensive",desc:"+12 % production des Carrières de Pierre et Extracteurs d’Éther par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:2,requires:[{id:"eco_start_res",rank:1}],effectLabel:i=>`+${i*12}% Prod.`,unlocksBuilding:"ether_forge"},{id:"eco_wave_reward",tree:"economy",name:"Butin de Guerre",desc:"+12 % ressources lâchées par les ennemis et en fin de vague par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:0,requires:[{id:"eco_build_disc",rank:2}],effectLabel:i=>`+${i*12}% Butin`},{id:"eco_nodes",tree:"economy",name:"Prospection Riche",desc:"Ajoute +2 filons de Pierre et +1 gisement d’Éther sur la carte par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:2,requires:[{id:"eco_prod",rank:2}],effectLabel:i=>`+${i*2}🪨 +${i}💎 Filons`},{id:"eco_ult_refund",tree:"economy",name:"Recyclage Parfait",desc:"Ultime : +10 % remboursement démolition (max 90 %) & -8 % coût améliorations Citadelle par rang.",maxRank:3,baseCost:12,costStep:10,row:3,col:1,requires:[{id:"eco_wave_reward",rank:2},{id:"eco_nodes",rank:2}],effectLabel:i=>`${60+i*10}% Remb. · -${i*8}% Tech`},{id:"hero_vitality",tree:"hero",name:"Sang de Titan",desc:"+15 % PV max & +6 % vitesse de déplacement du Héros par rang.",maxRank:5,baseCost:2,costStep:2,row:0,col:1,requires:[],effectLabel:i=>`+${i*15}% PV · +${i*6}% Vit.`},{id:"hero_dmg",tree:"hero",name:"Maîtrise Martiale",desc:"+12 % dégâts & +8 % cadence d’attaque du Héros par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:0,requires:[{id:"hero_vitality",rank:1}],effectLabel:i=>`+${i*12}% Dég. · +${i*8}% Cad.`},{id:"hero_cd",tree:"hero",name:"Flux Arcanique",desc:"-7 % temps de recharge des compétences (Ruée, Cri, Ultime) par rang.",maxRank:5,baseCost:3,costStep:3,row:1,col:2,requires:[{id:"hero_vitality",rank:1}],effectLabel:i=>`-${i*7}% Cooldowns`},{id:"hero_respawn",tree:"hero",name:"Résilience Immortelle",desc:"-12 % temps de réapparition & +2 Armure personnelle pour le Héros par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:0,requires:[{id:"hero_dmg",rank:2}],effectLabel:i=>`-${i*12}% Resp. · +${i*2} Arm.`},{id:"hero_aura",tree:"hero",name:"Présence de Commandement",desc:"+15 % vitesse de réparation & +12 % dégâts de l’Ultime [R] par rang.",maxRank:5,baseCost:5,costStep:4,row:2,col:2,requires:[{id:"hero_cd",rank:2}],effectLabel:i=>`+${i*15}% Rép. · +${i*12}% Ult.`,unlocksBuilding:"war_banner"},{id:"hero_ult_scale",tree:"hero",name:"Ascension Éternelle",desc:"Ultime : +2 % dégâts (Héros & Tourelles) par vague franchie, cumulable à l’infini par rang.",maxRank:3,baseCost:12,costStep:10,row:3,col:1,requires:[{id:"hero_respawn",rank:2},{id:"hero_aura",rank:2}],effectLabel:i=>`+${i*2}% Dégâts / vague`},{id:"eth_gain",tree:"ether",name:"Récolteur d’Essences",desc:"+15 % d’Essences d’Éther gagnées (Boss & paliers de vagues) par rang.",maxRank:5,baseCost:3,costStep:3,row:0,col:1,requires:[],effectLabel:i=>`+${i*15}% Essences`},{id:"eth_boss_slayer",tree:"ether",name:"Chasseur de Titans",desc:"+12 % dégâts contre les Boss & +1 Essence bonus par Boss vaincu par rang.",maxRank:5,baseCost:4,costStep:4,row:1,col:0,requires:[{id:"eth_gain",rank:1}],effectLabel:i=>`+${i*12}% Boss · +${i}✨/Boss`},{id:"eth_risk",tree:"ether",name:"Audace Récompensée",desc:"+20 % bonus de ressources lors de l’empilement anticipé de vagues [G] par rang.",maxRank:5,baseCost:4,costStep:4,row:1,col:2,requires:[{id:"eth_gain",rank:1}],effectLabel:i=>`+${i*20}% Bonus Risque`},{id:"eth_citadel_shield",tree:"ether",name:"Égide d’Éther",desc:"À chaque vague lancée, la Citadelle gagne un bouclier temporaire de +60 PV par rang.",maxRank:5,baseCost:6,costStep:5,row:2,col:0,requires:[{id:"eth_boss_slayer",rank:2}],effectLabel:i=>`+${i*60} Bouclier / vague`,unlocksBuilding:"chrono_obelisk"},{id:"eth_late_scale",tree:"ether",name:"Endurance des Âges",desc:"À partir de la vague 10 : +8 % dégâts globaux & +10 % PV des bâtiments par rang.",maxRank:5,baseCost:6,costStep:5,row:2,col:2,requires:[{id:"eth_risk",rank:2}],effectLabel:i=>`V10+ : +${i*8}% Dég. · +${i*10}% PV`},{id:"eth_ult_start",tree:"ether",name:"Éveil Ancestral",desc:"Ultime : +12 % dégâts globaux dès le départ & +15 % Essences supplémentaires dès la vague 15+ par rang.",maxRank:3,baseCost:14,costStep:12,row:3,col:1,requires:[{id:"eth_citadel_shield",rank:2},{id:"eth_late_scale",rank:2}],effectLabel:i=>`+${i*12}% Dég. · +${i*15}%✨ V15+`}];function is(i){return wl.find(e=>e.id===i)}function si(i){return J.metaUpgrades[i]||0}function tu(i){return i?si(i)>=1:!0}function Aa(i,e=si(i.id)){return i.baseCost+e*i.costStep}function nu(i){for(const e of i.requires)if(si(e.id)<e.rank)return!1;return!0}function iu(i){const e=is(i);if(!e)return{ok:!1,reason:"Inconnu"};const t=si(i);if(t>=e.maxRank)return{ok:!1,reason:"MAX"};if(!nu(e))return{ok:!1,reason:`Requiert : ${e.requires.filter(r=>si(r.id)<r.rank).map(r=>{const a=is(r.id);return`${a?a.name:r.id} Niv.${r.rank}`}).join(" & ")}`};const n=Aa(e,t);return J.essence<n?{ok:!1,reason:`Coût : ${n} ✨`}:{ok:!0}}function qh(i){if(!iu(i).ok)return W("error"),!1;const t=is(i),n=si(i),s=Aa(t,n);return J.essence-=s,J.metaUpgrades[i]=n+1,Vt(),W("upgrade"),!0}function su(){let i=0;for(const e of wl){const t=si(e.id);for(let n=0;n<t;n++)i+=Aa(e,n)}return i}function Xh(){const i=su();return i<=0?0:(J.essence+=i,J.metaUpgrades={},Vt(),W("upgrade"),i)}const Yh={citadelHpMult:1,citadelArmorBonus:0,turretDmgMult:1,wallHpMult:1,wallArmorBonus:0,turretRateMult:1,turretRangeMult:1,wallRegenPct:0,turretArmorPierce:0,bossDmgMult:1,startStoneBonus:0,startCrystalBonus:0,buildDiscountBonus:0,prodMult:1,lootMult:1,extraStoneNodes:0,extraCrystalNodes:0,refundRatio:.6,citadelUpgDiscount:0,heroHpMult:1,heroSpdMult:1,heroDmgMult:1,heroRateMult:1,skillCdrMult:1,respawnMult:1,heroArmor:0,repairPowerBonus:0,ultDmgMult:1,waveDmgPerCleared:0,essenceMult:1,bossEssenceFlat:0,waveStackBonusMult:1,citadelWaveShield:0,lateDmgMult:1,lateBuildingHpMult:1,globalDmgMult:1,lateEssenceMult:1};let ru=!0;function Cs(i){ru=i}function bn(i){if(!ru||(i==null?void 0:i.mode)==="adventure")return Yh;const e=t=>J.metaUpgrades[t]||0;return{citadelHpMult:1+e("def_citadel_hp")*.12,citadelArmorBonus:e("def_citadel_hp"),turretDmgMult:1+e("def_turret_dmg")*.1,wallHpMult:1+e("def_wall_hp")*.15,wallArmorBonus:e("def_wall_hp"),turretRateMult:Math.max(.55,1-e("def_turret_rate")*.07),turretRangeMult:1+e("def_turret_rate")*.06,wallRegenPct:e("def_regen")*.008,turretArmorPierce:e("def_ult_pierce")*2,bossDmgMult:1+e("def_ult_pierce")*.15+e("eth_boss_slayer")*.12,startStoneBonus:e("eco_start_res")*35,startCrystalBonus:e("eco_start_res")*12,buildDiscountBonus:e("eco_build_disc")*.04,prodMult:1+e("eco_prod")*.12,lootMult:1+e("eco_wave_reward")*.12,extraStoneNodes:e("eco_nodes")*2,extraCrystalNodes:e("eco_nodes"),refundRatio:Math.min(.95,.6+e("eco_ult_refund")*.1),citadelUpgDiscount:e("eco_ult_refund")*.08,heroHpMult:1+e("hero_vitality")*.15,heroSpdMult:1+e("hero_vitality")*.06,heroDmgMult:1+e("hero_dmg")*.12,heroRateMult:Math.max(.55,1-e("hero_dmg")*.08),skillCdrMult:Math.max(.55,1-e("hero_cd")*.07),respawnMult:Math.max(.35,1-e("hero_respawn")*.12),heroArmor:e("hero_respawn")*2,repairPowerBonus:e("hero_aura")*.15,ultDmgMult:1+e("hero_aura")*.12,waveDmgPerCleared:e("hero_ult_scale")*.02,essenceMult:1+e("eth_gain")*.15,bossEssenceFlat:e("eth_boss_slayer"),waveStackBonusMult:1+e("eth_risk")*.2,citadelWaveShield:e("eth_citadel_shield")*60,lateDmgMult:1+e("eth_late_scale")*.08,lateBuildingHpMult:1+e("eth_late_scale")*.1,globalDmgMult:1+e("eth_ult_start")*.12,lateEssenceMult:1+e("eth_ult_start")*.15}}function Kh(i,e,t,n,s){if(i.mode==="adventure")return 0;const r=bn(i),a=e==="boss_dragon"?10:e==="boss_behemoth"?5:2,o=Math.floor(Math.max(0,t-10)/5),l=eu[i.difficulty]||1,c=t>=15?r.lateEssenceMult:1,d=Math.max(1,Math.round((a+o+r.bossEssenceFlat)*l*r.essenceMult*c));return J.essence+=d,J.totalEssenceEarned+=d,i.stats.essenceEarned+=d,Vt(),Ke(i,n,s-18,`+${d} ✨ ESSENCES`,"#d8b4fe",!0),Rn({title:`+${d} ✨ Essences d’Éther`,sub:`Boss vaincu (Vague ${t}) · Total : ${J.essence} ✨`,col:"#b87aff"}),d}function Zh(i,e){if(i.mode==="adventure"||e<5||e%5!==0)return 0;const t=bn(i),n=Math.floor(e/5)*2,s=eu[i.difficulty]||1,r=e>=15?t.lateEssenceMult:1,a=Math.max(1,Math.round(n*s*t.essenceMult*r));return J.essence+=a,J.totalEssenceEarned+=a,i.stats.essenceEarned+=a,Vt(),Ke(i,i.citadel.x,i.citadel.y-36,`PALIER V.${e} : +${a} ✨`,"#d8b4fe",!0),Rn({title:`Palier Vague ${e} : +${a} ✨`,sub:`Essences d’Éther permanentes · Total : ${J.essence} ✨`,col:"#b87aff"}),a}const Js=[{id:1,name:"Les Remparts d’Apprentissage",subtitle:"Découvre les bases : murs, tourelles, pouvoirs du Gardien et premier Boss Troll.",color:"#5ef28c",startLevel:1,endLevel:10},{id:2,name:"Cieux Orageux",subtitle:"Les créatures volantes et mages arrivent : débloque la DCA, le Mur Anti-Air et l’artillerie.",color:"#38bdf8",startLevel:11,endLevel:20},{id:3,name:"Siège de Fer",subtitle:"Trois flancs, Assassins et Nécromanciens : Citadelle Niv.3, Sanctuaire et Obsidienne.",color:"#ffbe3b",startLevel:21,endLevel:30},{id:4,name:"Bastion Runique",subtitle:"Colosses blindés, Bannière de Guerre, Flèche Tesla et ton premier Dragon Ancestral.",color:"#ff7e33",startLevel:31,endLevel:40},{id:5,name:"Terres Brisées",subtitle:"Assauts sur les 4 flancs : Citadelle Niv.4, Forge d’Éther et Obélisque Chrono.",color:"#b87aff",startLevel:41,endLevel:50},{id:6,name:"Frontière d’Éther",subtitle:"Citadelle Niv.5 débloquée ! Maîtrise l’économie de guerre pour tenir 15 vagues.",color:"#4ef2e8",startLevel:51,endLevel:60},{id:7,name:"L’Assaut des Titans",subtitle:"Les doubles Boss entrent en scène. Chaque niveau exige une défense solide.",color:"#f97316",startLevel:61,endLevel:70},{id:8,name:"Crépuscule d’Obsidienne",subtitle:"Hordes blindées et nuées aériennes continues sur des batailles prolongées.",color:"#a855f7",startLevel:71,endLevel:80},{id:9,name:"Abysse Ardent",subtitle:"Les forces du siège déchaînent toute leur puissance. Gère ton Coffre avec stratégie.",color:"#ef4444",startLevel:81,endLevel:90},{id:10,name:"La Citadelle Éternelle",subtitle:"Les 10 derniers remparts jusqu’à l’ultime siège du Niveau 100 !",color:"#ffe066",startLevel:91,endLevel:100}],Qs={wall:1,archer_tower:1,quarry:1,gate:2,spike_trap:2,ballista:3,crystal_rig:6,frost_tower:7,arcane_tower:8,rune_mine:9,flak_tower:11,sky_wall:13,alch_mortar:15,catapult:18,sanctuary:21,obsidian_wall:24,solar_tower:27,shield_gen:30,war_banner:35,tesla_spire:40,ether_forge:45,chrono_obelisk:50},Hs={abilityDash:{level:2,label:"Pouvoir : Ruée [Espace]"},abilityRally:{level:4,label:"Pouvoir : Cri de Bastion [E]"},tacticalPause:{level:4,label:"Pause Tactique [P]"},upgrades:{level:5,label:"Améliorations Citadelle [U]"},abilityUlt:{level:6,label:"Pouvoir : Ultime [R]"},speedControls:{level:8,label:"Vitesse ×2 / ×3"},pathPreview:{level:8,label:"Chemins ennemis [H]"},toolDemolish:{level:10,label:"Démolition multiple [X]"},waveStacking:{level:10,label:"Empilement de vagues [G]"},toolBatch:{level:14,label:"Amélioration en lot [B]"},toolBlueprint:{level:16,label:"Copier / Coller plans [C]"},autoWave:{level:16,label:"Mode Vague Auto [V]"}},Jh={1:"Premiers Remparts",2:"Portes & Pièges",3:"La Baliste",4:"Cri de Guerre",5:"Épreuve du Troll",6:"Veines d’Éther",7:"Souffle de Givre",8:"Foudre Arcanique",9:"Champs de Mines",10:"Seigneur des Remparts",11:"Ailes dans la Brume",13:"Barrière du Ciel",15:"Pluie d’Acide",18:"Artillerie Lourde",20:"Choc du Béhémoth",21:"Donjon Majeur",24:"Mur d’Obsidienne",27:"Rayon Solaire",30:"Dôme d’Éther",35:"Bannière Royale",40:"L’Éveil du Dragon",45:"Forge Industrielle",50:"Maître du Temps",60:"Forteresse Suprême",70:"Chute des Titans",80:"Nuit d’Obsidienne",90:"Portes de l’Abysse",100:"Siège Éternel (FINAL)"};function Qh(i){const e=["goblin"];return i>=2&&e.push("orc"),i>=3&&e.push("ram_brute"),i>=4&&e.push("shadow_wolf"),i>=6&&e.push("archer_skel"),i>=8&&e.push("sapper"),i>=11&&e.push("harpy"),i>=14&&e.push("pyro_mage"),i>=17&&e.push("wyvern_swarm"),i>=21&&e.push("bastion_assassin"),i>=24&&e.push("siege_golem"),i>=27&&e.push("necromancer"),i>=31&&e.push("rune_colossus"),e}function jh(i){return i===1?3:i===2?4:i<=10?5:i<=20?6+Math.floor((i-11)/5):i<=30?8+Math.floor((i-21)/5):i<=40?10+Math.floor((i-31)/5):i<=50?12+Math.floor((i-41)/5):i<=60?14+Math.floor((i-51)/5):i<=70?16+Math.floor((i-61)/5):i<=80?18+Math.floor((i-71)/5):i<=90?20+Math.floor((i-81)/4):Math.min(25,22+Math.floor((i-91)/3))}function ef(){const i=[];for(let e=1;e<=100;e++){const t=Math.ceil(e/10),n=Js[t-1],s=jh(e),r=e<=3?1:e<=20?2:e<=44?3:4,a=(e-1)/99,o=e<=10?Number((.42+(e-1)*.048).toFixed(2)):Number((.88*Math.pow(1.031,e-10)).toFixed(2)),l=e<=10?Number((.45+(e-1)*.045).toFixed(2)):Number((.88*Math.pow(1.023,e-10)).toFixed(2)),c=Number(Se(.8+a*.45,.8,1.25).toFixed(2)),d=Number((.55+a*1.55).toFixed(2)),p=e<22?0:Math.min(6,Math.floor((e-15)/13)),u=e<5?1:e<21?2:e<45?3:e<60?4:5,h=e%5===0;let v,f=!1;h&&(e<=15?v="boss_troll":e<=35?v="boss_behemoth":v="boss_dragon",e>=65&&(f=!0));const m=Object.keys(Qs).filter(A=>Qs[A]<=e),g=Object.keys(Hs).filter(A=>Hs[A].level<=e),S=[];e===5&&S.push("Citadelle Niv.2"),e===10&&S.push("Héros : Rôdeur d’Émeraude"),e===21&&S.push("Citadelle Niv.3"),e===25&&S.push("Héros : Invocateur Astral"),e===45&&S.push("Citadelle Niv.4"),e===60&&S.push("Citadelle Niv.5");for(const A of Object.keys(Qs))Qs[A]===e&&e>1&&S.push(`Bâtiment : ${We[A].name}`);for(const A of Object.keys(Hs))Hs[A].level===e&&S.push(Hs[A].label);e===1&&S.push("Mur de Pierre","Tour d’Archers","Carrière de Pierre");const M=Math.round(95+(t-1)*28+e%10*3),_=e<6?0:Math.round(18+(t-1)*14),E=Math.round(45+e*6+(h?45:0)),y=e<5?0:Math.round(12+e*2.4+(h?20:0)),x=Jh[e]||(h?`Assaut de Boss ${e}`:`${n.name.split(" ")[0]} · Étape ${e}`),b=e===1?"Ton tout premier siège ! Pose quelques murs, une Tour d’Archers et une Carrière pour repousser 3 vagues de Gobelins.":h?`Niveau Boss ! Tiens ${s} vagues et terrasse ${f?"un double Boss":Zn[v].name} sur la dernière vague.`:`Repousse ${s} vagues d’ennemis venant de ${r} flanc${r>1?"s":""} pour valider le niveau ${e}.`;i.push({level:e,chapter:t,chapterName:n.name,name:x,desc:b,targetWaves:s,flanks:r,hpMult:o,dmgMult:l,spdMult:c,countMult:d,armorBonus:p,allowedEnemies:Qh(e),bossId:v,doubleBoss:f,baseFreeStone:M,baseFreeCrystal:_,rewardStone:E,rewardCrystal:y,maxCitadelLvl:u,unlockedBuildings:m,unlockedFeatures:g,newUnlocks:S})}return i}const Ro=ef();function Kn(i){const e=Se(Math.floor(i)-1,0,Ro.length-1);return Ro[e]}function Pt(i,e){return i.mode!=="adventure"||!i.adventure?!0:Kn(i.adventure.level).unlockedFeatures.includes(e)}function tf(i){return i.mode!=="adventure"||!i.adventure?5:Kn(i.adventure.level).maxCitadelLvl}function pa(i,e){const t=We[e];if(i.mode==="adventure"&&i.adventure)return Kn(i.adventure.level).unlockedBuildings.includes(e)?{ok:!0}:{ok:!1,reason:`Aventure Niv.${Qs[e]||1}`};if(!tu(t.reqMetaNode)){const n=t.reqMetaNode?is(t.reqMetaNode):void 0;return{ok:!1,reason:`Débloquer dans l'Arbre : ${n?n.name:"Amélioration permanente"}`}}return{ok:!0}}function au(i,e){const t=["N","E","S","W"],n=Se(e===1?Math.min(i.flanks,Math.max(1,i.flanks-1)):i.flanks,1,4),r=[...t].sort(()=>Math.random()-.5).slice(0,n),o=!!(e===i.targetWaves&&i.bossId),l=[],c=Math.max(4,Math.round((6+e*3.4+i.level*.25)*i.countMult)),d=i.allowedEnemies.map(f=>{const m=Zn[f]||Zn.goblin;let g=6;return f==="goblin"||f==="orc"?g=Math.max(4,12-Math.floor(i.level/10)):m.role==="juggernaut"||m.role==="summoner"?g=3:g=5,{id:f,w:g}}),p=()=>{const f=d.reduce((g,S)=>g+S.w,0);let m=Math.random()*f;for(const g of d)if(m-=g.w,m<=0)return g.id;return d[0].id},u=Se(.95-i.level*.005,.36,.95);for(let f=0;f<c;f++)l.push({enemyId:p(),flank:r[f%r.length],delay:f===0?.45:Ct(u*.65,u*1.25)});let h=`Niv.${i.level} · Vague ${e}/${i.targetWaves}`;if(o&&i.bossId){h=`BOSS FINAL : ${Zn[i.bossId].name}`;const m=Math.floor(l.length*.45);l.splice(m,0,{enemyId:i.bossId,flank:r[0],delay:1}),i.doubleBoss&&l.push({enemyId:i.level>=80?"boss_dragon":"boss_behemoth",flank:r[r.length-1],delay:1.4})}let v;return i.level>=6&&e>=2&&(e%3===2||Math.random()<.28)&&(v=ua[(i.level+e)%ua.length]),{wave:e,title:h,flanks:r,queue:l,totalCount:l.length,spawnedCount:0,isBossWave:o,spawnTimer:.45,event:v}}function nf(i){if(i.mode!=="adventure"||!i.adventure)return;const e=i.adventure,t=Kn(e.level),n=i.citadel.hp/Math.max(1,i.citadel.maxHp),r=!i.stats.citadelDamaged&&i.citadel.hp>=i.citadel.maxHp?3:n>=.6?2:1,a=J.adventure.levelStars[e.level]||0;r>a&&(J.adventure.levelStars[e.level]=r);const o=r===3&&a<3,l=o?Math.round(t.rewardStone*.8):0,c=o?Math.round(t.rewardCrystal*.8):0,d=Math.max(0,Math.floor(i.stone)),p=Math.max(0,Math.floor(i.crystal));let u=0,h=0;for(const x of i.buildings)u+=x.investedStone,h+=x.investedCrystal;const v=Math.round(u*.5),f=Math.round(h*.5),m=!J.adventure.completedLevels.includes(e.level),g=m?1.5:1,S=Math.round(t.rewardStone*g),M=Math.round(t.rewardCrystal*g),_=d+v+S+l,E=p+f+M+c;J.adventure.vaultStone+=_,J.adventure.vaultCrystal+=E,m&&J.adventure.completedLevels.push(e.level),e.level>=J.adventure.highestUnlocked&&e.level<100&&(J.adventure.highestUnlocked=e.level+1),e.level>=10&&!ti("ranger")&&Co("ranger",!1),e.level>=25&&!ti("summoner")&&Co("summoner",!1);const y=e.level<100?Kn(e.level+1):null;e.victorySummary={level:e.level,stars:r,newThreeStar:o,threeStarStone:l,threeStarCrystal:c,remainingStone:d,remainingCrystal:p,recycledStone:v,recycledCrystal:f,rewardStone:S,rewardCrystal:M,firstClear:m,totalReturnedStone:_,totalReturnedCrystal:E,nextLevelUnlocks:y&&m?y.newUnlocks:[]},i.paused=!0,i.modal="victory",pn(i,i.citadel.x,i.citadel.y,56,"#5ef28c"),W("upgrade"),ns(),El(i)}function wi(i,e){return i.upgrades[e]||0}function Zt(i){const e=c=>i.upgrades[c]||0,t=bn(),n=Math.max(.35,(1-e("skill_cdr")*.14)*t.skillCdrMult),s=Wt[i.difficulty],r=Mt[i.heroClass],a=1+i.clearedWaves*t.waveDmgPerCleared,o=i.wave>=10?t.lateDmgMult:1,l=t.globalDmgMult*o*a;return{wallHpMult:(1+e("wall_hp")*.25)*t.wallHpMult,turretDmgMult:(1+e("turret_dmg")*.18)*t.turretDmgMult*l,turretRateMult:Math.max(.36,(1-e("turret_rate")*.12)*t.turretRateMult),buildDiscount:Math.min(.55,e("build_cost")*.1+r.buildDiscountBonus+t.buildDiscountBonus),harvestBonus:1+e("hero_harvest")*.35,prodMult:(1+e("prod_yield")*.25)*t.prodMult,lootMult:(1+e("loot_bonus")*.25)*t.lootMult,heroDmg:22*r.dmgMult*(1+e("hero_dmg")*.22)*t.heroDmgMult*l,heroRateMult:Math.max(.32,(1-e("hero_rate")*.15)*r.rateMult*t.heroRateMult),heroPierce:1+e("hero_pierce"),skillCdrMult:n,heroMaxHp:Math.round((150+e("hero_hp")*40)*r.hpMult*t.heroHpMult),heroSpeed:92*r.spdMult*(1+e("hero_spd")*.1)*t.heroSpdMult,respawnTime:Math.max(2,(8-e("hero_respawn")*1.5)*s.respawnMult*t.respawnMult),repairPower:1+e("hero_repair")*.4+r.repairPowerBonus+t.repairPowerBonus,citadelArmor:3+e("citadel_armor")*3+t.citadelArmorBonus,citadelGuardLvl:e("citadel_guard")}}function Dn(i){return i==="wall"||i==="gate"||i==="obsidian_wall"||i==="sky_wall"}function Ra(i,e){const t=We[e.id],n=Zt(i),s=bn(),r=Dn(e.id)?n.wallHpMult:1,a=i.wave>=10?s.lateBuildingHpMult:1,o=e.antiAir&&e.id!=="sky_wall"?140:0;return Math.round((t.hp+o)*r*a*Math.pow(1.32,e.lvl-1))}function sf(i){const e=Dn(i.id)?bn().wallArmorBonus:0,t=i.antiAir&&i.id!=="sky_wall"?2:0;return We[i.id].armor+Math.floor((i.lvl-1)/2)+e+t}function Qr(i,e){const t=We[e.id];let n=1;return e.spec==="B"&&e.id==="archer_tower"?n=1.55:e.spec==="A"&&e.id==="ballista"?n=1.35:e.spec==="B"&&e.id==="flak_tower"?n=1.3:e.spec==="B"&&e.id==="arcane_tower"?n=1.55:e.spec==="B"&&e.id==="frost_tower"?n=1.5:e.spec==="B"&&e.id==="alch_mortar"?n=1.6:e.spec==="A"&&e.id==="solar_tower"?n=1.35:e.spec==="A"&&e.id==="catapult"?n=1.45:(e.spec==="B"&&e.id==="tesla_spire"||e.spec==="B"&&e.id==="chrono_obelisk")&&(n=1.55),t.dmg*Math.pow(1.28,e.lvl-1)*Zt(i).turretDmgMult*n}function Qi(i,e){const t=We[e.id],n=Zt(i),s=Math.max(.35,1/(1+(e.lvl-1)*.12)),r=e.overclockTimer>0?.68:1;let a=1;e.spec==="B"&&e.id==="ballista"?a=.71:e.spec==="B"&&e.id==="flak_tower"?a=.74:e.spec==="B"&&e.id==="catapult"&&(a=.71);const o=i.activeWaves.some(l=>l.event==="ether_storm")?.8:1;return Math.max(.14,t.fireRate*n.turretRateMult*s*r*a*o)}function di(i){const e=We[i.id];if(e.range<=0)return 0;if(e.category==="trap")return e.range;if(e.category==="support")return e.range+Math.min(32,(i.lvl-1)*5);let t=1;return i.spec==="B"&&i.id==="archer_tower"?t=1.25:i.spec==="A"&&i.id==="frost_tower"?t=1.35:i.spec==="A"&&i.id==="chrono_obelisk"&&(t=1.3),Math.round((e.range+Math.min(48,(i.lvl-1)*6))*bn().turretRangeMult*t)}function Mr(i){const e=We[i.id];if(e.splash<=0)return 0;let t=1;return i.spec==="A"&&i.id==="flak_tower"?t=1.45:i.spec==="A"&&i.id==="alch_mortar"?t=1.4:i.spec==="A"&&i.id==="catapult"&&(t=1.35),Math.round((e.splash+Math.min(20,(i.lvl-1)*3))*t)}function ou(i,e){const t=Wt[i.difficulty];return(e.bonusNode?2:1)*(1+(e.lvl-1)*.3)*Zt(i).prodMult*t.resourceMult}function pr(i){const e=bn().refundRatio;return{stone:Math.round(i.investedStone*e),crystal:Math.round(i.investedCrystal*e)}}function Tl(i,e){const t=wi(i,e.id),n=Math.pow(e.costScale,t),s=1-bn().citadelUpgDiscount;return{stone:Math.max(1,Math.round(e.stoneBase*n*s)),crystal:e.crystalBase>0?Math.max(1,Math.round(e.crystalBase*n*s)):0}}function Lo(i,e){const t=ha.find(r=>r.id===e);if(!t)return{ok:!1,reason:"Inconnu"};const n=wi(i,e);if(!t.repeatable&&n>=t.maxLvl)return{ok:!1,reason:"MAX"};if(e==="citadel_lvl"&&i.citadel.lvl>=tf(i))return{ok:!1,reason:"Plafond du niveau"};if(i.citadel.lvl<t.reqCitadel)return{ok:!1,reason:`Citadelle Niv.${t.reqCitadel}`};if(e==="citadel_heal"&&i.citadel.hp>=i.citadel.maxHp)return{ok:!1,reason:"Citadelle intacte"};const s=Tl(i,t);return i.stone<s.stone||i.crystal<s.crystal?{ok:!1,reason:"Ressources insuffisantes"}:{ok:!0}}function lu(i,e){if(!Lo(i,e).ok)return W("error"),!1;const n=ha.find(r=>r.id===e),s=Tl(i,n);if(i.stone-=s.stone,i.crystal-=s.crystal,i.upgrades[e]=wi(i,e)+1,i.stats.upgradesBought+=1,i.stats.upgradesBought>=10&&Yn("upgrades_10"),e==="citadel_lvl")i.citadel.lvl+=1,i.citadel.maxHp+=250,i.citadel.hp=Math.min(i.citadel.maxHp,i.citadel.hp+300),pn(i,i.citadel.x,i.citadel.y,48,"#4ef2e8"),i.pendingBanner={title:`CITADELLE NIVEAU ${i.citadel.lvl}`,sub:"Nouvelles structures et technologies débloquées !"},i.citadel.lvl>=3&&Yn("citadel_3"),i.citadel.lvl>=5&&Yn("citadel_5");else if(e==="citadel_armor")i.citadel.maxHp+=120,i.citadel.hp+=120,i.citadel.armor=Zt(i).citadelArmor;else if(e==="citadel_heal"){const r=i.citadel.hp;i.citadel.hp=Math.min(i.citadel.maxHp,i.citadel.hp+250),Ke(i,i.citadel.x,i.citadel.y-20,`+${Math.round(i.citadel.hp-r)} PV`,"#5ef28c",!0)}else if(e==="wall_hp"){for(const r of i.buildings)if(Dn(r.id)){const a=Ra(i,r),o=a-r.maxHp;r.maxHp=a,o>0&&(r.hp+=o)}}else if(e==="hero_hp"){const r=Zt(i).heroMaxHp,a=r-i.hero.maxHp;i.hero.maxHp=r,a>0&&i.hero.alive&&(i.hero.hp+=a)}return W("upgrade"),!0}const jr=1.15;function Cl(i,e){const t=We[e],n=1-Zt(i).buildDiscount,s=Wt[i.difficulty].costMult;let r=1;if(e==="quarry"||e==="crystal_rig"||e==="ether_forge"){const o=i.buildings.filter(l=>l.id===e).length;r=Math.pow(jr,o)}const a=n*s*r;return{stone:Math.max(1,Math.round(t.stoneCost*a)),crystal:t.crystalCost>0?Math.max(1,Math.round(t.crystalCost*a)):0}}function La(i,e){const t=We[e.id],n=1-Zt(i).buildDiscount,s=Wt[i.difficulty].costMult,r=Math.pow(1.68,e.lvl),a=Math.max(15,t.stoneCost),o=t.crystalCost>0?t.crystalCost:Math.max(5,Math.round(t.stoneCost*.25));return{stone:Math.round(a*r*n*s),crystal:Math.round(o*r*n*s)}}function Pa(i){const e=(i.maxHp-i.hp)/i.maxHp,t=We[i.id].stoneCost;return Math.max(2,Math.round(e*t*.6*(1+(i.lvl-1)*.25)))}function rf(i){let e=0;const t=(n,s)=>{let r=0,a=0;for(;r<s&&a<250;){a+=1;const o=fa(3,Le-4),l=fa(3,He-4);if(o>=_n-1&&o<=_n+ht&&l>=ln-1&&l<=ln+ht||i.buildings.some(h=>o>=h.gx&&o<h.gx+h.w&&l>=h.gy&&l<h.gy+h.h)||i.nodes.some(h=>Math.abs(h.gx-o)<=1&&Math.abs(h.gy-l)<=1))continue;const d=(o+.5)*U,p=(l+.5)*U,u=n==="stone"?160:100;i.nodes.push({uid:i.nextUid++,kind:n,gx:o,gy:l,x:d,y:p,amount:u,maxAmount:u,flash:.45}),_t(i,d,p,12,n==="stone"?"#b4c2d4":"#4ef2e8",65,.45,2),r+=1,e+=1}};return t("stone",3),t("crystal",2),e>0&&(i.pathDirty=!0,Ke(i,i.citadel.x,i.citadel.y-34,`💎 PLUIE DE CRISTAUX (+${e} FILONS) !`,"#4ef2e8",!0)),e}function Al(i,e="normal",t=1){const n=Wt[e],s=["N","E","S","W"],r=i===1?1:i<=3?2:i<=7?3:4,a=i>=2?Math.min(2,n.extraFlankWaves):0,o=Se(Math.max(n.minFlanks,r+a),1,4),c=[...s].sort(()=>Math.random()-.5).slice(0,o),d=i>=3&&(i%n.bossInterval===0||i%5===0),p=[],u=Math.max(1,i+n.waveShift),h=1+Math.max(0,t-1)*.35,v=Math.round((9+i*4.8+Math.max(0,i-8)*1.4)*n.countMult*h),f=[];for(const E of Object.values(Zn)){if(E.role==="boss")continue;if(E.id==="goblin"||E.id==="orc"||u>=E.minWave){let x=10;E.role==="classic"?x=Math.max(3,14-u):E.role==="breaker"?x=4+Math.min(6,u-E.minWave):E.role==="flanker"?x=4+Math.min(5,u-E.minWave):E.role==="sapper"?x=3+Math.min(5,u-E.minWave):E.role==="flyer"?x=3+Math.min(6,u-E.minWave):E.role==="ranged"?x=4+Math.min(5,u-E.minWave):E.role==="assassin"?x=3+Math.min(5,u-E.minWave):E.role==="summoner"?x=2+Math.min(4,Math.floor((u-E.minWave)*.8)):E.role==="juggernaut"&&(x=3+Math.min(5,u-E.minWave)),f.push({id:E.id,w:Math.max(1,x)})}}const m=()=>{const E=f.reduce((x,b)=>x+b.w,0);let y=Math.random()*E;for(const x of f)if(y-=x.w,y<=0)return x.id;return f[0].id},g=Math.max(.55,1/Math.sqrt(Math.max(.7,n.countMult))),S=(i>=6?.5:.8)*g;for(let E=0;E<v;E++){const y=c[E%c.length];if(p.push({enemyId:m(),flank:y,delay:E===0?.35:Ct(S*.65,S*1.25)}),u>=6&&E>0&&E%14===7){const x=c[(E+1)%c.length],b=u>=12?4:3;for(let A=0;A<b;A++)p.push({enemyId:"wyvern_swarm",flank:x,delay:.25})}}let M=`Vague ${i}`;if(d){const E=i>=15?"boss_dragon":i>=10?"boss_behemoth":"boss_troll";M=`BOSS : ${Zn[E].name}`;const x=Math.floor(p.length*.45),b=["ram_brute","sapper","bastion_assassin","rune_colossus","necromancer"].filter(R=>u>=Zn[R].minWave),A=[{enemyId:E,flank:c[0],delay:1}];for(let R=0;R<n.bossEscortCount;R++){const D=b.length>0?b[R%b.length]:i>=3?"ram_brute":"orc";A.push({enemyId:D,flank:c[R%c.length],delay:.22})}if(p.splice(x,0,...A),i>=18){const R=i>=24?"boss_dragon":"boss_behemoth";p.push({enemyId:R,flank:c[c.length-1],delay:1.4})}}else i===3?M="Vague 3 · Béliers & Archers":i===4?M="Vague 4 · Sapeurs Anti-Tourelles":i===6?M="Vague 6 · Assassins & Essaims":i===7?M="Vague 7 · Nécromanciens":i===8&&(M="Vague 8 · Colosses Runiques");let _;return i>=4&&(i%3===1||Math.random()<.28)&&(_=ua[Math.floor(Math.random()*ua.length)]),{wave:i,title:M,flanks:c,queue:p,totalCount:p.length,spawnedCount:0,isBossWave:d,spawnTimer:.45,event:_}}function Da(i,e=!1){if(i.waveLaunchCd>0)return;if(i.activeWaves.length>=10){e&&W("error");return}const t=i.phase==="wave"&&i.activeWaves.length>0,n=i.nextWavePlan,s=bn(i);if(i.mode==="adventure"&&i.adventure){if(n.wave>i.adventure.targetWaves)return;if(t&&!Pt(i,"waveStacking")){e&&W("error");return}}if(e){const a=Wt[i.difficulty].resourceMult,o=t?Math.min(2,1.35+i.activeWaves.length*.15)*s.waveStackBonusMult:1,l=Math.round((8+n.wave*2.5)*o*a),c=Math.round((2+Math.floor(n.wave*.9))*o*a);i.stone+=l,i.crystal+=c,i.stats.stoneEarned+=l,i.stats.crystalEarned+=c,Ke(i,i.citadel.x,i.citadel.y-22,`+${l}🪨 +${c}💎${t?" RISQUE !":""}`,"#ffbe3b",!0)}s.citadelWaveShield>0&&(i.citadel.shield=Math.min(i.citadel.maxHp,i.citadel.shield+s.citadelWaveShield),i.citadel.maxShield=Math.max(i.citadel.maxShield,i.citadel.shield),i.citadel.shieldTimer=Math.max(i.citadel.shieldTimer,18)),i.activeWaves.push(n),i.phase="wave",i.wave=n.wave,i.waveLaunchCd=.35,i.mode==="adventure"&&i.adventure?n.wave<i.adventure.targetWaves?i.nextWavePlan=au(Kn(i.adventure.level),n.wave+1):i.nextWavePlan={...n,wave:i.adventure.targetWaves+1,queue:[],totalCount:0,spawnedCount:0,isBossWave:!1}:i.nextWavePlan=Al(n.wave+1,i.difficulty,i.playerCount||1),n.event==="crystal_rain"&&rf(i);const r=n.event?To[n.event]:void 0;i.pendingBanner={title:t?`${n.title} (${i.activeWaves.length} VAGUES ACTIVES)`:r?`${n.title} · ${r.icon} ${r.short}`:n.title,sub:r?`${r.desc} · Flancs : ${n.flanks.join(" · ")}`:`Flancs : ${n.flanks.join(" · ")}`,warn:n.isBossWave||t||n.event==="blood_moon"},n.isBossWave?W("boss_warn"):W("wave_start")}function af(i,e,t=!1){const n=Wt[i.difficulty].resourceMult,s=bn(i),r=t?2:1,a=Math.round((16+e*4)*n*s.lootMult*r),o=Math.round((4+e*2)*n*s.lootMult*r);i.stone+=a,i.crystal+=o,i.stats.stoneEarned+=a,i.stats.crystalEarned+=o,i.clearedWaves+=1,Zh(i,e),i.citadel.hp=Math.min(i.citadel.maxHp,i.citadel.hp+45),i.hero.alive?i.hero.hp=Math.min(i.hero.maxHp,i.hero.hp+35):i.hero.respawnTimer=Math.min(i.hero.respawnTimer,1.5),e>=1&&Yn("wave_1"),e>=5&&Yn("wave_5"),e>=10&&Yn("wave_10"),e>=15&&Yn("wave_15"),i.stats.heroDeaths>0&&Yn("respawn_win"),i.activeWaves.length===0?i.pendingBanner={title:`VAGUE ${e} REPOUSSÉE !`,sub:`+${a} Pierre · +${o} Cristaux · Prépare la vague ${i.nextWavePlan.wave}`}:Ke(i,i.citadel.x,i.citadel.y-26,`V${e} REPOUSSÉE +${a}🪨 +${o}💎`,"#5ef28c",!0),W("upgrade"),Vt(),fr(i)}function of(i){if(i.mode==="adventure"&&i.adventure&&i.clearedWaves>=i.adventure.targetWaves){nf(i);return}const e=Wt[i.difficulty];i.phase="prep",i.wave=i.nextWavePlan.wave,i.prepTimer=i.autoWave?3:e.prepDuration,Vt(),fr(i)}function xn(i,e,t){i.toolMode=e,i.dragStart=null,i.dragEnd=null,i.buildMode=e==="build"&&t||null,e!=="none"&&(i.selectedBuildingUid=null),e!=="batch_upgrade"&&(i.batchSelectedUids=[],i.batchFilterId="all")}function cu(i,e,t,n,s,r){const a=r==="quarry"?"stone":r==="crystal_rig"?"crystal":null;if(!a)return!1;for(const o of i.nodes)if(o.kind===a&&o.gx>=e-1&&o.gx<=e+n&&o.gy>=t-1&&o.gy<=t+s)return!0;return!1}function Rl(i,e,t,n,s){const r=We[t],a=pa(i,t);if(!a.ok)return{ok:!1,reason:a.reason||"Verrouillé"};if(i.citadel.lvl<r.reqCitadel)return{ok:!1,reason:`Requiert Citadelle Niv.${r.reqCitadel}`};if(n<1||s<1||n+r.w>Le-1||s+r.h>He-1)return{ok:!1,reason:"Hors zone constructible"};let o=!1;for(let v=0;v<r.h;v++)for(let f=0;f<r.w;f++){const m=n+f,g=s+v;if(e.isCitadelCell(m,g))return{ok:!1,reason:"Emplacement Citadelle"};const S=e.getBuildingAtGrid(m,g);if(S)if(t==="sky_wall"&&Dn(S.id)){if(S.id==="sky_wall"||S.antiAir)return{ok:!1,reason:"Déjà Anti-Aérien"};o=!0}else return{ok:!1,reason:"Case occupée"}}const l=o?[]:i.nodes.filter(v=>v.gx>=n&&v.gx<n+r.w&&v.gy>=s&&v.gy<s+r.h),c=t==="quarry"?"stone":t==="crystal_rig"?"crystal":null,d=c!==null&&l.some(v=>v.kind===c),p=l.length>0&&!d,u=Cl(i,t);return i.stone<u.stone||i.crystal<u.crystal?{ok:!1,reason:"Ressources insuffisantes",destroysNode:p}:{ok:!0,bonusNode:cu(i,n,s,r.w,r.h,t),destroysNode:p,upgradeWall:o}}function du(i,e,t,n,s,r){const a=We[e];i.stone-=s.stone,i.crystal-=s.crystal;let o=!1;const l=e==="quarry"?"stone":e==="crystal_rig"?"crystal":null;for(let f=i.nodes.length-1;f>=0;f--){const m=i.nodes[f];m.gx>=t&&m.gx<t+a.w&&m.gy>=n&&m.gy<n+a.h&&(m.kind!==l&&(o=!0),_t(i,m.x,m.y,8,m.kind==="stone"?"#b4c2d4":"#4ef2e8",50,.35,2),i.nodes.splice(f,1))}const c=Zt(i),d=Dn(e)?c.wallHpMult:1,p=Math.round(a.hp*d),u=(t+a.w*.5)*U,h=(n+a.h*.5)*U,v={uid:i.nextUid++,id:e,gx:t,gy:n,w:a.w,h:a.h,x:u,y:h,hp:p,maxHp:p,lvl:1,investedStone:s.stone,investedCrystal:s.crystal,shield:0,maxShield:0,shieldTimer:0,beamTargetUid:0,beamCharge:0,sanctuaryHealCd:0,cd:.25,prodTimer:a.prodInterval>0?a.prodInterval*.5:0,flash:.15,overclockTimer:0,healFlash:0,totalDmg:0,kills:0,bonusNode:r,armed:!0,antiAir:e==="sky_wall"};return i.buildings.push(v),i.stats.builtCount+=1,i.stats.builtCount>=25&&Yn("architect_25"),r&&Yn("bonus_rig"),{b:v,crushedNonMatching:o}}function uu(i,e,t,n,s){const r=Rl(i,e,t,n,s);if(!r.ok)return null;const a=We[t],o=Cl(i,t);if(r.upgradeWall&&t==="sky_wall"){const d=e.getBuildingAtGrid(n,s);if(d&&Dn(d.id)&&!d.antiAir){i.stone-=o.stone,i.crystal-=o.crystal,d.antiAir=!0,d.investedStone+=o.stone,d.investedCrystal+=o.crystal;const p=d.maxHp,u=Ra(i,d);return d.maxHp=u,d.hp=Math.min(u,d.hp+Math.max(0,u-p)),d.healFlash=.3,i.stats.builtCount+=1,_t(i,d.x,d.y,10,"#38bdf8",55,.35,2),Ke(i,d.x,d.y-10,"ANTI-AÉRIEN !","#38bdf8",!0),W("upgrade"),d}}const{b:l,crushedNonMatching:c}=du(i,t,n,s,o,!!r.bonusNode);return e.recompute(i),_t(i,l.x,l.y,7,a.color,45,.3,2),r.bonusNode?Ke(i,l.x,l.y-10,"BONUS ×2 !","#ffbe3b",!0):c&&Ke(i,l.x,l.y-10,"FILON RASÉ","#ff7e33"),W("build"),l}function hu(i,e){const t=La(i,e);return i.stone<t.stone||i.crystal<t.crystal?(W("error"),!1):(i.stone-=t.stone,i.crystal-=t.crystal,e.lvl+=1,e.investedStone+=t.stone,e.investedCrystal+=t.crystal,e.maxHp=Ra(i,e),e.hp=e.maxHp,e.flash=.25,Ke(i,e.x,e.y-10,`NIV.${e.lvl}`,"#ffbe3b",!0),_t(i,e.x,e.y,10,"#ffbe3b",55,.35,2),W("upgrade"),!0)}function fu(i,e){if(e.hp>=e.maxHp)return!1;const t=Pa(e);return i.stone<t?(W("error"),!1):(i.stone-=t,e.hp=e.maxHp,e.healFlash=.3,Ke(i,e.x,e.y-8,"RÉPARÉ","#5ef28c"),W("repair"),!0)}function lf(i){const e=i.buildings.filter(r=>r.hp<r.maxHp).sort((r,a)=>r.hp/r.maxHp-a.hp/a.maxHp);let t=0,n=i.stone,s=0;for(const r of e){const a=Pa(r);t+=a,n>=a&&(n-=a,s+=1)}return{damagedCount:e.length,totalStone:t,affordableCount:s}}function pu(i){const e=i.buildings.filter(r=>r.hp<r.maxHp).sort((r,a)=>r.hp/r.maxHp-a.hp/a.maxHp);let t=0,n=0;for(const r of e){const a=Pa(r);i.stone<a||(i.stone-=a,n+=a,r.hp=r.maxHp,r.healFlash=.35,_t(i,r.x,r.y,4,"#5ef28c",38,.25,2),t+=1)}if(t===0)return W("error"),{repairedCount:0,stoneSpent:0};const s=i.hero.alive?i.hero:i.citadel;return Ke(i,s.x,s.y-18,`RÉPARÉS (${t}) -${n}🪨`,"#5ef28c",!0),W("repair"),{repairedCount:t,stoneSpent:n}}function mu(i){const e=new Set(i.batchSelectedUids);return i.buildings.filter(t=>e.has(t.uid)&&(i.batchFilterId==="all"||t.id===i.batchFilterId))}function cf(i){const e=mu(i).sort((c,d)=>c.lvl-d.lvl||c.uid-d.uid);let t=0,n=0,s=i.stone,r=i.crystal,a=0,o=0,l=0;for(const c of e){const d=La(i,c);t+=d.stone,n+=d.crystal,s>=d.stone&&r>=d.crystal&&(s-=d.stone,r-=d.crystal,a+=1,o+=d.stone,l+=d.crystal)}return{count:e.length,totalStone:t,totalCrystal:n,affordableCount:a,affordableStone:o,affordableCrystal:l}}function gu(i){const e=mu(i).sort((o,l)=>o.lvl-l.lvl||o.uid-l.uid);let t=0,n=0,s=0,r=0,a=0;for(const o of e){const l=La(i,o);i.stone<l.stone||i.crystal<l.crystal||(i.stone-=l.stone,i.crystal-=l.crystal,n+=l.stone,s+=l.crystal,o.lvl+=1,o.investedStone+=l.stone,o.investedCrystal+=l.crystal,o.maxHp=Ra(i,o),o.hp=o.maxHp,o.flash=.25,_t(i,o.x,o.y,6,"#ffbe3b",45,.3,2),r+=o.x,a+=o.y,t+=1)}return t===0?(W("error"),{upgradedCount:0,stoneSpent:0,crystalSpent:0}):(Ke(i,r/t,a/t-12,`+${t} AMÉLIORÉS !`,"#ffbe3b",!0),W("upgrade"),{upgradedCount:t,stoneSpent:n,crystalSpent:s})}function vu(i,e,t){const n=pr(t);i.stone+=n.stone,i.crystal+=n.crystal;const s=i.buildings.findIndex(a=>a.uid===t.uid);s>=0&&i.buildings.splice(s,1),i.selectedBuildingUid===t.uid&&(i.selectedBuildingUid=null),i.batchSelectedUids=i.batchSelectedUids.filter(a=>a!==t.uid),e.recompute(i);const r=n.crystal>0?`+${n.stone}🪨 +${n.crystal}💎`:`+${n.stone}🪨`;Ke(i,t.x,t.y-6,r,"#ffbe3b"),W("sell")}function Su(i,e,t){if(t.length===0)return{count:0,stone:0,crystal:0};const n=new Set;let s=0,r=0,a=0,o=0;for(const u of t){if(n.has(u.uid))continue;n.add(u.uid);const h=pr(u);s+=h.stone,r+=h.crystal,a+=u.x,o+=u.y,_t(i,u.x,u.y,6,We[u.id].color,45,.28,2)}const l=n.size;if(l===0)return{count:0,stone:0,crystal:0};i.buildings=i.buildings.filter(u=>!n.has(u.uid)),i.selectedBuildingUid&&n.has(i.selectedBuildingUid)&&(i.selectedBuildingUid=null),i.batchSelectedUids.length>0&&(i.batchSelectedUids=i.batchSelectedUids.filter(u=>!n.has(u))),i.stone+=s,i.crystal+=r,e.recompute(i);const c=a/l,d=o/l,p=r>0?`-${l} BÂT. · +${s}🪨 +${r}💎`:`-${l} BÂT. · +${s}🪨`;return Ke(i,c,d-10,p,"#ffbe3b",!0),W("sell"),{count:l,stone:s,crystal:r}}function xu(i,e){i.targetPriority=e,W("click")}function _u(i,e,t){const n=rr[e.id];if(!n||e.lvl<5||e.spec)return W("error"),!1;e.spec=t,e.healFlash=.35;const s=n[t];return _t(i,e.x,e.y,14,s.color,65,.4,2),Ke(i,e.x,e.y-12,`★ ${s.name.toUpperCase()} !`,s.color,!0),W("upgrade"),!0}function df(i,e,t,n,s){const r=i.buildings.filter(p=>p.gx<n+1&&p.gx+p.w>e&&p.gy<s+1&&p.gy+p.h>t);if(r.length===0)return null;let a=1/0,o=1/0,l=-1/0,c=-1/0;for(const p of r)p.gx<a&&(a=p.gx),p.gy<o&&(o=p.gy),p.gx+p.w>l&&(l=p.gx+p.w),p.gy+p.h>c&&(c=p.gy+p.h);const d=r.map(p=>({id:p.id,rx:p.gx-a,ry:p.gy-o,w:p.w,h:p.h}));return{w:l-a,h:c-o,items:d}}function yu(i){return{w:i.h,h:i.w,items:i.items.map(e=>({id:e.id,rx:i.h-(e.ry+e.h),ry:e.rx,w:e.h,h:e.w}))}}function Ll(i,e,t,n,s){const r=[],a=new Set,o=1-Zt(i).buildDiscount,l=Wt[i.difficulty].costMult;let c=i.stone,d=i.crystal,p=0,u=0,h=0;const v=i.buildings.filter(_=>_.id==="quarry").length,f=i.buildings.filter(_=>_.id==="crystal_rig").length,m=i.buildings.filter(_=>_.id==="ether_forge").length;let g=0,S=0,M=0;for(const _ of t.items){const E=n+_.rx,y=s+_.ry,x=We[_.id];let b=!1;if((!pa(i,_.id).ok||i.citadel.lvl<x.reqCitadel||E<1||y<1||E+_.w>Le-1||y+_.h>He-1)&&(b=!0),!b)for(let X=0;X<_.h&&!b;X++)for(let k=0;k<_.w;k++){const P=E+k,F=y+X;if(e.isCitadelCell(P,F)||e.getBuildingAtGrid(P,F)||a.has(`${P},${F}`)){b=!0;break}}let A=1;_.id==="quarry"?A=Math.pow(jr,v+p):_.id==="crystal_rig"?A=Math.pow(jr,f+u):_.id==="ether_forge"&&(A=Math.pow(jr,m+h));const R=o*l*A,D={stone:Math.max(1,Math.round(x.stoneCost*R)),crystal:x.crystalCost>0?Math.max(1,Math.round(x.crystalCost*R)):0};if(b){r.push({item:_,gx:E,gy:y,status:"blocked",cost:D,bonusNode:!1});continue}if(c<D.stone||d<D.crystal){r.push({item:_,gx:E,gy:y,status:"no_funds",cost:D,bonusNode:!1});continue}c-=D.stone,d-=D.crystal,S+=D.stone,M+=D.crystal,_.id==="quarry"?p+=1:_.id==="crystal_rig"?u+=1:_.id==="ether_forge"&&(h+=1);for(let X=0;X<_.h;X++)for(let k=0;k<_.w;k++)a.add(`${E+k},${y+X}`);const O=cu(i,E,y,_.w,_.h,_.id);g+=1,r.push({item:_,gx:E,gy:y,status:"valid",cost:D,bonusNode:O})}return{entries:r,validCount:g,totalStone:S,totalCrystal:M}}function Mu(i,e,t,n,s){const r=Ll(i,e,t,n,s);if(r.validCount===0)return W("error"),0;let a=0,o=0,l=0;for(const c of r.entries){if(c.status!=="valid")continue;const{b:d}=du(i,c.item.id,c.gx,c.gy,c.cost,c.bonusNode);_t(i,d.x,d.y,4,We[d.id].color,40,.25,2),a+=d.x,o+=d.y,l+=1}return l>0&&(e.recompute(i),Ke(i,a/l,o/l-12,`COLLÉ (${l})`,"#4ef2e8",!0),W("build")),l}function es(i,e,t,n,s=1,r){const a=We[t.id],o=Dn(t.id)?s:1,l=sf(t);let c=Math.max(1,Math.round(n*o-l));if(t.shield>0){c=Math.max(1,Math.round(c*.8));const d=Math.min(t.shield,c);t.shield-=d,c-=d,_t(i,t.x,t.y,3,"#38bdf8",35,.2,2)}if(c>0&&(t.hp-=c,t.flash=.1),t.id==="obsidian_wall"&&r&&r.hp>0){const d=Math.min(.75,.3+(t.lvl-1)*.05),p=Math.max(1,Math.round(n*d));Ht(i,r,p,2,t.uid),_t(i,r.x,r.y,3,"#b87aff",40,.22,2)}if(t.hp<=0){const d=i.buildings.findIndex(p=>p.uid===t.uid);d>=0&&i.buildings.splice(d,1),i.selectedBuildingUid===t.uid&&(i.selectedBuildingUid=null),i.batchSelectedUids.length>0&&(i.batchSelectedUids=i.batchSelectedUids.filter(p=>p!==t.uid)),pn(i,t.x,t.y,18,a.color),e.recompute(i),W("catapult")}}function bu(i,e){if(i.modal==="over")return;let t=Math.max(1,Math.round(e-i.citadel.armor));if(i.citadel.shield>0){t=Math.max(1,Math.round(t*.8));const n=Math.min(i.citadel.shield,t);i.citadel.shield-=n,t-=n,_t(i,i.citadel.x,i.citadel.y,4,"#38bdf8",40,.25,2)}t>0&&(i.citadel.hp-=t,i.citadel.flash=.14,i.hurtFlash=Math.max(i.hurtFlash,.35),i.stats.citadelDamaged=!0,nr(i,4)),i.citadel.hp<=0&&(i.citadel.hp=0,pn(i,i.citadel.x,i.citadel.y,64,"#ff4f6d"),i.paused=!0,i.modal="over",El(i),ns(),W("death"))}function ws(i,e,t){const n=t||i.hero,s=n===i.hero;if(!n.alive||n.invuln>0||n.dashTime>0)return;const r=bn().heroArmor,a=Math.max(1,Math.round(e-r));if(n.hp-=a,n.invuln=.38,n.hitFlash=.18,s&&(i.hurtFlash=.6,nr(i,5)),W("hurt"),Ke(i,n.x,n.y-10,`-${a}`,"#ff4f6d",!0),n.hp<=0){n.hp=0,n.alive=!1;const o=Zt(i);n.respawnMax=o.respawnTime,n.respawnTimer=o.respawnTime,i.stats.heroDeaths+=1,pn(i,n.x,n.y,26,"#4ef2e8"),W("death"),s?i.pendingBanner={title:"GARDIEN TOMBÉ",sub:`Réapparition à la Citadelle dans ${n.respawnMax.toFixed(0)} s · Défendez les murs !`,warn:!0}:Ke(i,n.x,n.y-18,"ALLIÉ TOMBÉ !","#ff4f6d",!0)}}function Ga(i,e,t,n,s){if(i.pickups.length>=220){const r=i.pickups.find(a=>a.kind===e);if(r){r.val+=s;return}}i.pickups.push({uid:i.nextUid++,kind:e,x:t+Ct(-4,4),y:n+Ct(-4,4),vx:Ct(-22,22),vy:Ct(-22,22),val:s,life:40,magnetized:!1})}function Ht(i,e,t,n=0,s,r=!1){if(e.hp<=0)return!1;const a=bn();e.isBoss&&a.bossDmgMult>1&&(t*=a.bossDmgMult),r&&e.splashResist>0&&(t*=1-e.splashResist);const o=s?a.turretArmorPierce:0,l=e.armorShred>0?Math.max(0,Math.floor(e.armor*.5)-2):e.armor,c=Math.max(0,l-n-o),d=Math.max(1,Math.round(t-c));e.hp-=d,e.flash=.1;const p=s?i.buildings.find(u=>u.uid===s):void 0;if(p&&(p.totalDmg+=d),Math.random()<.4&&Ke(i,e.x,e.y-e.r,`${d}`,"#f2f5fa"),e.isBoss){const u=e.hp/e.maxHp;u<=.6&&e.bossPhase===1?(e.bossPhase=2,pn(i,e.x,e.y,28,e.col)):u<=.3&&e.bossPhase===2&&(e.bossPhase=3,pn(i,e.x,e.y,34,"#ff4f6d"))}if(e.hp<=0){if(p&&(p.kills+=1),i.stats.kills+=1,i.stats.kills>=250&&Yn("kills_250"),e.isBoss&&(i.stats.bossesKilled+=1,Yn("boss_kill"),Kh(i,e.id,e.waveNum,e.x,e.y)),Nh(e.id),pn(i,e.x,e.y,e.r*1.8,e.col),!e.isSummon){const u=Zt(i),h=Wt[i.difficulty].resourceMult,f=i.activeWaves.some(S=>S.event==="blood_moon")?2:1,m=Math.max(1,Math.round(e.stoneDrop*u.lootMult*h*f)),g=e.crystalDrop>0?Math.max(1,Math.round(e.crystalDrop*u.lootMult*h*f)):0;Ga(i,"stone",e.x,e.y,m),g>0&&Ga(i,"crystal",e.x,e.y,g),(e.isBoss||Math.random()<.04)&&Ga(i,"heal",e.x,e.y,e.isBoss?50:20)}return!0}return!1}function ku(i,e,t,n,s,r,a,o){const l=a||i.hero,c=o||i.heroClass;if(!l.alive||l.dashCd>0||l.dashTime>0)return;const d=Zt(i);if(l.dashCd=l.dashMaxCd*d.skillCdrMult,c==="archmage"||c==="summoner"){let u=l.x,h=l.y;if(s!==void 0&&r!==void 0){const S=s-l.x,M=r-l.y,_=Math.hypot(S,M)||1,E=Math.min(210,_);u=l.x+S/_*E,h=l.y+M/_*E}else{const S=Math.hypot(t,n),M=S>.1?t/S:Math.cos(l.ang),_=S>.1?n/S:Math.sin(l.ang);u=l.x+M*140,h=l.y+_*140}u=Se(u,12,Ft-12),h=Se(h,12,Ot-12);const v=c==="summoner",f=v?"#38bdf8":"#b87aff",m=l.x,g=l.y;_t(i,m,g,14,f,70,.35,2);for(const S of i.enemies)Re(m,g,S.x,S.y)<=30+S.r&&Ht(i,S,d.heroDmg*1.3,2);l.x=u,l.y=h,l.invuln=Math.max(l.invuln,.35),_t(i,l.x,l.y,16,"#4ef2e8",80,.35,2);for(const S of i.enemies)Re(l.x,l.y,S.x,S.y)<=32+S.r&&(v?S.stun=Math.max(S.stun,.8):S.slow=Math.max(S.slow,1.8),Ht(i,S,d.heroDmg*1.3,2));if(v)for(const S of i.summonedTurrets)S.life=Math.min(S.maxLife,S.life+4);Ke(i,l.x,l.y-12,v?"TRANSFERT SPECTRAL":"TÉLÉPORTATION",f,!0),W("arcane");return}const p=Math.hypot(t,n);if(p>.1?(l.dashDirX=t/p,l.dashDirY=n/p):(l.dashDirX=Math.cos(l.ang),l.dashDirY=Math.sin(l.ang)),l.dashTime=c==="ranger"?.2:c==="engineer"?.14:.17,l.invuln=Math.max(l.invuln,.28),c==="ranger"){W("dash");const u=l.x,h=l.y;pn(i,u,h,38,"#5ef28c");for(const v of i.enemies)Re(u,h,v.x,v.y)<=42+v.r&&(v.slow=Math.max(v.slow,2.2),v.armorShred=Math.max(v.armorShred,3),Ht(i,v,d.heroDmg*1.8,3));Ke(i,l.x,l.y-12,"PAS DE L’OMBRE !","#5ef28c",!0);return}if(c==="engineer"){W("dash"),_t(i,l.x,l.y,12,"#ffbe3b",75,.3,2);const u=Math.round(45*d.repairPower);i.zonesFx.push({uid:i.nextUid++,kind:"repair_ring",x:l.x,y:l.y,r:68,dmg:0,life:.35,maxLife:.35,color:"#5ef28c",fromPlayer:!0,hitDone:!0});for(const h of i.buildings)h.hp<h.maxHp&&Re(l.x,l.y,h.x,h.y)<=68&&(h.hp=Math.min(h.maxHp,h.hp+u),h.healFlash=.3);for(const h of i.enemies)if(Re(l.x,l.y,h.x,h.y)<=42+h.r){const v=Math.atan2(h.y-l.y,h.x-l.x);h.x=Se(h.x+Math.cos(v)*14,4,Ft-4),h.y=Se(h.y+Math.sin(v)*14,4,Ot-4),Ht(i,h,d.heroDmg)}Ke(i,l.x,l.y-12,"BOND RÉPARATEUR","#5ef28c",!0);return}W("dash"),_t(i,l.x,l.y,10,"#4ef2e8",75,.3,2);for(const u of i.enemies)Re(l.x,l.y,u.x,u.y)<=32+u.r&&(u.slow=Math.max(u.slow,1.5),Ht(i,u,d.heroDmg*1.2))}function Eu(i,e,t){const n=e||i.hero,s=t||i.heroClass;if(!n.alive||n.rallyCd>0)return;const r=Zt(i);if(n.rallyCd=n.rallyMaxCd*r.skillCdrMult,n.rallyDur=5.5,s==="engineer"){i.zonesFx.push({uid:i.nextUid++,kind:"repair_ring",x:n.x,y:n.y,r:125,dmg:0,life:.42,maxLife:.42,color:"#ffbe3b",fromPlayer:!0,hitDone:!0});let c=0;for(const d of i.buildings)Re(n.x,n.y,d.x,d.y)<=125&&(d.overclockTimer=Math.max(d.overclockTimer,7),d.hp<d.maxHp&&(d.hp=Math.min(d.maxHp,d.hp+55),d.healFlash=.3),d.maxShield=Math.max(d.maxShield,60),d.shield=Math.min(d.maxShield,d.shield+60),d.shieldTimer=Math.max(d.shieldTimer,6),c+=1);n.hp=Math.min(n.maxHp,n.hp+25),Ke(i,n.x,n.y-14,`SURCHARGE SECTEUR (${c})`,"#ffbe3b",!0),W("shield");return}if(s==="archmage"){i.zonesFx.push({uid:i.nextUid++,kind:"stasis_ring",x:n.x,y:n.y,r:125,dmg:0,life:.45,maxLife:.45,color:"#b87aff",fromPlayer:!0,hitDone:!0});for(const c of i.enemies)Re(n.x,n.y,c.x,c.y)<=125+c.r&&(c.stun=Math.max(c.stun,1.4),c.slow=Math.max(c.slow,4),c.armorShred=Math.max(c.armorShred,5),Ht(i,c,r.heroDmg*1.25,3));Ke(i,n.x,n.y-14,"NOVA DE STASE !","#b87aff",!0),W("frost");return}if(s==="ranger"){i.zonesFx.push({uid:i.nextUid++,kind:"rally_ring",x:n.x,y:n.y,r:145,dmg:0,life:.42,maxLife:.42,color:"#5ef28c",fromPlayer:!0,hitDone:!0});let c=0;for(const d of i.buildings)Re(n.x,n.y,d.x,d.y)<=145&&(d.overclockTimer=Math.max(d.overclockTimer,6.5),c+=1);for(const d of i.enemies)Re(n.x,n.y,d.x,d.y)<=145+d.r&&(d.armorShred=Math.max(d.armorShred,6),d.slow=Math.max(d.slow,2));Ke(i,n.x,n.y-14,`ŒIL DE FAUCON (${c} TOURS)`,"#5ef28c",!0),W("rally");return}if(s==="summoner"){i.zonesFx.push({uid:i.nextUid++,kind:"repair_ring",x:n.x,y:n.y,r:130,dmg:0,life:.42,maxLife:.42,color:"#38bdf8",fromPlayer:!0,hitDone:!0});for(const c of i.buildings)Re(n.x,n.y,c.x,c.y)<=130&&(c.overclockTimer=Math.max(c.overclockTimer,6));for(const c of i.summonedTurrets)c.life=Math.min(c.maxLife,c.life+5),c.cd=0;i.citadel.shield=Math.min(i.citadel.maxHp,i.citadel.shield+140),i.citadel.maxShield=Math.max(i.citadel.maxShield,i.citadel.shield),i.citadel.shieldTimer=Math.max(i.citadel.shieldTimer,10),Ke(i,n.x,n.y-14,"PACTE D’ESSENCE (+140 🛡️)","#38bdf8",!0),W("shield");return}const a=110;i.zonesFx.push({uid:i.nextUid++,kind:"rally_ring",x:n.x,y:n.y,r:a,dmg:0,life:.38,maxLife:.38,color:"#ffbe3b",fromPlayer:!0,hitDone:!0});let o=0;for(const l of i.buildings)Re(n.x,n.y,l.x,l.y)<=a&&(l.overclockTimer=Math.max(l.overclockTimer,5.5),o+=1);n.hp=Math.min(n.maxHp,n.hp+20);for(const l of i.enemies)if(Re(n.x,n.y,l.x,l.y)<=a*.75+l.r){const c=Math.atan2(l.y-n.y,l.x-n.x);l.x+=Math.cos(c)*14,l.y+=Math.sin(c)*14,l.stun=Math.max(l.stun,.6),Ht(i,l,r.heroDmg*1.1)}Ke(i,n.x,n.y-14,`CRI DE BASTION (${o} TOURS)`,"#ffbe3b",!0),W("rally")}function wu(i,e,t){const n=e||i.hero,s=t||i.heroClass;if(!n.alive||n.ultCd>0)return;const r=Zt(i),a=bn().ultDmgMult;if(n.ultCd=n.ultMaxCd*r.skillCdrMult,s==="engineer"){i.summonedTurrets.length>=2&&i.summonedTurrets.shift(),i.summonedTurrets.push({uid:i.nextUid++,x:n.x,y:n.y,life:14,maxLife:14,cd:.15,range:124,dmg:r.heroDmg*.72*r.turretDmgMult*a,animPhase:0}),_t(i,n.x,n.y,14,"#ffbe3b",65,.35,2),Ke(i,n.x,n.y-14,"AUTOMATE DÉPLOYÉ !","#ffbe3b",!0),W("build");return}if(s==="summoner"){for(let c=0;c<3;c++){i.summonedTurrets.length>=4&&i.summonedTurrets.shift();const d=c*Math.PI*2/3+i.time,p=Se(n.x+Math.cos(d)*24,14,Ft-14),u=Se(n.y+Math.sin(d)*24,14,Ot-14);i.summonedTurrets.push({uid:i.nextUid++,x:p,y:u,life:18,maxLife:18,cd:.1+c*.08,range:136,dmg:r.heroDmg*.65*r.turretDmgMult*a,animPhase:c*2}),_t(i,p,u,10,"#38bdf8",55,.35,2)}Ke(i,n.x,n.y-14,"LÉGION D’ÉTHER (3×) !","#38bdf8",!0),W("ult");return}if(s==="ranger"){W("ult"),nr(i,5),Ke(i,n.x,n.y-14,"PLUIE DE FLÈCHES !","#5ef28c",!0);const c=[...i.enemies].sort((d,p)=>{const u=(d.isBoss?1e6:0)+(d.flying?2e5:0)+d.hp;return(p.isBoss?1e6:0)+(p.flying?2e5:0)+p.hp-u});for(let d=0;d<8;d++){const p=c[d%Math.max(1,c.length)],u=p?Math.atan2(p.y-n.y,p.x-n.x):d*Math.PI*2/8;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"hero_bolt",x:n.x+Math.cos(u)*6,y:n.y+Math.sin(u)*6,vx:Math.cos(u)*320,vy:Math.sin(u)*320,r:3,dmg:r.heroDmg*2.4*a,pierce:4,life:.9,maxLife:.9,color:"#5ef28c",splash:0,slow:0,armorBonus:6,hitList:[]})}return}if(s==="archmage"){W("ult"),nr(i,7),Ke(i,n.x,n.y-14,"CATACLYSME D’ÉTHER !","#b87aff",!0);const c=[...i.enemies].sort((p,u)=>{const h=(p.isBoss?1e6:0)+(p.role==="juggernaut"?5e5:0)+p.hp;return(u.isBoss?1e6:0)+(u.role==="juggernaut"?5e5:0)+u.hp-h}),d=[];for(let p=0;p<3;p++)if(c[p])d.push({x:c[p].x,y:c[p].y});else{const u=p*Math.PI*2/3;d.push({x:n.x+Math.cos(u)*50,y:n.y+Math.sin(u)*50})}for(const p of d)i.zonesFx.push({uid:i.nextUid++,kind:"ult_strike",x:p.x,y:p.y,r:44,dmg:r.heroDmg*5.2*a,life:.36,maxLife:.36,color:"#b87aff",fromPlayer:!0,hitDone:!1});return}W("ult"),nr(i,6),Ke(i,n.x,n.y-14,"JUGEMENT D’ÉTHER !","#b87aff",!0);const o=[],l=[...i.enemies].sort((c,d)=>Re(n.x,n.y,c.x,c.y)-Re(n.x,n.y,d.x,d.y));for(let c=0;c<5;c++)if(l[c])o.push({x:l[c].x,y:l[c].y});else{const d=c*Math.PI*2/5;o.push({x:n.x+Math.cos(d)*45,y:n.y+Math.sin(d)*45})}for(const c of o)i.zonesFx.push({uid:i.nextUid++,kind:"ult_strike",x:c.x,y:c.y,r:34,dmg:r.heroDmg*3.4*a,life:.32,maxLife:.32,color:"#b87aff",fromPlayer:!0,hitDone:!1})}function ar(i,e="normal",t="guardian",n=!0){Cs(n);const s=Wt[e],r=Mt[t];let a=1;const o=(_n+ht*.5)*U,l=(ln+ht*.5)*U,c=[],d=new Set;for(let M=-1;M<=ht;M++)for(let _=-1;_<=ht;_++)d.add(`${_n+_},${ln+M}`);const p=(M,_,E,y)=>{let x=0,b=0;for(;x<_&&b<600;){b+=1;const A=fa(3,Le-4),R=fa(3,He-4),D=Math.hypot(A-(_n+1),R-(ln+1));if(D<E||D>y)continue;let O=!0;for(let k=-1;k<=1;k++)for(let P=-1;P<=1;P++)d.has(`${A+P},${R+k}`)&&(O=!1);if(!O)continue;d.add(`${A},${R}`);const X=M==="stone"?160:100;c.push({uid:a++,kind:M,gx:A,gy:R,x:(A+.5)*U,y:(R+.5)*U,amount:X,maxAmount:X,flash:0}),x+=1}},u=bn();p("stone",5,4.5,9.5),p("stone",8+u.extraStoneNodes,10,19),p("crystal",3,5.5,10.5),p("crystal",6+u.extraCrystalNodes,11,19);const h=Math.round(115*s.resourceMult)+u.startStoneBonus,v=Math.round(25*s.resourceMult)+u.startCrystalBonus,f=Math.max(2,Math.round(8*s.respawnMult*u.respawnMult)),m=Math.round(800*u.citadelHpMult),g=Math.round(150*r.hpMult*u.heroHpMult),S={active:!0,mode:"survival",paused:!1,tacticalPause:!1,gameSpeed:1,pathPreview:"auto",modal:"none",difficulty:e,heroClass:t,autoWave:!1,waveLaunchCd:0,time:0,phase:"prep",prepTimer:s.prepDuration,wave:1,clearedWaves:0,nextWavePlan:Al(1,e),activeWaves:[],stone:h,crystal:v,citadel:{gx:_n,gy:ln,w:ht,h:ht,x:o,y:l,hp:m,maxHp:m,lvl:1,armor:3+u.citadelArmorBonus,shield:0,maxShield:0,shieldTimer:0,cd:.4,flash:0},hero:{x:o,y:(ln+ht+1.2)*U,vx:0,vy:0,ang:-Math.PI/2,faceX:1,r:5,hp:g,maxHp:g,alive:!0,respawnTimer:0,respawnMax:f,invuln:0,attackCd:.2,dashCd:0,dashMaxCd:2.5,dashTime:0,dashDirX:0,dashDirY:-1,rallyCd:0,rallyMaxCd:11,rallyDur:0,ultCd:0,ultMaxCd:16,hitFlash:0,animPhase:0,harvestTargetUid:0,harvestTimer:0,repairTargetUid:0,repairTimer:0},summonedTurrets:[],buildings:[],nodes:c,enemies:[],projectiles:[],pickups:[],zonesFx:[],particles:[],texts:[],arcs:[],upgrades:{},toolMode:"none",buildMode:null,dragStart:null,dragEnd:null,batchSelectedUids:[],batchFilterId:"all",blueprint:null,selectedBuildingUid:null,hoverGx:-1,hoverGy:-1,pathDirty:!0,nextUid:a,camX:o,camY:l,shake:0,hurtFlash:0,screenFlash:0,screenFlashCol:"#ffffff",stats:{kills:0,stoneEarned:h,crystalEarned:v,essenceEarned:0,builtCount:0,upgradesBought:0,heroDeaths:0,bossesKilled:0},pendingBanner:{title:`BASTION D’ÉTHER · ${s.label.toUpperCase()}`,sub:"Phase de Préparation · Bâtis tes défenses et récolte les filons"},pendingHint:"Clic : Construire/Sélectionner · X : Démolition multiple · V : Vague Auto · G : Lancer/Empiler vague · U : Améliorations"};return i.recompute(S),S}function uf(i,e,t,n,s="guardian"){Cs(!1);const r=Kn(e),a=Se(Math.floor(t),0,J.adventure.vaultStone),o=Se(Math.floor(n),0,J.adventure.vaultCrystal);J.adventure.vaultStone-=a,J.adventure.vaultCrystal-=o,Vt();const l=ar(i,"normal",s,!1),c=Mt[s],d=Math.round(150*c.hpMult),p=r.baseFreeStone+a,u=r.baseFreeCrystal+o;l.mode="adventure",l.stone=p,l.crystal=u,l.stats.stoneEarned=p,l.stats.crystalEarned=u,l.citadel.hp=800,l.citadel.maxHp=800,l.citadel.armor=3,l.hero.hp=d,l.hero.maxHp=d,l.hero.respawnMax=8,l.prepTimer=e===1?35:28,l.nextWavePlan=au(r,1),l.adventure={level:r.level,targetWaves:r.targetWaves,broughtStone:a,broughtCrystal:o,freeStone:r.baseFreeStone,freeCrystal:r.baseFreeCrystal};const h=r.newUnlocks.length>0?` · Nouveautés : ${r.newUnlocks.slice(0,2).join(", ")}`:"";return l.pendingBanner={title:`AVENTURE NIV.${r.level} — ${r.name.toUpperCase()}`,sub:`Objectif : ${r.targetWaves} vagues${h}`},l.pendingHint=e<=3?"Déplace-toi (ZQSD), construis tes défenses (Clic Gauche) puis lance la vague [G] !":`Niveau ${r.level} (${r.targetWaves} vagues) · Risque engagé : ${a}🪨 ${o}💎`,l}function hf(i,e,t,n){const s=ar(i,e,t.heroClass,!0),r=1+n.length,a=Wt[e],o=bn(s);s.playerCount=r,s.localPlayerId=t.id,s.localPlayerName=t.name,s.localPlayerColor=t.color;const l=n.length*35,c=n.length*10;s.stone+=l,s.crystal+=c,s.stats.stoneEarned+=l,s.stats.crystalEarned+=c,s.nextWavePlan=Al(1,e,r);const d=[{dx:-26,dy:0},{dx:26,dy:0},{dx:0,dy:-56}];return s.coopPlayers=n.map((p,u)=>{const h=Mt[p.heroClass]||Mt.guardian,v=Math.round(150*h.hpMult*o.heroHpMult),f=Math.max(2,Math.round(8*a.respawnMult*o.respawnMult)),m=d[u%d.length];return{id:p.id,name:p.name,color:p.color,heroClass:p.heroClass,moveX:0,moveY:0,repairHeld:!1,hero:{...s.hero,x:Se(s.hero.x+m.dx,18,Ft-18),y:Se(s.hero.y+m.dy,18,Ot-18),hp:v,maxHp:v,respawnMax:f}}}),s.pendingBanner={title:`COOP LAN (${r} JOUEURS) · ${a.label.toUpperCase()}`,sub:"Pot commun partagé · Défendez la Citadelle ensemble !"},s}function gc(i,e,t,n,s,r,a,o,l){const c=Zt(i),d=Mt[n]||Mt.guardian,p=Mt[i.heroClass]||Mt.guardian,u=d.spdMult/Math.max(.1,p.spdMult),h=c.heroSpeed*u,v=c.repairPower-p.repairPowerBonus+d.repairPowerBonus;if(t.invuln=Math.max(0,t.invuln-s),t.hitFlash=Math.max(0,t.hitFlash-s),t.dashCd=Math.max(0,t.dashCd-s),t.rallyCd=Math.max(0,t.rallyCd-s),t.rallyDur=Math.max(0,t.rallyDur-s),t.ultCd=Math.max(0,t.ultCd-s),!t.alive){t.respawnTimer-=s,t.respawnTimer<=0&&(t.alive=!0,t.respawnTimer=0,t.x=i.citadel.x,t.y=(ln+ht+1.1)*U,t.hp=t.maxHp,t.invuln=2.4,_t(i,t.x,t.y,16,"#4ef2e8",70,.45,3),Ke(i,t.x,t.y-14,l?"GARDIEN RÉAPPARU !":"ALLIÉ RÉAPPARU !","#4ef2e8",!0),W("respawn"));return}const f=wi(i,"hero_hp");f>0&&t.hp<t.maxHp&&(t.hp=Math.min(t.maxHp,t.hp+f*1.4*s)),t.dashTime>0?(t.dashTime-=s,t.vx=t.dashDirX*265,t.vy=t.dashDirY*265):(t.vx=r*h,t.vy=a*h),Math.hypot(r,a)>.1&&(t.ang=Math.atan2(a,r),Math.abs(r)>.15&&(t.faceX=r>0?1:-1),t.animPhase+=s*10);const m=Se(t.x+t.vx*s,10,Ft-10);!e.isHeroBlockedAt(m-4,t.y)&&!e.isHeroBlockedAt(m+4,t.y)&&(t.x=m);const g=Se(t.y+t.vy*s,10,Ot-10);!e.isHeroBlockedAt(t.x,g-4)&&!e.isHeroBlockedAt(t.x,g+4)&&(t.y=g);let S=null,M=28;for(const _ of i.nodes){if(l&&(_.flash=Math.max(0,_.flash-s)),_.amount<=0)continue;const E=Re(t.x,t.y,_.x,_.y);E<=M&&(M=E,S=_)}if(S){if(t.harvestTargetUid=S.uid,t.harvestTimer-=s*c.harvestBonus,t.harvestTimer<=0){t.harvestTimer=.65;const _=Math.min(S.amount,Math.max(1,Math.round((S.kind==="stone"?4:2)*c.harvestBonus)));if(S.amount-=_,S.flash=.14,S.kind==="stone"?(i.stone+=_,i.stats.stoneEarned+=_,Ke(i,S.x,S.y-8,`+${_}🪨`,"#d4dde8")):(i.crystal+=_,i.stats.crystalEarned+=_,Ke(i,S.x,S.y-8,`+${_}💎`,"#4ef2e8")),_t(i,S.x,S.y,4,S.kind==="stone"?"#b4c2d4":"#4ef2e8",35,.25,2),W("mine"),S.amount<=0){const E=i.nodes.findIndex(y=>y.uid===S.uid);E>=0&&i.nodes.splice(E,1),_t(i,S.x,S.y,10,S.kind==="stone"?"#b4c2d4":"#4ef2e8",50,.4,2),Ke(i,S.x,S.y-12,"FILON ÉPUISÉ","#96abc9"),i.pathDirty=!0,t.harvestTargetUid=0}}}else t.harvestTargetUid=0,t.harvestTimer=.15;if(t.repairTargetUid=0,o){let _=null,E=32;for(const x of i.buildings){if(x.hp>=x.maxHp)continue;const b=Re(t.x,t.y,x.x,x.y);b<=E&&(E=b,_=x)}const y=i.citadel.hp<i.citadel.maxHp&&Re(t.x,t.y,i.citadel.x,i.citadel.y)<=44;if((_||y)&&(t.repairTargetUid=_?_.uid:-1,t.repairTimer-=s,t.repairTimer<=0)){t.repairTimer=.35;const x=Math.round(22*v);i.stone>=1&&(i.stone-=1,_?(_.hp=Math.min(_.maxHp,_.hp+x),_.healFlash=.2,Ke(i,_.x,_.y-8,`+${x}`,"#5ef28c")):(i.citadel.hp=Math.min(i.citadel.maxHp,i.citadel.hp+x),Ke(i,i.citadel.x,i.citadel.y-18,`+${x}`,"#5ef28c")),W("repair"))}}}function ff(i,e,t,n,s,r){i.time+=t,i.waveLaunchCd=Math.max(0,i.waveLaunchCd-t),i.citadel.flash=Math.max(0,i.citadel.flash-t),i.citadel.shieldTimer>0?i.citadel.shieldTimer-=t:i.citadel.shield>0&&(i.citadel.shield=Math.max(0,i.citadel.shield-25*t),i.citadel.shield<=0&&(i.citadel.maxShield=0));const a=bn().wallRegenPct;if(a>0){i.citadel.hp>0&&i.citadel.hp<i.citadel.maxHp&&(i.citadel.hp=Math.min(i.citadel.maxHp,i.citadel.hp+i.citadel.maxHp*a*t));for(const d of i.buildings)Dn(d.id)&&d.hp>0&&d.hp<d.maxHp&&(d.hp=Math.min(d.maxHp,d.hp+d.maxHp*a*t))}i.pathDirty&&e.recompute(i),i.phase==="prep"&&(i.autoWave&&i.prepTimer>3&&(i.prepTimer=3),i.prepTimer-=t,i.prepTimer<=0&&Da(i,!1));const o=i.hero;if(gc(i,e,o,i.heroClass,t,n,s,r,!0),i.coopPlayers&&i.coopPlayers.length>0)for(const d of i.coopPlayers)gc(i,e,d.hero,d.heroClass,t,d.moveX,d.moveY,d.repairHeld,!1);const l=o.alive?o.x:i.citadel.x,c=o.alive?o.y:i.citadel.y;i.camX+=(l-i.camX)*Math.min(1,t*8),i.camY+=(c-i.camY)*Math.min(1,t*8);for(const d of i.buildings){d.flash=Math.max(0,d.flash-t),d.healFlash=Math.max(0,d.healFlash-t),d.overclockTimer=Math.max(0,d.overclockTimer-t),d.sanctuaryHealCd=Math.max(0,d.sanctuaryHealCd-t),d.shieldTimer>0?d.shieldTimer-=t:d.shield>0&&(d.shield=Math.max(0,d.shield-25*t),d.shield<=0&&(d.maxShield=0));const p=We[d.id];if(p.prodInterval>0&&(d.prodTimer-=t,d.prodTimer<=0)){d.prodTimer=p.prodInterval;const u=ou(i,d);if(p.prodStone>0){const h=Math.max(1,Math.round(p.prodStone*u));i.stone+=h,i.stats.stoneEarned+=h,Ke(i,d.x,d.y-8,`+${h}🪨`,"#d4dde8")}if(p.prodCrystal>0){const h=Math.max(1,Math.round(p.prodCrystal*u));i.crystal+=h,i.stats.crystalEarned+=h,Ke(i,d.x,d.y-8,`+${h}💎`,"#4ef2e8")}}}for(let d=i.pickups.length-1;d>=0;d--){const p=i.pickups[d];if(p.life-=t,p.life<=0){i.pickups.splice(d,1);continue}if(p.kind==="stone"||p.kind==="crystal"){p.magnetized=!0;const h=o.alive?o.x:i.citadel.x,v=o.alive?o.y:i.citadel.y,f=Re(h,v,p.x,p.y),m=Math.max(220,f*2.4),g=Math.atan2(v-p.y,h-p.x);p.x+=Math.cos(g)*m*t,p.y+=Math.sin(g)*m*t;const S=o.alive?o.r+9:22;f<=S&&(p.kind==="stone"?(i.stone+=p.val,i.stats.stoneEarned+=p.val,Ke(i,h,v-10,`+${p.val}🪨`,"#d4dde8")):(i.crystal+=p.val,i.stats.crystalEarned+=p.val,Ke(i,h,v-10,`+${p.val}💎`,"#4ef2e8")),W("pickup"),i.pickups.splice(d,1));continue}if(o.alive){const h=Re(o.x,o.y,p.x,p.y);if(h<=44&&(p.magnetized=!0),p.magnetized){const v=Math.atan2(o.y-p.y,o.x-p.x);p.x+=Math.cos(v)*185*t,p.y+=Math.sin(v)*185*t}else p.vx*=Math.exp(-5*t),p.vy*=Math.exp(-5*t),p.x=Se(p.x+p.vx*t,8,Ft-8),p.y=Se(p.y+p.vy*t,8,Ot-8);h<=o.r+7&&(o.hp=Math.min(o.maxHp,o.hp+p.val),Ke(i,p.x,p.y-6,`+${p.val} PV`,"#5ef28c"),W("pickup"),i.pickups.splice(d,1))}else p.vx*=Math.exp(-5*t),p.vy*=Math.exp(-5*t),p.x=Se(p.x+p.vx*t,8,Ft-8),p.y=Se(p.y+p.vy*t,8,Ot-8)}}function pf(i){switch(i){case"N":return{x:Ct(36,Ft-36),y:8};case"S":return{x:Ct(36,Ft-36),y:Ot-8};case"W":return{x:8,y:Ct(36,Ot-36)};case"E":return{x:Ft-8,y:Ct(36,Ot-36)}}}function Po(i,e,t,n,s,r=!1){const a=Zn[e]||Zn.goblin;Qd(e);const o=Math.max(0,s-1);let l,c,d,p,u;if(i.mode==="adventure"&&i.adventure){const m=Kn(i.adventure.level),g=1+o*.08,S=1+o*.04,M=Math.min(1.25,1+o*.01),_=Math.max(.65,1-o*.015);l=Math.max(1,Math.round(a.hp*m.hpMult*g)),c=Math.max(1,Math.round(a.dmg*m.dmgMult*S)),d=a.spd*m.spdMult*M,p=Math.max(.38,a.fireRate*_),u=a.armor+m.armorBonus+Math.floor(o/5)}else{const m=Wt[i.difficulty],g=Math.pow(1.16,o)*(1+o*.08),S=Math.pow(1.09,o)*(1+o*.05),M=Math.min(1.55,1+o*.022),_=Math.floor(o/3),E=Math.max(.55,1-o*.02);l=Math.max(1,Math.round(a.hp*g*m.hpMult)),c=Math.max(1,Math.round(a.dmg*S*m.dmgMult)),d=a.spd*M*m.spdMult,p=Math.max(.35,a.fireRate*E),u=a.armor+_+m.armorBonus}const h=Math.max(0,(i.playerCount||1)-1);h>0&&(l=Math.max(1,Math.round(l*(1+h*.42))));const v=i.activeWaves.find(m=>m.wave===s);(v==null?void 0:v.event)==="blood_moon"?d*=1.2:(v==null?void 0:v.event)==="ether_storm"&&(l=Math.max(1,Math.round(l*1.15)));const f={uid:i.nextUid++,id:a.id,name:a.name,role:a.role,waveNum:s,isSummon:r,x:t,y:n,vx:0,vy:0,r:a.r,hp:l,maxHp:l,spd:d,dmg:c,wallDmgMult:a.wallDmgMult,range:a.range,fireRate:p,armor:u,splashResist:a.splashResist||0,armorShred:0,poisonTimer:0,poisonDps:0,poisonTick:.4,stoneDrop:a.stoneDrop,crystalDrop:a.crystalDrop,art:a.art,col:a.col,flying:a.flying,isBoss:a.role==="boss",bossPhase:1,flash:0,slow:0,stun:0,bleed:0,aiTimer:Ct(.9,2),attackCd:.25,telegraph:0,telegraphX:0,telegraphY:0,telegraphR:0,animPhase:Math.random()*10};return i.enemies.push(f),f}function mf(i,e,t){let n=null,s=1e9;for(const r of i.buildings){const a=We[r.id].category;if(a==="turret"||a==="economy"||a==="support"){const o=Re(e,t,r.x,r.y);o<s&&(s=o,n=r)}}return n}function gf(i,e,t){let n=null,s=-1e9;for(const r of i.buildings){const a=We[r.id];if(a.category!=="turret"&&a.category!=="economy"&&a.category!=="support")continue;const o=Re(e,t,r.x,r.y),c=a.stoneCost+a.crystalCost*2.5-o*.15;c>s&&(s=c,n=r)}return n}function vf(i,e,t){let n=null,s=105;const r=Re(e,t,i.citadel.x,i.citadel.y);for(const a of i.buildings){const o=We[a.id].category;if(o!=="economy"&&o!=="support"&&o!=="turret")continue;const l=Re(e,t,a.x,a.y);l<=s&&l<r+15&&(s=l,n=a)}return n}function Sf(i,e,t,n){let s=null,r=n;for(const a of i.buildings)if(We[a.id].category==="economy"){const o=Re(e,t,a.x,a.y);o<r&&(r=o,s=a)}return s}function xf(i,e){const t=e.range;let n=null;const s=[i.hero,...(i.coopPlayers||[]).map(o=>o.hero)];for(const o of s){if(!o.alive)continue;const l=Re(e.x,e.y,o.x,o.y);l<=t&&(!n||l<n.d)&&(n={x:o.x,y:o.y,d:l})}if(n)return{x:n.x,y:n.y,kind:"hero"};let r=null,a=t;for(const o of i.buildings){if(!We[o.id].blocksEnemies)continue;const l=Re(e.x,e.y,o.x,o.y);l<=a&&(a=l,r=o)}return r?{x:r.x,y:r.y,kind:"building",building:r}:Re(e.x,e.y,i.citadel.x,i.citadel.y)<=t+18?{x:i.citadel.x,y:i.citadel.y,kind:"citadel"}:null}function _f(i,e,t,n){if(t.flash=Math.max(0,t.flash-n),t.slow=Math.max(0,t.slow-n),t.stun=Math.max(0,t.stun-n),t.armorShred=Math.max(0,t.armorShred-n),t.attackCd=Math.max(0,t.attackCd-n),t.animPhase+=n*9,t.poisonTimer>0&&(t.poisonTimer-=n,t.poisonTick-=n,t.poisonTick<=0&&(t.poisonTick=.5,Ht(i,t,Math.max(1,t.poisonDps*.5),99),t.hp<=0)))return;if(t.stun>0){t.vx=0,t.vy=0;return}const s=t.spd*(t.slow>0?.52:1),r=i.hero,a=i.citadel;if(t.role==="summoner"&&(t.aiTimer-=n,t.aiTimer<=0&&(t.aiTimer=Math.max(3,5.4-t.waveNum*.08),i.enemies.length<220))){for(let p=0;p<2;p++){const u=t.waveNum>=12&&Math.random()<.35?"sapper":Math.random()<.5?"archer_skel":"goblin";Po(i,u,t.x+Ct(-14,14),t.y+Ct(-14,14),t.waveNum,!0)}_t(i,t.x,t.y,10,"#b87aff",55,.35,2)}if(t.isBoss&&(t.aiTimer-=n,t.aiTimer<=0)){if(t.aiTimer=t.bossPhase===3?2.8:t.bossPhase===2?3.5:4.4,t.id==="boss_troll"||t.id==="boss_behemoth"){const p=[r,...(i.coopPlayers||[]).map(v=>v.hero)];let u=null,h=120;for(const v of p){if(!v.alive)continue;const f=Re(t.x,t.y,v.x,v.y);f<h&&(h=f,u={x:v.x,y:v.y})}u&&i.zonesFx.push({uid:i.nextUid++,kind:"boss_slam",x:u.x,y:u.y,r:36,dmg:t.dmg*1.15,life:.9,maxLife:.9,color:"#ff4f6d",fromPlayer:!1,hitDone:!1}),t.id==="boss_behemoth"&&t.bossPhase>=2&&Po(i,"sapper",t.x+Ct(-14,14),t.y+Ct(-14,14),t.waveNum,!0)}else if(t.id==="boss_dragon")for(let p=-1;p<=1;p++){const u=Math.atan2(a.y-t.y,a.x-t.x)+p*.25;i.projectiles.push({uid:i.nextUid++,fromPlayer:!1,kind:"fireball",x:t.x,y:t.y,vx:Math.cos(u)*125,vy:Math.sin(u)*125,r:4,dmg:t.dmg*.75,pierce:1,life:2,maxLife:2,color:"#ff4f6d",splash:24,slow:0,armorBonus:0,hitList:[]})}}if(t.role==="ranged"||t.role==="summoner"||t.id==="boss_dragon"){const p=xf(i,t);if(p){if(t.vx=0,t.vy=0,t.attackCd<=0){t.attackCd=t.fireRate;const u=Math.atan2(p.y-t.y,p.x-t.x),h=t.id==="pyro_mage"||t.id==="boss_dragon",v=t.role==="summoner";i.projectiles.push({uid:i.nextUid++,fromPlayer:!1,kind:h?"fireball":v?"dark_bolt":"enemy_arrow",x:t.x,y:t.y,vx:Math.cos(u)*(h?115:v?130:145),vy:Math.sin(u)*(h?115:v?130:145),r:h?3.5:v?2.5:2,dmg:t.dmg,pierce:1,life:1.5,maxLife:1.5,color:h?"#ff7e33":v?"#b87aff":"#e2e8f0",splash:h?20:0,slow:0,armorBonus:0,hitList:[]})}return}}if(!t.flying&&t.role!=="sapper"){const p=[i.hero,...(i.coopPlayers||[]).map(u=>u.hero)];for(const u of p)if(u.alive&&Re(t.x,t.y,u.x,u.y)<=t.r+u.r+5){t.vx=0,t.vy=0,t.attackCd<=0&&(t.attackCd=t.fireRate,ws(i,t.dmg,u));return}}if(Re(t.x,t.y,a.x,a.y)<=t.r+26){t.vx=0,t.vy=0,t.attackCd<=0&&(t.attackCd=t.fireRate,bu(i,t.dmg));return}let o=0,l=0;if(t.flying){const p=t.isBoss?null:vf(i,t.x,t.y);if(p){if(Re(t.x,t.y,p.x,p.y)<=t.r+p.w*7+2){t.vx=0,t.vy=0,t.attackCd<=0&&(t.attackCd=t.fireRate,es(i,e,p,t.dmg,t.wallDmgMult,t),_t(i,p.x,p.y,3,"#b4c2d4",35,.2,2));return}const h=p.x-t.x,v=p.y-t.y,f=Math.hypot(h,v)||1;o=h/f,l=v/f}else{const u=a.x-t.x,h=a.y-t.y,v=Math.hypot(u,h)||1;o=u/v,l=h/v}}else if(t.role==="sapper"){const p=mf(i,t.x,t.y);if(p&&Re(t.x,t.y,p.x,p.y)<180){const u=p.x-t.x,h=p.y-t.y,v=Math.hypot(u,h)||1;o=u/v,l=h/v}else{const u=e.sampleDir(t.x,t.y,!1);o=u.vx,l=u.vy}}else if(t.role==="assassin"){const p=gf(i,t.x,t.y);if(p&&Re(t.x,t.y,p.x,p.y)<190){const u=p.x-t.x,h=p.y-t.y,v=Math.hypot(u,h)||1;o=u/v,l=h/v}else{const u=e.sampleDir(t.x,t.y,!1);o=u.vx,l=u.vy}}else if(t.role==="flanker"){const p=Sf(i,t.x,t.y,80);if(p){const u=p.x-t.x,h=p.y-t.y,v=Math.hypot(u,h)||1;o=u/v,l=h/v}else{const u=e.sampleDir(t.x,t.y,!1);o=u.vx,l=u.vy}}else{const p=t.role==="breaker"||t.role==="juggernaut"||t.role==="boss",u=e.sampleDir(t.x,t.y,p);o=u.vx,l=u.vy}const c=Se(t.x+o*s*n,4,Ft-4),d=Se(t.y+l*s*n,4,Ot-4);if(t.flying){const p=c+o*(t.r+2),u=d+l*(t.r+2),h=e.getBuildingAtWorld(p,u)||e.getBuildingAtWorld(t.x+o*(t.r+3),t.y+l*(t.r+3));if(h&&(h.id==="sky_wall"||h.antiAir)){t.vx=0,t.vy=0,t.attackCd<=0&&(t.attackCd=t.fireRate,es(i,e,h,t.dmg,t.wallDmgMult,t),_t(i,h.x,h.y,4,"#38bdf8",42,.24,2));return}}else{const p=c+o*(t.r+2),u=d+l*(t.r+2),h=e.getBuildingAtWorld(p,u)||e.getBuildingAtWorld(t.x+o*(t.r+3),t.y+l*(t.r+3));if(h&&We[h.id].blocksEnemies){if(t.vx=0,t.vy=0,t.role==="sapper"){pn(i,t.x,t.y,26,"#ff4f6d"),W("catapult");for(const v of[...i.buildings])Re(t.x,t.y,v.x,v.y)<=28&&es(i,e,v,t.dmg,1.3);t.hp=0;return}t.attackCd<=0&&(t.attackCd=t.fireRate,es(i,e,h,t.dmg,t.wallDmgMult,t),_t(i,h.x,h.y,3,"#b4c2d4",35,.2,2));return}}t.vx=o*s,t.vy=l*s,t.x=c,t.y=d,t.flying&&r.alive&&Re(t.x,t.y,r.x,r.y)<=t.r+r.r&&t.attackCd<=0&&(t.attackCd=t.fireRate,ws(i,t.dmg))}function yf(i,e,t){if(i.phase==="wave"){for(const s of i.activeWaves)if(s.spawnedCount<s.totalCount&&(s.spawnTimer-=t,s.spawnTimer<=0)){const r=s.queue[s.spawnedCount];s.spawnedCount+=1;const a=pf(r.flank);Po(i,r.enemyId,a.x,a.y,s.wave),s.spawnTimer=r.delay}}for(let s=i.enemies.length-1;s>=0;s--){const r=i.enemies[s];if(r.hp<=0){i.enemies.splice(s,1);continue}_f(i,e,r,t),r.hp<=0&&i.enemies.splice(s,1)}const n=i.enemies.length;for(let s=0;s<n;s++){const r=i.enemies[s];for(let a=s+1;a<Math.min(n,s+10);a++){const o=i.enemies[a],l=o.x-r.x,c=o.y-r.y,d=r.r+o.r,p=l*l+c*c;if(p>.01&&p<d*d){const u=Math.sqrt(p),h=(d-u)*.3,v=l/u,f=c/u;e.getBuildingAtWorld(r.x-v*h,r.y-f*h)||(r.x-=v*h,r.y-=f*h),e.getBuildingAtWorld(o.x+v*h,o.y+f*h)||(o.x+=v*h,o.y+=f*h)}}}if(i.phase==="wave"){for(let s=i.activeWaves.length-1;s>=0;s--){const r=i.activeWaves[s];r.spawnedCount>=r.totalCount&&!i.enemies.some(a=>a.waveNum===r.wave)&&(i.activeWaves.splice(s,1),af(i,r.wave,r.event==="blood_moon"))}i.activeWaves.length===0&&i.enemies.length===0&&of(i)}}class Mf{constructor(e,t,n){j(this,"codes",new Set);j(this,"mouseScreenX",0);j(this,"mouseScreenY",0);j(this,"mouseDownLeft",!1);j(this,"mouseInside",!1);j(this,"queued",{dash:!1,rally:!1,ult:!1,upgrades:!1,startWave:!1,autoWave:!1,demolish:!1,tacticalPause:!1,togglePaths:!1,batchUpgrade:!1,copyMode:!1,rotateBlueprint:!1,cycleCamera:!1,pause:!1,cancelBuild:!1,selectBuildSlot:null,leftClick:!1,leftRelease:!1,rightClick:!1,orbitDeltaX:0,orbitDeltaY:0,wheelDeltaY:0});j(this,"orbitButton",null);j(this,"orbitStartX",0);j(this,"orbitStartY",0);j(this,"orbitLastX",0);j(this,"orbitLastY",0);j(this,"orbitMoved",!1);j(this,"isTouch",!1);j(this,"stickActive",!1);j(this,"stickOriginX",0);j(this,"stickOriginY",0);j(this,"stickX",0);j(this,"stickY",0);j(this,"stickPointerId",null);j(this,"repairTouchTimer",0);this.stickEl=t,this.knobEl=n,window.addEventListener("keydown",s=>{Qe();const r=s.code;if(r==="Tab"){s.preventDefault(),s.repeat||(this.queued.upgrades=!0);return}if(!s.repeat)if(r==="Space")s.preventDefault(),this.queued.dash=!0;else if(r==="KeyE")this.queued.rally=!0;else if(r==="KeyR")this.queued.ult=!0;else if(r==="KeyU")this.queued.upgrades=!0;else if(r==="KeyG")this.queued.startWave=!0;else if(r==="KeyV")this.queued.autoWave=!0;else if(r==="KeyX")this.queued.demolish=!0;else if(r==="KeyP"||r==="KeyT")this.queued.tacticalPause=!0;else if(r==="KeyH")this.queued.togglePaths=!0;else if(r==="KeyB")this.queued.batchUpgrade=!0;else if(r==="KeyC")this.queued.copyMode=!0;else if(r==="KeyN")this.queued.rotateBlueprint=!0;else if(r==="KeyK")this.queued.cycleCamera=!0;else if(r==="Escape")this.queued.pause=!0;else{const a={Digit1:0,Digit2:1,Digit3:2,Digit4:3,Digit5:4,Digit6:5,Digit7:6,Digit8:7,Digit9:8,Digit0:9,Minus:10,Equal:11};r in a&&(this.queued.selectBuildSlot=a[r])}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(r)&&s.preventDefault(),this.codes.add(r)}),window.addEventListener("keyup",s=>{this.codes.delete(s.code)}),window.addEventListener("blur",()=>{this.codes.clear(),this.mouseDownLeft=!1,this.orbitButton=null,this.orbitMoved=!1,this.resetStick()}),e.addEventListener("contextmenu",s=>s.preventDefault()),e.addEventListener("wheel",s=>{(Math.abs(s.deltaY)>0||Math.abs(s.deltaX)>0)&&(s.preventDefault(),this.queued.rotateBlueprint=!0,this.queued.wheelDeltaY+=s.deltaY)},{passive:!1}),e.addEventListener("pointermove",s=>{if(this.mouseScreenX=s.clientX,this.mouseScreenY=s.clientY,this.mouseInside=!0,this.orbitButton!==null){const r=s.clientX-this.orbitLastX,a=s.clientY-this.orbitLastY;this.orbitLastX=s.clientX,this.orbitLastY=s.clientY,!this.orbitMoved&&Math.hypot(s.clientX-this.orbitStartX,s.clientY-this.orbitStartY)>5&&(this.orbitMoved=!0),this.orbitMoved&&(this.queued.orbitDeltaX+=r,this.queued.orbitDeltaY+=a)}if(s.pointerId===this.stickPointerId&&this.stickActive){const r=s.clientX-this.stickOriginX,a=s.clientY-this.stickOriginY,o=44,l=Math.hypot(r,a);if(l>4){const c=Math.min(o,l)/o;this.stickX=r/l*c,this.stickY=a/l*c}else this.stickX=0,this.stickY=0;this.updateStickDom()}}),e.addEventListener("pointerleave",()=>{this.mouseInside=!1,this.mouseDownLeft=!1}),e.addEventListener("pointerdown",s=>{if(Qe(),this.mouseScreenX=s.clientX,this.mouseScreenY=s.clientY,this.mouseInside=!0,s.pointerType==="touch"||s.pointerType==="pen"){this.isTouch=!0,document.body.classList.add("touch"),s.clientX<window.innerWidth*.45&&this.stickPointerId===null?(this.stickPointerId=s.pointerId,this.stickActive=!0,this.stickOriginX=s.clientX,this.stickOriginY=s.clientY,this.stickX=0,this.stickY=0,this.updateStickDom()):this.queued.leftClick=!0;return}s.button===0?(this.mouseDownLeft=!0,this.queued.leftClick=!0):(s.button===2||s.button===1)&&(this.orbitButton=s.button,this.orbitStartX=s.clientX,this.orbitStartY=s.clientY,this.orbitLastX=s.clientX,this.orbitLastY=s.clientY,this.orbitMoved=!1)}),window.addEventListener("pointerup",s=>{s.button===0&&(this.mouseDownLeft&&(this.queued.leftRelease=!0),this.mouseDownLeft=!1),this.orbitButton!==null&&s.button===this.orbitButton&&(s.button===2&&!this.orbitMoved&&(this.queued.rightClick=!0,this.queued.cancelBuild=!0),this.orbitButton=null,this.orbitMoved=!1),s.pointerId===this.stickPointerId&&this.resetStick()}),window.addEventListener("pointercancel",s=>{this.mouseDownLeft&&(this.queued.leftRelease=!0),this.mouseDownLeft=!1,this.orbitButton=null,this.orbitMoved=!1,s.pointerId===this.stickPointerId&&this.resetStick()})}resetStick(){this.stickPointerId=null,this.stickActive=!1,this.stickX=0,this.stickY=0,this.updateStickDom()}updateStickDom(){if(!(!this.stickEl||!this.knobEl)){if(!this.stickActive){this.stickEl.hidden=!0;return}this.stickEl.hidden=!1,this.stickEl.style.transform=`translate(${Math.round(this.stickOriginX-50)}px, ${Math.round(this.stickOriginY-50)}px)`,this.knobEl.style.transform=`translate(${Math.round(this.stickX*32)}px, ${Math.round(this.stickY*32)}px)`}}pulseRepair(){this.repairTouchTimer=.6}isRepairHeld(e=0){return this.repairTouchTimer>0?(this.repairTouchTimer=Math.max(0,this.repairTouchTimer-e),!0):this.codes.has("KeyF")}getMoveVector(){let e=0,t=0;(this.codes.has("KeyA")||this.codes.has("ArrowLeft"))&&(e-=1),(this.codes.has("KeyD")||this.codes.has("ArrowRight"))&&(e+=1),(this.codes.has("KeyW")||this.codes.has("ArrowUp"))&&(t-=1),(this.codes.has("KeyS")||this.codes.has("ArrowDown"))&&(t+=1),this.stickActive&&(e+=this.stickX,t+=this.stickY);const n=Math.hypot(e,t);return n>1&&(e/=n,t/=n),{x:e,y:t}}trigger(e){this.queued[e]=!0}consumeActions(){const e={...this.queued};return this.queued.dash=!1,this.queued.rally=!1,this.queued.ult=!1,this.queued.upgrades=!1,this.queued.startWave=!1,this.queued.autoWave=!1,this.queued.demolish=!1,this.queued.tacticalPause=!1,this.queued.togglePaths=!1,this.queued.batchUpgrade=!1,this.queued.copyMode=!1,this.queued.rotateBlueprint=!1,this.queued.cycleCamera=!1,this.queued.pause=!1,this.queued.cancelBuild=!1,this.queued.selectBuildSlot=null,this.queued.leftClick=!1,this.queued.leftRelease=!1,this.queued.rightClick=!1,this.queued.orbitDeltaX=0,this.queued.orbitDeltaY=0,this.queued.wheelDeltaY=0,e}}class bf{constructor(){j(this,"ws",null);j(this,"connected",!1);j(this,"connecting",!1);j(this,"myId","");j(this,"lanIps",[]);j(this,"lanPort",Number(location.port)||5173);j(this,"rooms",[]);j(this,"room",null);j(this,"listeners",{});j(this,"lastBuildingSig","")}get role(){return!this.room||!this.myId?"none":this.room.hostId===this.myId?"host":"client"}get isMultiplayer(){return!!(this.room&&this.room.inGame&&this.connected)}get lanUrls(){const e=this.lanPort||Number(location.port)||5173,t=this.lanIps.map(n=>`http://${n}:${e}`);return t.length===0&&location.hostname&&location.hostname!=="localhost"&&location.hostname!=="127.0.0.1"&&t.push(location.origin),t}connect(){var n,s,r,a;if(this.connected||this.connecting)return;this.connecting=!0,(s=(n=this.listeners).onLobbyChange)==null||s.call(n);const t=`${location.protocol==="https:"?"wss:":"ws:"}//${location.host}/ws`;try{const o=new WebSocket(t);this.ws=o,o.addEventListener("open",()=>{var l,c;this.connected=!0,this.connecting=!1,(c=(l=this.listeners).onLobbyChange)==null||c.call(l)}),o.addEventListener("message",l=>{if(typeof l.data!="string")return;let c;try{c=JSON.parse(l.data)}catch{return}this.handleServerMessage(c)}),o.addEventListener("close",()=>{var c,d,p,u,h;const l=this.role==="client"&&((c=this.room)==null?void 0:c.inGame);this.connected=!1,this.connecting=!1,this.ws=null,this.room=null,this.rooms=[],l&&((p=(d=this.listeners).onHostDisconnected)==null||p.call(d,"Connexion au serveur LAN interrompue.")),(h=(u=this.listeners).onLobbyChange)==null||h.call(u)}),o.addEventListener("error",()=>{var l,c;this.connecting=!1,(c=(l=this.listeners).onLobbyChange)==null||c.call(l)})}catch{this.connecting=!1,(a=(r=this.listeners).onLobbyChange)==null||a.call(r)}}disconnect(){var e,t;if(this.ws){try{this.ws.close()}catch{}this.ws=null}this.connected=!1,this.connecting=!1,this.room=null,this.rooms=[],this.lastBuildingSig="",(t=(e=this.listeners).onLobbyChange)==null||t.call(e)}send(e){if(!(!this.ws||this.ws.readyState!==WebSocket.OPEN))try{this.ws.send(JSON.stringify(e))}catch{}}handleServerMessage(e){var t,n,s,r,a,o,l,c,d,p,u,h,v,f,m,g,S,M,_,E,y,x,b,A;switch(e.type){case"welcome":this.myId=String(e.id||""),this.lanIps=Array.isArray(e.ips)?e.ips:[],typeof e.port=="number"&&(this.lanPort=e.port),this.rooms=Array.isArray(e.rooms)?e.rooms:[],(n=(t=this.listeners).onLobbyChange)==null||n.call(t);break;case"rooms_list":this.rooms=Array.isArray(e.rooms)?e.rooms:[],(r=(s=this.listeners).onLobbyChange)==null||r.call(s);break;case"room_state":this.room=e.room||null,(o=(a=this.listeners).onLobbyChange)==null||o.call(a);break;case"room_left":this.room=null,(c=(l=this.listeners).onLobbyChange)==null||c.call(l);break;case"error":(p=(d=this.listeners).onError)==null||p.call(d,String(e.message||"Erreur réseau LAN"));break;case"game_start":this.room=e.room||this.room,this.lastBuildingSig="",this.room&&((h=(u=this.listeners).onGameStart)==null||h.call(u,this.room));break;case"remote_input":(f=(v=this.listeners).onRemoteInput)==null||f.call(v,String(e.playerId||""),e.input);break;case"remote_cmd":(g=(m=this.listeners).onRemoteCmd)==null||g.call(m,String(e.playerId||""),e.cmd);break;case"player_left":(M=(S=this.listeners).onPlayerLeft)==null||M.call(S,String(e.playerId||""));break;case"host_disconnected":this.room=null,(E=(_=this.listeners).onHostDisconnected)==null||E.call(_,String(e.reason||"L’hôte a quitté la partie.")),(x=(y=this.listeners).onLobbyChange)==null||x.call(y);break;case"snapshot":(A=(b=this.listeners).onSnapshot)==null||A.call(b,e.data);break}}requestRooms(){this.send({type:"list_rooms"})}createRoom(e,t,n){this.send({type:"create_room",name:e,heroClass:t,difficulty:n})}joinRoom(e,t,n){this.send({type:"join_room",code:e,name:t,heroClass:n})}updatePlayer(e,t){this.send({type:"update_player",name:e,heroClass:t})}updateRoomDifficulty(e){this.send({type:"update_room",difficulty:e})}leaveRoom(){var e,t;this.send({type:"leave_room"}),this.room=null,this.lastBuildingSig="",(t=(e=this.listeners).onLobbyChange)==null||t.call(e)}startGame(){this.send({type:"start_game"})}sendInput(e){this.send({type:"input",input:e})}sendCmd(e){this.send({type:"cmd",cmd:e})}sendSnapshot(e){if(this.role!=="host"||!this.room)return;const t=this.room.players.find(r=>r.id===this.myId),n=[{id:this.myId,name:e.localPlayerName||(t==null?void 0:t.name)||"Hôte",color:e.localPlayerColor||(t==null?void 0:t.color)||"#4ef2e8",heroClass:e.heroClass,hero:e.hero},...(e.coopPlayers||[]).map(r=>({id:r.id,name:r.name,color:r.color,heroClass:r.heroClass,hero:r.hero}))],s={time:e.time,phase:e.phase,prepTimer:e.prepTimer,wave:e.wave,clearedWaves:e.clearedWaves,difficulty:e.difficulty,playerCount:e.playerCount||n.length,stone:e.stone,crystal:e.crystal,autoWave:e.autoWave,gameSpeed:e.gameSpeed,tacticalPause:e.tacticalPause,paused:e.paused,modal:e.modal==="over"?"over":"none",citadel:e.citadel,heroes:n,buildings:e.buildings,nodes:e.nodes,enemies:e.enemies,projectiles:e.projectiles,pickups:e.pickups,zonesFx:e.zonesFx,summonedTurrets:e.summonedTurrets,arcs:e.arcs,upgrades:e.upgrades,stats:e.stats,activeWaves:e.activeWaves.map(r=>({wave:r.wave,title:r.title,flanks:r.flanks,totalCount:r.totalCount,spawnedCount:r.spawnedCount,isBossWave:r.isBossWave,event:r.event})),nextWavePlan:{wave:e.nextWavePlan.wave,title:e.nextWavePlan.title,flanks:e.nextWavePlan.flanks,totalCount:e.nextWavePlan.totalCount,spawnedCount:e.nextWavePlan.spawnedCount,isBossWave:e.nextWavePlan.isBossWave,event:e.nextWavePlan.event}};this.send({type:"snapshot",data:s})}applySnapshot(e,t,n){e.time=t.time,e.phase=t.phase,e.prepTimer=t.prepTimer,e.wave=t.wave,e.clearedWaves=t.clearedWaves,e.difficulty=t.difficulty,e.playerCount=t.playerCount,e.stone=t.stone,e.crystal=t.crystal,e.autoWave=t.autoWave,e.gameSpeed=t.gameSpeed,e.tacticalPause=t.tacticalPause,t.modal==="over"&&(e.modal="over",e.paused=!0),e.citadel=t.citadel;const s=t.heroes.find(a=>a.id===this.myId)||t.heroes[0];s&&(e.hero=s.hero,e.heroClass=s.heroClass,e.localPlayerId=s.id,e.localPlayerName=s.name,e.localPlayerColor=s.color),e.coopPlayers=t.heroes.filter(a=>a.id!==(s==null?void 0:s.id)).map(a=>({id:a.id,name:a.name,color:a.color,heroClass:a.heroClass,hero:a.hero,moveX:0,moveY:0,repairHeld:!1})),e.buildings=t.buildings,e.nodes=t.nodes,e.enemies=t.enemies,e.projectiles=t.projectiles,e.pickups=t.pickups,e.zonesFx=t.zonesFx,e.summonedTurrets=t.summonedTurrets,e.arcs=t.arcs,e.upgrades=t.upgrades,e.stats=t.stats,e.activeWaves=t.activeWaves.map(a=>({...a,queue:[],spawnTimer:0})),e.nextWavePlan={...t.nextWavePlan,queue:[],spawnTimer:0};const r=t.buildings.map(a=>`${a.uid}:${a.gx},${a.gy}`).join("|");r!==this.lastBuildingSig&&(this.lastBuildingSig=r,n.recompute(e))}}const ne=new bf;class kf{constructor(){j(this,"openDist",new Float32Array(Le*He));j(this,"siegeDist",new Float32Array(Le*He));j(this,"cellBuildingUid",new Int32Array(Le*He));j(this,"cellCitadel",new Uint8Array(Le*He));j(this,"cellNode",new Uint8Array(Le*He));j(this,"version",0);j(this,"buildingByUid",new Map);for(let e=0;e<ht;e++)for(let t=0;t<ht;t++){const n=_n+t,s=ln+e;this.cellCitadel[s*Le+n]=1}}getBuildingAtGrid(e,t){if(e<0||t<0||e>=Le||t>=He)return;const n=this.cellBuildingUid[t*Le+e];return n>0?this.buildingByUid.get(n):void 0}getBuildingAtWorld(e,t){return this.getBuildingAtGrid(Math.floor(e/U),Math.floor(t/U))}isCitadelCell(e,t){return e<0||t<0||e>=Le||t>=He?!1:this.cellCitadel[t*Le+e]===1}isHeroBlockedAt(e,t){const n=Math.floor(e/U),s=Math.floor(t/U);return n<0||s<0||n>=Le||s>=He}recompute(e){this.cellBuildingUid.fill(0),this.cellNode.fill(0),this.buildingByUid.clear();for(const t of e.nodes)t.gx>=0&&t.gx<Le&&t.gy>=0&&t.gy<He&&(this.cellNode[t.gy*Le+t.gx]=1);for(const t of e.buildings){this.buildingByUid.set(t.uid,t);for(let n=0;n<t.h;n++)for(let s=0;s<t.w;s++){const r=t.gx+s,a=t.gy+n;r>=0&&r<Le&&a>=0&&a<He&&(this.cellBuildingUid[a*Le+r]=t.uid)}}this.runDijkstra(this.openDist,!1),this.runDijkstra(this.siegeDist,!0),e.pathDirty=!1,this.version+=1}cellCost(e,t){if(this.cellCitadel[e]===1)return 1;const n=this.cellBuildingUid[e];if(n>0){const s=this.buildingByUid.get(n);if(s)return We[s.id].blocksEnemies?s.id==="wall"||s.id==="gate"?t?2.4:20:s.id==="obsidian_wall"?t?3.2:24:t?5:15:1.1}return this.cellNode[e]===1?1.6:1}runDijkstra(e,t){const n=Le*He;e.fill(1e9);const s=new Int32Array(n*4),r=new Float32Array(n*4);let a=0;const o=(d,p)=>{let u=a++;for(s[u]=d,r[u]=p;u>0;){const h=u-1>>1;if(r[h]<=r[u])break;const v=s[h],f=r[h];s[h]=s[u],r[h]=r[u],s[u]=v,r[u]=f,u=h}},l=()=>{const d=s[0],p=r[0];if(a-=1,a>0){s[0]=s[a],r[0]=r[a];let u=0;for(;;){let h=u;const v=u*2+1,f=u*2+2;if(v<a&&r[v]<r[h]&&(h=v),f<a&&r[f]<r[h]&&(h=f),h===u)break;const m=s[u],g=r[u];s[u]=s[h],r[u]=r[h],s[h]=m,r[h]=g,u=h}}return{idx:d,cost:p}};for(let d=0;d<ht;d++)for(let p=0;p<ht;p++){const u=(ln+d)*Le+(_n+p);e[u]=0,o(u,0)}const c=[[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.414],[-1,1,1.414],[1,-1,1.414],[-1,-1,1.414]];for(;a>0;){const d=l();if(d.cost>e[d.idx])continue;const p=d.idx%Le,u=Math.floor(d.idx/Le);for(let h=0;h<c.length;h++){const v=p+c[h][0],f=u+c[h][1];if(v<0||f<0||v>=Le||f>=He)continue;const m=f*Le+v,g=this.cellCost(m,t)*c[h][2],S=d.cost+g;S<e[m]&&(e[m]=S,o(m,S))}}}sampleDir(e,t,n){const s=n?this.siegeDist:this.openDist,r=Math.max(0,Math.min(Le-1,Math.floor(e/U))),a=Math.max(0,Math.min(He-1,Math.floor(t/U)));let o=r,l=a,c=s[a*Le+r];for(let f=-1;f<=1;f++)for(let m=-1;m<=1;m++){if(m===0&&f===0)continue;const g=r+m,S=a+f;if(g<0||S<0||g>=Le||S>=He)continue;if(m!==0&&f!==0){const _=this.getBuildingAtGrid(g,a),E=this.getBuildingAtGrid(r,S);if(_&&We[_.id].blocksEnemies||E&&We[E.id].blocksEnemies)continue}const M=s[S*Le+g];M<c&&(c=M,o=g,l=S)}const d=(o+.5)*U,p=(l+.5)*U,u=d-e,h=p-t,v=Math.hypot(u,h);if(v<.01){const f=(_n+ht*.5)*U,m=(ln+ht*.5)*U,g=Math.hypot(f-e,m-t)||1;return{vx:(f-e)/g,vy:(m-t)/g}}return{vx:u/v,vy:h/v}}tracePath(e,t,n){const s=n?this.siegeDist:this.openDist;let r=Math.max(0,Math.min(Le-1,e)),a=Math.max(0,Math.min(He-1,t));const o=[];for(let l=0;l<90&&(o.push({x:(r+.5)*U,y:(a+.5)*U}),this.cellCitadel[a*Le+r]!==1);l++){let c=r,d=a,p=s[a*Le+r];for(let u=-1;u<=1;u++)for(let h=-1;h<=1;h++){if(h===0&&u===0)continue;const v=r+h,f=a+u;if(v<0||f<0||v>=Le||f>=He)continue;if(h!==0&&u!==0){const g=this.getBuildingAtGrid(v,a),S=this.getBuildingAtGrid(r,f);if(g&&We[g.id].blocksEnemies||S&&We[S.id].blocksEnemies)continue}const m=s[f*Le+v];m<p&&(p=m,c=v,d=f)}if(c===r&&d===a)break;r=c,a=d}return o}}const ma=4;function Ia(i,e){const t=document.createElement("canvas");return t.width=i,t.height=e,t}function On(i,e){let t=Math.imul(i,374761393)+Math.imul(e,668265263);return t=(t^t>>>13)*1274126177,((t^t>>>16)>>>0)/4294967296}function za(i,e){const t=Math.floor(i),n=Math.floor(e),s=i-t,r=e-n,a=s*s*(3-2*s),o=r*r*(3-2*r),l=On(t,n),c=On(t+1,n),d=On(t,n+1),p=On(t+1,n+1);return l+(c-l)*a+(d-l)*o+(l-c-d+p)*a*o}function Ef(i,e){return za(i,e)*.58+za(i*2.1,e*2.1)*.28+za(i*4.3,e*4.3)*.14}let Va=null,Wa=null;function Tu(){const e=Ia(128,128),t=e.getContext("2d"),n=t.createImageData(128,128),s=n.data;for(let r=0;r<128;r++)for(let a=0;a<128;a++){const o=Math.cos(a/128*Math.PI*2),l=Math.sin(a/128*Math.PI*2),c=Math.cos(r/128*Math.PI*2),d=Math.sin(r/128*Math.PI*2),p=Ef(o*2.2+c*1.1+10,l*2.2+d*1.1+10),u=(On(a,r*2)-.5)*14,h=(r*128+a)*4;s[h]=Se(Math.round(26+p*18+u*.4),14,58),s[h+1]=Se(Math.round(44+p*28+u),28,86),s[h+2]=Se(Math.round(32+p*16+u*.5),18,62),s[h+3]=255}t.putImageData(n,0,0);for(let r=0;r<140;r++){const a=On(r,1)*128,o=On(r,2)*128;t.strokeStyle=r%3===0?"rgba(94, 168, 112, 0.35)":"rgba(20, 36, 26, 0.38)",t.lineWidth=1,t.beginPath(),t.moveTo(a,o),t.lineTo(a+(On(r,3)-.5)*4,o-3-On(r,4)*3),t.stroke()}return e}function Cu(){const e=Ia(64,64),t=e.getContext("2d");t.fillStyle="#252e3a",t.fillRect(0,0,64,64);const n=4,s=4,r=64/n,a=64/s;for(let o=0;o<n;o++){const l=o%2*(a*.5);for(let c=-1;c<=s;c++){const d=c*a+l+1.5,p=o*r+1.5,u=a-3,h=r-3,v=(On(c+10,o+20)-.5)*18,f=Se(Math.round(58+v),40,82),m=Se(Math.round(70+v),50,96),g=Se(Math.round(86+v),62,114),S=t.createLinearGradient(d,p,d+u,p+h);S.addColorStop(0,`rgb(${f+12}, ${m+12}, ${g+14})`),S.addColorStop(1,`rgb(${f-10}, ${m-10}, ${g-8})`),t.fillStyle=S,t.beginPath(),t.roundRect(d,p,u,h,3),t.fill(),t.strokeStyle="rgba(180, 198, 220, 0.22)",t.lineWidth=.8,t.stroke()}}return e}function wf(){if(Va)return Va;const i=2,e=Ft*i,t=Ot*i,n=Ia(e,t),s=n.getContext("2d"),r=Tu(),a=Cu(),o=s.createPattern(r,"repeat");s.fillStyle=o,s.fillRect(0,0,e,t);for(let h=0;h<28;h++){const v=On(h,10)*e,f=On(h,20)*t,m=(45+On(h,30)*85)*i,g=s.createRadialGradient(v,f,4,v,f,m);g.addColorStop(0,h%2===0?"rgba(62, 110, 74, 0.16)":"rgba(14, 24, 18, 0.18)"),g.addColorStop(1,"rgba(0, 0, 0, 0)"),s.fillStyle=g,s.beginPath(),s.arc(v,f,m,0,Math.PI*2),s.fill()}const l=U*i;s.fillStyle="#172022",s.fillRect(0,0,e,l),s.fillRect(0,t-l,e,l),s.fillRect(0,0,l,t),s.fillRect(e-l,0,l,t),s.strokeStyle="rgba(78, 110, 148, 0.45)",s.lineWidth=2,s.strokeRect(l+.5,l+.5,e-l*2-1,t-l*2-1);const c=(_n-1)*U*i,d=(ln-1)*U*i,p=(ht+2)*U*i,u=(ht+2)*U*i;return s.fillStyle="rgba(6, 10, 16, 0.45)",s.beginPath(),s.roundRect(c-4,d-4,p+8,u+8,8),s.fill(),s.save(),s.beginPath(),s.roundRect(c,d,p,u,6),s.clip(),s.fillStyle=s.createPattern(a,"repeat"),s.fillRect(c,d,p,u),s.restore(),s.strokeStyle="#6d8299",s.lineWidth=2.5,s.beginPath(),s.roundRect(c,d,p,u,6),s.stroke(),s.strokeStyle="rgba(78, 242, 232, 0.25)",s.lineWidth=1.5,s.beginPath(),s.arc(c+p*.5,d+u*.5,p*.42,0,Math.PI*2),s.stroke(),Va=n,n}function Tf(){if(Wa)return Wa;const i=2,e=15*U*i,t=12*U*i,n=Ia(e,t),s=n.getContext("2d");s.fillStyle=s.createPattern(Tu(),"repeat"),s.fillRect(0,0,e,t);const r=5*U*i,a=4*U*i,o=5*U*i,l=5*U*i;return s.save(),s.beginPath(),s.roundRect(r,a,o,l,6),s.clip(),s.fillStyle=s.createPattern(Cu(),"repeat"),s.fillRect(r,a,o,l),s.restore(),s.strokeStyle="#6d8299",s.lineWidth=2,s.beginPath(),s.roundRect(r,a,o,l,6),s.stroke(),Wa=n,n}const wn=Math.PI*2;function Au(i,e){const t=document.createElement("canvas");return t.width=i,t.height=e,t}function Cf(i){const e=Au(i.width,i.height),t=e.getContext("2d");return t.drawImage(i,0,0),t.globalCompositeOperation="source-atop",t.fillStyle="rgba(255, 255, 255, 0.88)",t.fillRect(0,0,e.width,e.height),e}function ni(i,e,t,n,s,r){const a=Math.min(r,n*.5,s*.5);i.beginPath(),i.moveTo(e+a,t),i.lineTo(e+n-a,t),i.quadraticCurveTo(e+n,t,e+n,t+a),i.lineTo(e+n,t+s-a),i.quadraticCurveTo(e+n,t+s,e+n-a,t+s),i.lineTo(e+a,t+s),i.quadraticCurveTo(e,t+s,e,t+s-a),i.lineTo(e,t+a),i.quadraticCurveTo(e,t,e+a,t),i.closePath()}function Lt(i,e,t,n,s,r="rgba(0,0,0,0)"){const a=i.createRadialGradient(e,t,.5,e,t,n);a.addColorStop(0,s),a.addColorStop(1,r),i.fillStyle=a,i.beginPath(),i.arc(e,t,n,0,wn),i.fill()}function st(i,e,t,n,s,r,a){const o=i.createRadialGradient(e-n*.32,t-n*.32,n*.1,e,t,n);o.addColorStop(0,s),o.addColorStop(.55,r),o.addColorStop(1,a),i.fillStyle=o,i.beginPath(),i.arc(e,t,n,0,wn),i.fill()}function lt(i,e,t,n,s,r=6,a="#9fb0c5",o="#667890",l="#3b485c"){const c=i.createLinearGradient(e,t,e,t+s);c.addColorStop(0,a),c.addColorStop(.45,o),c.addColorStop(1,l),ni(i,e,t,n,s,r),i.fillStyle=c,i.fill(),i.strokeStyle="rgba(10, 15, 26, 0.72)",i.lineWidth=2,i.stroke(),i.strokeStyle="rgba(255, 255, 255, 0.22)",i.lineWidth=1.5,i.beginPath(),i.moveTo(e+r,t+1.5),i.lineTo(e+n-r,t+1.5),i.stroke()}function An(i,e,t,n,s,r,a,o,l){i.save(),i.translate(e,t),i.rotate(r),i.beginPath(),i.moveTo(0,-s*.65),i.lineTo(-n*.5,0),i.lineTo(-n*.28,s*.45),i.lineTo(0,s*.45),i.closePath(),i.fillStyle=a,i.fill(),i.beginPath(),i.moveTo(0,-s*.65),i.lineTo(n*.5,0),i.lineTo(n*.28,s*.45),i.lineTo(0,s*.45),i.closePath(),i.fillStyle=o,i.fill(),i.beginPath(),i.moveTo(0,-s*.65),i.lineTo(n*.5,0),i.lineTo(n*.28,s*.45),i.lineTo(-n*.28,s*.45),i.lineTo(-n*.5,0),i.closePath(),i.strokeStyle=l,i.lineWidth=1.6,i.stroke(),i.restore()}function Af(i,e,t){const n=e*.5,s=t*.5;Lt(i,n,s,e*.48,"rgba(78, 242, 232, 0.22)"),lt(i,14,16,e-28,t-28,18,"#7e90a8","#526278","#2c3648");const r=[[28,30],[e-28,30],[28,t-28],[e-28,t-28]];for(const[a,o]of r)st(i,a,o,20,"#b5c5d8","#687990","#2d3748"),i.strokeStyle="rgba(10,15,26,0.7)",i.lineWidth=2,i.stroke(),st(i,a,o,10,"#f5d27a","#c98b2e","#6d4410");lt(i,42,40,e-84,t-80,14,"#b8c8dc","#74869e","#3c495e"),i.strokeStyle="#ffbe3b",i.lineWidth=3,ni(i,50,48,e-100,t-96,10),i.stroke(),i.fillStyle="#182132",ni(i,n-18,t-56,36,34,14),i.fill(),i.strokeStyle="#c98b2e",i.lineWidth=2.5,i.stroke(),Lt(i,n,s-6,48,"rgba(78, 242, 232, 0.55)"),st(i,n,s-4,24,"#e0fffd","#4ef2e8","#10626d"),An(i,n,s-10,26,46,0,"#e6ffff","#4ef2e8","#0e505a"),An(i,n-14,s-2,12,24,-.35,"#c8fffc","#38bdf8","#0e4960"),An(i,n+14,s-2,12,24,.35,"#c8fffc","#38bdf8","#0e4960")}function Rf(i,e,t,n){const s=t*.5,r=n*.5;switch(i){case"wall":{lt(e,5,8,t-10,n-14,7,"#b5c4d6","#728399","#3f4c60"),e.strokeStyle="rgba(15,23,42,0.35)",e.lineWidth=1.5,e.beginPath(),e.moveTo(7,n*.44),e.lineTo(t-7,n*.44),e.moveTo(7,n*.7),e.lineTo(t-7,n*.7),e.moveTo(t*.5,10),e.lineTo(t*.5,n*.44),e.moveTo(t*.32,n*.44),e.lineTo(t*.32,n*.7),e.moveTo(t*.68,n*.44),e.lineTo(t*.68,n*.7),e.stroke();for(const a of[7,25,43])lt(e,a,4,14,11,3,"#cbd8e8","#8a9cb3","#526175");break}case"gate":{lt(e,5,8,t-10,n-14,7,"#a8b7c9","#67778c","#394659");const a=e.createLinearGradient(14,16,14,n-10);a.addColorStop(0,"#c0824e"),a.addColorStop(.5,"#8f5932"),a.addColorStop(1,"#573318"),ni(e,14,16,t-28,n-24,10),e.fillStyle=a,e.fill(),e.strokeStyle="#25150a",e.lineWidth=2,e.stroke(),e.strokeStyle="#cbd5e1",e.lineWidth=2.5,e.beginPath(),e.moveTo(s,17),e.lineTo(s,n-9),e.moveTo(15,28),e.lineTo(t-15,28),e.moveTo(15,42),e.lineTo(t-15,42),e.stroke();break}case"obsidian_wall":{lt(e,4,8,t-8,n-14,7,"#584c7d","#2f2747","#141022"),Lt(e,s,r,22,"rgba(184, 122, 255, 0.32)"),e.strokeStyle="#c084fc",e.lineWidth=2.2,e.beginPath(),e.moveTo(16,18),e.lineTo(28,30),e.lineTo(22,46),e.moveTo(48,20),e.lineTo(36,34),e.lineTo(44,48),e.stroke();for(const a of[11,27,43])An(e,a+4,10,10,14,0,"#7c69b5","#3e3361","#0e0a1a");break}case"sky_wall":{lt(e,5,18,t-10,n-24,7,"#a7bcd4","#637894","#314056"),Lt(e,s,16,26,"rgba(56, 189, 248, 0.45)");for(const a of[14,t-14])lt(e,a-5,8,10,22,4,"#cbd5e1","#64748b","#1e293b"),st(e,a,10,5.5,"#ffffff","#38bdf8","#0284c7");e.strokeStyle="#7ce8ff",e.lineWidth=3,e.beginPath(),e.moveTo(14,10),e.quadraticCurveTo(s,3,t-14,10),e.stroke(),e.strokeStyle="#ffffff",e.lineWidth=1.2,e.stroke();break}case"spike_trap":{lt(e,8,10,t-16,n-20,6,"#718096","#4a5568","#1a202c");const a=[[20,22],[44,22],[32,32],[20,44],[44,44]];for(const[o,l]of a){e.beginPath(),e.moveTo(o,l-9),e.lineTo(o+5.5,l+4),e.lineTo(o-5.5,l+4),e.closePath();const c=e.createLinearGradient(o-5,l-9,o+5,l+4);c.addColorStop(0,"#f8fafc"),c.addColorStop(.5,"#94a3b8"),c.addColorStop(1,"#334155"),e.fillStyle=c,e.fill(),e.strokeStyle="#0f172a",e.lineWidth=1.3,e.stroke()}break}case"rune_mine":{Lt(e,s,r,26,"rgba(255, 79, 109, 0.35)"),st(e,s,r,21,"#a0aec0","#475569","#1e293b"),e.strokeStyle="#0f172a",e.lineWidth=2,e.stroke(),st(e,s,r,11,"#ffd1dc","#ff4f6d","#881337"),e.strokeStyle="#fda4af",e.lineWidth=1.6,e.beginPath(),e.arc(s,r,15,0,wn),e.stroke();break}case"archer_tower":{lt(e,11,22,t-22,n-27,7,"#b4c2d4","#6f7f94","#394659"),e.beginPath(),e.moveTo(s,6),e.lineTo(t-7,27),e.lineTo(7,27),e.closePath();const a=e.createLinearGradient(s,6,s,27);a.addColorStop(0,"#5ef28c"),a.addColorStop(.4,"#249454"),a.addColorStop(1,"#14532d"),e.fillStyle=a,e.fill(),e.strokeStyle="#091a10",e.lineWidth=2,e.stroke(),ni(e,s-3,33,6,15,3),e.fillStyle="#0f172a",e.fill();break}case"ballista":{lt(e,9,20,t-18,n-26,8,"#aebcc9","#64748b","#334155"),e.strokeStyle="#c0824e",e.lineWidth=5,e.lineCap="round",e.beginPath(),e.moveTo(11,26),e.quadraticCurveTo(s,12,t-11,26),e.stroke(),e.strokeStyle="#e2e8f0",e.lineWidth=1.5,e.beginPath(),e.moveTo(11,26),e.lineTo(s,36),e.lineTo(t-11,26),e.stroke(),e.strokeStyle="#ffbe3b",e.lineWidth=3.5,e.beginPath(),e.moveTo(s,44),e.lineTo(s,10),e.stroke(),e.fillStyle="#f8fafc",e.beginPath(),e.moveTo(s,5),e.lineTo(s+5,14),e.lineTo(s-5,14),e.closePath(),e.fill();break}case"flak_tower":{lt(e,9,24,t-18,n-30,8,"#94a3b8","#475569","#1e293b"),st(e,s,32,14,"#cbd5e1","#64748b","#1e293b");for(const a of[-7,7])e.save(),e.translate(s+a,26),e.rotate(a<0?-.18:.18),lt(e,-3.5,-18,7,22,2,"#e2e8f0","#64748b","#1e293b"),e.restore();st(e,s,32,5,"#e0f2fe","#38bdf8","#0369a1");break}case"arcane_tower":{Lt(e,s,18,26,"rgba(184, 122, 255, 0.5)"),lt(e,14,24,t-28,n-30,8,"#a795c7","#5a4482","#261842"),e.strokeStyle="#d8b4fe",e.lineWidth=2,e.beginPath(),e.ellipse(s,18,16,6,.25,0,wn),e.stroke(),st(e,s,18,10,"#ffffff","#c084fc","#6b21a8");break}case"frost_tower":{Lt(e,s,24,28,"rgba(124, 232, 255, 0.45)"),lt(e,13,34,t-26,n-40,7,"#bae6fd","#5b8fb9","#1e3a5f"),An(e,s,23,18,34,0,"#f0f9ff","#7ce8ff","#0369a1"),An(e,s-12,30,10,20,-.35,"#e0f2fe","#38bdf8","#0c4a6e"),An(e,s+12,30,10,20,.35,"#e0f2fe","#38bdf8","#0c4a6e");break}case"alch_mortar":{Lt(e,s,22,24,"rgba(163, 230, 53, 0.42)"),lt(e,10,32,t-20,n-38,8,"#9ca3af","#4b5563","#1f2937"),st(e,s,28,16,"#64748b","#334155","#0f172a"),st(e,s,25,11,"#ecfccb","#a3e635","#3f6212"),st(e,s-4,22,3,"#ffffff","#d9f99d","#84cc16"),st(e,s+5,26,2.5,"#ffffff","#d9f99d","#84cc16");break}case"solar_tower":{Lt(e,s,18,28,"rgba(255, 224, 102, 0.55)"),lt(e,15,28,t-30,n-34,8,"#fde68a","#b4781c","#5c3807"),e.strokeStyle="#ffe066",e.lineWidth=2.2;for(let a=0;a<8;a++){const o=a*wn/8;e.beginPath(),e.moveTo(s+Math.cos(o)*12,18+Math.sin(o)*12),e.lineTo(s+Math.cos(o)*17,18+Math.sin(o)*17),e.stroke()}st(e,s,18,11,"#ffffff","#ffe066","#d97706");break}case"tesla_spire":{Lt(e,s,16,26,"rgba(56, 189, 248, 0.52)"),lt(e,14,34,t-28,n-40,7,"#94a3b8","#475569","#1e293b");for(const a of[24,31,38])e.fillStyle="#d97706",ni(e,s-13,a,26,4.5,2),e.fill(),e.strokeStyle="#38bdf8",e.lineWidth=1.2,e.stroke();st(e,s,15,9.5,"#ffffff","#38bdf8","#0369a1");break}case"quarry":{lt(e,8,26,t-16,n-32,7,"#cbd5e1","#7c8ea3","#3b485c"),e.strokeStyle="#b07240",e.lineWidth=4.5,e.lineCap="round",e.beginPath(),e.moveTo(16,48),e.lineTo(24,14),e.lineTo(48,20),e.stroke(),e.strokeStyle="#e2e8f0",e.lineWidth=1.6,e.beginPath(),e.moveTo(46,20),e.lineTo(46,36),e.stroke(),lt(e,37,34,18,14,3,"#e2e8f0","#94a3b8","#475569");break}case"crystal_rig":{Lt(e,s,r-4,26,"rgba(78, 242, 232, 0.42)"),lt(e,10,30,t-20,n-36,7,"#94a3b8","#475569","#1e293b"),e.strokeStyle="#ffbe3b",e.lineWidth=3.5,e.beginPath(),e.moveTo(14,48),e.lineTo(s,12),e.lineTo(t-14,48),e.stroke(),An(e,s,26,16,28,0,"#e6ffff","#4ef2e8","#0e7490");break}case"war_banner":{Lt(e,s,22,24,"rgba(255, 126, 51, 0.36)"),lt(e,14,42,t-28,16,5,"#cbd5e1","#64748b","#1e293b"),e.strokeStyle="#fde68a",e.lineWidth=4,e.beginPath(),e.moveTo(s,44),e.lineTo(s,8),e.stroke(),e.beginPath(),e.moveTo(s-17,13),e.lineTo(s+17,13),e.lineTo(s+15,34),e.lineTo(s,42),e.lineTo(s-15,34),e.closePath();const a=e.createLinearGradient(s,13,s,42);a.addColorStop(0,"#ff7e33"),a.addColorStop(.55,"#dc2626"),a.addColorStop(1,"#7f1d1d"),e.fillStyle=a,e.fill(),e.strokeStyle="#ffbe3b",e.lineWidth=2,e.stroke(),st(e,s,24,5,"#ffffff","#ffe066","#b45309");break}case"catapult":{lt(e,10,14,t-20,n-24,14,"#94a3b8","#526278","#273142"),lt(e,20,26,t-40,n-48,8,"#c0824e","#854d27","#45230e"),e.strokeStyle="#d99b5e",e.lineWidth=10,e.lineCap="round",e.beginPath(),e.moveTo(s,n-28),e.lineTo(s,32),e.stroke(),Lt(e,s,34,28,"rgba(255, 126, 51, 0.45)"),st(e,s,34,16,"#fed7aa","#f97316","#7c2d12");for(const[a,o]of[[24,38],[t-24,38],[24,n-36],[t-24,n-36]])st(e,a,o,10,"#cbd5e1","#475569","#0f172a");break}case"sanctuary":{Lt(e,s,r,56,"rgba(94, 242, 140, 0.34)"),lt(e,12,14,t-24,n-24,16,"#e2e8f0","#94a3b8","#475569"),st(e,s,r,38,"#fef3c7","#d97706","#78350f"),st(e,s,r,30,"#dcfce7","#5ef28c","#15803d"),e.fillStyle="#ffffff",ni(e,s-7,r-20,14,40,4),e.fill(),ni(e,s-20,r-7,40,14,4),e.fill();break}case"shield_gen":{Lt(e,s,r,58,"rgba(56, 189, 248, 0.42)"),lt(e,12,16,t-24,n-26,16,"#94a3b8","#475569","#1e293b");for(const[a,o]of[[28,30],[t-28,30],[28,n-30],[t-28,n-30]])st(e,a,o,10,"#fde68a","#d97706","#78350f");st(e,s,r,34,"rgba(224,242,254,0.92)","rgba(56,189,248,0.75)","rgba(3,105,161,0.88)"),e.strokeStyle="#7ce8ff",e.lineWidth=3,e.beginPath(),e.arc(s,r,36,0,wn),e.stroke();break}case"ether_forge":{Lt(e,s,r,56,"rgba(255, 190, 59, 0.36)"),lt(e,10,14,t-20,n-24,14,"#8d9bb0","#4d5b70","#1f2937"),lt(e,20,24,42,42,10,"#64748b","#334155","#0f172a"),st(e,41,45,15,"#fffbeb","#ffbe3b","#b45309"),lt(e,66,24,42,42,10,"#64748b","#334155","#0f172a"),An(e,87,45,18,28,0,"#e6ffff","#4ef2e8","#0e7490"),lt(e,24,76,t-48,28,8,"#fde68a","#b45309","#451a03");break}case"chrono_obelisk":{Lt(e,s,r-4,60,"rgba(184, 122, 255, 0.48)"),lt(e,16,20,t-32,n-30,18,"#5b4b80","#2b2047","#110b21"),e.strokeStyle="#ffe066",e.lineWidth=2.5,e.beginPath(),e.ellipse(s,r,44,20,-.3,0,wn),e.stroke(),e.strokeStyle="#c084fc",e.lineWidth=2.5,e.beginPath(),e.ellipse(s,r,44,20,.3,0,wn),e.stroke(),An(e,s,r-4,34,78,0,"#e9d5ff","#8b5cf6","#1e1b4b"),st(e,s,r-4,11,"#ffffff","#d8b4fe","#6b21a8");break}case"node_stone":{e.fillStyle="#475569",e.beginPath(),e.ellipse(s,r+12,22,12,0,0,wn),e.fill(),lt(e,10,20,26,28,9,"#e2e8f0","#94a3b8","#475569"),lt(e,28,14,26,34,9,"#f1f5f9","#94a3b8","#334155"),lt(e,18,28,24,22,7,"#cbd5e1","#64748b","#1e293b");break}case"node_crystal":{Lt(e,s,r,30,"rgba(78, 242, 232, 0.48)"),An(e,s-12,r+6,14,30,-.45,"#e0ffff","#38bdf8","#0c4a6e"),An(e,s+13,r+6,14,28,.42,"#e0ffff","#4ef2e8","#0e7490"),An(e,s,r+2,20,44,.04,"#ffffff","#4ef2e8","#083344");break}case"drop_stone":{lt(e,8,8,t-16,n-16,8,"#f1f5f9","#94a3b8","#475569");break}case"drop_crystal":{Lt(e,s,r,t*.45,"rgba(78, 242, 232, 0.5)"),An(e,s,r,t*.55,n*.72,0,"#ffffff","#4ef2e8","#0e7490");break}case"drop_heal":{Lt(e,s,r,t*.45,"rgba(94, 242, 140, 0.55)"),st(e,s,r,t*.34,"#dcfce7","#5ef28c","#15803d"),e.fillStyle="#ffffff",ni(e,s-3,r-8,6,16,2),e.fill(),ni(e,s-8,r-3,16,6,2),e.fill();break}default:{lt(e,8,8,t-16,n-16,8);break}}}function Lf(i,e,t,n,s){const r=t*.5,a=s===1?-1.8:0;if(i==="auto_turret"){Lt(e,r,n*.5+a,20,"rgba(78, 242, 232, 0.4)"),st(e,r,n*.5+a,13,"#fde68a","#d97706","#78350f"),st(e,r,n*.5+a,7,"#ffffff","#4ef2e8","#0e7490");return}const o={hero:{cloak:"#0e7490",armor:"#cbd5e1",trim:"#4ef2e8",glow:"#4ef2e8"},hero_engineer:{cloak:"#92400e",armor:"#d97706",trim:"#fde68a",glow:"#ffbe3b"},hero_archmage:{cloak:"#5b21b6",armor:"#7c3aed",trim:"#e9d5ff",glow:"#b87aff"},hero_ranger:{cloak:"#166534",armor:"#22c55e",trim:"#bbf7d0",glow:"#5ef28c"},hero_summoner:{cloak:"#1d4ed8",armor:"#38bdf8",trim:"#e0f2fe",glow:"#38bdf8"}},l=o[i]||o.hero;Lt(e,r,n*.45+a,20,`${l.glow}44`),e.beginPath(),e.moveTo(r-12,n-5+a*.5),e.quadraticCurveTo(r-14,n*.42+a,r,n*.25+a),e.quadraticCurveTo(r+14,n*.42+a,r+12,n-5+a*.5),e.closePath(),e.fillStyle=l.cloak,e.fill(),e.strokeStyle="#090d16",e.lineWidth=2,e.stroke(),st(e,r,n*.56+a,9.5,l.trim,l.armor,"#1e293b"),st(e,r,n*.3+a,8.5,"#f8fafc",l.armor,"#0f172a"),e.fillStyle=l.glow,ni(e,r-4.5,n*.27+a,9,3.2,1.5),e.fill(),i==="hero_ranger"?(e.strokeStyle="#5ef28c",e.lineWidth=2.6,e.beginPath(),e.arc(r+11,n*.52+a,8,-1.1,1.1),e.stroke()):i==="hero_summoner"?(st(e,r-14,n*.34-a,3.5,"#ffffff","#38bdf8","#0284c7"),st(e,r+14,n*.34+a,3.5,"#ffffff","#38bdf8","#0284c7")):(e.strokeStyle=l.trim,e.lineWidth=2.6,e.lineCap="round",e.beginPath(),e.moveTo(r+10,n*.72+a),e.lineTo(r+14,n*.24+a),e.stroke())}function Pf(i,e,t,n,s){const r=t*.5,a=n*.52,o=s===1?-1.8:.8,l=Math.min(t,n)*.34;if(i==="harpy"||i==="wyvern_swarm"||i==="boss_dragon"){const h=i==="boss_dragon",v=i==="wyvern_swarm",f=s===1?-l*.35:l*.28,m=h?"#dc2626":v?"#38bdf8":"#7c3aed",g=h?"#7f1d1d":v?"#0c4a6e":"#3b0764",S=h?"#ffbe3b":v?"#bae6fd":"#d8b4fe";h&&Lt(e,r,a,t*.45,"rgba(255, 79, 109, 0.38)");for(const M of[-1,1])e.beginPath(),e.moveTo(r,a+o),e.quadraticCurveTo(r+M*t*.28,a-l*.9+f,r+M*t*.46,a+f),e.quadraticCurveTo(r+M*t*.26,a+l*.45+f*.4,r,a+l*.25+o),e.closePath(),e.fillStyle=m,e.fill(),e.strokeStyle=g,e.lineWidth=2,e.stroke();st(e,r,a+o,l*.72,S,m,g),st(e,r,a-l*.55+o,l*.48,S,m,g),e.fillStyle=h?"#ffe066":"#ffffff",e.beginPath(),e.arc(r-l*.18,a-l*.6+o,Math.max(1.8,l*.12),0,wn),e.arc(r+l*.18,a-l*.6+o,Math.max(1.8,l*.12),0,wn),e.fill();return}if(i==="shadow_wolf"){e.fillStyle="#1e1b4b",e.beginPath(),e.ellipse(r,a+o,l*1.15,l*.65,0,0,wn),e.fill(),e.strokeStyle="#6366f1",e.lineWidth=2,e.stroke(),st(e,r+l*.6,a-l*.2+o,l*.48,"#6366f1","#312e81","#0f172a"),e.fillStyle="#4ef2e8",e.beginPath(),e.arc(r+l*.78,a-l*.25+o,2.2,0,wn),e.fill();return}const c={goblin:{hi:"#86efac",mid:"#22c55e",lo:"#14532d",eye:"#fef08a",accent:"#a16207"},orc:{hi:"#a3e635",mid:"#4d7c0f",lo:"#1a2e05",eye:"#ff4f6d",accent:"#94a3b8"},ram_brute:{hi:"#cbd5e1",mid:"#64748b",lo:"#1e293b",eye:"#ff7e33",accent:"#92400e"},archer_skel:{hi:"#f8fafc",mid:"#cbd5e1",lo:"#475569",eye:"#4ef2e8",accent:"#854d0e"},sapper:{hi:"#fda4af",mid:"#e11d48",lo:"#4c0519",eye:"#ffe066",accent:"#ffbe3b"},pyro_mage:{hi:"#fdba74",mid:"#ea580c",lo:"#431407",eye:"#fef08a",accent:"#ff4f6d"},siege_golem:{hi:"#cbd5e1",mid:"#526278",lo:"#1e293b",eye:"#ffbe3b",accent:"#ff7e33"},bastion_assassin:{hi:"#c084fc",mid:"#4c1d95",lo:"#090d16",eye:"#ff4f6d",accent:"#e2e8f0"},necromancer:{hi:"#d8b4fe",mid:"#6b21a8",lo:"#1e1b4b",eye:"#5ef28c",accent:"#a855f7"},rune_colossus:{hi:"#93c5fd",mid:"#3b4f78",lo:"#0f172a",eye:"#4ef2e8",accent:"#38bdf8"},boss_troll:{hi:"#a7f3d0",mid:"#2e6f40",lo:"#0b2917",eye:"#ff4f6d",accent:"#b45309"},boss_behemoth:{hi:"#fca5a5",mid:"#52525b",lo:"#18181b",eye:"#ffbe3b",accent:"#ff4f6d"}},d=c[i]||c.goblin,p=i.startsWith("boss_");if((p||i==="rune_colossus"||i==="pyro_mage"||i==="necromancer")&&Lt(e,r,a,t*.44,`${d.accent}44`),st(e,r,a+l*.25+o,l*.92,d.hi,d.mid,d.lo),e.strokeStyle="rgba(9, 13, 22, 0.8)",e.lineWidth=p?2.5:1.8,e.stroke(),st(e,r,a-l*.52+o,l*.62,d.hi,d.mid,d.lo),e.stroke(),p||i==="ram_brute"||i==="orc"||i==="rune_colossus"){e.fillStyle=d.accent;for(const h of[-1,1])e.beginPath(),e.moveTo(r+h*l*.35,a-l*.85+o),e.lineTo(r+h*l*.85,a-l*1.15+o),e.lineTo(r+h*l*.55,a-l*.45+o),e.closePath(),e.fill()}i==="sapper"&&st(e,r+l*.65,a+o,l*.42,"#fef08a","#ff4f6d","#7f1d1d"),e.fillStyle=d.eye;const u=Math.max(1.8,l*.15);e.beginPath(),e.arc(r-l*.22,a-l*.54+o,u,0,wn),e.arc(r+l*.22,a-l*.54+o,u,0,wn),e.fill()}const vc=new Set(["wall","gate","obsidian_wall","sky_wall","spike_trap","rune_mine","archer_tower","ballista","flak_tower","arcane_tower","frost_tower","alch_mortar","solar_tower","tesla_spire","catapult","chrono_obelisk","quarry","crystal_rig","ether_forge","sanctuary","shield_gen","war_banner","node_stone","node_crystal","drop_stone","drop_crystal","drop_heal"]),Df=new Set(["hero","hero_engineer","hero_archmage","hero_ranger","hero_summoner","auto_turret"]);function If(i,e,t,n){const s=Math.max(24,Math.round(e*ma)),r=Math.max(24,Math.round(t*ma)),a=[],o=[],l=i==="citadel"||vc.has(i)?1:Math.max(1,n);for(let c=0;c<l;c++){const d=Au(s,r),p=d.getContext("2d");p.imageSmoothingEnabled=!0,p.imageSmoothingQuality="high",i==="citadel"?Af(p,s,r):vc.has(i)?Rf(i,p,s,r):Df.has(i)?Lf(i,p,s,r,c):Pf(i,p,s,r,c),a.push(d),o.push(Cf(d))}return{w:s,h:r,frames:a,flashFrames:o}}const Fn=new Map,ga=new Map,Sc=new Map,Uf={".":""," ":"",k:"#090d16",s:"#6f7f94",S:"#465266",L:"#b4c2d4",w:"#f2f5fa",t:"#8f5d38",T:"#57351e",y:"#ffbe3b",Y:"#a86514",c:"#4ef2e8",C:"#1a858d",v:"#b87aff",V:"#5e2c9e",g:"#5ef28c",G:"#217843",r:"#ff4f6d",R:"#8c1c34",o:"#ff7e33",b:"#3b82f6",B:"#1d4487",d:"#252136",D:"#453c66",a:"#a3e635",A:"#4d7c0f"};function Do(i,e){const t=document.createElement("canvas");return t.width=i,t.height=e,t}function vi(i){const e=i[0].length,t=i[0].reduce((r,a)=>Math.max(r,a.length),0),n=[],s=[];for(const r of i){const a=Do(t,e),o=a.getContext("2d"),l=Do(t,e),c=l.getContext("2d");for(let d=0;d<r.length;d++){const p=r[d];for(let u=0;u<p.length;u++){const h=p[u],v=Uf[h];v&&(o.fillStyle=v,o.fillRect(u,d,1,1),c.fillStyle=h==="k"?"#d8e8ff":"#ffffff",c.fillRect(u,d,1,1))}}n.push(a),s.push(l)}return{w:t,h:e,frames:n,flashFrames:s}}function Tn(i){return i.map(e=>e.map(t=>t+t.split("").reverse().join("")))}const Nf=Tn([["...kkk","..kcck","..kLLk",".kLccL","kBssss","kBssyw",".ksSSs",".ksk.k",".kSk.k",".kkk.."],["...kkk","..kcck","..kLLk",".kLccL","kBssss","kBssyw",".ksSSs",".ks.kk",".kk.kS","....kk"]]),Bf=Tn([["...kkk","..kyyk","..kcck",".kYyyY","kTtttt","kTsscw",".kssss",".ksk.k",".kSk.k",".kkk.."],["...kkk","..kyyk","..kcck",".kYyyY","kTtttt","kTsscw",".kssss",".ks.kk",".kk.kS","....kk"]]),Ff=Tn([["...kkk","..kVVk","..kcck",".kVvvV","kVvvcv","kVVwwv",".kVVvv",".kVk.k",".kVk.k",".kkk.."],["...kkk","..kVVk","..kwwk",".kVvvV","kVvvcv","kVVccv",".kVVvv",".kV.kk",".kk.kV","....kk"]]),Of=Tn([["...kkk","..kGGk","..kggk",".kGggG","kGggcg","kGGwwg",".kttgg",".kGk.k",".kGk.k",".kkk.."],["...kkk","..kGGk","..kwwk",".kGggG","kGggcg","kGGccg",".kttgg",".kG.kk",".kk.kG","....kk"]]),Hf=Tn([["..kcck",".kBbbk","..kwwk",".kBccB","kBbccb","kBBwwb",".kBBbb",".kBk.k",".kBk.k",".kkk.."],["..kwwk",".kBbbk","..kcck",".kBccB","kBbccb","kBBccb",".kBBbb",".kB.kk",".kk.kB","....kk"]]),Gf=Tn([["...kkk","..kyyk",".kLLyk","kSSccw","kYYccw",".kSSyk","..kyyk","..k.k.","..c.k.","......"],["......","...kkk","..kyyk",".kLLyk","kSSwwc","kYYccw",".kSSyk","..kyyk","..k.c.","......"]]),zf=["......................kk",".....................kcc","....................kccw","...................kcwwc","..................kccwwc","..................kcCCCC",".................kssyyss","..kkk..kkk......kLLsssss",".kLLLk.kLLk....kLsssssss",".kssskkkssk...kLssSSSSss",".ksssssssskkkkkssSyyyySs",".kssSSSSsssssssssSywwySs",".kssSbbSsssssssssSyyyySs",".kssSbbSsssssssssSSSSSSs",".kssSSSSsskk..kk..kkssss",".ksssssssssLLkkLLkkLLsss",".kLLsssssssSSSSSSSSSSsss",".ksssssssssLLssssssLLsss",".kssSSSSssssssssssssssss",".kssSyySsssssSSSSSSSSSSS",".kssSyySssssSccccccccccc",".kssSSSSssssScwwwwcccccc",".kssssssssssScwwwwwwcccc",".kLLsssssLLsScwwccwwcccc",".kssssssssssScwwwwwwcccc",".kssSSSSssssScwwwwcccccc",".kssSbbSssssSccccccccccc",".kssSbbSsssssSSSSSSSSSSS",".kssSSSSssssssssssssssss",".ksssssssssssLLssssssLLs",".kSSssssssssssssssssssss",".kSSSSSSSSSSssSSyyyyyySS",".kLLssssssLLsSSyTTTTTTTT",".ksssssssssssSyTTTTTTTTT",".kssSSSSsssssSyTTttttttt",".kssSbbSsssssSyTtttttttt",".kssSbbSsssssSyTttyytttt",".kssSSSSsssssSyTtttttttt",".ksssssssssssSyTTttttttt",".kSSSSSSSSsssSyTtttttttt",".kLLssssssLLsSyTtttttttt",".ksssssssssssSyTTyyyyyyy",".kSSsssssssssSyTTTTTTTTT",".kSSsssssssssSyTTTTTTTTT",".kSSSSSSSSSSSssSSSSSSSSS","..ksssssssssssssssssssss","..kSSSSSSSSSSSSSSSSSSSSS","...kkkkkkkkkkkkkkkkkkkkk"],Vf=[zf.map(i=>i+i.split("").reverse().join(""))],Wf={wall:[["kk..kk..kk..kk..","kLkkLLkkLLkkLLk.","ksssssSSsssssSk.","kSSSSSSSSSSSSSk.","kLLssLLLssLLLsk.","kssSSsssSSsssSk.","kSSSSSSSSSSSSSk.","ksssLLLssLLLssk.","kSSSsssSSsssSSk.","kLLssssSSssssLk.","kssssSSssSSssSk.","kSSSSSSSSSSSSSk.","kSSSSSSSSSSSSSk.",".kkkkkkkkkkkkkk.","................","................"]],gate:[["kkkkkkkkkkkkkkkk","kLLssTTTTTTssLLk","kssSTTyyyyTTSssk","kssSTksssskTSssk","kSSSTksSSskTSSSk","kssSTksssskTSssk","kssSTksSSskTSssk","kSSSTksssskTSSSk","kssSTksSSskTSssk","kssSTksssskTSssk","kSSSTksSSskTSSSk","kssSTksssskTSssk","kSSSTkTTTTkTSSSk","kkkkkkkkkkkkkkkk","................","................"]],archer_tower:[["....kkkkkkkk....","...kggggggggk...","..kggGGGGGGggk..","..kttttttttttk..","..ktSSSSSSSSstk.","...ksskkkkssk...","...kssskksssk...","...kSSSSSSSSk...","...kLLssssLLk...","...kssssssssk...","...kssstttssk...","...kSSstttSSk...","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],ballista:[["......kkkk......","..kkkkwwwwkkkk..",".ktLLLLwwLLLLtk.",".kttTTTTTTTTttk.","...kssyyyyssk...","...kssSyySssk...","...kSSSSSSSSk...","...kLLssssLLk...","...kssssssssk...","...kssSSSSssk...","...kssskksssk...","..kSSSSSSSSSSk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],spike_trap:[["................","..kk..kk..kk..k.",".kLLkkLLkkLLkLk.",".kSSkkSSkkSSkSk.",".kssssssssssssk.","..kLLkkLLkkLLk..","..kSSkkSSkkSSk..",".kssssssssssssk.",".kLLkkLLkkLLkLk.",".kSSkkSSkkSSkSk.",".kSSSSSSSSSSSSk.","..kkkkkkkkkkkk..","................","................","................","................"]],quarry:[["....kkkkkkkk....","...kttttttttk...","..ktT......Ttk..","..ktT..kk..Ttk..","..ktT.kLLk.Ttk..","..kssskssksssk..",".kLLsssssssLLk..",".ksssssssssssk..",".kssyyyyyysssk..",".kssSSSSSSsssk..",".kSSSSSSSSSSSk..",".kLLsssssssLLk..",".kSSSSSSSSSSSk..",".kkkkkkkkkkkkk..","................","................"]],crystal_rig:[[".....kkkkkk.....","....kcccccck....","...kcwwwwwwck...","...kcCCCCCCck...","..kssccccccssk..","..kssSSSSSSssk..",".kLLssssssssLLk.",".kssscCCCCcsssk.",".kssscwwwwcsssk.",".kSSScCCCCcSSSk.",".kSSSSSSSSSSSSk.",".kLLssssssssLLk.","..kkkkkkkkkkkk..","................","................","................"]],arcane_tower:[[".....kkkkkk.....","....kvvvvvvk....","...kvcwwwwcvk...","....kvvvvvvk....","...kSSSSSSSSk...","...kLLvvvvLLk...","...ksssvvsssk...","...kssSSSSssk...","...kssssssssk...","...ksssvvsssk...","..kSSSSSSSSSSk..","..kLLssssssLLk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],frost_tower:[["......kkkk......",".....kcwwck.....","....kcccccck....","....kcCCCCck....","...kcwwwwwwck...","...kssccccssk...","...kssCCCCssk...","...kSSSSSSSSk...","...kLLssssLLk...","...kssccccssk...","..kSSSSSSSSSSk..","..kLLssssssLLk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],rune_mine:[["................","....kkkkkkkk....","..kkSSrrrrSSkk..",".kSSrrwwwwrrSSk.",".kSrwwrrrrwwrSk.",".kSrwrrrrrrwrSk.",".kSrwwrrrrwwrSk.",".kSSrrwwwwrrSSk.","..kkSSrrrrSSkk..","....kkkkkkkk....","................","................","................","................","................","................"]],catapult:Tn([["............kkkk","...........kLLLL","..........kLLssL","..........kLssww","..........ksssss","...........kSSSS","..........kTTTTT",".........kTttttT","........kTttYYtT","........kTTttttT",".......kTTTTtttT","......kTTttTTTTT",".....kTTtT.ktttt","....kTTtT..kTyyT","...kTTtT...kTyyT","..kTTtT....kTTTT",".kTTtT....kTTsss",".kTtT....kTTssss","kTTtT...kTTssSSS","kTTTTTTTtTssssss","kTTTTTTTTttttttt","kSSSTTTTTyyyyyyy","kssSTTTTTssssssS","kSSSSSSSSSSSSSSS","kLLsssssssssssss","ksssssssssssssss","ksskkkTTTTTTTkkk","kSSkSSkTTTTTkSSk","ksskSSkSSSSSkSSk",".kkkSSkkkkkkkSSk","...kSSk.....kSSk","....kk.......kkk"]]),sanctuary:Tn([[".............kkk","............kccc","...........kcwwc","..........kccwwc",".........kcccccc",".......kkyyyyyyy","......kyywwwwwwy",".....kySSyyyyyyS","....kLLSSccccccS","...kLLsSScwwwwcS","..kLLssSScwwwwcS","..kssssSSccccccS","..kSSssSSyyyyyyS","..ksskkSSSSSSSSS","..ksskLLssgggggg","..ksskssssggwwgg","..ksskssssggwwgg","..ksskssssgggggg","..ksskSSssggccgg","..ksskssssgggggg","..ksskkSSSSSSSSS",".kLLsssssyyyyyyy",".kssSSssyggggggy",".kssSSssygwwwwgy",".kssssssygwwwwgy",".kssSSssyggggggy",".kLLsssssyyyyyyy",".kSSSSSSSSSSSSSS","kLLsssssssssssss","ksssssssssssssss","kSSSSSSSSSSSSSSS",".kkkkkkkkkkkkkkk"]]),obsidian_wall:[["kk..kk..kk..kk..","kDkkDDkkDDkkDDk.","kddddvddddvdddk.","kdddddddddddddk.","kDDddDDDddDDDdk.","kddvvdddDDvvddk.","kdddddddddddddk.","kdddDDDddDDDddk.","kDDDdddDDdddDDk.","kDDddddvvddddDk.","kddddDDddDDdddk.","kdddddddddddddk.","kdddddddddddddk.",".kkkkkkkkkkkkkk.","................","................"]],sky_wall:[["..kk........kk..",".kcck.cccc.kcck.",".kcwkcwwwwckwck.","..kccbbbbbbcck..",".kLLSSSSSSSSLLk.",".kssLLccccLLssk.",".kssssccccssssk.",".kSSssLLLLssSSk.",".kLLssssssssLLk.",".kssSSccccSSssk.",".kssssccccssssk.",".kSSssssssssSSk.",".kSSSSSSSSSSSSk.",".kkkkkkkkkkkkkk.","................","................"]],flak_tower:[["..kk........kk..",".kLLk......kLLk.","..kSSk....kSSk..","..kcckkkkkkcck..","..kSSLLLLLLSSk..","...kSSccccSSk...","...kSSSSSSSSk...","...kLLssssLLk...","...kssccccssk...","...kssssssssk...","..kSSSSSSSSSSk..","..kLLssssssLLk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],alch_mortar:[["....kkkkkkkk....","...kaaaaaaaaak..","..kAawwaawwaaAk.","..kAAaaaaaaaaAk.","..kTTaaaaaaaaTk.","..kTTSAAAAAASTk.","..kSSSSSSSSSSSk.","...kssYaaYssk...","...kssYAAYssk...","..kSSSSSSSSSSk..","..kLLssssssLLk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................","................"]],solar_tower:[[".....kkkkkk.....","....kyyyyyyk....","...kywwwwwwyk...","...kywoooowyk...","....kyyyyyyk....","...kSSSSSSSSk...","...kYYyyyyYYk...","...kssyyyyssk...","...kssSSSSssk...","...kssssssssk...","..kSSSSSSSSSSk..","..kYYssssssYYk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................","................"]],shield_gen:Tn([[".........kkkkkkk",".......kkccccccc","......kccwwwwwwc",".....kcwwccccccw","....kcwccbbbbbbc","...kcwcbbwwwwbbc","..kcwcbbwccccccb","..kccbwwcccccccc",".kcwcbwccwwwwccc",".kcwcbwccwwwwccc",".kcccbwccccccccc",".kSScbwccbbbbbbc",".kLLScbccccccccc",".kssSScccccccccc",".kSSsSSSSSSSSSSS",".kssskSSbbbbbbSS",".kLLskSbccccccbS",".kssskSbcwwwwcbS",".kssskSbcwwwwcbS",".kSSskSbccccccbS",".kssskSSbbbbbbSS",".kLLsSSSSSSSSSSS",".kssssssssssssss","kLLssSSyyyyyySSs","kssssSSyCCCCySSs","kSSssSSyccccySSs","kssLLssyyyyyySSs","kSSSSSSSSSSSSSSS","kLLsssssssssssss","ksssssssssssssss","kSSSSSSSSSSSSSSS",".kkkkkkkkkkkkkkk"]]),tesla_spire:[["......kkkk......",".....kcccck.....","....kcwwwwck....","....kcwbbwck....",".....kcccck.....","....kYYYYYYk....","...kccbbbbcck...","....kYYYYYYk....","...kccbbbbcck...","....kssssssk....","...kLLssssSSk...","...kssccccSSk...","..kLLssssssSSk..","..kSSSSSSSSSSk..","..kkkkkkkkkkkk..","................"]],war_banner:[["......kkkk......",".....kywwyk.....","....koyyyook....","...koorrrrook...","...kooryyrook...","...koorrrrook...","...koooYYoook...","....koooook.....",".....kYYyk......",".....ktttk......","....kLLssSk.....","...kLLssssSk....","..kLLssyyssSk...","..kSSSSSSSSSk...","..kkkkkkkkkkk...","................"]],ether_forge:Tn([["................","......kkkkkkkkkk",".....kSSSSSSSSSS","....kSSyyyyyyyyy","...kSSyooooooooo","...kSSyoowwwwwwo","...kSSyooooooooo","..kLLSSyyyyyyyyy","..kssssSSSSSSSSS","..kLLssSSccccccS","..kssssSScwwwwcS",".kLLsssSScCCCCcS",".ksssssSSccccccS",".kSSsssSSSSSSSSS",".kLLsssSSyyyyyyS",".ksssssSSyoooooy",".kSSsssSSyowwwoy",".kssLLsSSyoooooy",".ksssssSSyyyyyyS",".kSSSSSSSSSSSSSS","kLLssSSccccccSSs","kssssSScwwwwcSSs","kSSssSScCCCCcSSs","kssLLssccccccSSs","kSSSSSSSSSSSSSSS","kLLsssssssssssss","ksssssssssssssss","kSSssyyssyyssSSS","kSSSSSSSSSSSSSSS",".kkkkkkkkkkkkkkk","................","................"]]),chrono_obelisk:Tn([["..............kk",".............kvv","............kvwv","...........kvwwv","..........kdvwvd",".........kddvvdd","........kddDvvDd","........kdDvvvvD",".......kdDvwwwwv",".......kdDvwwwwv",".......kdDvvvvvv",".......kddDvvvvD","......kddDDvvvvD","......kdDDvvwwvv","......kdDDvvwwvv","......kdDDvvvvvv",".....kddDDDvvvvD",".....kddDDdVvvVd",".....kddDDddVVdd","....kLLddDDddddD","....kssddDDvvvvD","...kLLssddDwwwwD","...kssssddDvvvvD","..kLLsssdddDDDDd","..ksssssdddddddd",".kLLssssSSvvvvSS",".kssssssSSvwwvSS",".kSSssssSSvvvvSS",".kSSSSSSSSSSSSSS",".kLLssssssssssss",".kSSSSSSSSSSSSSS","..kkkkkkkkkkkkkk"]]),node_stone:[["................","....kkkkkkkk....","..kkLLLLLLLLkk..",".kLLssssssssLLk.",".kLssLLsssssSSk.","kLssLwwLsssssSSk","kssLLssLssLLssSk","kssSSssssLwwLsSk","kSSSSSSSSssssSSk",".kSSSSSSSSSSSSk.","..kSSkSSSSkSSk..","...kkkkkkkkkk...","................","................","................","................"]],node_crystal:[["......kkkk......",".....kcccck.....","...kkkcccckkk...","..kcckcwwckcck..",".kcwckcccckcwck.",".kccckcCCckccck.",".kcCCkCCCCkCCck.","kkSSScCCCCcSSSkk","kSSSSccccccSSSSk","kSSSSSSSSSSSSSSk",".kSSSSSSSSSSSSk.","..kkkkkkkkkkkk..","................","................","................","................"]],drop_stone:[[".kkkk.","kLLLLk","kLssSk","kSSSSk",".kkkk."]],drop_crystal:[["..kk..",".kcck.","kcwwck",".kCCk.","..kk.."]],drop_heal:[[".kkkkk.","kgggggk","kgwwwgk","kgggggk",".kkkkk."]]},$f={goblin:[["..kk..kk..",".kggkkggk.","..kggggk..",".kgrrrrgk.","..kttttk..",".kttssttk.","..kdk.kdk.","..kk...kk."],["..kk..kk..",".kggkkggk.","..kggggk..",".kgrrrrgk.","..kttttk..",".kttssttk.","..kk..kdk.",".......kk."]],orc:[["...kkkkkk...","..kGGGGGGk..",".kGrrGGrrGk.",".kSSSSSSSSk.","kLLssTTssLLk","kssTTTTTTssk","..kSS..SSk..","..kkk..kkk.."],["...kkkkkk...","..kGGGGGGk..",".kGrrGGrrGk.",".kSSSSSSSSk.","kLLssTTssLLk","kssTTTTTTssk","..kSk..SSk..","..kk....kk.."]],shadow_wolf:[[".kk......kk.","kvvk....kvvk",".kvvvvvvvvk.","kvrwvvvvvvvk",".kvvvvvvvvk.","..kvk..kvk..",".kvk....kvk."],[".kk......kk.","kvvk....kvvk",".kvvvvvvvvk.","kvrwvvvvvvvk",".kvvvvvvvvk.","..kkv..vkk..","....k..k...."]],ram_brute:[["..kkkkkkkkkk..",".kSSSSSSSSSSk.","kLLssssyyyyLLk","kssrrrryyyyssk","kSSSSSSSSSSSSk","kTTTTTTTTTTTTk",".kSSk....kSSk.",".kkkk....kkkk."],["..kkkkkkkkkk..",".kSSSSSSSSSSk.","kLLssssyyyyLLk","kssrrrryyyyssk","kSSSSSSSSSSSSk","kTTTTTTTTTTTTk","..kSk....kSk..","..kkk....kkk.."]],archer_skel:[["...kkkk...","..kwwwwk..","..kwrwwk..",".kktLLtkk.","kt.kLLk.tk","...kLLk...","..kL..Lk..","..kk..kk.."],["...kkkk...","..kwwwwk..","..kwrwwk..",".kktLLtkk.","kt.kLLk.tk","...kLLk...","..kk..Lk..","......kk.."]],sapper:[["...kkkk...","..krrrrk..",".krrwwrrk.",".kkoooook.","kTTssssTTk",".kSSSSSSk.","..kSk.kSk.","..kk...kk."],["...kkkk...","..krrrrk..",".krryyrrk.",".kkwwwwkk.","kTTssssTTk",".kSSSSSSk.","..kk..kSk.",".......kk."]],harpy:[["kk..........kk","kcck..kk..kcck",".kccckvvckcck.","..kccvvvvcck..","...kvrwwrvk...","....kvvvvk....","....kk..kk...."],["..............","..kk..kk..kk..",".kccckvvckcck.","kcckkvvvvkkcck",".kk.kvrwwrvk..","....kvvvvk....","....kk..kk...."]],pyro_mage:[["....kkkk....","...krrrrk...","..krroorrk..","..kRryyrRk..",".kRRrrrrRRk.",".kRRRRRRRRk.","..kRR..RRk..","..kkk..kkk.."],["....kkkk....","...krrrrk...","..kroyyork..","..kRryyrRk..",".kRRrrrrRRk.",".kRRRRRRRRk.","..kRR..RRk..","..kkk..kkk.."]],siege_golem:[["...kkkkkkkkkk...","..kLLLLLLLLLLk..",".kLLssssssssLLk.","kLLssrrrrrrssLLk","kssssssssssssssk","kSSssssssssssSSk","kSSSkkkkkkkkSSSk",".kSSk......kSSk.",".kkkk......kkkk."],["...kkkkkkkkkk...","..kLLLLLLLLLLk..",".kLLssssssssLLk.","kLLssroooorsLLk.","kssssssssssssssk","kSSssssssssssSSk","kSSSkkkkkkkkSSSk","..kSk......kSk..","..kkk......kkk.."]],bastion_assassin:[["...kkkkkk...","..kddddddk..",".kddrrrrddk.",".kddddddddk.","kwwkDDDDkwwk",".kLLddddLLk.","..kddddddk..","..kdd..ddk..","..kdk..kdk..","..kk....kk.."],["...kkkkkk...","..kddddddk..",".kddrrrrddk.",".kddddddddk.",".kwwDDDDwwk.","kLLddddddLLk","..kddddddk..","..kdd..ddk..","...kk..kdk..","........kk.."]],necromancer:[["...kkkkkk...","..kVVVVVVk..",".kVVvvvvVVk.",".kVvccccvVk.","kwwkVVVVkVVk","ktT.kVVk.VVk","ktT.kVVk.VVk",".kk.kVVVVVVk","....kVVVVVVk","....kVV..VVk","....kkk..kkk","............"],["...kkkkkk...","..kVVVVVVk..",".kVVvvvvVVk.",".kVvwwwwvVk.","kcckVVVVkVVk","ktT.kVVk.VVk","ktT.kVVk.VVk",".kk.kVVVVVVk","....kVVVVVVk","....kVk..VVk","....kk....kk","............"]],rune_colossus:Tn([["....kkkkk","..kkDDDDD",".kDDccccc","kDDddcccc","kddwwdddd","kddddcccc","kDDddcccc","kDDDDddcc","kLLDDDDDD","kSSDDDDDD","kSSSkDDDD",".kSSkDDDD",".kkk.kDDk",".....kDDk",".....kDDk",".....kkkk"],["....kkkkk","..kkDDDDD",".kDDcwwcc","kDDddcccc","kddwwdddd","kddddcwwc","kDDddcccc","kDDDDddcc","kLLDDDDDD","kSSDDDDDD","kSSSkDDDD",".kSSkDDDD",".kkk.kDDk",".....kDk.",".....kDDk",".....kkkk"]]),wyvern_swarm:[["kk..........kk","kyyk..kk..kyyk",".kyyykYYkyyyk.","..kyyYYYYyyk..","...kYroorYk...","....kYYYYk....","....kYYkYYk...","...kYk..kYk...","...kk....kk..."],["..............","..kk..kk..kk..",".kyyykYYkyyyk.","kyykkYYYYkkyyk",".kk.kYroorYk..","....kYYYYk....","....kYYkYYk...","....kk..kk....",".............."]],boss_troll:Tn([["......kkkkkk","....kkTTTTTT","...kTTyyyyTT","..kLLsrrrrsS",".kLLssssssss","kYYssssSSSSS","kYYssssssssS","kYYssSSSSSSS",".kkssSSk..kS","...kSSk...kS","...kkkk...kk"]]),boss_behemoth:Tn([["......kkkkkkkk","....kkSSSSSSSS","..kkLLssssssss",".kLLssrrrrrrrr","kYYsssssssssss","kYYssSSSSSSSss","kSSssSyyyyySss","kSSsssssssssss",".kkSSSkkkkkSSS","...kSSk....kSS","...kkkk....kkk"]]),boss_dragon:Tn([[".kkk........kkkk","krrrk.....kkrrrr",".krrrk...krrwwww","..krrrk.krrroooo","...krrrrrrroooRR","....kkRRRRRRRRRR","......kRRRRRRRkk","......kRRk..kRk.","......kkk....kk."],["................","kkk.........kkkk","krrrk.....kkrrrr",".krrrk...krrwwww","..krrrk.krrroooo","...krrrrrrroooRR","....kkRRRRRRRRRR","......kRRk..kRk.","......kkk....kk."]])};function Pl(){if(!(Fn.size>0)){Fn.set("hero",vi(Nf)),Fn.set("hero_engineer",vi(Bf)),Fn.set("hero_archmage",vi(Ff)),Fn.set("hero_ranger",vi(Of)),Fn.set("hero_summoner",vi(Hf)),Fn.set("auto_turret",vi(Gf)),Fn.set("citadel",vi(Vf));for(const[i,e]of Object.entries(Wf))Fn.set(i,vi(e));for(const[i,e]of Object.entries($f))Fn.set(i,vi(e))}}function qf(){if(!(ga.size>0)){Pl();for(const[i,e]of Fn.entries())ga.set(i,If(i,e.w,e.h,e.frames.length))}}function Ru(i,e=!1){return e?(qf(),ga.get(i)||ga.get("goblin")):(Pl(),Fn.get(i)||Fn.get("goblin"))}function cs(i,e=4,t=!1,n=!1){const s=`${i}_${e}_${t?"1":"0"}_${n?"hd":"px"}`,r=Sc.get(s);if(r)return r;const a=Ru(i,n);if(!a)return"";const o=a.frames[0],l=n?Math.max(1,e/ma):e,c=Do(Math.round(a.w*l),Math.round(a.h*l)),d=c.getContext("2d");d.imageSmoothingEnabled=n,n&&(d.imageSmoothingQuality="high"),d.drawImage(o,0,0,c.width,c.height),t&&(d.globalCompositeOperation="source-in",d.fillStyle="#182235",d.fillRect(0,0,c.width,c.height));const p=c.toDataURL();return Sc.set(s,p),p}const xc={stone:'<path d="M4 2h8l3 4-2 8H3L1 6zM5 5h4v4H5z"/>',crystal:'<path d="M8 1l5 5-5 9-5-9zM7 4v5h2V4z"/>',citadel:'<path d="M2 14V5h3V3h2v2h2V3h2v2h3v9zM6 9h4v5H6z"/>',wall:'<path d="M1 4h14v9H1zM3 2h3v2H3zM10 2h3v2h-3z"/>',gate:'<path d="M2 2h12v12h-3V7H5v7H2zM6 8h4v6H6z"/>',archer_tower:'<path d="M4 2h8v4h-1v8H5V6H4zM7 8h2v3H7z"/>',ballista:'<path d="M2 6h12v2H9v6H7V8H2zM5 3h6v2H5z"/>',catapult:'<path d="M2 10h12v4H2zM4 4h2v6H4zM6 3h7v2H6z"/>',arcane_tower:'<path d="M7 1h2v3h2v2H9v8H7V6H5V4h2z"/>',frost_tower:'<path d="M7 1h2v14H7zM3 5h10v2H3zM5 9h6v2H5z"/>',spike_trap:'<path d="M2 11h12v3H2zM3 6l2 5H1zM8 5l2 6H6zM13 6l2 5h-4z"/>',rune_mine:'<path d="M4 4h8v8H4zM6 6h4v4H6zM2 7h2v2H2zM12 7h2v2h-2z"/>',quarry:'<path d="M2 12h12v2H2zM4 6h5v6H4zM10 3h3v9h-3z"/>',crystal_rig:'<path d="M7 2h2v4h3v8H4V6h3zM6 8h4v4H6z"/>',sanctuary:'<path d="M3 12h10v2H3zM5 6h6v6H5zM7 2h2v4H7z"/>',obsidian_wall:'<path d="M1 4h14v9H1zM2 2h3v2H2zM6 2h4v2H6zM11 2h3v2h-3zM6 7h4v3H6z"/>',sky_wall:'<path d="M2 1h2v4H2zM12 1h2v4h-2zM4 2h8v2H4zM1 6h14v8H1zM6 8h4v4H6z"/>',flak_tower:'<path d="M3 2h2v5H3zM11 2h2v5h-2zM4 7h8v7H4z"/>',alch_mortar:'<path d="M4 3h8v2H4zM3 5h10v7H3zM2 12h12v2H2z"/>',solar_tower:'<path d="M7 1h2v2H7zM5 3h6v5H5zM6 8h4v6H6zM3 12h10v2H3z"/>',shield_gen:'<path d="M3 3h10v6l-5 5-5-5zM6 5h4v4H6z"/>',tesla_spire:'<path d="M6 1h4v3H6zM4 5h8v2H4zM5 8h6v2H5zM4 11h8v3H4z"/>',ether_forge:'<path d="M2 11h12v3H2zM3 6h10v5H3zM5 2h6v4H5zM6 7h4v3H6z"/>',war_banner:'<path d="M7 1h2v13H7zM3 2h10v6l-5 3-5-3z"/>',chrono_obelisk:'<path d="M7 1h2v2H6v3H5v5H4v3h8v-3h-1V6h-1V3H7zM7 6h2v4H7z"/>',demolish:'<path d="M3 2h10v2H3zM5 4h6v10H5zM2 5h12v2H2z"/>',auto_wave:'<path d="M2 3l6 5-6 5zM8 3l6 5-6 5z"/>',shield:'<path d="M3 2h10v6l-5 6-5-6z"/>',arcane:'<path d="M9 1L4 9h4l-1 6 5-8H8z"/>',heal:'<path d="M6 2h4v4h4v4h-4v4H6v-4H2V6h4z"/>',gear:'<path d="M6 2h4v2h2v2h2v4h-2v2h-2v2H6v-2H4v-2H2V6h2V4h2zM7 6h2v4H7z"/>',hammer:'<path d="M3 3h8v4H8v7H6V7H3z"/>',pick:'<path d="M3 3h9v3H9v8H7V6H3z"/>',sword:'<path d="M11 2h3v3l-6 6 2 2-2 1-2-2-2 2-1-1 2-2-2-2 1-2 2 2z"/>',bolt:'<path d="M9 1L4 9h4l-1 6 5-8H8z"/>',ult:'<path d="M7 1h2v14H7zM1 7h14v2H1zM4 4h8v8H4z"/>',heart:'<path d="M3 4h4v2h2V4h4v5l-5 5-5-5z"/>',boot:'<path d="M4 2h4v7h5v4H4z"/>',respawn:'<path d="M4 3h8v2H4zM10 5h2v5h-2zM4 11h8v2H4zM4 6h2v5H4z"/>',check:'<path d="M12 4l2 2-7 7-5-5 2-2 3 3z"/>',lock:'<path d="M5 3h6v4H5zM3 7h10v7H3z"/>',skull:'<path d="M4 3h8v7H4zM5 10h6v3H5zM6 5h1v2H6zM9 5h1v2H9z"/>'};function $a(i,e=""){const t=xc[i]||xc.shield;return`<svg class="ic ${e}" viewBox="0 0 16 16" fill="currentColor" shape-rendering="crispEdges" aria-hidden="true">${t}</svg>`}class Xf{constructor(e){j(this,"bufCanvas");j(this,"bctx");j(this,"viewW",533);j(this,"viewH",300);j(this,"cachedPathKey","");j(this,"cachedOpenPaths",[]);j(this,"cachedSiegePaths",[]);j(this,"lastHdResize",!1);this.targetCanvas=e,this.bufCanvas=document.createElement("canvas"),this.bctx=this.bufCanvas.getContext("2d",{alpha:!1}),this.resize()}resize(){const e=Math.max(320,window.innerWidth),t=Math.max(240,window.innerHeight),n=this.isHd?Math.min(2,window.devicePixelRatio||1):1;this.lastHdResize=this.isHd,this.targetCanvas.width=Math.round(e*n),this.targetCanvas.height=Math.round(t*n),this.viewH=300,this.viewW=Se(Math.round(e/t*this.viewH),340,620),this.bufCanvas.width=this.viewW,this.bufCanvas.height=this.viewH,this.bctx.imageSmoothingEnabled=!1}screenToGrid(e,t,n){const s=this.targetCanvas.getBoundingClientRect(),r=(e-s.left)/Math.max(1,s.width)*this.viewW,a=(t-s.top)/Math.max(1,s.height)*this.viewH,o=Math.round(this.viewW*.5-n.camX),l=Math.round(this.viewH*.5-n.camY),c=r-o,d=a-l;return{gx:Math.floor(c/U),gy:Math.floor(d/U),wx:c,wy:d}}get isHd(){return J.settings.theme==="textured"}beginFrameCtx(){if(this.lastHdResize!==this.isHd&&this.resize(),this.isHd){const e=this.targetCanvas.getContext("2d");return e.save(),e.imageSmoothingEnabled=!0,e.imageSmoothingQuality="high",e.scale(this.targetCanvas.width/this.viewW,this.targetCanvas.height/this.viewH),e}return this.bctx.imageSmoothingEnabled=!1,this.bctx}drawSpriteAt(e,t,n,s,r,a,o,l=1){const c=this.isHd,d=Ru(t,c);if(!d)return;const p=a?d.flashFrames:d.frames,u=p[Math.abs(Math.floor(r))%p.length],h=c?l/ma:l,v=d.w*h,f=d.h*h,m=c?n:Math.round(n),g=c?s:Math.round(s);c&&t!=="spike_trap"&&t!=="rune_mine"&&!t.startsWith("drop_")&&(e.fillStyle="rgba(5, 9, 16, 0.34)",e.beginPath(),e.ellipse(m,g+f*.42,v*.38,Math.max(2,f*.14),0,0,zt),e.fill()),o?(e.save(),e.translate(m,g),e.scale(-1,1),e.drawImage(u,c?-v/2:Math.round(-v/2),c?-f/2:Math.round(-f/2),v,f),e.restore()):e.drawImage(u,c?m-v/2:Math.round(m-v/2),c?g-f/2:Math.round(g-f/2),v,f)}drawPixelText(e,t,n,s,r,a=!1){if(this.isHd){e.font=a?'700 8.5px "Inter", "Segoe UI", system-ui, sans-serif':'600 6.8px "Inter", "Segoe UI", system-ui, sans-serif',e.textAlign="center",e.textBaseline="middle",e.lineWidth=2.2,e.lineJoin="round",e.strokeStyle="rgba(9, 13, 22, 0.92)",e.strokeText(t,n,s),e.fillStyle=r,e.fillText(t,n,s);return}e.font=a?"bold 9px monospace":"bold 7px monospace",e.textAlign="center",e.textBaseline="middle";const o=Math.round(n),l=Math.round(s);e.fillStyle="#090d16",e.fillText(t,o+1,l),e.fillText(t,o-1,l),e.fillText(t,o,l+1),e.fillText(t,o,l-1),e.fillStyle=r,e.fillText(t,o,l)}drawTerrain(e,t){if(e.fillStyle="#0d131a",e.fillRect(-160,-160,Ft+320,Ot+320),this.isHd)e.drawImage(wf(),0,0,Ft,Ot);else{for(let n=0;n<He;n++)for(let s=0;s<Le;s++){if(s===0||n===0||s===Le-1||n===He-1)e.fillStyle=(s+n)%2===0?"#1b2625":"#182221";else{const a=(s*7+n*13)%5;e.fillStyle=a===0?"#243c2c":a===1?"#213628":"#1e3225"}e.fillRect(s*U,n*U,U,U)}e.fillStyle="#333e4d",e.fillRect((_n-1)*U,(ln-1)*U,(ht+2)*U,(ht+2)*U),e.strokeStyle="#536275",e.lineWidth=1,e.strokeRect((_n-1)*U+.5,(ln-1)*U+.5,(ht+2)*U-1,(ht+2)*U-1),e.strokeStyle="#3a4c6e",e.lineWidth=1,e.strokeRect(U,U,Ft-U*2,Ot-U*2)}if(t){e.strokeStyle=this.isHd?"rgba(242, 245, 250, 0.14)":"rgba(242, 245, 250, 0.08)",e.lineWidth=this.isHd?.5:1,e.beginPath();for(let n=1;n<=Le-1;n++)e.moveTo(n*U,U),e.lineTo(n*U,Ot-U);for(let n=1;n<=He-1;n++)e.moveTo(U,n*U),e.lineTo(Ft-U,n*U);e.stroke()}}renderMenuScene(e,t="guardian"){const n=this.beginFrameCtx();n.fillStyle="#14201c",n.fillRect(0,0,this.viewW,this.viewH);const s=Math.round(this.viewW*.7),r=Math.round(this.viewH*.5);if(n.save(),n.translate(s-120,r-90),this.isHd)n.drawImage(Tf(),0,0,15*U,12*U);else{for(let a=0;a<12;a++)for(let o=0;o<15;o++)n.fillStyle=(o+a)%2===0?"#243c2c":"#1e3225",n.fillRect(o*U,a*U,U,U);n.fillStyle="#333e4d",n.fillRect(5*U,4*U,5*U,5*U)}for(let a=4;a<=10;a++)this.drawSpriteAt(n,a===7?"gate":"wall",(a+.5)*U,3.5*U,0,!1,!1,1),this.drawSpriteAt(n,a===7?"gate":"wall",(a+.5)*U,8.5*U,0,!1,!1,1);this.drawSpriteAt(n,"archer_tower",4.5*U,3.5*U,0,!1,!1,1),this.drawSpriteAt(n,"arcane_tower",10.5*U,3.5*U,0,!1,!1,1),this.drawSpriteAt(n,"ballista",4.5*U,8.5*U,0,!1,!1,1),this.drawSpriteAt(n,"frost_tower",10.5*U,8.5*U,0,!1,!1,1),this.drawSpriteAt(n,"citadel",7.5*U,6*U,0,!1,!1,1),this.drawSpriteAt(n,Mt[t].spriteKey,7.5*U+Math.cos(e*1.4)*26,9.6*U,e*8,!1,Math.sin(e*1.4)<0,1),this.drawSpriteAt(n,"goblin",2*U,6*U+Math.sin(e*2)*18,e*8,!1,!1,1),this.drawSpriteAt(n,"orc",13*U,5*U+Math.cos(e*1.7)*20,e*8,!1,!0,1),n.restore(),this.flush()}renderGame(e,t){var v;const n=this.beginFrameCtx(),s=this.isHd;n.fillStyle="#090d16",n.fillRect(0,0,this.viewW,this.viewH);const r=e.shake>0?(Math.random()-.5)*e.shake:0,a=e.shake>0?(Math.random()-.5)*e.shake:0,o=(s?this.viewW*.5-e.camX:Math.round(this.viewW*.5-e.camX))+(s?r:Math.round(r)),l=(s?this.viewH*.5-e.camY:Math.round(this.viewH*.5-e.camY))+(s?a:Math.round(a));n.save(),n.translate(o,l),this.drawTerrain(n,e.toolMode!=="none");for(const f of e.nodes)this.drawSpriteAt(n,f.kind==="stone"?"node_stone":"node_crystal",f.x,f.y,0,f.flash>0,!1,1),f.amount<f.maxAmount&&(n.fillStyle="#090d16",n.fillRect(Math.round(f.x-6),Math.round(f.y+6),12,2),n.fillStyle=f.kind==="stone"?"#b4c2d4":"#4ef2e8",n.fillRect(Math.round(f.x-6),Math.round(f.y+6),Math.round(12*(f.amount/f.maxAmount)),2));if(e.pathPreview==="on"||e.pathPreview==="auto"&&e.phase==="prep"){const f=e.phase==="prep"?e.nextWavePlan.flanks:Array.from(new Set(e.activeWaves.flatMap(g=>g.flanks))),m=`${t.version}|${f.join(",")}`;if(m!==this.cachedPathKey){this.cachedPathKey=m,this.cachedOpenPaths=[],this.cachedSiegePaths=[];for(const g of f){const S=g==="N"?[{gx:Math.round(Le*.35),gy:1},{gx:Math.round(Le*.65),gy:1}]:g==="S"?[{gx:Math.round(Le*.35),gy:He-2},{gx:Math.round(Le*.65),gy:He-2}]:g==="W"?[{gx:1,gy:Math.round(He*.35)},{gx:1,gy:Math.round(He*.65)}]:[{gx:Le-2,gy:Math.round(He*.35)},{gx:Le-2,gy:Math.round(He*.65)}];for(const M of S){const _=t.tracePath(M.gx,M.gy,!1),E=t.tracePath(M.gx,M.gy,!0);this.cachedOpenPaths.push(_),(E.length!==_.length||E.some((x,b)=>{var A,R;return x.x!==((A=_[b])==null?void 0:A.x)||x.y!==((R=_[b])==null?void 0:R.y)}))&&this.cachedSiegePaths.push(E)}}}if(this.cachedSiegePaths.length>0){n.strokeStyle="rgba(184, 122, 255, 0.58)",n.lineWidth=1.25,n.setLineDash([4,4]),n.lineDashOffset=-e.time*16;for(const g of this.cachedSiegePaths)if(!(g.length<2)){n.beginPath(),n.moveTo(g[0].x,g[0].y);for(let S=1;S<g.length;S++)n.lineTo(g[S].x,g[S].y);n.stroke()}n.setLineDash([]),n.lineDashOffset=0}if(this.cachedOpenPaths.length>0){n.strokeStyle="rgba(255, 107, 87, 0.8)",n.lineWidth=1.5,n.setLineDash([5,4]),n.lineDashOffset=-e.time*24;for(const g of this.cachedOpenPaths)if(!(g.length<2)){n.beginPath(),n.moveTo(g[0].x,g[0].y);for(let S=1;S<g.length;S++)n.lineTo(g[S].x,g[S].y);n.stroke(),n.fillStyle="#ff6b57",n.fillRect(Math.round(g[0].x-2),Math.round(g[0].y-2),4,4)}n.setLineDash([]),n.lineDashOffset=0}}for(const f of e.buildings){if(!Dn(f.id))continue;const m=t.getBuildingAtGrid(f.gx+1,f.gy),g=t.getBuildingAtGrid(f.gx,f.gy+1);m&&Dn(m.id)&&(n.fillStyle=f.id==="obsidian_wall"||m.id==="obsidian_wall"?"#453c66":"#6f7f94",n.fillRect(f.gx*U+12,f.gy*U+4,8,8)),g&&Dn(g.id)&&(n.fillStyle=f.id==="obsidian_wall"||g.id==="obsidian_wall"?"#453c66":"#6f7f94",n.fillRect(f.gx*U+4,f.gy*U+12,8,8))}for(const f of e.buildings)f.id!=="spike_trap"&&f.id!=="rune_mine"||(n.globalAlpha=f.id==="rune_mine"&&!f.armed?.38:1,this.drawSpriteAt(n,f.id,f.x,f.y,0,f.flash>0,!1,1),n.globalAlpha=1);this.drawSpriteAt(n,"citadel",e.citadel.x,e.citadel.y,0,e.citadel.flash>0,!1,1);for(let f=0;f<e.citadel.lvl;f++)n.fillStyle="#4ef2e8",n.fillRect(Math.round(e.citadel.x-e.citadel.lvl*2+f*4),Math.round(e.citadel.y-26),2,2);if(e.citadel.shield>0&&e.citadel.maxShield>0){const m=Math.round(e.citadel.x-18),g=Math.round(e.citadel.y+25);n.fillStyle="#090d16",n.fillRect(m,g,36,2),n.fillStyle="#38bdf8",n.fillRect(m,g,Math.round(36*Se(e.citadel.shield/e.citadel.maxShield,0,1)),2)}for(const f of e.buildings)if(!(f.id==="spike_trap"||f.id==="rune_mine")){if(this.drawSpriteAt(n,f.id,f.x,f.y,0,f.flash>0,!1,1),f.id==="shield_gen"){const m=di(f);n.strokeStyle="rgba(56, 189, 248, 0.2)",n.lineWidth=1,n.beginPath(),n.arc(Math.round(f.x),Math.round(f.y),m,0,zt),n.stroke()}if(f.antiAir||f.id==="sky_wall"){const m=.55+.35*Math.sin(e.time*6+f.gx*.7+f.gy*.7);f.id!=="sky_wall"&&(n.fillStyle="#090d16",n.fillRect(f.gx*U+1,f.gy*U-1,3,4),n.fillRect(f.gx*U+U-4,f.gy*U-1,3,4),n.fillStyle="#38bdf8",n.fillRect(f.gx*U+2,f.gy*U,1,2),n.fillRect(f.gx*U+U-3,f.gy*U,1,2)),n.fillStyle=`rgba(78, 242, 232, ${m.toFixed(2)})`,n.fillRect(f.gx*U+2,f.gy*U+1,U-4,1);const g=t.getBuildingAtGrid(f.gx+1,f.gy);g&&(g.antiAir||g.id==="sky_wall")&&(n.fillStyle=`rgba(56, 189, 248, ${(m*.8).toFixed(2)})`,n.fillRect(f.gx*U+12,f.gy*U+1,8,2));const S=t.getBuildingAtGrid(f.gx,f.gy+1);S&&(S.antiAir||S.id==="sky_wall")&&(n.fillStyle=`rgba(56, 189, 248, ${(m*.8).toFixed(2)})`,n.fillRect(f.gx*U+7,f.gy*U+12,2,8))}if(f.shield>0&&(n.strokeStyle="rgba(56, 189, 248, 0.85)",n.lineWidth=1,n.strokeRect(f.gx*U+.5,f.gy*U+.5,f.w*U-1,f.h*U-1)),f.overclockTimer>0&&(n.strokeStyle="#ffbe3b",n.lineWidth=1,n.strokeRect(f.gx*U+.5,f.gy*U+.5,f.w*U-1,f.h*U-1)),f.healFlash>0&&(n.strokeStyle="#5ef28c",n.lineWidth=1,n.strokeRect(f.gx*U+.5,f.gy*U+.5,f.w*U-1,f.h*U-1)),f.lvl>1){const m=f.lvl>=10?"#b87aff":f.lvl>=5?"#4ef2e8":"#ffbe3b";n.font=s?'700 5.8px "Inter", "Segoe UI", sans-serif':"bold 6px monospace",n.textAlign="left",n.textBaseline="top";const g=f.gx*U+1.2,S=f.gy*U+1,M=`L${f.lvl}`;s?(n.lineWidth=1.8,n.lineJoin="round",n.strokeStyle="rgba(9, 13, 22, 0.92)",n.strokeText(M,g,S),n.fillStyle=m,n.fillText(M,g,S)):(n.fillStyle="#090d16",n.fillText(M,g+1,S),n.fillText(M,g,S+1),n.fillStyle=m,n.fillText(M,g,S))}if(f.bonusNode&&(n.fillStyle="#4ef2e8",s?(n.beginPath(),n.arc(f.gx*U+f.w*U-3,f.gy*U+3,1.8,0,zt),n.fill()):n.fillRect(f.gx*U+f.w*U-4,f.gy*U+1,3,3)),f.spec){const m=(v=rr[f.id])==null?void 0:v[f.spec];if(m){const g=f.gx*U+f.w*U-4,S=f.gy*U+3.2;s?(n.fillStyle="#090d16",n.beginPath(),n.arc(g,S,2.7,0,zt),n.fill(),n.fillStyle=m.color,n.beginPath(),n.arc(g,S,1.8,0,zt),n.fill()):(n.fillStyle="#090d16",n.fillRect(g-2,S-2,5,5),n.fillStyle=m.color,n.fillRect(g-1,S-1,3,3))}}if(f.shield>0&&f.maxShield>0){const m=f.w*U-2;n.fillStyle="#090d16",n.fillRect(f.gx*U+1,f.gy*U+f.h*U-5,m,2),n.fillStyle="#38bdf8",n.fillRect(f.gx*U+1,f.gy*U+f.h*U-5,Math.round(m*Se(f.shield/f.maxShield,0,1)),2)}if(f.hp<f.maxHp){const m=f.w*U-2;n.fillStyle="#090d16",n.fillRect(f.gx*U+1,f.gy*U+f.h*U-3,m,2),n.fillStyle=f.hp<f.maxHp*.35?"#ff4f6d":"#5ef28c",n.fillRect(f.gx*U+1,f.gy*U+f.h*U-3,Math.round(m*(f.hp/f.maxHp)),2)}}if(e.selectedBuildingUid){const f=e.buildings.find(m=>m.uid===e.selectedBuildingUid);if(f){n.strokeStyle="#4ef2e8",n.lineWidth=1,n.strokeRect(f.gx*U,f.gy*U,f.w*U,f.h*U);const m=di(f);m>0&&(n.setLineDash([3,3]),n.beginPath(),n.arc(f.x,f.y,m,0,zt),n.stroke(),n.setLineDash([]))}}if(e.toolMode==="build"&&e.buildMode&&e.hoverGx>=0&&e.hoverGy>=0){const f=We[e.buildMode],m=Rl(e,t,e.buildMode,e.hoverGx,e.hoverGy),g=e.hoverGx*U,S=e.hoverGy*U,M=f.w*U,_=f.h*U;n.fillStyle=m.ok?"rgba(94, 242, 140, 0.25)":"rgba(255, 79, 109, 0.28)",n.fillRect(g,S,M,_),n.strokeStyle=m.ok?"#5ef28c":"#ff4f6d",n.lineWidth=1,n.strokeRect(g+.5,S+.5,M-1,_-1),n.globalAlpha=.72,this.drawSpriteAt(n,f.id,g+M*.5,S+_*.5,0,!1,!1,1),n.globalAlpha=1,f.range>0&&(n.strokeStyle=m.ok?"rgba(78, 242, 232, 0.6)":"rgba(255, 79, 109, 0.45)",n.setLineDash([3,3]),n.beginPath(),n.arc(g+M*.5,S+_*.5,f.range,0,zt),n.stroke(),n.setLineDash([])),m.upgradeWall?this.drawPixelText(n,"+ ANTI-AÉRIEN",g+M*.5,S-6,"#38bdf8",!0):m.bonusNode?this.drawPixelText(n,"×2 FILON",g+M*.5,S-6,"#ffbe3b",!0):m.destroysNode&&this.drawPixelText(n,"ÉCRASE FILON",g+M*.5,S-6,"#ff7e33")}if(e.toolMode==="demolish"){let f=e.hoverGx,m=e.hoverGy,g=e.hoverGx,S=e.hoverGy;if(e.dragStart&&e.dragEnd&&(f=Math.min(e.dragStart.gx,e.dragEnd.gx),m=Math.min(e.dragStart.gy,e.dragEnd.gy),g=Math.max(e.dragStart.gx,e.dragEnd.gx),S=Math.max(e.dragStart.gy,e.dragEnd.gy)),f>=0&&m>=0){f=Se(f,0,Le-1),m=Se(m,0,He-1),g=Se(g,0,Le-1),S=Se(S,0,He-1);const M=f*U,_=m*U,E=(g-f+1)*U,y=(S-m+1)*U,x=[];let b=0,A=0;for(const D of e.buildings)if(D.gx<g+1&&D.gx+D.w>f&&D.gy<S+1&&D.gy+D.h>m){x.push(D);const O=pr(D);b+=O.stone,A+=O.crystal,n.fillStyle="rgba(255, 79, 109, 0.48)",n.fillRect(D.gx*U,D.gy*U,D.w*U,D.h*U),n.strokeStyle="#ff4f6d",n.lineWidth=1,n.strokeRect(D.gx*U+.5,D.gy*U+.5,D.w*U-1,D.h*U-1)}n.fillStyle="rgba(255, 79, 109, 0.22)",n.fillRect(M,_,E,y),n.strokeStyle="#ff4f6d",n.lineWidth=1,n.setLineDash([3,2]),n.strokeRect(M+.5,_+.5,E-1,y-1),n.setLineDash([]);const R=x.length>0?`DÉMOLIR ${x.length} · +${b}🪨${A>0?` +${A}💎`:""}`:"MODE DÉMOLITION";this.drawPixelText(n,R,M+E*.5,_-7,"#ff4f6d",!0)}}if(e.toolMode==="batch_upgrade"){const f=new Set(e.batchSelectedUids);for(const m of e.buildings){if(!f.has(m.uid))continue;const g=e.batchFilterId==="all"||m.id===e.batchFilterId;n.fillStyle=g?"rgba(255, 190, 59, 0.28)":"rgba(150, 171, 201, 0.14)",n.fillRect(m.gx*U,m.gy*U,m.w*U,m.h*U),n.strokeStyle=g?"#ffbe3b":"#6f7f94",n.lineWidth=1,n.strokeRect(m.gx*U+.5,m.gy*U+.5,m.w*U-1,m.h*U-1)}if(e.dragStart&&e.dragEnd){const m=Se(Math.min(e.dragStart.gx,e.dragEnd.gx),0,Le-1),g=Se(Math.min(e.dragStart.gy,e.dragEnd.gy),0,He-1),S=Se(Math.max(e.dragStart.gx,e.dragEnd.gx),0,Le-1),M=Se(Math.max(e.dragStart.gy,e.dragEnd.gy),0,He-1),_=m*U,E=g*U,y=(S-m+1)*U,x=(M-g+1)*U;n.fillStyle="rgba(255, 190, 59, 0.18)",n.fillRect(_,E,y,x),n.strokeStyle="#ffbe3b",n.lineWidth=1,n.setLineDash([3,2]),n.strokeRect(_+.5,E+.5,y-1,x-1),n.setLineDash([])}else e.batchSelectedUids.length===0&&e.hoverGx>=0&&e.hoverGy>=0&&this.drawPixelText(n,"GLISSER POUR SÉLECTIONNER",(e.hoverGx+.5)*U,e.hoverGy*U-7,"#ffbe3b",!0)}if(e.toolMode==="copy_select"){let f=e.hoverGx,m=e.hoverGy,g=e.hoverGx,S=e.hoverGy;if(e.dragStart&&e.dragEnd&&(f=Math.min(e.dragStart.gx,e.dragEnd.gx),m=Math.min(e.dragStart.gy,e.dragEnd.gy),g=Math.max(e.dragStart.gx,e.dragEnd.gx),S=Math.max(e.dragStart.gy,e.dragEnd.gy)),f>=0&&m>=0){f=Se(f,0,Le-1),m=Se(m,0,He-1),g=Se(g,0,Le-1),S=Se(S,0,He-1);const M=f*U,_=m*U,E=(g-f+1)*U,y=(S-m+1)*U;let x=0;for(const A of e.buildings)A.gx<g+1&&A.gx+A.w>f&&A.gy<S+1&&A.gy+A.h>m&&(x+=1,n.fillStyle="rgba(78, 242, 232, 0.35)",n.fillRect(A.gx*U,A.gy*U,A.w*U,A.h*U),n.strokeStyle="#4ef2e8",n.lineWidth=1,n.strokeRect(A.gx*U+.5,A.gy*U+.5,A.w*U-1,A.h*U-1));n.fillStyle="rgba(78, 242, 232, 0.16)",n.fillRect(M,_,E,y),n.strokeStyle="#4ef2e8",n.lineWidth=1,n.setLineDash([3,2]),n.strokeRect(M+.5,_+.5,E-1,y-1),n.setLineDash([]);const b=x>0?`COPIER ${x} BÂT.`:"GLISSER POUR COPIER";this.drawPixelText(n,b,M+E*.5,_-7,"#4ef2e8",!0)}}if(e.toolMode==="paste"&&e.blueprint&&e.hoverGx>=0&&e.hoverGy>=0){const f=e.blueprint,m=e.hoverGx-Math.floor(f.w/2),g=e.hoverGy-Math.floor(f.h/2),S=Ll(e,t,f,m,g);for(const b of S.entries){const A=b.gx*U,R=b.gy*U,D=b.item.w*U,O=b.item.h*U;n.fillStyle=b.status==="valid"?"rgba(94, 242, 140, 0.25)":b.status==="no_funds"?"rgba(255, 190, 59, 0.3)":"rgba(255, 79, 109, 0.3)",n.fillRect(A,R,D,O),n.strokeStyle=b.status==="valid"?"#5ef28c":b.status==="no_funds"?"#ffbe3b":"#ff4f6d",n.lineWidth=1,n.strokeRect(A+.5,R+.5,D-1,O-1),n.globalAlpha=.7,this.drawSpriteAt(n,b.item.id,A+D*.5,R+O*.5,0,!1,!1,1),n.globalAlpha=1}const M=m*U,_=g*U,E=f.w*U,y=f.h*U;n.strokeStyle="#4ef2e8",n.lineWidth=1,n.setLineDash([4,3]),n.strokeRect(M+.5,_+.5,E-1,y-1),n.setLineDash([]);const x=`COLLER ${S.validCount}/${f.items.length} · ${S.totalStone}🪨${S.totalCrystal>0?` ${S.totalCrystal}💎`:""} · [N] ROT.`;this.drawPixelText(n,x,M+E*.5,_-7,"#4ef2e8",!0)}for(const f of e.pickups){const m=f.kind==="stone"?"drop_stone":f.kind==="crystal"?"drop_crystal":"drop_heal",g=Math.round(Math.sin(e.time*5+f.uid)*1.2);this.drawSpriteAt(n,m,f.x,f.y+g,0,!1,!1,1)}for(const f of e.zonesFx){const m=Se(f.life/f.maxLife,0,1);if(f.kind==="acid_pool"){n.fillStyle=`rgba(163, 230, 53, ${.28*Math.min(1,m*2)})`,n.beginPath(),n.arc(Math.round(f.x),Math.round(f.y),f.r,0,zt),n.fill(),n.strokeStyle=`rgba(163, 230, 53, ${.65*Math.min(1,m*2)})`,n.lineWidth=1,n.setLineDash([3,2]),n.stroke(),n.setLineDash([]);const g=Math.round(f.x+Math.sin(e.time*6+f.uid)*(f.r*.45)),S=Math.round(f.y+Math.cos(e.time*5+f.uid)*(f.r*.35));n.fillStyle="#a3e635",n.fillRect(g,S,2,2)}else if(f.kind==="ult_strike"||f.kind==="boss_slam"){const g=Math.floor(e.time*18)%2===0;n.fillStyle=f.kind==="boss_slam"?g?"rgba(255, 79, 109, 0.28)":"rgba(255, 190, 59, 0.14)":"rgba(184, 122, 255, 0.22)",n.beginPath(),n.arc(Math.round(f.x),Math.round(f.y),f.r,0,zt),n.fill(),n.strokeStyle=f.color,n.lineWidth=1,n.stroke()}else{const g=f.r*(1-m*.6);n.strokeStyle=f.color,n.globalAlpha=m,n.lineWidth=1.5,n.beginPath(),n.arc(Math.round(f.x),Math.round(f.y),g,0,zt),n.stroke(),n.globalAlpha=1}}for(const f of e.enemies){f.flying&&(n.fillStyle="rgba(0, 0, 0, 0.35)",s?(n.beginPath(),n.ellipse(f.x,f.y+f.r+4.5,f.isBoss?10:5,f.isBoss?3.5:2,0,0,zt),n.fill()):n.fillRect(Math.round(f.x-4),Math.round(f.y+f.r+3),8,3));const m=f.isBoss?2:1,g=f.vx<-2;if(this.drawSpriteAt(n,f.art,f.x,f.y,f.animPhase,f.flash>0,g,m),(f.armorShred>0||f.poisonTimer>0)&&(n.fillStyle="#a3e635",n.fillRect(Math.round(f.x+f.r-1),Math.round(f.y-f.r),3,2)),f.hp<f.maxHp||f.isBoss){const S=f.isBoss?28:12,M=f.isBoss?f.r+8:f.r+4;n.fillStyle="#090d16",n.fillRect(Math.round(f.x-S/2),Math.round(f.y-M),S,2),n.fillStyle=f.isBoss?"#ffbe3b":"#ff4f6d",n.fillRect(Math.round(f.x-S/2),Math.round(f.y-M),Math.round(S*(f.hp/f.maxHp)),2)}}for(const f of e.summonedTurrets)this.drawSpriteAt(n,"auto_turret",f.x,f.y,f.animPhase,!1,!1,1),n.fillStyle="#090d16",n.fillRect(Math.round(f.x-5),Math.round(f.y+6),10,2),n.fillStyle="#ffbe3b",n.fillRect(Math.round(f.x-5),Math.round(f.y+6),Math.round(10*Se(f.life/f.maxLife,0,1)),2);const d=e.hero,p=!!(e.coopPlayers&&e.coopPlayers.length>0);if(d.alive){if(d.invuln>0&&Math.floor(e.time*20)%2===0&&d.hitFlash<=0||this.drawSpriteAt(n,Mt[e.heroClass].spriteKey,d.x,d.y,d.animPhase,d.hitFlash>0,d.faceX<0,1),p&&e.localPlayerName&&this.drawPixelText(n,e.localPlayerName,d.x,d.y-12,e.localPlayerColor||"#4ef2e8",!1),d.harvestTargetUid>0){const m=e.nodes.find(g=>g.uid===d.harvestTargetUid);m&&(n.strokeStyle=m.kind==="stone"?"#b4c2d4":"#4ef2e8",n.lineWidth=1,n.setLineDash([2,2]),n.beginPath(),n.moveTo(Math.round(d.x),Math.round(d.y)),n.lineTo(Math.round(m.x),Math.round(m.y)),n.stroke(),n.setLineDash([]))}d.rallyDur>0&&(n.strokeStyle="rgba(255, 190, 59, 0.5)",n.lineWidth=1,n.beginPath(),n.arc(Math.round(d.x),Math.round(d.y),12,0,zt),n.stroke())}else{const f=18+Math.sin(e.time*8)*3;n.strokeStyle="#4ef2e8",n.lineWidth=1,n.setLineDash([3,2]),n.beginPath(),n.arc(e.citadel.x,e.citadel.y+18,f,0,zt),n.stroke(),n.setLineDash([])}if(e.coopPlayers)for(const f of e.coopPlayers){const m=f.hero;if(!m.alive)continue;this.drawSpriteAt(n,(Mt[f.heroClass]||Mt.guardian).spriteKey,m.x,m.y,m.animPhase,m.hitFlash>0,m.faceX<0,1);const g=14;n.fillStyle="#090d16",n.fillRect(Math.round(m.x-g/2),Math.round(m.y+8),g,2),n.fillStyle=f.color,n.fillRect(Math.round(m.x-g/2),Math.round(m.y+8),Math.round(g*Se(m.hp/Math.max(1,m.maxHp),0,1)),2),this.drawPixelText(n,f.name,m.x,m.y-12,f.color,!1),m.rallyDur>0&&(n.strokeStyle=f.color,n.lineWidth=1,n.beginPath(),n.arc(m.x,m.y,12,0,zt),n.stroke())}for(const f of e.projectiles)if(s){const m=Math.hypot(f.vx,f.vy);if(m>20){const g=f.x-f.vx/m*Math.min(9,f.r*2.8),S=f.y-f.vy/m*Math.min(9,f.r*2.8);n.strokeStyle=f.color,n.globalAlpha=.55,n.lineWidth=Math.max(1.2,f.r*1.25),n.lineCap="round",n.beginPath(),n.moveTo(g,S),n.lineTo(f.x,f.y),n.stroke(),n.globalAlpha=1}n.fillStyle=f.color,n.beginPath(),n.arc(f.x,f.y,Math.max(1.4,f.r*1.15),0,zt),n.fill(),n.fillStyle="#ffffff",n.beginPath(),n.arc(f.x-f.r*.25,f.y-f.r*.25,Math.max(.6,f.r*.45),0,zt),n.fill()}else{const m=Math.round(f.x),g=Math.round(f.y);n.fillStyle=f.color;const S=Math.max(1,Math.round(f.r));n.fillRect(m-S,g-S,S*2,S*2),n.fillStyle="#ffffff",n.fillRect(m,g,1,1)}for(const f of e.arcs){n.strokeStyle=f.color,n.globalAlpha=Se(f.life/f.maxLife,0,1),n.lineWidth=f.width,n.beginPath();for(let m=0;m<f.pts.length;m++){const g=f.pts[m];m===0?n.moveTo(Math.round(g.x),Math.round(g.y)):n.lineTo(Math.round(g.x),Math.round(g.y))}n.stroke(),n.globalAlpha=1}for(const f of e.buildings){if(f.id!=="solar_tower"||f.beamTargetUid<=0)continue;const m=e.enemies.find(g=>g.uid===f.beamTargetUid&&g.hp>0);m&&(n.strokeStyle=f.beamCharge>.65?"#ff7e33":"#ffbe3b",n.lineWidth=1.5+f.beamCharge*2.5,n.beginPath(),n.moveTo(Math.round(f.x),Math.round(f.y-4)),n.lineTo(Math.round(m.x),Math.round(m.y)),n.stroke(),n.strokeStyle="#ffffff",n.lineWidth=1,n.beginPath(),n.moveTo(Math.round(f.x),Math.round(f.y-4)),n.lineTo(Math.round(m.x),Math.round(m.y)),n.stroke(),n.fillStyle="#ffe066",n.fillRect(Math.round(m.x-2),Math.round(m.y-2),4,4))}for(const f of e.particles){const m=Se(f.life/f.maxLife,0,1),g=Math.max(1,f.size2+(f.size-f.size2)*m);if(n.fillStyle=f.color,n.globalAlpha=m,s)n.beginPath(),n.arc(f.x,f.y,g*.55,0,zt),n.fill();else{const S=Math.round(g);n.fillRect(Math.round(f.x-S*.5),Math.round(f.y-S*.5),S,S)}}n.globalAlpha=1;for(const f of e.texts)this.drawPixelText(n,f.text,f.x,f.y,f.color,f.crit);if(e.phase==="wave"){const f=e.activeWaves.some(S=>S.event==="blood_moon"),m=e.activeWaves.some(S=>S.event==="ether_storm"),g=e.activeWaves.some(S=>S.event==="crystal_rain");(f||m||g)&&(n.fillStyle=f?"rgba(255, 45, 85, 0.08)":m?"rgba(184, 122, 255, 0.08)":"rgba(78, 242, 232, 0.06)",n.fillRect(0,0,Ft,Ot))}const u=new Set;if(e.phase==="prep")for(const f of e.nextWavePlan.flanks)u.add(f);else for(const f of e.activeWaves)for(const m of f.flanks)u.add(m);if(Math.floor(e.time*4)%2===0)for(const f of u){const m=f==="W"?14:f==="E"?Ft-14:Ft*.5,g=f==="N"?14:f==="S"?Ot-14:Ot*.5;this.drawPixelText(n,"▲ ASSAUT",m,g,"#ff4f6d",!0)}n.restore(),e.tacticalPause&&(n.strokeStyle="rgba(78, 242, 232, 0.65)",n.lineWidth=2,n.strokeRect(1,1,this.viewW-2,this.viewH-2)),e.screenFlash>0&&(n.fillStyle=e.screenFlashCol,n.globalAlpha=e.screenFlash*.35,n.fillRect(0,0,this.viewW,this.viewH),n.globalAlpha=1),this.flush()}renderMinimap(e,t){const n=e.getContext("2d");if(!n)return;const s=e.width,r=e.height,a=s/Ft,o=r/Ot;n.fillStyle="#0c1614",n.fillRect(0,0,s,r);for(const l of t.nodes)l.amount<=0||(n.fillStyle=l.kind==="stone"?"#8fa3c7":"#4ef2e8",n.fillRect(Math.round(l.x*a)-1,Math.round(l.y*o)-1,2,2));for(const l of t.buildings)n.fillStyle=We[l.id].color,n.fillRect(Math.round(l.gx*U*a),Math.round(l.gy*U*o),Math.max(2,Math.round(l.w*U*a)),Math.max(2,Math.round(l.h*U*o)));n.fillStyle="#ffbe3b",n.fillRect(Math.round(_n*U*a),Math.round(ln*U*o),Math.round(ht*U*a),Math.round(ht*U*o));for(const l of t.enemies){n.fillStyle=l.isBoss?"#ffbe3b":"#ff4f6d";const c=l.isBoss?4:2;n.fillRect(Math.round(l.x*a-c/2),Math.round(l.y*o-c/2),c,c)}if(t.hero.alive&&(n.fillStyle="#ffffff",n.fillRect(Math.round(t.hero.x*a-1),Math.round(t.hero.y*o-1),3,3)),t.coopPlayers)for(const l of t.coopPlayers)l.hero.alive&&(n.fillStyle=l.color,n.fillRect(Math.round(l.hero.x*a-1),Math.round(l.hero.y*o-1),3,3))}flush(){const e=this.targetCanvas.getContext("2d");if(this.isHd){e.restore();return}e.imageSmoothingEnabled=!1,e.drawImage(this.bufCanvas,0,0,this.targetCanvas.width,this.targetCanvas.height)}}/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Dl="187",Yf=0,_c=1,Kf=2,ea=1,Lu=2,js=3,Li=0,In=1,Hn=2,As=0,ir=1,yc=2,Mc=3,bc=4,Zf=5,bs=100,Jf=101,Qf=102,jf=103,ep=104,tp=200,np=201,ip=202,sp=203,Pu=204,Du=205,rp=206,ap=207,op=208,lp=209,cp=210,dp=211,up=212,hp=213,fp=214,Io=0,Uo=1,No=2,or=3,Bo=4,Fo=5,Oo=6,Ho=7,Iu=0,pp=1,mp=2,Ai=0,Uu=1,Nu=2,Bu=3,Il=4,Fu=5,Ou=6,Hu=7,Gu=300,Ls=301,lr=302,qa=303,Xa=304,cr=1e3,Ti=1001,Go=1002,cn=1003,gp=1004,br=1005,Pn=1006,Ya=1007,Ci=1008,Gn=1009,zu=1010,Vu=1011,dr=1012,Ul=1013,pi=1014,ri=1015,mi=1016,Nl=1017,Bl=1018,Ps=1020,Wu=35902,$u=35899,qu=1021,Xu=1022,hi=1023,zi=1026,Hi=1027,Fl=1028,Ol=1029,ss=1030,Hl=1031,Gl=1033,ta=33776,na=33777,ia=33778,sa=33779,zo=35840,Vo=35841,Wo=35842,$o=35843,qo=36196,Xo=37492,Yo=37496,Ko=37488,Zo=37489,va=37490,Jo=37491,Qo=37808,jo=37809,el=37810,tl=37811,nl=37812,il=37813,sl=37814,rl=37815,al=37816,ol=37817,ll=37818,cl=37819,dl=37820,ul=37821,hl=36492,fl=36494,pl=36495,ml=36283,gl=36284,Sa=36285,vl=36286,vp=3200,Sl=0,Sp=1,Oi="",Ln="srgb",xa="srgb-linear",_a="linear",xt="srgb",Ka=7680,xp=519,_p=512,yp=513,Mp=514,Yu=515,bp=516,kp=517,Ku=518,Zu=519,Ep=35044,kc=35048,Ec="300 es",ai=2e3,ur=2001;function wp(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function ya(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Tp(){const i=ya("canvas");return i.style.display="block",i}const wc={};function Tc(...i){const e="THREE."+i.shift();console.log(e,...i)}function Ju(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function qe(...i){i=Ju(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function pt(...i){i=Ju(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function ra(...i){const e=i.join(" ");e in wc||(wc[e]=!0,qe(...i))}function Cp(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}const Ap={[Io]:Io,[No]:Oo,[Bo]:Bo,[or]:Fo,[Uo]:Uo,[Oo]:No,[Ho]:Ho,[Fo]:or};class as{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,e);e.target=null}}}const vn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Za=Math.PI/180,xl=180/Math.PI;function mr(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(vn[i&255]+vn[i>>8&255]+vn[i>>16&255]+vn[i>>24&255]+"-"+vn[e&255]+vn[e>>8&255]+"-"+vn[e>>16&15|64]+vn[e>>24&255]+"-"+vn[t&63|128]+vn[t>>8&255]+"-"+vn[t>>16&255]+vn[t>>24&255]+vn[n&255]+vn[n>>8&255]+vn[n>>16&255]+vn[n>>24&255]).toLowerCase()}function ut(i,e,t){return Math.max(e,Math.min(t,i))}function Rp(i,e){return(i%e+e)%e}function Ja(i,e,t){return(1-t)*i+t*e}function Lp(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function zl(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function Pp(i,e){if(e.constructor===Float32Array)return i;const t=zl(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/t,-1)}function Dp(i,e){if(e.constructor===Float32Array)return i;const t=zl(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*t)}const ec=class ec{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=ut(this.x,e.x,t.x),this.y=ut(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=ut(this.x,e,t),this.y=ut(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ut(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(ut(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*n-a*s+e.x,this.y=r*s+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};ec.prototype.isVector2=!0;let it=ec;class os{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,a,o){let l=n[s+0],c=n[s+1],d=n[s+2],p=n[s+3],u=r[a+0],h=r[a+1],v=r[a+2],f=r[a+3];if(p!==f||l!==u||c!==h||d!==v){let m=l*u+c*h+d*v+p*f;m<0&&(u=-u,h=-h,v=-v,f=-f,m=-m);let g=1-o;if(m<.9995){const S=Math.acos(m),M=Math.sin(S);g=Math.sin(g*S)/M,o=Math.sin(o*S)/M,l=l*g+u*o,c=c*g+h*o,d=d*g+v*o,p=p*g+f*o}else{l=l*g+u*o,c=c*g+h*o,d=d*g+v*o,p=p*g+f*o;const S=1/Math.sqrt(l*l+c*c+d*d+p*p);l*=S,c*=S,d*=S,p*=S}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=p}static multiplyQuaternionsFlat(e,t,n,s,r,a){const o=n[s],l=n[s+1],c=n[s+2],d=n[s+3],p=r[a],u=r[a+1],h=r[a+2],v=r[a+3];return e[t]=o*v+d*p+l*h-c*u,e[t+1]=l*v+d*u+c*p-o*h,e[t+2]=c*v+d*h+o*u-l*p,e[t+3]=d*v-o*p-l*u-c*h,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(s/2),p=o(r/2),u=l(n/2),h=l(s/2),v=l(r/2);switch(a){case"XYZ":this._x=u*d*p+c*h*v,this._y=c*h*p-u*d*v,this._z=c*d*v+u*h*p,this._w=c*d*p-u*h*v;break;case"YXZ":this._x=u*d*p+c*h*v,this._y=c*h*p-u*d*v,this._z=c*d*v-u*h*p,this._w=c*d*p+u*h*v;break;case"ZXY":this._x=u*d*p-c*h*v,this._y=c*h*p+u*d*v,this._z=c*d*v+u*h*p,this._w=c*d*p-u*h*v;break;case"ZYX":this._x=u*d*p-c*h*v,this._y=c*h*p+u*d*v,this._z=c*d*v-u*h*p,this._w=c*d*p+u*h*v;break;case"YZX":this._x=u*d*p+c*h*v,this._y=c*h*p+u*d*v,this._z=c*d*v-u*h*p,this._w=c*d*p-u*h*v;break;case"XZY":this._x=u*d*p-c*h*v,this._y=c*h*p-u*d*v,this._z=c*d*v+u*h*p,this._w=c*d*p+u*h*v;break;default:qe("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],a=t[1],o=t[5],l=t[9],c=t[2],d=t[6],p=t[10],u=n+o+p;if(u>0){const h=.5/Math.sqrt(u+1);this._w=.25/h,this._x=(d-l)*h,this._y=(r-c)*h,this._z=(a-s)*h}else if(n>o&&n>p){const h=2*Math.sqrt(1+n-o-p);this._w=(d-l)/h,this._x=.25*h,this._y=(s+a)/h,this._z=(r+c)/h}else if(o>p){const h=2*Math.sqrt(1+o-n-p);this._w=(r-c)/h,this._x=(s+a)/h,this._y=.25*h,this._z=(l+d)/h}else{const h=2*Math.sqrt(1+p-n-o);this._w=(a-s)/h,this._x=(r+c)/h,this._y=(l+d)/h,this._z=.25*h}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(ut(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,a=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=n*d+a*o+s*c-r*l,this._y=s*d+a*l+r*o-n*c,this._z=r*d+a*c+n*l-s*o,this._w=a*d-n*o-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,s=e._y,r=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,s=-s,r=-r,a=-a,o=-o);let l=1-t;if(o<.9995){const c=Math.acos(o),d=Math.sin(c);l=Math.sin(l*c)/d,t=Math.sin(t*c)/d,this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+r*t,this._w=this._w*l+a*t,this._onChangeCallback()}else this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+r*t,this._w=this._w*l+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const tc=class tc{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Cc.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Cc.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,a=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*s-o*n),d=2*(o*t-r*s),p=2*(r*n-a*t);return this.x=t+l*c+a*p-o*d,this.y=n+l*d+o*c-r*p,this.z=s+l*p+r*d-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=ut(this.x,e.x,t.x),this.y=ut(this.y,e.y,t.y),this.z=ut(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=ut(this.x,e,t),this.y=ut(this.y,e,t),this.z=ut(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ut(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,a=t.x,o=t.y,l=t.z;return this.x=s*l-r*o,this.y=r*a-n*l,this.z=n*o-s*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Qa.copy(this).projectOnVector(e),this.sub(Qa)}reflect(e){return this.sub(Qa.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(ut(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};tc.prototype.isVector3=!0;let z=tc;const Qa=new z,Cc=new os,nc=class nc{constructor(e,t,n,s,r,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,l,c)}set(e,t,n,s,r,a,o,l,c){const d=this.elements;return d[0]=e,d[1]=s,d[2]=o,d[3]=t,d[4]=r,d[5]=l,d[6]=n,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],d=n[4],p=n[7],u=n[2],h=n[5],v=n[8],f=s[0],m=s[3],g=s[6],S=s[1],M=s[4],_=s[7],E=s[2],y=s[5],x=s[8];return r[0]=a*f+o*S+l*E,r[3]=a*m+o*M+l*y,r[6]=a*g+o*_+l*x,r[1]=c*f+d*S+p*E,r[4]=c*m+d*M+p*y,r[7]=c*g+d*_+p*x,r[2]=u*f+h*S+v*E,r[5]=u*m+h*M+v*y,r[8]=u*g+h*_+v*x,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*a*d-t*o*c-n*r*d+n*o*l+s*r*c-s*a*l}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],p=d*a-o*c,u=o*l-d*r,h=c*r-a*l,v=t*p+n*u+s*h;if(v===0)return this.set(0,0,0,0,0,0,0,0,0);const f=1/v;return e[0]=p*f,e[1]=(s*c-d*n)*f,e[2]=(o*n-s*a)*f,e[3]=u*f,e[4]=(d*t-s*l)*f,e[5]=(s*r-o*t)*f,e[6]=h*f,e[7]=(n*l-c*t)*f,e[8]=(a*t-n*r)*f,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,a,o){const l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+e,-s*c,s*l,-s*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return ra("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ja.makeScale(e,t)),this}rotate(e){return ra("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ja.makeRotation(-e)),this}translate(e,t){return ra("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ja.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};nc.prototype.isMatrix3=!0;let Ye=nc;const ja=new Ye,Ac=new Ye().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Rc=new Ye().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Ip(){const i={enabled:!0,workingColorSpace:xa,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===xt&&(s.r=Ri(s.r),s.g=Ri(s.g),s.b=Ri(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===xt&&(s.r=Rs(s.r),s.g=Rs(s.g),s.b=Rs(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Oi?_a:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[a].fromXYZ).multiply(this.spaces[r].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[xa]:{primaries:e,whitePoint:n,transfer:_a,toXYZ:Ac,fromXYZ:Rc,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Ln},outputColorSpaceConfig:{drawingBufferColorSpace:Ln}},[Ln]:{primaries:e,whitePoint:n,transfer:xt,toXYZ:Ac,fromXYZ:Rc,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Ln}}}),i}const dt=Ip();function Ri(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Rs(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let ds;class Up{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ds===void 0&&(ds=ya("canvas")),ds.width=e.width,ds.height=e.height;const s=ds.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=ds}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ya("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=Ri(r[a]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Ri(t[n]/255)*255):t[n]=Ri(t[n]);return{data:t,width:e.width,height:e.height}}else return qe("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Np=0;class Vl{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Np++}),this.uuid=mr(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width||0,t.height||0,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(eo(s[a].image)):r.push(eo(s[a]))}else r=eo(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function eo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Up.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(qe("Texture: Unable to serialize Texture."),{})}let Bp=0;const to=new z;class Mn extends as{constructor(e=Mn.DEFAULT_IMAGE,t=Mn.DEFAULT_MAPPING,n=Ti,s=Ti,r=Pn,a=Ci,o=hi,l=Gn,c=Mn.DEFAULT_ANISOTROPY,d=Oi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Bp++}),this.uuid=mr(),this.name="",this.source=new Vl(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new it(0,0),this.repeat=new it(1,1),this.center=new it(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ye,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(to).x}get height(){return this.source.getSize(to).y}get depth(){return this.source.getSize(to).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){qe(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){qe(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Gu)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case cr:e.x=e.x-Math.floor(e.x);break;case Ti:e.x=e.x<0?0:1;break;case Go:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case cr:e.y=e.y-Math.floor(e.y);break;case Ti:e.y=e.y<0?0:1;break;case Go:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Mn.DEFAULT_IMAGE=null;Mn.DEFAULT_MAPPING=Gu;Mn.DEFAULT_ANISOTROPY=1;const ic=class ic{constructor(e=0,t=0,n=0,s=1){this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*t+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*t+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*t+a[7]*n+a[11]*s+a[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const l=e.elements,c=l[0],d=l[4],p=l[8],u=l[1],h=l[5],v=l[9],f=l[2],m=l[6],g=l[10];if(Math.abs(d-u)<.01&&Math.abs(p-f)<.01&&Math.abs(v-m)<.01){if(Math.abs(d+u)<.1&&Math.abs(p+f)<.1&&Math.abs(v+m)<.1&&Math.abs(c+h+g-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const M=(c+1)/2,_=(h+1)/2,E=(g+1)/2,y=(d+u)/4,x=(p+f)/4,b=(v+m)/4;return M>_&&M>E?M<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(M),s=y/n,r=x/n):_>E?_<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(_),n=y/s,r=b/s):E<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(E),n=x/r,s=b/r),this.set(n,s,r,t),this}let S=Math.sqrt((m-v)*(m-v)+(p-f)*(p-f)+(u-d)*(u-d));return Math.abs(S)<.001&&(S=1),this.x=(m-v)/S,this.y=(p-f)/S,this.z=(u-d)/S,this.w=Math.acos((c+h+g-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=ut(this.x,e.x,t.x),this.y=ut(this.y,e.y,t.y),this.z=ut(this.z,e.z,t.z),this.w=ut(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=ut(this.x,e,t),this.y=ut(this.y,e,t),this.z=ut(this.z,e,t),this.w=ut(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ut(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};ic.prototype.isVector4=!0;let Gt=ic;class Fp extends as{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Pn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Gt(0,0,e,t),this.scissorTest=!1,this.viewport=new Gt(0,0,e,t),this.textures=[];const s=n.count;for(let r=0;r<s;r++)this.textures[r]=new Mn({width:e,height:t,depth:n.depth}),this.textures[r].isRenderTargetTexture=!0,this.textures[r].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:Pn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new Vl(s)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class fi extends Fp{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Qu extends Mn{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=cn,this.minFilter=cn,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Op extends Mn{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=cn,this.minFilter=cn,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}const Ta=class Ta{constructor(e,t,n,s,r,a,o,l,c,d,p,u,h,v,f,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,l,c,d,p,u,h,v,f,m)}set(e,t,n,s,r,a,o,l,c,d,p,u,h,v,f,m){const g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=s,g[1]=r,g[5]=a,g[9]=o,g[13]=l,g[2]=c,g[6]=d,g[10]=p,g[14]=u,g[3]=h,g[7]=v,g[11]=f,g[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ta().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,s=1/us.setFromMatrixColumn(e,0).length(),r=1/us.setFromMatrixColumn(e,1).length(),a=1/us.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),d=Math.cos(r),p=Math.sin(r);if(e.order==="XYZ"){const u=a*d,h=a*p,v=o*d,f=o*p;t[0]=l*d,t[4]=-l*p,t[8]=c,t[1]=h+v*c,t[5]=u-f*c,t[9]=-o*l,t[2]=f-u*c,t[6]=v+h*c,t[10]=a*l}else if(e.order==="YXZ"){const u=l*d,h=l*p,v=c*d,f=c*p;t[0]=u+f*o,t[4]=v*o-h,t[8]=a*c,t[1]=a*p,t[5]=a*d,t[9]=-o,t[2]=h*o-v,t[6]=f+u*o,t[10]=a*l}else if(e.order==="ZXY"){const u=l*d,h=l*p,v=c*d,f=c*p;t[0]=u-f*o,t[4]=-a*p,t[8]=v+h*o,t[1]=h+v*o,t[5]=a*d,t[9]=f-u*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const u=a*d,h=a*p,v=o*d,f=o*p;t[0]=l*d,t[4]=v*c-h,t[8]=u*c+f,t[1]=l*p,t[5]=f*c+u,t[9]=h*c-v,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const u=a*l,h=a*c,v=o*l,f=o*c;t[0]=l*d,t[4]=f-u*p,t[8]=v*p+h,t[1]=p,t[5]=a*d,t[9]=-o*d,t[2]=-c*d,t[6]=h*p+v,t[10]=u-f*p}else if(e.order==="XZY"){const u=a*l,h=a*c,v=o*l,f=o*c;t[0]=l*d,t[4]=-p,t[8]=c*d,t[1]=u*p+f,t[5]=a*d,t[9]=h*p-v,t[2]=v*p-h,t[6]=o*d,t[10]=f*p+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Hp,e,Gp)}lookAt(e,t,n){const s=this.elements;return Un.subVectors(e,t),Un.lengthSq()===0&&(Un.z=1),Un.normalize(),Ii.crossVectors(n,Un),Ii.lengthSq()===0&&(Math.abs(n.z)===1?Un.x+=1e-4:Un.z+=1e-4,Un.normalize(),Ii.crossVectors(n,Un)),Ii.normalize(),kr.crossVectors(Un,Ii),s[0]=Ii.x,s[4]=kr.x,s[8]=Un.x,s[1]=Ii.y,s[5]=kr.y,s[9]=Un.y,s[2]=Ii.z,s[6]=kr.z,s[10]=Un.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],d=n[1],p=n[5],u=n[9],h=n[13],v=n[2],f=n[6],m=n[10],g=n[14],S=n[3],M=n[7],_=n[11],E=n[15],y=s[0],x=s[4],b=s[8],A=s[12],R=s[1],D=s[5],O=s[9],X=s[13],k=s[2],P=s[6],F=s[10],G=s[14],se=s[3],Y=s[7],ae=s[11],le=s[15];return r[0]=a*y+o*R+l*k+c*se,r[4]=a*x+o*D+l*P+c*Y,r[8]=a*b+o*O+l*F+c*ae,r[12]=a*A+o*X+l*G+c*le,r[1]=d*y+p*R+u*k+h*se,r[5]=d*x+p*D+u*P+h*Y,r[9]=d*b+p*O+u*F+h*ae,r[13]=d*A+p*X+u*G+h*le,r[2]=v*y+f*R+m*k+g*se,r[6]=v*x+f*D+m*P+g*Y,r[10]=v*b+f*O+m*F+g*ae,r[14]=v*A+f*X+m*G+g*le,r[3]=S*y+M*R+_*k+E*se,r[7]=S*x+M*D+_*P+E*Y,r[11]=S*b+M*O+_*F+E*ae,r[15]=S*A+M*X+_*G+E*le,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],a=e[1],o=e[5],l=e[9],c=e[13],d=e[2],p=e[6],u=e[10],h=e[14],v=e[3],f=e[7],m=e[11],g=e[15],S=l*h-c*u,M=o*h-c*p,_=o*u-l*p,E=a*h-c*d,y=a*u-l*d,x=a*p-o*d;return t*(f*S-m*M+g*_)-n*(v*S-m*E+g*y)+s*(v*M-f*E+g*x)-r*(v*_-f*y+m*x)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[1],a=e[5],o=e[9],l=e[2],c=e[6],d=e[10];return t*(a*d-o*c)-n*(r*d-o*l)+s*(r*c-a*l)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],p=e[9],u=e[10],h=e[11],v=e[12],f=e[13],m=e[14],g=e[15],S=t*o-n*a,M=t*l-s*a,_=t*c-r*a,E=n*l-s*o,y=n*c-r*o,x=s*c-r*l,b=d*f-p*v,A=d*m-u*v,R=d*g-h*v,D=p*m-u*f,O=p*g-h*f,X=u*g-h*m,k=S*X-M*O+_*D+E*R-y*A+x*b;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const P=1/k;return e[0]=(o*X-l*O+c*D)*P,e[1]=(s*O-n*X-r*D)*P,e[2]=(f*x-m*y+g*E)*P,e[3]=(u*y-p*x-h*E)*P,e[4]=(l*R-a*X-c*A)*P,e[5]=(t*X-s*R+r*A)*P,e[6]=(m*_-v*x-g*M)*P,e[7]=(d*x-u*_+h*M)*P,e[8]=(a*O-o*R+c*b)*P,e[9]=(n*R-t*O-r*b)*P,e[10]=(v*y-f*_+g*S)*P,e[11]=(p*_-d*y-h*S)*P,e[12]=(o*A-a*D-l*b)*P,e[13]=(t*D-n*A+s*b)*P,e[14]=(f*M-v*E-m*S)*P,e[15]=(d*E-p*M+u*S)*P,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,a=e.x,o=e.y,l=e.z,c=r*a,d=r*o;return this.set(c*a+n,c*o-s*l,c*l+s*o,0,c*o+s*l,d*o+n,d*l-s*a,0,c*l-s*o,d*l+s*a,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,a){return this.set(1,n,r,0,e,1,a,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,a=t._y,o=t._z,l=t._w,c=r+r,d=a+a,p=o+o,u=r*c,h=r*d,v=r*p,f=a*d,m=a*p,g=o*p,S=l*c,M=l*d,_=l*p,E=n.x,y=n.y,x=n.z;return s[0]=(1-(f+g))*E,s[1]=(h+_)*E,s[2]=(v-M)*E,s[3]=0,s[4]=(h-_)*y,s[5]=(1-(u+g))*y,s[6]=(m+S)*y,s[7]=0,s[8]=(v+M)*x,s[9]=(m-S)*x,s[10]=(1-(u+f))*x,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;e.x=s[12],e.y=s[13],e.z=s[14];const r=this.determinantAffine();if(r===0)return n.set(1,1,1),t.identity(),this;let a=us.set(s[0],s[1],s[2]).length();const o=us.set(s[4],s[5],s[6]).length(),l=us.set(s[8],s[9],s[10]).length();r<0&&(a=-a),Qn.copy(this);const c=1/a,d=1/o,p=1/l;return Qn.elements[0]*=c,Qn.elements[1]*=c,Qn.elements[2]*=c,Qn.elements[4]*=d,Qn.elements[5]*=d,Qn.elements[6]*=d,Qn.elements[8]*=p,Qn.elements[9]*=p,Qn.elements[10]*=p,t.setFromRotationMatrix(Qn),n.x=a,n.y=o,n.z=l,this}makePerspective(e,t,n,s,r,a,o=ai,l=!1){const c=this.elements,d=2*r/(t-e),p=2*r/(n-s),u=(t+e)/(t-e),h=(n+s)/(n-s);let v,f;if(l)v=r/(a-r),f=a*r/(a-r);else if(o===ai)v=-(a+r)/(a-r),f=-2*a*r/(a-r);else if(o===ur)v=-a/(a-r),f=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=p,c[9]=h,c[13]=0,c[2]=0,c[6]=0,c[10]=v,c[14]=f,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,r,a,o=ai,l=!1){const c=this.elements,d=2/(t-e),p=2/(n-s),u=-(t+e)/(t-e),h=-(n+s)/(n-s);let v,f;if(l)v=1/(a-r),f=a/(a-r);else if(o===ai)v=-2/(a-r),f=-(a+r)/(a-r);else if(o===ur)v=-1/(a-r),f=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=u,c[1]=0,c[5]=p,c[9]=0,c[13]=h,c[2]=0,c[6]=0,c[10]=v,c[14]=f,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};Ta.prototype.isMatrix4=!0;let yt=Ta;const us=new z,Qn=new yt,Hp=new z(0,0,0),Gp=new z(1,1,1),Ii=new z,kr=new z,Un=new z,Lc=new yt,Pc=new os;class Vi{constructor(e=0,t=0,n=0,s=Vi.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],a=s[4],o=s[8],l=s[1],c=s[5],d=s[9],p=s[2],u=s[6],h=s[10];switch(t){case"XYZ":this._y=Math.asin(ut(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,h),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-ut(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,h),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-p,r),this._z=0);break;case"ZXY":this._x=Math.asin(ut(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-p,h),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-ut(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(u,h),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(ut(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-p,r)):(this._x=0,this._y=Math.atan2(o,h));break;case"XZY":this._z=Math.asin(-ut(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-d,h),this._y=0);break;default:qe("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Lc.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Lc,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Pc.setFromEuler(this),this.setFromQuaternion(Pc,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Vi.DEFAULT_ORDER="XYZ";class Wl{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let zp=0;const Dc=new z,hs=new os,Si=new yt,Er=new z,Gs=new z,Vp=new z,Wp=new os,Ic=new z(1,0,0),Uc=new z(0,1,0),Nc=new z(0,0,1),Bc={type:"added"},$p={type:"removed"},fs={type:"childadded",child:null},no={type:"childremoved",child:null};class dn extends as{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:zp++}),this.uuid=mr(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=dn.DEFAULT_UP.clone();const e=new z,t=new Vi,n=new os,s=new z(1,1,1);function r(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new yt},normalMatrix:{value:new Ye}}),this.matrix=new yt,this.matrixWorld=new yt,this.matrixAutoUpdate=dn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=dn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Wl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return hs.setFromAxisAngle(e,t),this.quaternion.multiply(hs),this}rotateOnWorldAxis(e,t){return hs.setFromAxisAngle(e,t),this.quaternion.premultiply(hs),this}rotateX(e){return this.rotateOnAxis(Ic,e)}rotateY(e){return this.rotateOnAxis(Uc,e)}rotateZ(e){return this.rotateOnAxis(Nc,e)}translateOnAxis(e,t){return Dc.copy(e).applyQuaternion(this.quaternion),this.position.add(Dc.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Ic,e)}translateY(e){return this.translateOnAxis(Uc,e)}translateZ(e){return this.translateOnAxis(Nc,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Si.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Er.copy(e):Er.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Gs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Si.lookAt(Gs,Er,this.up):Si.lookAt(Er,Gs,this.up),this.quaternion.setFromRotationMatrix(Si),s&&(Si.extractRotation(s.matrixWorld),hs.setFromRotationMatrix(Si),this.quaternion.premultiply(hs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(pt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Bc),fs.child=e,this.dispatchEvent(fs),fs.child=null):pt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent($p),no.child=e,this.dispatchEvent(no),no.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Si.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Si.multiply(e.parent.matrixWorld)),e.applyMatrix4(Si),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Bc),fs.child=e,this.dispatchEvent(fs),fs.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Gs,e,Vp),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Gs,Wp,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,s=e.z,r=this.matrix.elements;r[12]+=t-r[0]*t-r[4]*n-r[8]*s,r[13]+=n-r[1]*t-r[5]*n-r[9]*s,r[14]+=s-r[2]*t-r[6]*n-r[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const r=this.children;for(let a=0,o=r.length;a<o;a++)r[a].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const p=l[c];r(e.shapes,p)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(e.materials,this.material[l]));s.material=o}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(r(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),d=a(e.images),p=a(e.shapes),u=a(e.skeletons),h=a(e.animations),v=a(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),p.length>0&&(n.shapes=p),u.length>0&&(n.skeletons=u),h.length>0&&(n.animations=h),v.length>0&&(n.nodes=v)}return n.object=s,n;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}dn.DEFAULT_UP=new z(0,1,0);dn.DEFAULT_MATRIX_AUTO_UPDATE=!0;dn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class wt extends dn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const qp={type:"move"};class io{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new wt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new wt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new z,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new z),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new wt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new z,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new z,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const f of e.hand.values()){const m=t.getJointPose(f,n),g=this._getHandJoint(c,f);m!==null&&(g.matrix.fromArray(m.transform.matrix),g.matrix.decompose(g.position,g.quaternion,g.scale),g.matrixWorldNeedsUpdate=!0,g.jointRadius=m.radius),g.visible=m!==null}const d=c.joints["index-finger-tip"],p=c.joints["thumb-tip"],u=d.position.distanceTo(p.position),h=.02,v=.005;c.inputState.pinching&&u>h+v?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&u<=h-v&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(qp)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new wt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const ju={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ui={h:0,s:0,l:0},wr={h:0,s:0,l:0};function so(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class et{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Ln){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,dt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=dt.workingColorSpace){return this.r=e,this.g=t,this.b=n,dt.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=dt.workingColorSpace){if(e=Rp(e,1),t=ut(t,0,1),n=ut(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,a=2*n-r;this.r=so(a,r,e+1/3),this.g=so(a,r,e),this.b=so(a,r,e-1/3)}return dt.colorSpaceToWorking(this,s),this}setStyle(e,t=Ln){function n(r){r!==void 0&&parseFloat(r)<1&&qe("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseFloat(r[1]))/100,Math.min(100,parseFloat(r[2]))/100,Math.min(100,parseFloat(r[3]))/100,t);break;case"hsl":case"hsla":if(r=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:qe("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);qe("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Ln){const n=ju[e.toLowerCase()];return n!==void 0?this.setHex(n,t):qe("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ri(e.r),this.g=Ri(e.g),this.b=Ri(e.b),this}copyLinearToSRGB(e){return this.r=Rs(e.r),this.g=Rs(e.g),this.b=Rs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ln){return dt.workingToColorSpace(Sn.copy(this),e),Math.round(ut(Sn.r*255,0,255))*65536+Math.round(ut(Sn.g*255,0,255))*256+Math.round(ut(Sn.b*255,0,255))}getHexString(e=Ln){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=dt.workingColorSpace){dt.workingToColorSpace(Sn.copy(this),t);const n=Sn.r,s=Sn.g,r=Sn.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const p=a-o;switch(c=d<=.5?p/(a+o):p/(2-a-o),a){case n:l=(s-r)/p+(s<r?6:0);break;case s:l=(r-n)/p+2;break;case r:l=(n-s)/p+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=dt.workingColorSpace){return dt.workingToColorSpace(Sn.copy(this),t),e.r=Sn.r,e.g=Sn.g,e.b=Sn.b,e}getStyle(e=Ln){dt.workingToColorSpace(Sn.copy(this),e);const t=Sn.r,n=Sn.g,s=Sn.b;return e!==Ln?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(Ui),this.setHSL(Ui.h+e,Ui.s+t,Ui.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Ui),e.getHSL(wr);const n=Ja(Ui.h,wr.h,t),s=Ja(Ui.s,wr.s,t),r=Ja(Ui.l,wr.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Sn=new et;et.NAMES=ju;class Ma{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new et(e),this.density=t}clone(){return new Ma(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class Fc extends dn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Vi,this.environmentIntensity=1,this.environmentRotation=new Vi,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const jn=new z,xi=new z,ro=new z,_i=new z,ps=new z,ms=new z,Oc=new z,ao=new z,oo=new z,lo=new z,co=new Gt,uo=new Gt,ho=new Gt;class ii{constructor(e=new z,t=new z,n=new z){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),jn.subVectors(e,t),s.cross(jn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){jn.subVectors(s,t),xi.subVectors(n,t),ro.subVectors(e,t);const a=jn.dot(jn),o=jn.dot(xi),l=jn.dot(ro),c=xi.dot(xi),d=xi.dot(ro),p=a*c-o*o;if(p===0)return r.set(0,0,0),null;const u=1/p,h=(c*l-o*d)*u,v=(a*d-o*l)*u;return r.set(1-h-v,v,h)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,_i)===null?!1:_i.x>=0&&_i.y>=0&&_i.x+_i.y<=1}static getInterpolation(e,t,n,s,r,a,o,l){return this.getBarycoord(e,t,n,s,_i)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,_i.x),l.addScaledVector(a,_i.y),l.addScaledVector(o,_i.z),l)}static getInterpolatedAttribute(e,t,n,s,r,a){return co.setScalar(0),uo.setScalar(0),ho.setScalar(0),co.fromBufferAttribute(e,t),uo.fromBufferAttribute(e,n),ho.fromBufferAttribute(e,s),a.setScalar(0),a.addScaledVector(co,r.x),a.addScaledVector(uo,r.y),a.addScaledVector(ho,r.z),a}static isFrontFacing(e,t,n,s){return jn.subVectors(n,t),xi.subVectors(e,t),jn.cross(xi).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return jn.subVectors(this.c,this.b),xi.subVectors(this.a,this.b),jn.cross(xi).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return ii.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return ii.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return ii.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return ii.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return ii.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let a,o;ps.subVectors(s,n),ms.subVectors(r,n),ao.subVectors(e,n);const l=ps.dot(ao),c=ms.dot(ao);if(l<=0&&c<=0)return t.copy(n);oo.subVectors(e,s);const d=ps.dot(oo),p=ms.dot(oo);if(d>=0&&p<=d)return t.copy(s);const u=l*p-d*c;if(u<=0&&l>=0&&d<=0&&l-d>0)return a=l/(l-d),t.copy(n).addScaledVector(ps,a);lo.subVectors(e,r);const h=ps.dot(lo),v=ms.dot(lo);if(v>=0&&h<=v)return t.copy(r);const f=h*c-l*v;if(f<=0&&c>=0&&v<=0)return o=c/(c-v),t.copy(n).addScaledVector(ms,o);const m=d*v-h*p;if(m<=0&&p-d>=0&&h-v>=0)return Oc.subVectors(r,s),o=(p-d)/(p-d+(h-v)),t.copy(s).addScaledVector(Oc,o);const g=1/(m+f+u);return a=f*g,o=u*g,t.copy(n).addScaledVector(ps,a).addScaledVector(ms,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class ls{constructor(e=new z(1/0,1/0,1/0),t=new z(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(ei.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(ei.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=ei.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let a=0,o=r.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,ei):ei.fromBufferAttribute(r,a),ei.applyMatrix4(e.matrixWorld),this.expandByPoint(ei);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Tr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Tr.copy(n.boundingBox)),Tr.applyMatrix4(e.matrixWorld),this.union(Tr)}const s=e.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,ei),ei.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(zs),Cr.subVectors(this.max,zs),gs.subVectors(e.a,zs),vs.subVectors(e.b,zs),Ss.subVectors(e.c,zs),Ni.subVectors(vs,gs),Bi.subVectors(Ss,vs),Xi.subVectors(gs,Ss);let t=[0,-Ni.z,Ni.y,0,-Bi.z,Bi.y,0,-Xi.z,Xi.y,Ni.z,0,-Ni.x,Bi.z,0,-Bi.x,Xi.z,0,-Xi.x,-Ni.y,Ni.x,0,-Bi.y,Bi.x,0,-Xi.y,Xi.x,0];return!fo(t,gs,vs,Ss,Cr)||(t=[1,0,0,0,1,0,0,0,1],!fo(t,gs,vs,Ss,Cr))?!1:(Ar.crossVectors(Ni,Bi),t=[Ar.x,Ar.y,Ar.z],fo(t,gs,vs,Ss,Cr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,ei).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(ei).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(yi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),yi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),yi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),yi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),yi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),yi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),yi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),yi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(yi),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const yi=[new z,new z,new z,new z,new z,new z,new z,new z],ei=new z,Tr=new ls,gs=new z,vs=new z,Ss=new z,Ni=new z,Bi=new z,Xi=new z,zs=new z,Cr=new z,Ar=new z,Yi=new z;function fo(i,e,t,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Yi.fromArray(i,r);const o=s.x*Math.abs(Yi.x)+s.y*Math.abs(Yi.y)+s.z*Math.abs(Yi.z),l=e.dot(Yi),c=t.dot(Yi),d=n.dot(Yi);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const Kt=new z,Rr=new it;let Xp=0;class Gi extends as{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Xp++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Ep,this.updateRanges=[],this.gpuType=ri,this.version=0,this._normalizationScale=e!==void 0?zl(e):void 0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Rr.fromBufferAttribute(this,t),Rr.applyMatrix3(e),this.setXY(t,Rr.x,Rr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.applyMatrix3(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.applyMatrix4(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.applyNormalMatrix(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Kt.fromBufferAttribute(this,t),Kt.transformDirection(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s),r=this._normalize(r)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):Pp(e,this.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Dp(e,this.array)}}class eh extends Gi{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class th extends Gi{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class It extends Gi{constructor(e,t,n){super(new Float32Array(e),t,n)}}const Yp=new ls,Vs=new z,po=new z;class Us{constructor(e=new z,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Yp.setFromPoints(e).getCenter(n);let s=0;for(let r=0,a=e.length;r<a;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Vs.subVectors(e,this.center);const t=Vs.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Vs,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(po.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Vs.copy(e.center).add(po)),this.expandByPoint(Vs.copy(e.center).sub(po))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Kp=0;const qn=new yt,mo=new dn,xs=new z,Nn=new ls,Ws=new ls,on=new z;class yn extends as{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Kp++}),this.uuid=mr(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(wp(e)?th:eh)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Ye().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return qn.makeRotationFromQuaternion(e),this.applyMatrix4(qn),this}rotateX(e){return qn.makeRotationX(e),this.applyMatrix4(qn),this}rotateY(e){return qn.makeRotationY(e),this.applyMatrix4(qn),this}rotateZ(e){return qn.makeRotationZ(e),this.applyMatrix4(qn),this}translate(e,t,n){return qn.makeTranslation(e,t,n),this.applyMatrix4(qn),this}scale(e,t,n){return qn.makeScale(e,t,n),this.applyMatrix4(qn),this}lookAt(e){return mo.lookAt(e),mo.updateMatrix(),this.applyMatrix4(mo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(xs).negate(),this.translate(xs.x,xs.y,xs.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const a=e[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new It(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&qe("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ls);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){pt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new z(-1/0,-1/0,-1/0),new z(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];Nn.setFromBufferAttribute(r),this.morphTargetsRelative?(on.addVectors(this.boundingBox.min,Nn.min),this.boundingBox.expandByPoint(on),on.addVectors(this.boundingBox.max,Nn.max),this.boundingBox.expandByPoint(on)):(this.boundingBox.expandByPoint(Nn.min),this.boundingBox.expandByPoint(Nn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&pt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Us);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){pt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new z,1/0);return}if(e){const n=this.boundingSphere.center;if(Nn.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const o=t[r];Ws.setFromBufferAttribute(o),this.morphTargetsRelative?(on.addVectors(Nn.min,Ws.min),Nn.expandByPoint(on),on.addVectors(Nn.max,Ws.max),Nn.expandByPoint(on)):(Nn.expandByPoint(Ws.min),Nn.expandByPoint(Ws.max))}Nn.getCenter(n);let s=0;for(let r=0,a=e.count;r<a;r++)on.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(on));if(t)for(let r=0,a=t.length;r<a;r++){const o=t[r],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)on.fromBufferAttribute(o,c),l&&(xs.fromBufferAttribute(e,c),on.add(xs)),s=Math.max(s,n.distanceToSquared(on))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&pt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){pt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new Gi(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const o=[],l=[],c=new Uint8Array(n.count);for(let A=0;A<n.count;A++)o[A]=new z,l[A]=new z;const d=new z,p=new z,u=new z,h=new it,v=new it,f=new it,m=new z,g=new z;function S(A,R,D){c[A]=c[R]=c[D]=1,d.fromBufferAttribute(n,A),p.fromBufferAttribute(n,R),u.fromBufferAttribute(n,D),h.fromBufferAttribute(r,A),v.fromBufferAttribute(r,R),f.fromBufferAttribute(r,D),p.sub(d),u.sub(d),v.sub(h),f.sub(h);const O=1/(v.x*f.y-f.x*v.y);isFinite(O)&&(m.copy(p).multiplyScalar(f.y).addScaledVector(u,-v.y).multiplyScalar(O),g.copy(u).multiplyScalar(v.x).addScaledVector(p,-f.x).multiplyScalar(O),o[A].add(m),o[R].add(m),o[D].add(m),l[A].add(g),l[R].add(g),l[D].add(g))}let M=this.groups;M.length===0&&(M=[{start:0,count:e.count}]);for(let A=0,R=M.length;A<R;++A){const D=M[A],O=D.start,X=D.count;for(let k=O,P=O+X;k<P;k+=3)S(e.getX(k+0),e.getX(k+1),e.getX(k+2))}const _=new z,E=new z,y=new z,x=new z;function b(A){y.fromBufferAttribute(s,A),x.copy(y);const R=o[A];_.copy(R),_.sub(y.multiplyScalar(y.dot(R))).normalize(),E.crossVectors(x,R);const O=E.dot(l[A])<0?-1:1;a.setXYZW(A,_.x,_.y,_.z,O)}for(let A=0,R=n.count;A<R;++A)c[A]&&b(A);this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new Gi(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,h=n.count;u<h;u++)n.setXYZ(u,0,0,0);const s=new z,r=new z,a=new z,o=new z,l=new z,c=new z,d=new z,p=new z;if(e)for(let u=0,h=e.count;u<h;u+=3){const v=e.getX(u+0),f=e.getX(u+1),m=e.getX(u+2);s.fromBufferAttribute(t,v),r.fromBufferAttribute(t,f),a.fromBufferAttribute(t,m),d.subVectors(a,r),p.subVectors(s,r),d.cross(p),o.fromBufferAttribute(n,v),l.fromBufferAttribute(n,f),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(v,o.x,o.y,o.z),n.setXYZ(f,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let u=0,h=t.count;u<h;u+=3)s.fromBufferAttribute(t,u+0),r.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),d.subVectors(a,r),p.subVectors(s,r),d.cross(p),n.setXYZ(u+0,d.x,d.y,d.z),n.setXYZ(u+1,d.x,d.y,d.z),n.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)on.fromBufferAttribute(e,t),on.normalize(),e.setXYZ(t,on.x,on.y,on.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,p=o.normalized,u=new c.constructor(l.length*d);let h=0,v=0;for(let f=0,m=l.length;f<m;f++){o.isInterleavedBufferAttribute?h=l[f]*o.data.stride+o.offset:h=l[f]*d;for(let g=0;g<d;g++)u[v++]=c[h++]}return new Gi(u,d,p)}if(this.index===null)return qe("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new yn,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=e(l,n);t.setAttribute(o,c)}const r=this.morphAttributes;for(const o in r){const l=[],c=r[o];for(let d=0,p=c.length;d<p;d++){const u=c[d],h=e(u,n);l.push(h)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const s={};let r=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let p=0,u=c.length;p<u;p++){const h=c[p];d.push(h.toJSON(e.data))}d.length>0&&(s[l]=d,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const c in s){const d=s[c];this.setAttribute(c,d.clone(t))}const r=e.morphAttributes;for(const c in r){const d=[],p=r[c];for(let u=0,h=p.length;u<h;u++)d.push(p[u].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,d=a.length;c<d;c++){const p=a[c];this.addGroup(p.start,p.count,p.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const go=new z,Zp=new z,Jp=new Ye;class ki{constructor(e=new z(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=go.subVectors(n,t).cross(Zp.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const s=e.delta(go),r=this.normal.dot(s);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/r;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(s,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||Jp.getNormalMatrix(e),s=this.coplanarPoint(go).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let Qp=0;class Ns extends as{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Qp++}),this.uuid=mr(),this.name="",this.type="Material",this.blending=ir,this.side=Li,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pu,this.blendDst=Du,this.blendEquation=bs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new et(0,0,0),this.blendAlpha=0,this.depthFunc=or,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=xp,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ka,this.stencilZFail=Ka,this.stencilZPass=Ka,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){qe(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){qe(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const l=r[o];delete l.metadata,a.push(l)}return a}if(t){const r=s(e.textures),a=s(e.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new et().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new ki().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new it().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new it().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Mi=new z,vo=new z,Lr=new z,Pr=new z;class $l{constructor(e=new z,t=new z(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Mi)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Mi.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Mi.copy(this.origin).addScaledVector(this.direction,t),Mi.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){vo.copy(e).add(t).multiplyScalar(.5),Lr.copy(t).sub(e).normalize(),Pr.copy(this.origin).sub(vo);const r=e.distanceTo(t)*.5,a=-this.direction.dot(Lr),o=Pr.dot(this.direction),l=-Pr.dot(Lr),c=Pr.lengthSq(),d=Math.abs(1-a*a);let p,u,h,v;if(d>0)if(p=a*l-o,u=a*o-l,v=r*d,p>=0)if(u>=-v)if(u<=v){const f=1/d;p*=f,u*=f,h=p*(p+a*u+2*o)+u*(a*p+u+2*l)+c}else u=r,p=Math.max(0,-(a*u+o)),h=-p*p+u*(u+2*l)+c;else u=-r,p=Math.max(0,-(a*u+o)),h=-p*p+u*(u+2*l)+c;else u<=-v?(p=Math.max(0,-(-a*r+o)),u=p>0?-r:Math.min(Math.max(-r,-l),r),h=-p*p+u*(u+2*l)+c):u<=v?(p=0,u=Math.min(Math.max(-r,-l),r),h=u*(u+2*l)+c):(p=Math.max(0,-(a*r+o)),u=p>0?r:Math.min(Math.max(-r,-l),r),h=-p*p+u*(u+2*l)+c);else u=a>0?-r:r,p=Math.max(0,-(a*u+o)),h=-p*p+u*(u+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,p),s&&s.copy(vo).addScaledVector(Lr,u),h}intersectSphere(e,t){if(e.radius<0)return null;Mi.subVectors(e.center,this.origin);const n=Mi.dot(this.direction),s=Mi.dot(Mi)-n*n,r=e.radius*e.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,p=1/this.direction.z,u=this.origin;return c>=0?(n=(e.min.x-u.x)*c,s=(e.max.x-u.x)*c):(n=(e.max.x-u.x)*c,s=(e.min.x-u.x)*c),d>=0?(r=(e.min.y-u.y)*d,a=(e.max.y-u.y)*d):(r=(e.max.y-u.y)*d,a=(e.min.y-u.y)*d),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),p>=0?(o=(e.min.z-u.z)*p,l=(e.max.z-u.z)*p):(o=(e.max.z-u.z)*p,l=(e.min.z-u.z)*p),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,Mi)!==null}intersectTriangle(e,t,n,s,r){const a=this.origin,o=this.direction,l=o.x,c=o.y,d=o.z,p=e.x-a.x,u=e.y-a.y,h=e.z-a.z,v=t.x-a.x,f=t.y-a.y,m=t.z-a.z,g=n.x-a.x,S=n.y-a.y,M=n.z-a.z,_=Math.abs(l),E=Math.abs(c),y=Math.abs(d);let x,b,A,R,D,O,X,k,P,F,G,se;if(_>=E&&_>=y?(A=l,O=p,P=v,se=g,l>=0?(x=c,b=d,R=u,D=h,X=f,k=m,F=S,G=M):(x=d,b=c,R=h,D=u,X=m,k=f,F=M,G=S)):E>=y?(A=c,O=u,P=f,se=S,c>=0?(x=d,b=l,R=h,D=p,X=m,k=v,F=M,G=g):(x=l,b=d,R=p,D=h,X=v,k=m,F=g,G=M)):(A=d,O=h,P=m,se=M,d>=0?(x=l,b=c,R=p,D=u,X=v,k=f,F=g,G=S):(x=c,b=l,R=u,D=p,X=f,k=v,F=S,G=g)),A===0)return null;const Y=x/A,ae=b/A,le=1/A,ce=R-Y*O,xe=D-ae*O,Z=X-Y*P,be=k-ae*P,we=F-Y*se,Fe=G-ae*se,Ee=we*be-Fe*Z,Je=ce*Fe-xe*we,Xt=Z*xe-be*ce;if(s){if(Ee<0||Je<0||Xt<0)return null}else if((Ee<0||Je<0||Xt<0)&&(Ee>0||Je>0||Xt>0))return null;const $e=Ee+Je+Xt;if($e===0)return null;const vt=le*(Ee*O+Je*P+Xt*se);return($e>0?vt<0:vt>0)?null:this.at(vt/$e,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class ks extends Ns{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new et(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Vi,this.combine=Iu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Hc=new yt,Ki=new $l,Dr=new Us,Gc=new z,Ir=new z,Ur=new z,Nr=new z,So=new z,Br=new z,zc=new z,Fr=new z;class ct extends dn{constructor(e=new yn,t=new ks){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(r&&o){Br.set(0,0,0);for(let l=0,c=r.length;l<c;l++){const d=o[l],p=r[l];d!==0&&(So.fromBufferAttribute(p,e),a?Br.addScaledVector(So,d):Br.addScaledVector(So.sub(t),d))}t.add(Br)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Dr.copy(n.boundingSphere),Dr.applyMatrix4(r),Ki.copy(e.ray).recast(e.near),!(Dr.containsPoint(Ki.origin)===!1&&(Ki.intersectSphere(Dr,Gc)===null||Ki.origin.distanceToSquared(Gc)>(e.far-e.near)**2))&&(Hc.copy(r).invert(),Ki.copy(e.ray).applyMatrix4(Hc),!(n.boundingBox!==null&&Ki.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Ki)))}_computeIntersections(e,t,n){let s;const r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,d=r.attributes.uv1,p=r.attributes.normal,u=r.groups,h=r.drawRange;if(o!==null)if(Array.isArray(a))for(let v=0,f=u.length;v<f;v++){const m=u[v],g=a[m.materialIndex],S=Math.max(m.start,h.start),M=Math.min(o.count,Math.min(m.start+m.count,h.start+h.count));for(let _=S,E=M;_<E;_+=3){const y=o.getX(_),x=o.getX(_+1),b=o.getX(_+2);s=Or(this,g,e,n,c,d,p,y,x,b),s&&(s.faceIndex=Math.floor(_/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const v=Math.max(0,h.start),f=Math.min(o.count,h.start+h.count);for(let m=v,g=f;m<g;m+=3){const S=o.getX(m),M=o.getX(m+1),_=o.getX(m+2);s=Or(this,a,e,n,c,d,p,S,M,_),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let v=0,f=u.length;v<f;v++){const m=u[v],g=a[m.materialIndex],S=Math.max(m.start,h.start),M=Math.min(l.count,Math.min(m.start+m.count,h.start+h.count));for(let _=S,E=M;_<E;_+=3){const y=_,x=_+1,b=_+2;s=Or(this,g,e,n,c,d,p,y,x,b),s&&(s.faceIndex=Math.floor(_/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const v=Math.max(0,h.start),f=Math.min(l.count,h.start+h.count);for(let m=v,g=f;m<g;m+=3){const S=m,M=m+1,_=m+2;s=Or(this,a,e,n,c,d,p,S,M,_),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function jp(i,e,t,n,s,r,a,o){let l;if(e.side===In?l=n.intersectTriangle(a,r,s,!0,o):l=n.intersectTriangle(s,r,a,e.side===Li,o),l===null)return null;Fr.copy(o),Fr.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Fr);return c<t.near||c>t.far?null:{distance:c,point:Fr.clone(),object:i}}function Or(i,e,t,n,s,r,a,o,l,c){i.getVertexPosition(o,Ir),i.getVertexPosition(l,Ur),i.getVertexPosition(c,Nr);const d=jp(i,e,t,n,Ir,Ur,Nr,zc);if(d){const p=new z;ii.getBarycoord(zc,Ir,Ur,Nr,p),s&&(d.uv=ii.getInterpolatedAttribute(s,o,l,c,p,new it)),r&&(d.uv1=ii.getInterpolatedAttribute(r,o,l,c,p,new it)),a&&(d.normal=ii.getInterpolatedAttribute(a,o,l,c,p,new z),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new z,materialIndex:0};ii.getNormal(Ir,Ur,Nr,u.normal),d.face=u,d.barycoord=p}return d}class nh extends Mn{constructor(e=null,t=1,n=1,s,r,a,o,l,c=cn,d=cn,p,u){super(null,a,o,l,c,d,s,r,p,u),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Vc extends Gi{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const _s=new yt,Wc=new yt,Hr=[],$c=new ls,em=new yt,$s=new ct,qs=new Us;class qc extends ct{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Vc(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,em)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new ls),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,_s),$c.copy(e.boundingBox).applyMatrix4(_s),this.boundingBox.union($c)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Us),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,_s),qs.copy(e.boundingSphere).applyMatrix4(_s),this.boundingSphere.union(qs)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture!==null?e.morphTexture.clone():null,this.instanceColor=e.instanceColor!==null?e.instanceColor.clone():null,this.count=e.count,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=e*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(e,t){const n=this.matrixWorld,s=this.count;if($s.geometry=this.geometry,$s.material=this.material,$s.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),qs.copy(this.boundingSphere),qs.applyMatrix4(n),e.ray.intersectsSphere(qs)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,_s),Wc.multiplyMatrices(n,_s),$s.matrixWorld=Wc,$s.raycast(e,Hr);for(let a=0,o=Hr.length;a<o;a++){const l=Hr[a];l.instanceId=r,l.object=this,t.push(l)}Hr.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new Vc(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new nh(new Float32Array(s*this.count),s,this.count,Fl,ri));const r=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=s*e;return r[l]=o,r.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Zi=new Us,tm=new it(.5,.5),Gr=new z;class hr{constructor(e=new ki,t=new ki,n=new ki,s=new ki,r=new ki,a=new ki){this.planes=[e,t,n,s,r,a]}set(e,t,n,s,r,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ai,n=!1){const s=this.planes,r=e.elements,a=r[0],o=r[1],l=r[2],c=r[3],d=r[4],p=r[5],u=r[6],h=r[7],v=r[8],f=r[9],m=r[10],g=r[11],S=r[12],M=r[13],_=r[14],E=r[15];if(s[0].setComponents(c-a,h-d,g-v,E-S).normalize(),s[1].setComponents(c+a,h+d,g+v,E+S).normalize(),s[2].setComponents(c+o,h+p,g+f,E+M).normalize(),s[3].setComponents(c-o,h-p,g-f,E-M).normalize(),n)s[4].setComponents(l,u,m,_).normalize(),s[5].setComponents(c-l,h-u,g-m,E-_).normalize();else if(s[4].setComponents(c-l,h-u,g-m,E-_).normalize(),t===ai)s[5].setComponents(c+l,h+u,g+m,E+_).normalize();else if(t===ur)s[5].setComponents(l,u,m,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Zi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Zi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Zi)}intersectsSprite(e){Zi.center.set(0,0,0);const t=tm.distanceTo(e.center);return Zi.radius=.7071067811865476+t,Zi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Zi)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(Gr.x=s.normal.x>0?e.max.x:e.min.x,Gr.y=s.normal.y>0?e.max.y:e.min.y,Gr.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Gr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const Xc=new yt;class ql{constructor(){this.coordinateSystem=ai,this._frustums=[],this._count=0}setFromArrayCamera(e){const t=e.cameras,n=this._frustums;for(let s=0;s<t.length;s++){const r=t[s];Xc.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),n[s]===void 0&&(n[s]=new hr),n[s].setFromProjectionMatrix(Xc,r.coordinateSystem,r.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;const t=this._frustums,n=e._frustums;for(let s=0;s<e._count;s++)t[s]===void 0&&(t[s]=new hr),t[s].copy(n[s]);return this._count=e._count,this}clone(){return new ql().copy(this)}}class er extends Ns{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new et(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const ba=new z,ka=new z,Yc=new yt,Xs=new $l,zr=new Us,xo=new z,Kc=new z;class aa extends dn{constructor(e=new yn,t=new er){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)ba.fromBufferAttribute(t,s-1),ka.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=ba.distanceTo(ka);e.setAttribute("lineDistance",new It(n,1))}else qe("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),zr.copy(n.boundingSphere),zr.applyMatrix4(s),zr.radius+=r,e.ray.intersectsSphere(zr)===!1)return;Yc.copy(s).invert(),Xs.copy(e.ray).applyMatrix4(Yc);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,u=n.attributes.position;if(d!==null){const h=Math.max(0,a.start),v=Math.min(d.count,a.start+a.count);for(let f=h,m=v-1;f<m;f+=c){const g=d.getX(f),S=d.getX(f+1),M=Vr(this,e,Xs,l,g,S,f);M&&t.push(M)}if(this.isLineLoop){const f=d.getX(v-1),m=d.getX(h),g=Vr(this,e,Xs,l,f,m,v-1);g&&t.push(g)}}else{const h=Math.max(0,a.start),v=Math.min(u.count,a.start+a.count);for(let f=h,m=v-1;f<m;f+=c){const g=Vr(this,e,Xs,l,f,f+1,f);g&&t.push(g)}if(this.isLineLoop){const f=Vr(this,e,Xs,l,v-1,h,v-1);f&&t.push(f)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Vr(i,e,t,n,s,r,a){const o=i.geometry.attributes.position;if(ba.fromBufferAttribute(o,s),ka.fromBufferAttribute(o,r),t.distanceSqToSegment(ba,ka,xo,Kc)>n)return;xo.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(xo);if(!(c<e.near||c>e.far))return{distance:c,point:Kc.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Zc=new z,Jc=new z;class nm extends aa{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)Zc.fromBufferAttribute(t,s),Jc.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Zc.distanceTo(Jc);e.setAttribute("lineDistance",new It(n,1))}else qe("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class ih extends Mn{constructor(e=[],t=Ls,n,s,r,a,o,l,c,d){super(e,t,n,s,r,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class im extends Mn{constructor(e,t,n,s,r,a,o,l,c){super(e,t,n,s,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Ds extends Mn{constructor(e,t,n=pi,s,r,a,o=cn,l=cn,c,d=zi,p=1){if(d!==zi&&d!==Hi)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:e,height:t,depth:p};super(u,s,r,a,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Vl(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class sh extends Ds{constructor(e,t=pi,n=Ls,s,r,a=cn,o=cn,l,c=zi){const d={width:e,height:e,depth:1},p=[d,d,d,d,d,d];super(e,e,t,n,s,r,a,o,l,c),this.image=p,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class rh extends Mn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Bs extends yn{constructor(e=1,t=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const l=[],c=[],d=[],p=[];let u=0,h=0;v("z","y","x",-1,-1,n,t,e,a,r,0),v("z","y","x",1,-1,n,t,-e,a,r,1),v("x","z","y",1,1,e,n,t,s,a,2),v("x","z","y",1,-1,e,n,-t,s,a,3),v("x","y","z",1,-1,e,t,n,s,r,4),v("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new It(c,3)),this.setAttribute("normal",new It(d,3)),this.setAttribute("uv",new It(p,2));function v(f,m,g,S,M,_,E,y,x,b,A){const R=_/x,D=E/b,O=_/2,X=E/2,k=y/2,P=x+1,F=b+1;let G=0,se=0;const Y=new z;for(let ae=0;ae<F;ae++){const le=ae*D-X;for(let ce=0;ce<P;ce++){const xe=ce*R-O;Y[f]=xe*S,Y[m]=le*M,Y[g]=k,c.push(Y.x,Y.y,Y.z),Y[f]=0,Y[m]=0,Y[g]=y>0?1:-1,d.push(Y.x,Y.y,Y.z),p.push(ce/x),p.push(1-ae/b),G+=1}}for(let ae=0;ae<b;ae++)for(let le=0;le<x;le++){const ce=u+le+P*ae,xe=u+le+P*(ae+1),Z=u+(le+1)+P*(ae+1),be=u+(le+1)+P*ae;l.push(ce,xe,be),l.push(xe,Z,be),se+=6}o.addGroup(h,se,A),h+=se,u+=G}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Bs(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Ua extends yn{constructor(e=1,t=1,n=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),r=Math.floor(r);const d=[],p=[],u=[],h=[];let v=0;const f=[],m=n/2;let g=0;S(),a===!1&&(e>0&&M(!0),t>0&&M(!1)),this.setIndex(d),this.setAttribute("position",new It(p,3)),this.setAttribute("normal",new It(u,3)),this.setAttribute("uv",new It(h,2));function S(){const _=new z,E=new z;let y=0;const x=(t-e)/n;for(let b=0;b<=r;b++){const A=[],R=b/r,D=R*(t-e)+e;for(let O=0;O<=s;O++){const X=O/s,k=X*l+o,P=Math.sin(k),F=Math.cos(k);E.x=D*P,E.y=-R*n+m,E.z=D*F,p.push(E.x,E.y,E.z),_.set(P,x,F).normalize(),u.push(_.x,_.y,_.z),h.push(X,1-R),A.push(v++)}f.push(A)}for(let b=0;b<s;b++)for(let A=0;A<r;A++){const R=f[A][b],D=f[A+1][b],O=f[A+1][b+1],X=f[A][b+1];(e>0||A!==0)&&(d.push(R,D,X),y+=3),(t>0||A!==r-1)&&(d.push(D,O,X),y+=3)}c.addGroup(g,y,0),g+=y}function M(_){const E=v,y=new it,x=new z;let b=0;const A=_===!0?e:t,R=_===!0?1:-1;for(let O=1;O<=s;O++)p.push(0,m*R,0),u.push(0,R,0),h.push(.5,.5),v++;const D=v;for(let O=0;O<=s;O++){const k=O/s*l+o,P=Math.cos(k),F=Math.sin(k);x.x=A*F,x.y=m*R,x.z=A*P,p.push(x.x,x.y,x.z),u.push(0,R,0),y.x=P*.5+.5,y.y=F*.5*R+.5,h.push(y.x,y.y),v++}for(let O=0;O<s;O++){const X=E+O,k=D+O;_===!0?d.push(k,k+1,X):d.push(k+1,k,X),b+=3}c.addGroup(g,b,_===!0?1:2),g+=b}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ua(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Xl extends Ua{constructor(e=1,t=1,n=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,e,t,n,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(e){return new Xl(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Yl extends yn{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const r=[],a=[];o(s),c(n),d(),this.setAttribute("position",new It(r,3)),this.setAttribute("normal",new It(r.slice(),3)),this.setAttribute("uv",new It(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(S){const M=new z,_=new z,E=new z;for(let y=0;y<t.length;y+=3)h(t[y+0],M),h(t[y+1],_),h(t[y+2],E),l(M,_,E,S)}function l(S,M,_,E){const y=E+1,x=[];for(let b=0;b<=y;b++){x[b]=[];const A=S.clone().lerp(_,b/y),R=M.clone().lerp(_,b/y),D=y-b;for(let O=0;O<=D;O++)O===0&&b===y?x[b][O]=A:x[b][O]=A.clone().lerp(R,O/D)}for(let b=0;b<y;b++)for(let A=0;A<2*(y-b)-1;A++){const R=Math.floor(A/2);A%2===0?(u(x[b][R+1]),u(x[b+1][R]),u(x[b][R])):(u(x[b][R+1]),u(x[b+1][R+1]),u(x[b+1][R]))}}function c(S){const M=new z;for(let _=0;_<r.length;_+=3)M.x=r[_+0],M.y=r[_+1],M.z=r[_+2],M.normalize().multiplyScalar(S),r[_+0]=M.x,r[_+1]=M.y,r[_+2]=M.z}function d(){const S=new z;for(let M=0;M<r.length;M+=3){S.x=r[M+0],S.y=r[M+1],S.z=r[M+2];const _=m(S)/2/Math.PI+.5,E=g(S)/Math.PI+.5;a.push(_,1-E)}v(),p()}function p(){for(let S=0;S<a.length;S+=6){const M=a[S+0],_=a[S+2],E=a[S+4],y=Math.max(M,_,E),x=Math.min(M,_,E);y>.9&&x<.1&&(M<.2&&(a[S+0]+=1),_<.2&&(a[S+2]+=1),E<.2&&(a[S+4]+=1))}}function u(S){r.push(S.x,S.y,S.z)}function h(S,M){const _=S*3;M.x=e[_+0],M.y=e[_+1],M.z=e[_+2]}function v(){const S=new z,M=new z,_=new z,E=new z,y=new it,x=new it,b=new it;for(let A=0,R=0;A<r.length;A+=9,R+=6){S.set(r[A+0],r[A+1],r[A+2]),M.set(r[A+3],r[A+4],r[A+5]),_.set(r[A+6],r[A+7],r[A+8]),y.set(a[R+0],a[R+1]),x.set(a[R+2],a[R+3]),b.set(a[R+4],a[R+5]),E.copy(S).add(M).add(_).divideScalar(3);const D=m(E);f(y,R+0,S,D),f(x,R+2,M,D),f(b,R+4,_,D)}}function f(S,M,_,E){E<0&&S.x===1&&(a[M]=S.x-1),_.x===0&&_.z===0&&(a[M]=E/2/Math.PI+.5)}function m(S){return Math.atan2(S.z,-S.x)}function g(S){return Math.atan2(-S.y,Math.sqrt(S.x*S.x+S.z*S.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Yl(e.vertices,e.indices,e.radius,e.detail)}}class Kl extends Yl{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Kl(e.radius,e.detail)}}class Ei extends yn{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,a=t/2,o=Math.floor(n),l=Math.floor(s),c=o+1,d=l+1,p=e/o,u=t/l,h=[],v=[],f=[],m=[];for(let g=0;g<d;g++){const S=g*u-a;for(let M=0;M<c;M++){const _=M*p-r;v.push(_,-S,0),f.push(0,0,1),m.push(M/o),m.push(1-g/l)}}for(let g=0;g<l;g++)for(let S=0;S<o;S++){const M=S+c*g,_=S+c*(g+1),E=S+1+c*(g+1),y=S+1+c*g;h.push(M,_,y),h.push(_,E,y)}this.setIndex(h),this.setAttribute("position",new It(v,3)),this.setAttribute("normal",new It(f,3)),this.setAttribute("uv",new It(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ei(e.width,e.height,e.widthSegments,e.heightSegments)}}class Zl extends yn{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const d=[],p=new z,u=new z,h=[],v=[],f=[],m=[];for(let g=0;g<=n;g++){const S=[],M=g/n,_=a+M*o,E=e*Math.cos(_),y=Math.sqrt(e*e-E*E);let x=0;g===0&&a===0?x=.5/t:g===n&&l===Math.PI&&(x=-.5/t);for(let b=0;b<=t;b++){const A=b/t,R=s+A*r;p.x=-y*Math.cos(R),p.y=E,p.z=y*Math.sin(R),v.push(p.x,p.y,p.z),u.copy(p).normalize(),f.push(u.x,u.y,u.z),m.push(A+x,1-M),S.push(c++)}d.push(S)}for(let g=0;g<n;g++)for(let S=0;S<t;S++){const M=d[g][S+1],_=d[g][S],E=d[g+1][S],y=d[g+1][S+1];(g!==0||a>0)&&h.push(M,_,y),(g!==n-1||l<Math.PI)&&h.push(_,E,y)}this.setIndex(h),this.setAttribute("position",new It(v,3)),this.setAttribute("normal",new It(f,3)),this.setAttribute("uv",new It(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Zl(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Jl extends yn{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2,a=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r,thetaStart:a,thetaLength:o},n=Math.floor(n),s=Math.floor(s);const l=[],c=[],d=[],p=[],u=new z,h=new z,v=new z;for(let f=0;f<=n;f++){const m=a+f/n*o;for(let g=0;g<=s;g++){const S=g/s*r;h.x=(e+t*Math.cos(m))*Math.cos(S),h.y=(e+t*Math.cos(m))*Math.sin(S),h.z=t*Math.sin(m),c.push(h.x,h.y,h.z),u.x=e*Math.cos(S),u.y=e*Math.sin(S),v.subVectors(h,u).normalize(),d.push(v.x,v.y,v.z),p.push(g/s),p.push(f/n)}}for(let f=1;f<=n;f++)for(let m=1;m<=s;m++){const g=(s+1)*f+m-1,S=(s+1)*(f-1)+m-1,M=(s+1)*(f-1)+m,_=(s+1)*f+m;l.push(g,S,_),l.push(S,M,_)}this.setIndex(l),this.setAttribute("position",new It(c,3)),this.setAttribute("normal",new It(d,3)),this.setAttribute("uv",new It(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Jl(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function Is(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];if(Qc(s))s.isRenderTargetTexture?(qe("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone();else if(Array.isArray(s))if(Qc(s[0])){const r=[];for(let a=0,o=s.length;a<o;a++)r[a]=s[a].clone();e[t][n]=r}else e[t][n]=s.slice();else e[t][n]=s}}return e}function En(i){const e={};for(let t=0;t<i.length;t++){const n=Is(i[t]);for(const s in n)e[s]=n[s]}return e}function Qc(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function sm(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function ah(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:dt.workingColorSpace}const rm={clone:Is,merge:En};var am=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,om=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class rs extends Ns{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=am,this.fragmentShader=om,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Is(e.uniforms),this.uniformsGroups=sm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?t.uniforms[s]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[s]={type:"m4",value:a.toArray()}:t.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const s=e.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=t[s.value]||null;break;case"c":this.uniforms[n].value=new et().setHex(s.value);break;case"v2":this.uniforms[n].value=new it().fromArray(s.value);break;case"v3":this.uniforms[n].value=new z().fromArray(s.value);break;case"v4":this.uniforms[n].value=new Gt().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Ye().fromArray(s.value);break;case"m4":this.uniforms[n].value=new yt().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class lm extends rs{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Ea extends Ns{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new et(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new et(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Sl,this.normalScale=new it(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Vi,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class cm extends Ns{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=vp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class dm extends Ns{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Ql extends dn{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new et(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class jc extends Ql{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(dn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new et(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const _o=new yt,ed=new z,td=new z;class oh{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new it(512,512),this.mapType=Gn,this.map=null,this.mapPass=null,this.matrix=new yt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new hr,this._frameExtents=new it(1,1),this._viewportCount=1,this._viewports=[new Gt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;ed.setFromMatrixPosition(e.matrixWorld),t.position.copy(ed),td.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(td),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,s){_o.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(_o,e.coordinateSystem,e.reversedDepth);const r=this._frameExtents,a=s?s.z/r.x:1,o=s?s.w/r.y:1,l=s?s.x/r.x:0,c=s?s.y/r.y:0;e.coordinateSystem===ur||e.reversedDepth?t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(_o)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Wr=new z,$r=new os,li=new z;class lh extends dn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new yt,this.projectionMatrix=new yt,this.projectionMatrixInverse=new yt,this.coordinateSystem=ai,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Wr,$r,li),li.x===1&&li.y===1&&li.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Wr,$r,li.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Wr,$r,li),li.x===1&&li.y===1&&li.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Wr,$r,li.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Fi=new z,nd=new it,id=new it;class Xn extends lh{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=xl*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Za*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return xl*2*Math.atan(Math.tan(Za*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Fi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Fi.x,Fi.y).multiplyScalar(-e/Fi.z),Fi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Fi.x,Fi.y).multiplyScalar(-e/Fi.z)}getViewSize(e,t){return this.getViewBounds(e,nd,id),t.subVectors(id,nd)}setViewOffset(e,t,n,s,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Za*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*s/l,t-=a.offsetY*n/c,s*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(r+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class um extends oh{constructor(){super(new Xn(90,1,.5,500)),this.isPointLightShadow=!0}}class sd extends Ql{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new um}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}}class ch extends lh{constructor(e=-1,t=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,a=n+e,o=s+t,l=s-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class hm extends oh{constructor(){super(new ch(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class rd extends Ql{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(dn.DEFAULT_UP),this.updateMatrix(),this.target=new dn,this.shadow=new hm}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}const ys=-90,Ms=1;class _l extends dn{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Xn(ys,Ms,e,t);s.layers=this.layers,this.add(s);const r=new Xn(ys,Ms,e,t);r.layers=this.layers,this.add(r);const a=new Xn(ys,Ms,e,t);a.layers=this.layers,this.add(a);const o=new Xn(ys,Ms,e,t);o.layers=this.layers,this.add(o);const l=new Xn(ys,Ms,e,t);l.layers=this.layers,this.add(l);const c=new Xn(ys,Ms,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,a,o,l]=t;for(const c of t)this.remove(c);if(e===ai)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===ur)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,l,c,d]=this.children,p=e.getRenderTarget(),u=e.getActiveCubeFace(),h=e.getActiveMipmapLevel(),v=e.xr.enabled;e.xr.enabled=!1;const f=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(n,0,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,r),e.setRenderTarget(n,1,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,4,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.mipmapsAutoUpdate=f,e.setRenderTarget(n,5,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(p,u,h),e.xr.enabled=v,n.texture.needsPMREMUpdate=!0}}class fm extends Xn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}const ad=new yt;class pm{constructor(e,t,n=0,s=1/0){this.ray=new $l(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Wl,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):pt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return ad.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(ad),this}intersectObject(e,t=!0,n=[]){return yl(e,this,n,t),n.sort(od),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)yl(e[s],this,n,t);return n.sort(od),n}}function od(i,e){return i.distance-e.distance}function yl(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)yl(r[a],e,t,!0)}}function ld(i,e,t,n){const s=mm(n);switch(t){case qu:return i*e;case Fl:return i*e/s.components*s.byteLength;case Ol:return i*e/s.components*s.byteLength;case ss:return i*e*2/s.components*s.byteLength;case Hl:return i*e*2/s.components*s.byteLength;case Xu:return i*e*3/s.components*s.byteLength;case hi:return i*e*4/s.components*s.byteLength;case Gl:return i*e*4/s.components*s.byteLength;case ta:case na:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ia:case sa:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Vo:case $o:return Math.max(i,16)*Math.max(e,8)/4;case zo:case Wo:return Math.max(i,8)*Math.max(e,8)/2;case qo:case Xo:case Ko:case Zo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Yo:case va:case Jo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Qo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case jo:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case el:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case tl:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case nl:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case il:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case sl:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case rl:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case al:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case ol:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case ll:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case cl:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case dl:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case ul:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case hl:case fl:case pl:return Math.ceil(i/4)*Math.ceil(e/4)*16;case ml:case gl:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Sa:case vl:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function mm(i){switch(i){case Gn:case zu:return{byteLength:1,components:1};case dr:case Vu:case mi:return{byteLength:2,components:1};case Nl:case Bl:return{byteLength:2,components:4};case pi:case Ul:case ri:return{byteLength:4,components:1};case Wu:case $u:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Dl}}));typeof window<"u"&&(window.__THREE__?qe("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Dl);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function dh(){let i=null,e=!1,t=null,n=null;function s(r,a){n=i.requestAnimationFrame(s),t(r,a)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function gm(i){const e=new WeakMap;function t(o,l){const c=o.array,d=o.usage,p=c.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,c,d),o.onUploadCallback();let h;if(c instanceof Float32Array)h=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)h=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?h=i.HALF_FLOAT:h=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)h=i.SHORT;else if(c instanceof Uint32Array)h=i.UNSIGNED_INT;else if(c instanceof Int32Array)h=i.INT;else if(c instanceof Int8Array)h=i.BYTE;else if(c instanceof Uint8Array)h=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)h=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:h,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:p}}function n(o,l,c){const d=l.array,p=l.updateRanges;if(i.bindBuffer(c,o),p.length===0)i.bufferSubData(c,0,d);else{p.sort((h,v)=>h.start-v.start);let u=0;for(let h=1;h<p.length;h++){const v=p[u],f=p[h];f.start<=v.start+v.count+1?v.count=Math.max(v.count,f.start+f.count-v.start):(++u,p[u]=f)}p.length=u+1;for(let h=0,v=p.length;h<v;h++){const f=p[h];i.bufferSubData(c,f.start*d.BYTES_PER_ELEMENT,d,f.start,f.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=e.get(o);(!d||d.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:r,update:a}}var vm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Sm=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,xm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,_m=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,ym=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Mm=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,bm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,km=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Em=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,wm=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Tm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Cm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Am=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Rm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Lm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Pm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Dm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Im=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Um=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Nm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Bm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Fm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Om=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Hm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Gm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,zm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Vm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Wm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,$m=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,qm="gl_FragColor = linearToOutputTexel( gl_FragColor );",Xm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Ym=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Km=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,Zm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Jm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Qm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,jm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,e0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,t0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,n0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,i0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,s0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,r0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,a0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,o0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,l0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,c0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,d0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,u0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,h0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,f0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,p0=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,m0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,g0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,v0=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,S0=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,x0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,y0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,M0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,b0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,k0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,E0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,w0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,T0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,C0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,A0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,R0=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,L0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,P0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,D0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,I0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,U0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,N0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,B0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,F0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,O0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,H0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,G0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,z0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,V0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,W0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,$0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,q0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,X0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Y0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,K0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Z0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,J0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Q0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,j0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,eg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,tg=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,ng=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ig=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,sg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,rg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,ag=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,og=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,lg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,cg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,dg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,ug=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,hg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,fg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,pg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,mg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const gg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,vg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Sg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,xg=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_g=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,yg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,bg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,kg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Eg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,wg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Tg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Cg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ag=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Rg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Lg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Dg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ig=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Ug=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ng=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Bg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Fg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Og=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Gg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,$g=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,qg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Xg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Yg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Kg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,nt={alphahash_fragment:vm,alphahash_pars_fragment:Sm,alphamap_fragment:xm,alphamap_pars_fragment:_m,alphatest_fragment:ym,alphatest_pars_fragment:Mm,aomap_fragment:bm,aomap_pars_fragment:km,batching_pars_vertex:Em,batching_vertex:wm,begin_vertex:Tm,beginnormal_vertex:Cm,bsdfs:Am,iridescence_fragment:Rm,bumpmap_pars_fragment:Lm,clipping_planes_fragment:Pm,clipping_planes_pars_fragment:Dm,clipping_planes_pars_vertex:Im,clipping_planes_vertex:Um,color_fragment:Nm,color_pars_fragment:Bm,color_pars_vertex:Fm,color_vertex:Om,common:Hm,defaultnormal_vertex:Gm,displacementmap_pars_vertex:zm,displacementmap_vertex:Vm,emissivemap_fragment:Wm,emissivemap_pars_fragment:$m,colorspace_fragment:qm,colorspace_pars_fragment:Xm,envmap_fragment:Ym,envmap_common_pars_fragment:Km,envmap_pars_fragment:Zm,envmap_pars_vertex:Jm,envmap_physical_pars_fragment:l0,envmap_vertex:Qm,fog_vertex:jm,fog_pars_vertex:e0,fog_fragment:t0,fog_pars_fragment:n0,gradientmap_pars_fragment:i0,lightmap_pars_fragment:s0,lights_lambert_fragment:r0,lights_lambert_pars_fragment:a0,lights_pars_begin:o0,lights_toon_fragment:c0,lights_toon_pars_fragment:d0,lights_phong_fragment:u0,lights_phong_pars_fragment:h0,lights_physical_fragment:f0,lights_physical_pars_fragment:p0,lights_fragment_begin:m0,lights_fragment_maps:g0,lights_fragment_end:v0,lightprobes_pars_fragment:S0,logdepthbuf_fragment:x0,logdepthbuf_pars_fragment:_0,logdepthbuf_pars_vertex:y0,logdepthbuf_vertex:M0,map_fragment:b0,map_pars_fragment:k0,map_particle_fragment:E0,map_particle_pars_fragment:w0,metalnessmap_fragment:T0,metalnessmap_pars_fragment:C0,morphinstance_vertex:A0,morphcolor_vertex:R0,morphnormal_vertex:L0,morphtarget_pars_vertex:P0,morphtarget_vertex:D0,normal_fragment_begin:I0,normal_fragment_maps:U0,normal_pars_fragment:N0,normal_pars_vertex:B0,normal_vertex:F0,normalmap_pars_fragment:O0,clearcoat_normal_fragment_begin:H0,clearcoat_normal_fragment_maps:G0,clearcoat_pars_fragment:z0,iridescence_pars_fragment:V0,opaque_fragment:W0,packing:$0,premultiplied_alpha_fragment:q0,project_vertex:X0,dithering_fragment:Y0,dithering_pars_fragment:K0,roughnessmap_fragment:Z0,roughnessmap_pars_fragment:J0,shadowmap_pars_fragment:Q0,shadowmap_pars_vertex:j0,shadowmap_vertex:eg,shadowmask_pars_fragment:tg,skinbase_vertex:ng,skinning_pars_vertex:ig,skinning_vertex:sg,skinnormal_vertex:rg,specularmap_fragment:ag,specularmap_pars_fragment:og,tonemapping_fragment:lg,tonemapping_pars_fragment:cg,transmission_fragment:dg,transmission_pars_fragment:ug,uv_pars_fragment:hg,uv_pars_vertex:fg,uv_vertex:pg,worldpos_vertex:mg,background_vert:gg,background_frag:vg,backgroundCube_vert:Sg,backgroundCube_frag:xg,cube_vert:_g,cube_frag:yg,depth_vert:Mg,depth_frag:bg,distance_vert:kg,distance_frag:Eg,equirect_vert:wg,equirect_frag:Tg,linedashed_vert:Cg,linedashed_frag:Ag,meshbasic_vert:Rg,meshbasic_frag:Lg,meshlambert_vert:Pg,meshlambert_frag:Dg,meshmatcap_vert:Ig,meshmatcap_frag:Ug,meshnormal_vert:Ng,meshnormal_frag:Bg,meshphong_vert:Fg,meshphong_frag:Og,meshphysical_vert:Hg,meshphysical_frag:Gg,meshtoon_vert:zg,meshtoon_frag:Vg,points_vert:Wg,points_frag:$g,shadow_vert:qg,shadow_frag:Xg,sprite_vert:Yg,sprite_frag:Kg},Ce={common:{diffuse:{value:new et(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ye}},envmap:{envMap:{value:null},envMapRotation:{value:new Ye},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ye}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ye}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ye},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ye},normalScale:{value:new it(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ye},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ye}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ye}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ye}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new et(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new et(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0},uvTransform:{value:new Ye}},sprite:{diffuse:{value:new et(16777215)},opacity:{value:1},center:{value:new it(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}}},ui={basic:{uniforms:En([Ce.common,Ce.specularmap,Ce.envmap,Ce.aomap,Ce.lightmap,Ce.fog]),vertexShader:nt.meshbasic_vert,fragmentShader:nt.meshbasic_frag},lambert:{uniforms:En([Ce.common,Ce.specularmap,Ce.envmap,Ce.aomap,Ce.lightmap,Ce.emissivemap,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,Ce.fog,Ce.lights,{emissive:{value:new et(0)},envMapIntensity:{value:1}}]),vertexShader:nt.meshlambert_vert,fragmentShader:nt.meshlambert_frag},phong:{uniforms:En([Ce.common,Ce.specularmap,Ce.envmap,Ce.aomap,Ce.lightmap,Ce.emissivemap,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,Ce.fog,Ce.lights,{emissive:{value:new et(0)},specular:{value:new et(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:nt.meshphong_vert,fragmentShader:nt.meshphong_frag},standard:{uniforms:En([Ce.common,Ce.envmap,Ce.aomap,Ce.lightmap,Ce.emissivemap,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,Ce.roughnessmap,Ce.metalnessmap,Ce.fog,Ce.lights,{emissive:{value:new et(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:nt.meshphysical_vert,fragmentShader:nt.meshphysical_frag},toon:{uniforms:En([Ce.common,Ce.aomap,Ce.lightmap,Ce.emissivemap,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,Ce.gradientmap,Ce.fog,Ce.lights,{emissive:{value:new et(0)}}]),vertexShader:nt.meshtoon_vert,fragmentShader:nt.meshtoon_frag},matcap:{uniforms:En([Ce.common,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,Ce.fog,{matcap:{value:null}}]),vertexShader:nt.meshmatcap_vert,fragmentShader:nt.meshmatcap_frag},points:{uniforms:En([Ce.points,Ce.fog]),vertexShader:nt.points_vert,fragmentShader:nt.points_frag},dashed:{uniforms:En([Ce.common,Ce.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:nt.linedashed_vert,fragmentShader:nt.linedashed_frag},depth:{uniforms:En([Ce.common,Ce.displacementmap]),vertexShader:nt.depth_vert,fragmentShader:nt.depth_frag},normal:{uniforms:En([Ce.common,Ce.bumpmap,Ce.normalmap,Ce.displacementmap,{opacity:{value:1}}]),vertexShader:nt.meshnormal_vert,fragmentShader:nt.meshnormal_frag},sprite:{uniforms:En([Ce.sprite,Ce.fog]),vertexShader:nt.sprite_vert,fragmentShader:nt.sprite_frag},background:{uniforms:{uvTransform:{value:new Ye},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:nt.background_vert,fragmentShader:nt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ye}},vertexShader:nt.backgroundCube_vert,fragmentShader:nt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:nt.cube_vert,fragmentShader:nt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:nt.equirect_vert,fragmentShader:nt.equirect_frag},distance:{uniforms:En([Ce.common,Ce.displacementmap,{referencePosition:{value:new z},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:nt.distance_vert,fragmentShader:nt.distance_frag},shadow:{uniforms:En([Ce.lights,Ce.fog,{color:{value:new et(0)},opacity:{value:1}}]),vertexShader:nt.shadow_vert,fragmentShader:nt.shadow_frag}};ui.physical={uniforms:En([ui.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ye},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ye},clearcoatNormalScale:{value:new it(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ye},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Ye},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ye},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ye},sheen:{value:0},sheenColor:{value:new et(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ye},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ye},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ye},transmissionSamplerSize:{value:new it},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ye},attenuationDistance:{value:0},attenuationColor:{value:new et(0)},specularColor:{value:new et(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ye},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ye},anisotropyVector:{value:new it},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ye}}]),vertexShader:nt.meshphysical_vert,fragmentShader:nt.meshphysical_frag};const qr={r:0,b:0,g:0},Zg=new yt,uh=new Ye;uh.set(-1,0,0,0,1,0,0,0,1);function Jg(i,e,t,n,s,r){const a=new et(0);let o=s===!0?0:1,l,c,d=null,p=0,u=null;function h(S){let M=S.isScene===!0?S.background:null;if(M&&M.isTexture){const _=S.backgroundBlurriness>0;M=e.get(M,_)}return M}function v(S){let M=!1;const _=h(S);_===null?m(a,o):_&&_.isColor&&(m(_,1),M=!0);const E=i.xr.getEnvironmentBlendMode();E==="additive"?t.buffers.color.setClear(0,0,0,1,r):E==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,r),(i.autoClear||M)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function f(S,M){const _=h(M);_&&_.isCubeTexture?(c===void 0&&(c=new ct(new Bs(1,1,1),new rs({name:"BackgroundCubeMaterial",uniforms:Is(ui.backgroundCube.uniforms),vertexShader:ui.backgroundCube.vertexShader,fragmentShader:ui.backgroundCube.fragmentShader,side:In,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(E,y,x){this.matrixWorld.copyPosition(x.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=_,c.material.uniforms.backgroundBlurriness.value=M.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Zg.makeRotationFromEuler(M.backgroundRotation)).transpose(),_.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(uh),c.material.toneMapped=dt.getTransfer(_.colorSpace)!==xt,(d!==_||p!==_.version||u!==i.toneMapping)&&(c.material.needsUpdate=!0,d=_,p=_.version,u=i.toneMapping),c.layers.enableAll(),S.unshift(c,c.geometry,c.material,0,0,null)):_&&_.isTexture&&(l===void 0&&(l=new ct(new Ei(2,2),new rs({name:"BackgroundMaterial",uniforms:Is(ui.background.uniforms),vertexShader:ui.background.vertexShader,fragmentShader:ui.background.fragmentShader,side:Li,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=_,l.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,l.material.toneMapped=dt.getTransfer(_.colorSpace)!==xt,_.matrixAutoUpdate===!0&&_.updateMatrix(),l.material.uniforms.uvTransform.value.copy(_.matrix),(d!==_||p!==_.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,d=_,p=_.version,u=i.toneMapping),l.layers.enableAll(),S.unshift(l,l.geometry,l.material,0,0,null))}function m(S,M){S.getRGB(qr,ah(i)),t.buffers.color.setClear(qr.r,qr.g,qr.b,M,r)}function g(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(S,M=1){a.set(S),o=M,m(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(S){o=S,m(a,o)},render:v,addToRenderList:f,dispose:g}}function Qg(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let r=s,a=!1;function o(D,O,X,k,P){let F=!1;const G=p(D,k,X,O);r!==G&&(r=G,c(r.object)),F=h(D,k,X,P),F&&v(D,k,X,P),P!==null&&e.update(P,i.ELEMENT_ARRAY_BUFFER),(F||a)&&(a=!1,_(D,O,X,k),P!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(P).buffer))}function l(){return i.createVertexArray()}function c(D){return i.bindVertexArray(D)}function d(D){return i.deleteVertexArray(D)}function p(D,O,X,k){const P=k.wireframe===!0;let F=n[O.id];F===void 0&&(F={},n[O.id]=F);const G=D.isInstancedMesh===!0?D.id:0;let se=F[G];se===void 0&&(se={},F[G]=se);let Y=se[X.id];Y===void 0&&(Y={},se[X.id]=Y);let ae=Y[P];return ae===void 0&&(ae=u(l()),Y[P]=ae),ae}function u(D){const O=[],X=[],k=[];for(let P=0;P<t;P++)O[P]=0,X[P]=0,k[P]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:O,enabledAttributes:X,attributeDivisors:k,object:D,attributes:{},index:null}}function h(D,O,X,k){const P=r.attributes,F=O.attributes;let G=0;const se=X.getAttributes();for(const Y in se)if(se[Y].location>=0){const le=P[Y];let ce=F[Y];if(ce===void 0&&(Y==="instanceMatrix"&&D.instanceMatrix&&(ce=D.instanceMatrix),Y==="instanceColor"&&D.instanceColor&&(ce=D.instanceColor)),le===void 0||le.attribute!==ce||ce&&le.data!==ce.data)return!0;G++}return r.attributesNum!==G||r.index!==k}function v(D,O,X,k){const P={},F=O.attributes;let G=0;const se=X.getAttributes();for(const Y in se)if(se[Y].location>=0){let le=F[Y];le===void 0&&(Y==="instanceMatrix"&&D.instanceMatrix&&(le=D.instanceMatrix),Y==="instanceColor"&&D.instanceColor&&(le=D.instanceColor));const ce={};ce.attribute=le,le&&le.data&&(ce.data=le.data),P[Y]=ce,G++}r.attributes=P,r.attributesNum=G,r.index=k}function f(){const D=r.newAttributes;for(let O=0,X=D.length;O<X;O++)D[O]=0}function m(D){g(D,0)}function g(D,O){const X=r.newAttributes,k=r.enabledAttributes,P=r.attributeDivisors;X[D]=1,k[D]===0&&(i.enableVertexAttribArray(D),k[D]=1),P[D]!==O&&(i.vertexAttribDivisor(D,O),P[D]=O)}function S(){const D=r.newAttributes,O=r.enabledAttributes;for(let X=0,k=O.length;X<k;X++)O[X]!==D[X]&&(i.disableVertexAttribArray(X),O[X]=0)}function M(D,O,X,k,P,F,G){G===!0?i.vertexAttribIPointer(D,O,X,P,F):i.vertexAttribPointer(D,O,X,k,P,F)}function _(D,O,X,k){f();const P=k.attributes,F=X.getAttributes(),G=O.defaultAttributeValues;for(const se in F){const Y=F[se];if(Y.location>=0){let ae=P[se];if(ae===void 0&&(se==="instanceMatrix"&&D.instanceMatrix&&(ae=D.instanceMatrix),se==="instanceColor"&&D.instanceColor&&(ae=D.instanceColor)),ae!==void 0){const le=ae.normalized,ce=ae.itemSize,xe=e.get(ae);if(xe===void 0)continue;const Z=xe.buffer,be=xe.type,we=xe.bytesPerElement,Fe=be===i.INT||be===i.UNSIGNED_INT||ae.gpuType===Ul;if(ae.isInterleavedBufferAttribute){const Ee=ae.data,Je=Ee.isInterleavedBuffer===!0?Ee.stride:Ee.itemSize,Xt=ae.offset;if(Ee.isInstancedInterleavedBuffer||Ee.isInstancedBufferAttribute){for(let $e=0;$e<Y.locationSize;$e++)g(Y.location+$e,Ee.meshPerAttribute);D.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=Ee.meshPerAttribute*Ee.count)}else for(let $e=0;$e<Y.locationSize;$e++)m(Y.location+$e);i.bindBuffer(i.ARRAY_BUFFER,Z);for(let $e=0;$e<Y.locationSize;$e++)M(Y.location+$e,ce/Y.locationSize,be,le,Je*we,(Xt+ce/Y.locationSize*$e)*we,Fe)}else{if(ae.isInstancedBufferAttribute){for(let Ee=0;Ee<Y.locationSize;Ee++)g(Y.location+Ee,ae.meshPerAttribute);D.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ae.meshPerAttribute*ae.count)}else for(let Ee=0;Ee<Y.locationSize;Ee++)m(Y.location+Ee);i.bindBuffer(i.ARRAY_BUFFER,Z);for(let Ee=0;Ee<Y.locationSize;Ee++)M(Y.location+Ee,ce/Y.locationSize,be,le,ce*we,ce/Y.locationSize*Ee*we,Fe)}}else if(G!==void 0){const le=G[se];if(le!==void 0)switch(le.length){case 2:i.vertexAttrib2fv(Y.location,le);break;case 3:i.vertexAttrib3fv(Y.location,le);break;case 4:i.vertexAttrib4fv(Y.location,le);break;default:i.vertexAttrib1fv(Y.location,le)}}}}S()}function E(){A();for(const D in n){const O=n[D];for(const X in O){const k=O[X];for(const P in k){const F=k[P];for(const G in F)d(F[G].object),delete F[G];delete k[P]}}delete n[D]}}function y(D){if(n[D.id]===void 0)return;const O=n[D.id];for(const X in O){const k=O[X];for(const P in k){const F=k[P];for(const G in F)d(F[G].object),delete F[G];delete k[P]}}delete n[D.id]}function x(D){for(const O in n){const X=n[O];for(const k in X){const P=X[k];if(P[D.id]===void 0)continue;const F=P[D.id];for(const G in F)d(F[G].object),delete F[G];delete P[D.id]}}}function b(D){for(const O in n){const X=n[O],k=D.isInstancedMesh===!0?D.id:0,P=X[k];if(P!==void 0){for(const F in P){const G=P[F];for(const se in G)d(G[se].object),delete G[se];delete P[F]}delete X[k],Object.keys(X).length===0&&delete n[O]}}}function A(){R(),a=!0,r!==s&&(r=s,c(r.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:A,resetDefaultState:R,dispose:E,releaseStatesOfGeometry:y,releaseStatesOfObject:b,releaseStatesOfProgram:x,initAttributes:f,enableAttribute:m,disableUnusedAttributes:S}}function jg(i,e,t){let n;function s(l){n=l}function r(l,c){i.drawArrays(n,l,c),t.update(c,n,1)}function a(l,c,d){d!==0&&(i.drawArraysInstanced(n,l,c,d),t.update(c,n,d))}function o(l,c,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,d);let u=0;for(let h=0;h<d;h++)u+=c[h];t.update(u,n,1)}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o}function ev(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const x=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(x.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(x){return!(x!==hi&&n.convert(x)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(x){const b=x===mi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(x!==Gn&&x!==ri&&!b&&n.convert(x)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(x){if(x==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";x="mediump"}return x==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const d=l(c);d!==c&&(qe("WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const p=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=t.logarithmicDepthBuffer===!0&&p===!1;t.reversedDepthBuffer===!0&&p===!1&&qe("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),t.logarithmicDepthBuffer===!0&&p===!0&&qe("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const h=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),g=i.getParameter(i.MAX_VERTEX_ATTRIBS),S=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),M=i.getParameter(i.MAX_VARYING_VECTORS),_=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),E=i.getParameter(i.MAX_SAMPLES),y=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:p,maxTextures:h,maxVertexTextures:v,maxTextureSize:f,maxCubemapSize:m,maxAttributes:g,maxVertexUniforms:S,maxVaryings:M,maxFragmentUniforms:_,maxSamples:E,samples:y}}function tv(i){const e=this;let t=null,n=0,s=!1,r=!1;const a=new ki,o=new Ye,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(p,u){const h=p.length!==0||u||n!==0||s;return s=u,n=p.length,h},this.beginShadows=function(){r=!0,d(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(p,u){t=d(p,u,0)},this.setState=function(p,u,h){const v=p.clippingPlanes,f=p.clipIntersection,m=p.clipShadows,g=i.get(p);if(!s||v===null||v.length===0||r&&!m)r?d(null):c();else{const S=r?0:n,M=S*4;let _=g.clippingState||null;l.value=_,_=d(v,u,M,h);for(let E=0;E!==M;++E)_[E]=t[E];g.clippingState=_,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=S}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function d(p,u,h,v){const f=p!==null?p.length:0;let m=null;if(f!==0){if(m=l.value,v!==!0||m===null){const g=h+f*4,S=u.matrixWorldInverse;o.getNormalMatrix(S),(m===null||m.length<g)&&(m=new Float32Array(g));for(let M=0,_=h;M!==f;++M,_+=4)a.copy(p[M]).applyMatrix4(S,o),a.normal.toArray(m,_),m[_+3]=a.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=f,e.numIntersection=0,m}}class jl extends fi{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new ih(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Bs(5,5,5),r=new rs({name:"CubemapFromEquirect",uniforms:Is(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:In,blending:As});r.uniforms.tEquirect.value=t;const a=new ct(s,r),o=t.minFilter;return t.minFilter===Ci&&(t.minFilter=Pn),new _l(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,s);e.setRenderTarget(r)}}const cd=256,nv=3,iv=20,hh=256,fh=16,sv=3,rv=new z,av=new et;class wa{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new _l(1,10,null),this._boxMesh=new ct(new Bs(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,s=100,r={}){const{size:a=256,position:o=rv}=r,l=this._renderer;this._setSize(a);const c=this._allocateTarget(),d=this._getSourceTarget(!0);t>0&&(d.texture.mipmapsAutoUpdate=!1);const p=l.autoClear,u=l.autoClearColor,h=l.autoClearDepth,v=l.autoClearStencil,f=e.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,f===null&&(e.background=l.getClearColor(av));const m=new _l(n,s,d);return m.position.copy(o),m.update(l,e),l.autoClear=p,l.autoClearColor=u,l.autoClearDepth=h,l.autoClearStencil=v,e.background=f,t>0&&(d.texture.mipmapsAutoUpdate=!0,this._blur(c,t)),this._applyPMREM(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=hd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ud(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(cd,Lp(e))}_fromTexture(e,t){e.mapping===Ls||e.mapping===lr?this._setSize(e.image.length===0?cd:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);const n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){const e=this._cubeSize,t=dd(e,!1,!1),n=Math.log2(e)-nv;for(let s=0;s<=n;s++)t.texture.mipmaps.push({width:e>>s,height:e>>s});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){const t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=dd(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){const s=this._boxMesh,r=this._cubeCamera;s.material=n,r.renderTarget=e,r.activeMipmapLevel=t;const a=e.width>>t;e.viewport.set(0,0,a,a),r.update(this._renderer,s),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===Ls||e.mapping===lr?(this._cubemapMaterial===null&&(this._cubemapMaterial=hd()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=ud()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){this._ggxMaterial===null&&(this._ggxMaterial=ov(),this._integrationMaterial=lv());const t=this._cubeSize,n=e.texture.mipmaps.length-1,s=this._ggxMaterial.uniforms;s.envMap.value=this._sourceTarget.texture;const r=this._integrationMaterial.uniforms;r.envMap.value=this._sourceTarget.texture,r.sourceLod.value=Math.log2(t/fh);for(let a=0;a<=n;a++){const o=wa.lodToRoughness(a,n);if(a>n-sv)r.roughness.value=o,this._renderCube(e,a,this._integrationMaterial);else{const l=o>0?Math.log2(t)+.5*Math.log2(6/(hh*Math.pow(o,4)))+.5:0;s.roughness.value=o,s.lodBias.value=l,this._renderCube(e,a,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=cv());const n=this._blurMaterial,s=n.uniforms,r=this._sourceTarget;s.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,s.envMap.value=r.texture,this._renderCube(e,0,n),s.envMap.value=e.texture,this._renderCube(r,0,n)}}function dd(i,e,t){return new jl(i,{minFilter:Ci,generateMipmaps:e,type:mi,colorSpace:xa,depthBuffer:t})}function gr(i,e,t){return new rs({name:i,uniforms:e,vertexShader:nt.cube_vert,fragmentShader:t,side:In,blending:As,depthTest:!1,depthWrite:!1})}function ov(){return gr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${hh}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function lv(){return gr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:fh}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function cv(){return gr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${iv}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function ud(){return gr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function hd(){return gr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function dv(i){let e=new WeakMap,t=new WeakMap,n=null;function s(u,h=!1){return u==null?null:h?a(u):r(u)}function r(u){if(u&&u.isTexture){const h=u.mapping;if(h===qa||h===Xa)if(e.has(u)){const v=e.get(u).texture;return o(v,u.mapping)}else{const v=u.image;if(v&&v.height>0){const f=new jl(v.height);return f.fromEquirectangularTexture(i,u),e.set(u,f),u.addEventListener("dispose",c),o(f.texture,u.mapping)}else return null}}return u}function a(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const h=u.mapping,v=h===qa||h===Xa,f=h===Ls||h===lr;if(v||f){let m=t.get(u);const g=m!==void 0?m.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==g)return n===null&&(n=new wa(i)),m=v?n.fromEquirectangular(u,m):n.fromCubemap(u,m),m.texture.pmremVersion=u.pmremVersion,t.set(u,m),m.texture;if(m!==void 0)return m.texture;{const S=u.image;return v&&S&&S.height>0||f&&S&&l(S)?(n===null&&(n=new wa(i)),m=v?n.fromEquirectangular(u):n.fromCubemap(u),m.texture.pmremVersion=u.pmremVersion,t.set(u,m),u.addEventListener("dispose",d),m.texture):null}}}return u}function o(u,h){return h===qa?u.mapping=Ls:h===Xa&&(u.mapping=lr),u}function l(u){let h=0;const v=6;for(let f=0;f<v;f++)u[f]!==void 0&&h++;return h===v}function c(u){const h=u.target;h.removeEventListener("dispose",c);const v=e.get(h);v!==void 0&&(e.delete(h),v.dispose())}function d(u){const h=u.target;h.removeEventListener("dispose",d);const v=t.get(h);v!==void 0&&(t.delete(h),v.dispose())}function p(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:p}}function uv(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const s=i.getExtension(n);return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&ra("WebGLRenderer: "+n+" extension not supported."),s}}}function hv(i,e,t,n){const s={},r=new WeakMap,a=new FinalizationRegistry(v=>delete s[v]);function o(v){l(v.target)}function l(v){v.index!==null&&e.remove(v.index);for(const m in v.attributes)e.remove(v.attributes[m]);v.removeEventListener("dispose",o),delete s[v.id],a.unregister(v);const f=r.get(v);f&&(e.remove(f),r.delete(v)),n.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,t.memory.geometries--}function c(v,f){return s[f.id]!==void 0||(f.addEventListener("dispose",o),s[f.id]=new WeakRef(f),a.register(f,f.id,f),t.memory.geometries++),f}function d(v){const f=v.attributes;for(const m in f)e.update(f[m],i.ARRAY_BUFFER)}function p(v){const f=v.index,m=v.attributes.position;let g=0;if(m===void 0)return;const S=f!==null?f.array.length:m.array.length/3-1,M=m.count>=65535?th:eh,_=new M(Math.ceil(S/3)*6,1),E=_.array;if(f!==null){const x=f.array;g=f.version;for(let b=0,A=0;b<S;b+=3){const R=x[b+0],D=x[b+1],O=x[b+2];E[A++]=R,E[A++]=D,E[A++]=D,E[A++]=O,E[A++]=O,E[A++]=R}}else{g=m.version;for(let x=0,b=0;x<S;x+=3){const A=x+0,R=x+1,D=x+2;E[b++]=A,E[b++]=R,E[b++]=R,E[b++]=D,E[b++]=D,E[b++]=A}}_.version=g;const y=r.get(v);y&&e.remove(y),r.set(v,_)}function u(v){const f=r.get(v);if(f){const m=v.index;m!==null&&f.version<m.version&&p(v)}else p(v);return r.get(v)}function h(){for(const v in s){const f=s[v].deref();f!==void 0&&l(f)}}return{get:c,update:d,getWireframeAttribute:u,dispose:h}}function fv(i,e,t){let n;function s(p){n=p}let r,a;function o(p){r=p.type,a=p.bytesPerElement}function l(p,u){i.drawElements(n,u,r,p*a),t.update(u,n,1)}function c(p,u,h){h!==0&&(i.drawElementsInstanced(n,u,r,p*a,h),t.update(u,n,h))}function d(p,u,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,r,p,0,h);let f=0;for(let m=0;m<h;m++)f+=u[m];t.update(f,n,1)}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d}function pv(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(r/3);break;case i.LINES:t.lines+=o*(r/2);break;case i.LINE_STRIP:t.lines+=o*(r-1);break;case i.LINE_LOOP:t.lines+=o*r;break;case i.POINTS:t.points+=o*r;break;default:pt("WebGLInfo: Unknown draw mode:",a);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function mv(i,e,t){const n=new WeakMap,s=new Gt;function r(a,o,l){const c=a.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,p=d!==void 0?d.length:0;let u=n.get(o);if(u===void 0||u.count!==p){let R=function(){b.dispose(),n.delete(o),o.removeEventListener("dispose",R)};var h=R;u!==void 0&&u.texture.dispose();const v=o.morphAttributes.position!==void 0,f=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,g=o.morphAttributes.position||[],S=o.morphAttributes.normal||[],M=o.morphAttributes.color||[];let _=0;v===!0&&(_=1),f===!0&&(_=2),m===!0&&(_=3);let E=o.attributes.position.count*_,y=1;E>e.maxTextureSize&&(y=Math.ceil(E/e.maxTextureSize),E=e.maxTextureSize);const x=new Float32Array(E*y*4*p),b=new Qu(x,E,y,p);b.type=ri,b.needsUpdate=!0;const A=_*4;for(let D=0;D<p;D++){const O=g[D],X=S[D],k=M[D],P=E*y*4*D;for(let F=0;F<O.count;F++){const G=F*A;v===!0&&(s.fromBufferAttribute(O,F),x[P+G+0]=s.x,x[P+G+1]=s.y,x[P+G+2]=s.z,x[P+G+3]=0),f===!0&&(s.fromBufferAttribute(X,F),x[P+G+4]=s.x,x[P+G+5]=s.y,x[P+G+6]=s.z,x[P+G+7]=0),m===!0&&(s.fromBufferAttribute(k,F),x[P+G+8]=s.x,x[P+G+9]=s.y,x[P+G+10]=s.z,x[P+G+11]=k.itemSize===4?s.w:1)}}u={count:p,texture:b,size:new it(E,y)},n.set(o,u),o.addEventListener("dispose",R)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let v=0;for(let m=0;m<c.length;m++)v+=c[m];const f=o.morphTargetsRelative?1:1-v;l.getUniforms().setValue(i,"morphTargetBaseInfluence",f),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:r}}function gv(i,e,t,n,s){let r=new WeakMap;function a(c){const d=s.render.frame,p=c.geometry,u=e.get(c,p);if(r.get(u)!==d&&(e.update(u),r.set(u,d)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),r.get(c)!==d&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),r.set(c,d))),c.isSkinnedMesh){const h=c.skeleton;r.get(h)!==d&&(h.update(),r.set(h,d))}return u}function o(){r=new WeakMap}function l(c){const d=c.target;d.removeEventListener("dispose",l),n.releaseStatesOfObject(d),t.remove(d.instanceMatrix),d.instanceColor!==null&&t.remove(d.instanceColor)}return{update:a,dispose:o}}const vv={[Uu]:"LINEAR_TONE_MAPPING",[Nu]:"REINHARD_TONE_MAPPING",[Bu]:"CINEON_TONE_MAPPING",[Il]:"ACES_FILMIC_TONE_MAPPING",[Ou]:"AGX_TONE_MAPPING",[Hu]:"NEUTRAL_TONE_MAPPING",[Fu]:"CUSTOM_TONE_MAPPING"};function Sv(i,e,t,n,s,r){const a=new fi(e,t,{type:i,depthBuffer:s,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null,c=null;const d=new yn;d.setAttribute("position",new It([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new It([0,2,0,0,2,0],2));const p=new lm({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new ct(d,p),h=new ch(-1,1,1,-1,0,1);let v=null,f=null,m=!1,g,S=null,M=[],_=!1;this.setSize=function(E,y){a.setSize(E,y),o!==null&&o.setSize(E,y),l!==null&&l.setSize(E,y);for(let x=0;x<M.length;x++){const b=M[x];b.setSize&&b.setSize(E,y)}},this.setEffects=function(E){M=E,_=M.length>0&&M[0].isRenderPass===!0;const y=a.width,x=a.height;M.length>0&&o===null&&(o=new fi(y,x,{type:mi,depthBuffer:!1,stencilBuffer:!1}),l=new fi(y,x,{type:mi,depthBuffer:!1,stencilBuffer:!1}));const b=s===!0&&M.some(A=>A.needsDepthTexture===!0);b!==(a.depthTexture!==null)&&(b===!0&&c===null&&(c=new Ds(y,x),r===!0&&(c.format=Hi,c.type=Ps)),a.dispose(),a.depthTexture=b?c:null,a.resolveDepthBuffer=b,a.storeMultisampledDepthBuffer=b);for(let A=0;A<M.length;A++){const R=M[A];R.setSize&&R.setSize(y,x),b&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(c)}},this.begin=function(E,y){if(m||E.toneMapping===Ai&&M.length===0)return!1;if(S=y,y!==null){const x=y.width,b=y.height;(a.width!==x||a.height!==b)&&this.setSize(x,b)}return _===!1&&E.setRenderTarget(a),g=E.toneMapping,E.toneMapping=Ai,!0},this.hasRenderPass=function(){return _},this.end=function(E,y){E.toneMapping=g,m=!0;let x=a,b=o;for(let A=0;A<M.length;A++){const R=M[A];R.enabled!==!1&&(R.render(E,b,x,y),R.needsSwap!==!1&&(x=b,b=b===o?l:o))}if(v!==E.outputColorSpace||f!==E.toneMapping){v=E.outputColorSpace,f=E.toneMapping,p.defines={},dt.getTransfer(v)===xt&&(p.defines.SRGB_TRANSFER="");const A=vv[f];A&&(p.defines[A]=""),p.needsUpdate=!0}p.uniforms.tDiffuse.value=x.texture,E.setRenderTarget(S),E.render(u,h),S=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),d.dispose(),p.dispose()}}const ph=new Mn,mh=new Ds(1,1),gh=new sh(1),vh=new Qu,Sh=new Op,xh=new ih,fd=[],pd=[],md=new Float32Array(16),gd=new Float32Array(9),vd=new Float32Array(4);function Fs(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=fd[s];if(r===void 0&&(r=new Float32Array(s),fd[s]=r),e!==0){n.toArray(r,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(r,o)}return r}function tn(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function nn(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function Na(i,e){let t=pd[e];t===void 0&&(t=new Int32Array(e),pd[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function xv(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function _v(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(tn(t,e))return;i.uniform2fv(this.addr,e),nn(t,e)}}function yv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(tn(t,e))return;i.uniform3fv(this.addr,e),nn(t,e)}}function Mv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(tn(t,e))return;i.uniform4fv(this.addr,e),nn(t,e)}}function bv(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(tn(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),nn(t,e)}else{if(tn(t,n))return;vd.set(n),i.uniformMatrix2fv(this.addr,!1,vd),nn(t,n)}}function kv(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(tn(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),nn(t,e)}else{if(tn(t,n))return;gd.set(n),i.uniformMatrix3fv(this.addr,!1,gd),nn(t,n)}}function Ev(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(tn(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),nn(t,e)}else{if(tn(t,n))return;md.set(n),i.uniformMatrix4fv(this.addr,!1,md),nn(t,n)}}function wv(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function Tv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(tn(t,e))return;i.uniform2iv(this.addr,e),nn(t,e)}}function Cv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(tn(t,e))return;i.uniform3iv(this.addr,e),nn(t,e)}}function Av(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(tn(t,e))return;i.uniform4iv(this.addr,e),nn(t,e)}}function Rv(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function Lv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(tn(t,e))return;i.uniform2uiv(this.addr,e),nn(t,e)}}function Pv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(tn(t,e))return;i.uniform3uiv(this.addr,e),nn(t,e)}}function Dv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(tn(t,e))return;i.uniform4uiv(this.addr,e),nn(t,e)}}function Ba(i){return i.version===0&&(i.compareFunction=Zu,i.needsUpdate=!0),i}function Iv(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?r=Ba(mh):r=ph,t.setTexture2D(e||r,s)}function Uv(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Sh,s)}function Nv(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_CUBE_SHADOW?r=Ba(gh):r=xh,t.setTextureCube(e||r,s)}function Bv(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||vh,s)}function Fv(i){switch(i){case 5126:return xv;case 35664:return _v;case 35665:return yv;case 35666:return Mv;case 35674:return bv;case 35675:return kv;case 35676:return Ev;case 5124:case 35670:return wv;case 35667:case 35671:return Tv;case 35668:case 35672:return Cv;case 35669:case 35673:return Av;case 5125:return Rv;case 36294:return Lv;case 36295:return Pv;case 36296:return Dv;case 35678:case 36198:case 36298:case 36306:case 35682:return Iv;case 35679:case 36299:case 36307:return Uv;case 35680:case 36300:case 36308:case 36293:return Nv;case 36289:case 36303:case 36311:case 36292:return Bv}}function Ov(i,e){i.uniform1fv(this.addr,e)}function Hv(i,e){const t=Fs(e,this.size,2);i.uniform2fv(this.addr,t)}function Gv(i,e){const t=Fs(e,this.size,3);i.uniform3fv(this.addr,t)}function zv(i,e){const t=Fs(e,this.size,4);i.uniform4fv(this.addr,t)}function Vv(i,e){const t=Fs(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Wv(i,e){const t=Fs(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function $v(i,e){const t=Fs(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function qv(i,e){i.uniform1iv(this.addr,e)}function Xv(i,e){i.uniform2iv(this.addr,e)}function Yv(i,e){i.uniform3iv(this.addr,e)}function Kv(i,e){i.uniform4iv(this.addr,e)}function Zv(i,e){i.uniform1uiv(this.addr,e)}function Jv(i,e){i.uniform2uiv(this.addr,e)}function Qv(i,e){i.uniform3uiv(this.addr,e)}function jv(i,e){i.uniform4uiv(this.addr,e)}function eS(i,e,t){const n=this.cache,s=e.length,r=Na(t,s);tn(n,r)||(i.uniform1iv(this.addr,r),nn(n,r));let a;this.type===i.SAMPLER_2D_SHADOW?a=Ba(mh):a=ph;for(let o=0;o!==s;++o)t.setTexture2D(e[o]||a,r[o])}function tS(i,e,t){const n=this.cache,s=e.length,r=Na(t,s);tn(n,r)||(i.uniform1iv(this.addr,r),nn(n,r));for(let a=0;a!==s;++a)t.setTexture3D(e[a]||Sh,r[a])}function nS(i,e,t){const n=this.cache,s=e.length,r=Na(t,s);tn(n,r)||(i.uniform1iv(this.addr,r),nn(n,r));let a;this.type===i.SAMPLER_CUBE_SHADOW?a=Ba(gh):a=xh;for(let o=0;o!==s;++o)t.setTextureCube(e[o]||a,r[o])}function iS(i,e,t){const n=this.cache,s=e.length,r=Na(t,s);tn(n,r)||(i.uniform1iv(this.addr,r),nn(n,r));for(let a=0;a!==s;++a)t.setTexture2DArray(e[a]||vh,r[a])}function sS(i){switch(i){case 5126:return Ov;case 35664:return Hv;case 35665:return Gv;case 35666:return zv;case 35674:return Vv;case 35675:return Wv;case 35676:return $v;case 5124:case 35670:return qv;case 35667:case 35671:return Xv;case 35668:case 35672:return Yv;case 35669:case 35673:return Kv;case 5125:return Zv;case 36294:return Jv;case 36295:return Qv;case 36296:return jv;case 35678:case 36198:case 36298:case 36306:case 35682:return eS;case 35679:case 36299:case 36307:return tS;case 35680:case 36300:case 36308:case 36293:return nS;case 36289:case 36303:case 36311:case 36292:return iS}}class rS{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Fv(t.type)}}class aS{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=sS(t.type)}}class oS{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(e,t[o.id],n)}}}const yo=/(\w+)(\])?(\[|\.)?/g;function Sd(i,e){i.seq.push(e),i.map[e.id]=e}function lS(i,e,t){const n=i.name,s=n.length;for(yo.lastIndex=0;;){const r=yo.exec(n),a=yo.lastIndex;let o=r[1];const l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===s){Sd(t,c===void 0?new rS(o,i,e):new aS(o,i,e));break}else{let p=t.map[o];p===void 0&&(p=new oS(o),Sd(t,p)),t=p}}}class oa{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const o=e.getActiveUniform(t,a),l=e.getUniformLocation(t,o.name);lS(o,l,this)}const s=[],r=[];for(const a of this.seq)a.type===e.SAMPLER_2D_SHADOW||a.type===e.SAMPLER_CUBE_SHADOW||a.type===e.SAMPLER_2D_ARRAY_SHADOW?s.push(a):r.push(a);s.length>0&&(this.seq=s.concat(r))}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,a=t.length;r!==a;++r){const o=t[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const a=e[s];a.id in t&&n.push(a)}return n}}function xd(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const cS=37297;let dS=0;function uS(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const _d=new Ye;function hS(i){dt._getMatrix(_d,dt.workingColorSpace,i);const e=`mat3( ${_d.elements.map(t=>t.toFixed(4))} )`;switch(dt.getTransfer(i)){case _a:return[e,"LinearTransferOETF"];case xt:return[e,"sRGBTransferOETF"];default:return qe("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function yd(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),r=(i.getShaderInfoLog(e)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+r+`

`+uS(i.getShaderSource(e),o)}else return r}function fS(i,e){const t=hS(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( ${t[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const pS={[Uu]:"Linear",[Nu]:"Reinhard",[Bu]:"Cineon",[Il]:"ACESFilmic",[Ou]:"AgX",[Hu]:"Neutral",[Fu]:"Custom"};function mS(i,e){const t=pS[e];return t===void 0?(qe("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Xr=new z;function gS(){dt.getLuminanceCoefficients(Xr);const i=Xr.x.toFixed(4),e=Xr.y.toFixed(4),t=Xr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function vS(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(tr).join(`
`)}function SS(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function xS(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),t[a]={type:r.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function tr(i){return i!==""}function Md(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,e.numLightProbeGrids)}function bd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const _S=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ml(i){return i.replace(_S,yS)}function yS(i,e){const t=nt[e];if(t===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">");return Ml(t)}const MS=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function kd(i){return i.replace(MS,bS)}function bS(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Ed(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const kS={[ea]:"SHADOWMAP_TYPE_PCF",[js]:"SHADOWMAP_TYPE_VSM"};function ES(i){return kS[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const wS={[lr]:"ENVMAP_MODE_REFRACTION"};function TS(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":wS[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const CS={[Iu]:"ENVMAP_BLENDING_MULTIPLY",[pp]:"ENVMAP_BLENDING_MIX",[mp]:"ENVMAP_BLENDING_ADD"};function AS(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":CS[i.combine]||"ENVMAP_BLENDING_NONE"}function RS(i,e,t,n){const s=i.getContext(),r=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=ES(t),c=t.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",d=TS(t),p=AS(t),u=vS(t),h=SS(r),v=s.createProgram();let f,m,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h].filter(tr).join(`
`),f.length>0&&(f+=`
`),m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h].filter(tr).join(`
`),m.length>0&&(m+=`
`)):(f=[Ed(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+t.diffuseRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(tr).join(`
`),m=[Ed(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+p:"",t.envMapPMREM?"#define ENVMAP_MAX_LOD "+t.envMapMaxLod+".0":"",t.envMapPMREM?"#define ENVMAP_SIZE "+t.envMapSize+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ai?"#define TONE_MAPPING":"",t.toneMapping!==Ai?nt.tonemapping_pars_fragment:"",t.toneMapping!==Ai?mS("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",nt.colorspace_pars_fragment,fS("linearToOutputTexel",t.outputColorSpace),gS(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(tr).join(`
`)),a=Ml(a),a=Md(a,t),a=bd(a,t),o=Ml(o),o=Md(o,t),o=bd(o,t),a=kd(a),o=kd(o),t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,f=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,m=["#define varying in",t.glslVersion===Ec?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Ec?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const S=g+f+a,M=g+m+o,_=xd(s,s.VERTEX_SHADER,S),E=xd(s,s.FRAGMENT_SHADER,M);s.attachShader(v,_),s.attachShader(v,E),t.index0AttributeName!==void 0?s.bindAttribLocation(v,0,t.index0AttributeName):t.hasPositionAttribute===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function y(R){if(i.debug.checkShaderErrors){const D=s.getProgramInfoLog(v)||"",O=s.getShaderInfoLog(_)||"",X=s.getShaderInfoLog(E)||"",k=D.trim(),P=O.trim(),F=X.trim();let G=!0,se=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(G=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,v,_,E);else{const Y=yd(s,_,"vertex"),ae=yd(s,E,"fragment");pt("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+k+`
`+Y+`
`+ae)}else k!==""?qe("WebGLProgram: Program Info Log:",k):(P===""||F==="")&&(se=!1);se&&(R.diagnostics={runnable:G,programLog:k,vertexShader:{log:P,prefix:f},fragmentShader:{log:F,prefix:m}})}s.deleteShader(_),s.deleteShader(E),x=new oa(s,v),b=xS(s,v)}let x;this.getUniforms=function(){return x===void 0&&y(this),x};let b;this.getAttributes=function(){return b===void 0&&y(this),b};let A=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return A===!1&&(A=s.getProgramParameter(v,cS)),A},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=dS++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=_,this.fragmentShader=E,this}let LS=0;class PS{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const s=this._getShaderCacheForMaterial(e);return s.has(t)===!1&&(s.add(t),t.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new DS(e),t.set(e,n)),n}}class DS{constructor(e){this.id=LS++,this.code=e,this.usedTimes=0}}function IS(i){return i===ss||i===va||i===Sa}function US(i,e,t,n,s,r){const a=new Wl,o=new PS,l=new Set,c=[],d=new Map,p=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function h(x){return l.add(x),x===0?"uv":`uv${x}`}function v(x,b,A,R,D,O){const X=R.fog,k=D.geometry,P=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?R.environment:null,F=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,G=e.get(x.envMap||P,F),se=u[x.type];let Y=n.precision;x.precision!==null&&(Y=n.getMaxPrecision(x.precision),Y!==x.precision&&qe("WebGLProgram.getParameters:",x.precision,"not supported, using",Y,"instead."));const ae=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,le=ae!==void 0?ae.length:0;let ce=0;k.morphAttributes.position!==void 0&&(ce=1),k.morphAttributes.normal!==void 0&&(ce=2),k.morphAttributes.color!==void 0&&(ce=3);let xe,Z,be,we;if(se){const Te=ui[se];xe=Te.vertexShader,Z=Te.fragmentShader}else{xe=x.vertexShader,Z=x.fragmentShader;const Te=o.getVertexShaderStage(x),St=o.getFragmentShaderStage(x);o.update(x,Te,St),be=Te.id,we=St.id}const Fe=i.getRenderTarget(),Ee=i.state.buffers.depth.getReversed(),Je=D.isInstancedMesh===!0,Xt=D.isBatchedMesh===!0,$e=!!x.map,vt=!!x.matcap,bt=!!G,rt=bt&&G.isPMREMTexture===!0,un=!!x.aoMap,Jt=!!x.lightMap,Cn=!!x.bumpMap&&x.wireframe===!1,Ut=!!x.normalMap,oi=!!x.displacementMap,sn=!!x.emissiveMap,zn=!!x.metalnessMap,Vn=!!x.roughnessMap,Wn=x.anisotropy>0,H=x.clearcoat>0,$n=x.diffuseRoughness>0,At=x.dispersion>0,Rt=x.retroreflectivity>0,ke=x.iridescence>0,Qt=x.sheen>0,ze=x.transmission>0,Xe=Wn&&!!x.anisotropyMap,C=H&&!!x.clearcoatMap,w=H&&!!x.clearcoatNormalMap,$=H&&!!x.clearcoatRoughnessMap,de=$n&&!!x.diffuseRoughnessMap,oe=ke&&!!x.iridescenceMap,pe=ke&&!!x.iridescenceThicknessMap,ye=Qt&&!!x.sheenColorMap,te=Qt&&!!x.sheenRoughnessMap,ie=!!x.specularMap,ge=!!x.specularColorMap,I=!!x.specularIntensityMap,re=ze&&!!x.transmissionMap,ee=ze&&!!x.thicknessMap,ve=!!x.gradientMap,fe=!!x.alphaMap,me=x.alphaTest>0,Oe=!!x.alphaHash,tt=!!x.extensions;let ue=Ai;x.toneMapped&&(Fe===null||Fe.isXRRenderTarget===!0)&&(ue=i.toneMapping);const Ge=rt?G.isCompressedCubeTexture?G.image[0].mipmaps:G.mipmaps:null,je={shaderID:se,shaderType:x.type,shaderName:x.name,vertexShader:xe,fragmentShader:Z,defines:x.defines,customVertexShaderID:be,customFragmentShaderID:we,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:Y,batching:Xt,batchingColor:Xt&&D._colorsTexture!==null,instancing:Je,instancingColor:Je&&D.instanceColor!==null,instancingMorph:Je&&D.morphTexture!==null,outputColorSpace:Fe===null?i.outputColorSpace:Fe.isXRRenderTarget===!0?Fe.texture.colorSpace:dt.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:$e,matcap:vt,envMap:bt,envMapMode:bt&&G.mapping,envMapPMREM:rt,envMapMaxLod:rt?Ge.length-1:null,envMapSize:rt?Ge[0].width:null,aoMap:un,lightMap:Jt,bumpMap:Cn,normalMap:Ut,displacementMap:oi,emissiveMap:sn,normalMapObjectSpace:Ut&&x.normalMapType===Sp,normalMapTangentSpace:Ut&&x.normalMapType===Sl,packedNormalMap:Ut&&x.normalMapType===Sl&&IS(x.normalMap.format),metalnessMap:zn,roughnessMap:Vn,anisotropy:Wn,anisotropyMap:Xe,clearcoat:H,clearcoatMap:C,clearcoatNormalMap:w,clearcoatRoughnessMap:$,diffuseRoughness:$n,diffuseRoughnessMap:de,dispersion:At,retroreflection:Rt,iridescence:ke,iridescenceMap:oe,iridescenceThicknessMap:pe,sheen:Qt,sheenColorMap:ye,sheenRoughnessMap:te,specularMap:ie,specularColorMap:ge,specularIntensityMap:I,transmission:ze,transmissionMap:re,thicknessMap:ee,gradientMap:ve,opaque:x.transparent===!1&&x.blending===ir&&x.alphaToCoverage===!1,alphaMap:fe,alphaTest:me,alphaHash:Oe,combine:x.combine,mapUv:$e&&h(x.map.channel),aoMapUv:un&&h(x.aoMap.channel),lightMapUv:Jt&&h(x.lightMap.channel),bumpMapUv:Cn&&h(x.bumpMap.channel),normalMapUv:Ut&&h(x.normalMap.channel),displacementMapUv:oi&&h(x.displacementMap.channel),emissiveMapUv:sn&&h(x.emissiveMap.channel),metalnessMapUv:zn&&h(x.metalnessMap.channel),roughnessMapUv:Vn&&h(x.roughnessMap.channel),anisotropyMapUv:Xe&&h(x.anisotropyMap.channel),clearcoatMapUv:C&&h(x.clearcoatMap.channel),clearcoatNormalMapUv:w&&h(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:$&&h(x.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:de&&h(x.diffuseRoughnessMap.channel),iridescenceMapUv:oe&&h(x.iridescenceMap.channel),iridescenceThicknessMapUv:pe&&h(x.iridescenceThicknessMap.channel),sheenColorMapUv:ye&&h(x.sheenColorMap.channel),sheenRoughnessMapUv:te&&h(x.sheenRoughnessMap.channel),specularMapUv:ie&&h(x.specularMap.channel),specularColorMapUv:ge&&h(x.specularColorMap.channel),specularIntensityMapUv:I&&h(x.specularIntensityMap.channel),transmissionMapUv:re&&h(x.transmissionMap.channel),thicknessMapUv:ee&&h(x.thicknessMap.channel),alphaMapUv:fe&&h(x.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(Ut||Wn),vertexNormals:!!k.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,pointsUvs:D.isPoints===!0&&!!k.attributes.uv&&($e||fe),fog:!!X,useFog:x.fog===!0,fogExp2:!!X&&X.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||k.attributes.normal===void 0&&Ut===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:p,reversedDepthBuffer:Ee,skinning:D.isSkinnedMesh===!0,hasPositionAttribute:k.attributes.position!==void 0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:le,morphTextureStride:ce,numSunLights:b.sun.length,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numSunLightShadows:b.sunShadowMap.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numLightProbeGrids:O.filter(Te=>Te.texture!==null).length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:x.dithering,shadowMapEnabled:i.shadowMap.enabled&&A.length>0,shadowMapType:i.shadowMap.type,toneMapping:ue,decodeVideoTexture:$e&&x.map.isVideoTexture===!0&&dt.getTransfer(x.map.colorSpace)===xt,decodeVideoTextureEmissive:sn&&x.emissiveMap.isVideoTexture===!0&&dt.getTransfer(x.emissiveMap.colorSpace)===xt,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===Hn,flipSided:x.side===In,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:tt&&x.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(tt&&x.extensions.multiDraw===!0||Xt)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return je.vertexUv1s=l.has(1),je.vertexUv2s=l.has(2),je.vertexUv3s=l.has(3),l.clear(),je}function f(x){const b=[];if(x.shaderID?b.push(x.shaderID):(b.push(x.customVertexShaderID),b.push(x.customFragmentShaderID)),x.defines!==void 0)for(const A in x.defines)b.push(A),b.push(x.defines[A]);return x.isRawShaderMaterial===!1&&(m(b,x),g(b,x),b.push(i.outputColorSpace)),b.push(x.customProgramCacheKey),b.join()}function m(x,b){x.push(b.precision),x.push(b.outputColorSpace),x.push(b.envMapMode),x.push(b.envMapPMREM),x.push(b.envMapMaxLod),x.push(b.envMapSize),x.push(b.mapUv),x.push(b.alphaMapUv),x.push(b.lightMapUv),x.push(b.aoMapUv),x.push(b.bumpMapUv),x.push(b.normalMapUv),x.push(b.displacementMapUv),x.push(b.emissiveMapUv),x.push(b.metalnessMapUv),x.push(b.roughnessMapUv),x.push(b.anisotropyMapUv),x.push(b.clearcoatMapUv),x.push(b.clearcoatNormalMapUv),x.push(b.clearcoatRoughnessMapUv),x.push(b.diffuseRoughnessMapUv),x.push(b.iridescenceMapUv),x.push(b.iridescenceThicknessMapUv),x.push(b.sheenColorMapUv),x.push(b.sheenRoughnessMapUv),x.push(b.specularMapUv),x.push(b.specularColorMapUv),x.push(b.specularIntensityMapUv),x.push(b.transmissionMapUv),x.push(b.thicknessMapUv),x.push(b.combine),x.push(b.fogExp2),x.push(b.sizeAttenuation),x.push(b.morphTargetsCount),x.push(b.numSunLights),x.push(b.numDirLights),x.push(b.numPointLights),x.push(b.numSpotLights),x.push(b.numSpotLightMaps),x.push(b.numHemiLights),x.push(b.numRectAreaLights),x.push(b.numSunLightShadows),x.push(b.numDirLightShadows),x.push(b.numPointLightShadows),x.push(b.numSpotLightShadows),x.push(b.numSpotLightShadowsWithMaps),x.push(b.numLightProbes),x.push(b.numLightProbeGrids),x.push(b.shadowMapType),x.push(b.toneMapping),x.push(b.numClippingPlanes),x.push(b.numClipIntersection),x.push(b.depthPacking)}function g(x,b){a.disableAll(),b.instancing&&a.enable(0),b.instancingColor&&a.enable(1),b.instancingMorph&&a.enable(2),b.matcap&&a.enable(3),b.envMap&&a.enable(4),b.normalMapObjectSpace&&a.enable(5),b.normalMapTangentSpace&&a.enable(6),b.clearcoat&&a.enable(7),b.iridescence&&a.enable(8),b.alphaTest&&a.enable(9),b.vertexColors&&a.enable(10),b.vertexAlphas&&a.enable(11),b.vertexUv1s&&a.enable(12),b.vertexUv2s&&a.enable(13),b.vertexUv3s&&a.enable(14),b.vertexTangents&&a.enable(15),b.anisotropy&&a.enable(16),b.alphaHash&&a.enable(17),b.batching&&a.enable(18),b.dispersion&&a.enable(19),b.retroreflection&&a.enable(24),b.diffuseRoughness&&a.enable(25),b.batchingColor&&a.enable(20),b.gradientMap&&a.enable(21),b.packedNormalMap&&a.enable(22),b.vertexNormals&&a.enable(23),x.push(a.mask),a.disableAll(),b.fog&&a.enable(0),b.useFog&&a.enable(1),b.flatShading&&a.enable(2),b.logarithmicDepthBuffer&&a.enable(3),b.reversedDepthBuffer&&a.enable(4),b.skinning&&a.enable(5),b.morphTargets&&a.enable(6),b.morphNormals&&a.enable(7),b.morphColors&&a.enable(8),b.premultipliedAlpha&&a.enable(9),b.shadowMapEnabled&&a.enable(10),b.doubleSided&&a.enable(11),b.flipSided&&a.enable(12),b.useDepthPacking&&a.enable(13),b.dithering&&a.enable(14),b.transmission&&a.enable(15),b.sheen&&a.enable(16),b.opaque&&a.enable(17),b.pointsUvs&&a.enable(18),b.decodeVideoTexture&&a.enable(19),b.decodeVideoTextureEmissive&&a.enable(20),b.alphaToCoverage&&a.enable(21),b.numLightProbeGrids>0&&a.enable(22),b.hasPositionAttribute&&a.enable(23),x.push(a.mask)}function S(x){const b=u[x.type];let A;if(b){const R=ui[b];A=rm.clone(R.uniforms)}else A=x.uniforms;return A}function M(x,b){let A=d.get(b);return A!==void 0?++A.usedTimes:(A=new RS(i,b,x,s),c.push(A),d.set(b,A)),A}function _(x){if(--x.usedTimes===0){const b=c.indexOf(x);c[b]=c[c.length-1],c.pop(),d.delete(x.cacheKey),x.destroy()}}function E(x){o.remove(x)}function y(){o.dispose()}return{getParameters:v,getProgramCacheKey:f,getUniforms:S,acquireProgram:M,releaseProgram:_,releaseShaderCache:E,programs:c,dispose:y}}function NS(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,l){i.get(a)[o]=l}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function BS(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function wd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Td(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function a(u){let h=0;return u.isInstancedMesh&&(h+=2),u.isSkinnedMesh&&(h+=1),h}function o(u,h,v,f,m,g){let S=i[e];return S===void 0?(S={id:u.id,object:u,geometry:h,material:v,materialVariant:a(u),groupOrder:f,renderOrder:u.renderOrder,z:m,group:g},i[e]=S):(S.id=u.id,S.object=u,S.geometry=h,S.material=v,S.materialVariant=a(u),S.groupOrder=f,S.renderOrder=u.renderOrder,S.z=m,S.group=g),e++,S}function l(u,h,v,f,m,g,S){S.reversedDepth===!0&&(m=-m);const M=o(u,h,v,f,m,g);v.transmission>0?n.push(M):v.transparent===!0?s.push(M):t.push(M)}function c(u,h,v,f,m,g){const S=o(u,h,v,f,m,g);v.transmission>0?n.unshift(S):v.transparent===!0?s.unshift(S):t.unshift(S)}function d(u,h){t.length>1&&t.sort(u||BS),n.length>1&&n.sort(h||wd),s.length>1&&s.sort(h||wd)}function p(){for(let u=e,h=i.length;u<h;u++){const v=i[u];if(v.id===null)break;v.id=null,v.object=null,v.geometry=null,v.material=null,v.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:l,unshift:c,finish:p,sort:d}}function FS(){let i=new WeakMap;function e(n,s){const r=i.get(n);let a;return r===void 0?(a=new Td,i.set(n,[a])):s>=r.length?(a=new Td,r.push(a)):a=r[s],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function OS(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new z,color:new et};break;case"SpotLight":t={position:new z,direction:new z,color:new et,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new z,color:new et,distance:0,decay:0};break;case"HemisphereLight":t={direction:new z,skyColor:new et,groundColor:new et};break;case"RectAreaLight":t={color:new et,position:new z,halfWidth:new z,halfHeight:new z};break}return i[e.id]=t,t}}}function HS(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new it};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new it};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new it,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let GS=0;function zS(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function VS(i){const e=new OS,t=HS(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new z);const s=new z,r=new yt,a=new yt;function o(c){let d=0,p=0,u=0;for(let O=0;O<9;O++)n.probe[O].set(0,0,0);let h=0,v=0,f=0,m=0,g=0,S=0,M=0,_=0,E=0,y=0,x=0,b=0,A=0,R=0;c.sort(zS);for(let O=0,X=c.length;O<X;O++){const k=c[O],P=k.color,F=k.intensity,G=k.distance;let se=null;if(k.shadow&&k.shadow.map&&(k.shadow.map.texture.format===ss?se=k.shadow.map.texture:se=k.shadow.map.depthTexture||k.shadow.map.texture),k.isAmbientLight)d+=P.r*F,p+=P.g*F,u+=P.b*F;else if(k.isLightProbe){for(let Y=0;Y<9;Y++)n.probe[Y].addScaledVector(k.sh.coefficients[Y],F);R++}else if(k.isSunLight){const Y=e.get(k);if(Y.color.copy(k.color).multiplyScalar(k.intensity),k.castShadow){const ae=k.shadow,le=t.get(k);le.shadowIntensity=ae.intensity,le.shadowBias=ae.bias,le.shadowNormalBias=ae.normalBias,le.shadowRadius=ae.radius,le.shadowMapSize.copy(ae.mapSize).multiply(ae.getFrameExtents()),n.sunShadow[v]=le,n.sunShadowMap[v]=se;const ce=ae.getViewportCount();for(let xe=0;xe<ce;xe++)n.sunShadowMatrix[f+xe]=ae.getMatrix(xe),n.sunShadowCascade[f+xe]=ae._cascadeData[xe];f+=ce,v++}n.sun[h]=Y,h++}else if(k.isDirectionalLight){const Y=e.get(k);if(Y.color.copy(k.color).multiplyScalar(k.intensity),k.castShadow){const ae=k.shadow,le=t.get(k);le.shadowIntensity=ae.intensity,le.shadowBias=ae.bias,le.shadowNormalBias=ae.normalBias,le.shadowRadius=ae.radius,le.shadowMapSize=ae.mapSize,n.directionalShadow[m]=le,n.directionalShadowMap[m]=se,n.directionalShadowMatrix[m]=k.shadow.matrix,E++}n.directional[m]=Y,m++}else if(k.isSpotLight){const Y=e.get(k);Y.position.setFromMatrixPosition(k.matrixWorld),Y.color.copy(P).multiplyScalar(F),Y.distance=G,Y.coneCos=Math.cos(k.angle),Y.penumbraCos=Math.cos(k.angle*(1-k.penumbra)),Y.decay=k.decay,n.spot[S]=Y;const ae=k.shadow;if(k.map&&(n.spotLightMap[b]=k.map,b++,ae.updateMatrices(k),k.castShadow&&A++),n.spotLightMatrix[S]=ae.matrix,k.castShadow){const le=t.get(k);le.shadowIntensity=ae.intensity,le.shadowBias=ae.bias,le.shadowNormalBias=ae.normalBias,le.shadowRadius=ae.radius,le.shadowMapSize=ae.mapSize,n.spotShadow[S]=le,n.spotShadowMap[S]=se,x++}S++}else if(k.isRectAreaLight){const Y=e.get(k);Y.color.copy(P).multiplyScalar(F),Y.halfWidth.set(k.width*.5,0,0),Y.halfHeight.set(0,k.height*.5,0),n.rectArea[M]=Y,M++}else if(k.isPointLight){const Y=e.get(k);if(Y.color.copy(k.color).multiplyScalar(k.intensity),Y.distance=k.distance,Y.decay=k.decay,k.castShadow){const ae=k.shadow,le=t.get(k);le.shadowIntensity=ae.intensity,le.shadowBias=ae.bias,le.shadowNormalBias=ae.normalBias,le.shadowRadius=ae.radius,le.shadowMapSize=ae.mapSize,le.shadowCameraNear=ae.camera.near,le.shadowCameraFar=ae.camera.far,n.pointShadow[g]=le,n.pointShadowMap[g]=se,n.pointShadowMatrix[g]=k.shadow.matrix,y++}n.point[g]=Y,g++}else if(k.isHemisphereLight){const Y=e.get(k);Y.skyColor.copy(k.color).multiplyScalar(F),Y.groundColor.copy(k.groundColor).multiplyScalar(F),n.hemi[_]=Y,_++}}M>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Ce.LTC_FLOAT_1,n.rectAreaLTC2=Ce.LTC_FLOAT_2):(n.rectAreaLTC1=Ce.LTC_HALF_1,n.rectAreaLTC2=Ce.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=p,n.ambient[2]=u;const D=n.hash;(D.sunLength!==h||D.directionalLength!==m||D.pointLength!==g||D.spotLength!==S||D.rectAreaLength!==M||D.hemiLength!==_||D.numSunShadows!==v||D.numDirectionalShadows!==E||D.numPointShadows!==y||D.numSpotShadows!==x||D.numSpotMaps!==b||D.numLightProbes!==R)&&(n.sun.length=h,n.directional.length=m,n.spot.length=S,n.rectArea.length=M,n.point.length=g,n.hemi.length=_,n.sunShadow.length=v,n.sunShadowMap.length=v,n.sunShadowMatrix.length=f,n.sunShadowCascade.length=f,n.directionalShadow.length=E,n.directionalShadowMap.length=E,n.directionalShadowMatrix.length=E,n.pointShadow.length=y,n.pointShadowMap.length=y,n.pointShadowMatrix.length=y,n.spotShadow.length=x,n.spotShadowMap.length=x,n.spotLightMatrix.length=x+b-A,n.spotLightMap.length=b,n.numSpotLightShadowsWithMaps=A,n.numLightProbes=R,D.sunLength=h,D.directionalLength=m,D.pointLength=g,D.spotLength=S,D.rectAreaLength=M,D.hemiLength=_,D.numSunShadows=v,D.numDirectionalShadows=E,D.numPointShadows=y,D.numSpotShadows=x,D.numSpotMaps=b,D.numLightProbes=R,n.version=GS++)}function l(c,d){let p=0,u=0,h=0,v=0,f=0,m=0;const g=d.matrixWorldInverse;for(let S=0,M=c.length;S<M;S++){const _=c[S];if(_.isSunLight){const E=n.sun[p];E.direction.setFromMatrixPosition(_.matrixWorld),E.direction.transformDirection(g),p++}else if(_.isDirectionalLight){const E=n.directional[u];E.direction.setFromMatrixPosition(_.matrixWorld),s.setFromMatrixPosition(_.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(g),u++}else if(_.isSpotLight){const E=n.spot[v];E.position.setFromMatrixPosition(_.matrixWorld),E.position.applyMatrix4(g),E.direction.setFromMatrixPosition(_.matrixWorld),s.setFromMatrixPosition(_.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(g),v++}else if(_.isRectAreaLight){const E=n.rectArea[f];E.position.setFromMatrixPosition(_.matrixWorld),E.position.applyMatrix4(g),a.identity(),r.copy(_.matrixWorld),r.premultiply(g),a.extractRotation(r),E.halfWidth.set(_.width*.5,0,0),E.halfHeight.set(0,_.height*.5,0),E.halfWidth.applyMatrix4(a),E.halfHeight.applyMatrix4(a),f++}else if(_.isPointLight){const E=n.point[h];E.position.setFromMatrixPosition(_.matrixWorld),E.position.applyMatrix4(g),h++}else if(_.isHemisphereLight){const E=n.hemi[m];E.direction.setFromMatrixPosition(_.matrixWorld),E.direction.transformDirection(g),m++}}}return{setup:o,setupView:l,state:n}}function Cd(i){const e=new VS(i),t=[],n=[],s=[];function r(p){d.camera=p,t.length=0,n.length=0,s.length=0}function a(p){p.isLightProbeGrid?s.push(p):t.push(p)}function o(p){n.push(p)}function l(){e.setup(t),s.sort((p,u)=>p.priority-u.priority||p.id-u.id)}function c(p){e.setupView(t,p)}const d={lightsArray:t,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:d,setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function WS(i){let e=new WeakMap;function t(s,r=0){const a=e.get(s);let o;return a===void 0?(o=new Cd(i),e.set(s,[o])):r>=a.length?(o=new Cd(i),a.push(o)):o=a[r],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const $S=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,qS=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,XS=[new z(1,0,0),new z(-1,0,0),new z(0,1,0),new z(0,-1,0),new z(0,0,1),new z(0,0,-1)],YS=[new z(0,-1,0),new z(0,-1,0),new z(0,0,1),new z(0,0,-1),new z(0,-1,0),new z(0,-1,0)],Ad=new yt,Ys=new z,Mo=new z;function KS(i,e,t){let n=new hr;const s=new it,r=new it,a=new Gt,o=new cm,l=new dm,c={},d=t.maxTextureSize,p={[Li]:In,[In]:Li,[Hn]:Hn},u=new rs({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new it},radius:{value:4}},vertexShader:$S,fragmentShader:qS}),h=u.clone();h.defines.HORIZONTAL_PASS=1;const v=new yn;v.setAttribute("position",new Gi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const f=new ct(v,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ea;let g=this.type;this.render=function(y,x,b){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||y.length===0)return;this.type===Lu&&(qe("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=ea);const A=i.getRenderTarget(),R=i.getActiveCubeFace(),D=i.getActiveMipmapLevel(),O=i.state;O.setBlending(As),O.buffers.depth.getReversed()===!0?O.buffers.color.setClear(0,0,0,0):O.buffers.color.setClear(1,1,1,1),O.buffers.depth.setTest(!0),O.setScissorTest(!1);const X=g!==this.type;X&&x.traverse(function(k){k.material&&(Array.isArray(k.material)?k.material.forEach(P=>P.needsUpdate=!0):k.material.needsUpdate=!0)});for(let k=0,P=y.length;k<P;k++){const F=y[k],G=F.shadow;if(G===void 0){qe("WebGLShadowMap:",F,"has no shadow.");continue}if(G.autoUpdate===!1&&G.needsUpdate===!1)continue;s.copy(G.mapSize);const se=G.getFrameExtents();s.multiply(se),r.copy(G.mapSize),(s.x>d||s.y>d)&&(s.x>d&&(r.x=Math.floor(d/se.x),s.x=r.x*se.x,G.mapSize.x=r.x),s.y>d&&(r.y=Math.floor(d/se.y),s.y=r.y*se.y,G.mapSize.y=r.y));const Y=i.state.buffers.depth.getReversed();if(G.camera._reversedDepth=Y,G.map===null||X===!0){if(G.map!==null&&(G.map.depthTexture!==null&&(G.map.depthTexture.dispose(),G.map.depthTexture=null),G.map.dispose()),this.type===js){if(F.isPointLight){qe("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}G.map=new fi(s.x,s.y,{format:ss,type:mi,minFilter:Pn,magFilter:Pn,generateMipmaps:!1}),G.map.texture.name=F.name+".shadowMap",G.map.depthTexture=new Ds(s.x,s.y,ri),G.map.depthTexture.name=F.name+".shadowMapDepth",G.map.depthTexture.format=zi,G.map.depthTexture.compareFunction=null,G.map.depthTexture.minFilter=cn,G.map.depthTexture.magFilter=cn}else F.isPointLight?(G.map=new jl(s.x),G.map.depthTexture=new sh(s.x,pi)):(G.map=new fi(s.x,s.y),G.map.depthTexture=new Ds(s.x,s.y,pi)),G.map.depthTexture.name=F.name+".shadowMap",G.map.depthTexture.format=zi,this.type===ea?(G.map.depthTexture.compareFunction=Y?Ku:Yu,G.map.depthTexture.minFilter=Pn,G.map.depthTexture.magFilter=Pn):(G.map.depthTexture.compareFunction=null,G.map.depthTexture.minFilter=cn,G.map.depthTexture.magFilter=cn);G.camera.updateProjectionMatrix()}G.map.isWebGLCubeRenderTarget!==!0&&(G.map.width!==s.x||G.map.height!==s.y)&&G.map.setSize(s.x,s.y);const ae=G.map.isWebGLCubeRenderTarget?6:G.getViewportCount();F.isPointLight!==!0&&G.updateMatrices(F,b);const le=(G.camera.layers.mask&4294967294)!==0?G.camera.layers:b.layers;for(let ce=0;ce<ae;ce++){const xe=G.getCamera(ce);if(F.isPointLight){const Z=G.camera,be=G.matrix,we=F.distance||Z.far;we!==Z.far&&(Z.far=we,Z.updateProjectionMatrix()),Ys.setFromMatrixPosition(F.matrixWorld),Z.position.copy(Ys),Mo.copy(Z.position),Mo.add(XS[ce]),Z.up.copy(YS[ce]),Z.lookAt(Mo),Z.updateMatrixWorld(),be.makeTranslation(-Ys.x,-Ys.y,-Ys.z),Ad.multiplyMatrices(Z.projectionMatrix,Z.matrixWorldInverse),G._frustum.setFromProjectionMatrix(Ad,Z.coordinateSystem,Z.reversedDepth)}if(G.map.isWebGLCubeRenderTarget)i.setRenderTarget(G.map,ce),i.clear();else{ce===0&&(i.setRenderTarget(G.map),i.clear());const Z=G.getViewport(ce);a.set(r.x*Z.x,r.y*Z.y,r.x*Z.z,r.y*Z.w),O.viewport(a)}n=G.getFrustum(ce),_(x,b,xe,F,le,this.type)}G.isPointLightShadow!==!0&&this.type===js&&S(G,b),G.needsUpdate=!1}g=this.type,m.needsUpdate=!1,i.setRenderTarget(A,R,D)};function S(y,x){const b=e.update(f);u.defines.VSM_SAMPLES!==y.blurSamples&&(u.defines.VSM_SAMPLES=y.blurSamples,h.defines.VSM_SAMPLES=y.blurSamples,u.needsUpdate=!0,h.needsUpdate=!0),y.mapPass===null?y.mapPass=new fi(s.x,s.y,{format:ss,type:mi}):(y.mapPass.width!==y.map.width||y.mapPass.height!==y.map.height)&&y.mapPass.setSize(y.map.width,y.map.height),u.uniforms.shadow_pass.value=y.map.depthTexture,u.uniforms.resolution.value.set(y.map.width,y.map.height),u.uniforms.radius.value=y.radius,i.setRenderTarget(y.mapPass),i.clear(),i.renderBufferDirect(x,null,b,u,f,null),h.uniforms.shadow_pass.value=y.mapPass.texture,h.uniforms.resolution.value.set(y.map.width,y.map.height),h.uniforms.radius.value=y.radius,i.setRenderTarget(y.map),i.clear(),i.renderBufferDirect(x,null,b,h,f,null)}function M(y,x,b,A){let R=null;const D=b.isPointLight===!0?y.customDistanceMaterial:y.customDepthMaterial;if(D!==void 0)R=D;else if(R=b.isPointLight===!0?l:o,i.localClippingEnabled&&x.clipShadows===!0&&Array.isArray(x.clippingPlanes)&&x.clippingPlanes.length!==0||x.displacementMap&&x.displacementScale!==0||x.alphaMap&&x.alphaTest>0||x.map&&x.alphaTest>0||x.alphaToCoverage===!0){const O=R.uuid,X=x.uuid;let k=c[O];k===void 0&&(k={},c[O]=k);let P=k[X];P===void 0&&(P=R.clone(),k[X]=P,x.addEventListener("dispose",E)),R=P}if(R.visible=x.visible,R.wireframe=x.wireframe,A===js?R.side=x.shadowSide!==null?x.shadowSide:x.side:R.side=x.shadowSide!==null?x.shadowSide:p[x.side],R.alphaMap=x.alphaMap,R.alphaTest=x.alphaToCoverage===!0?.5:x.alphaTest,R.map=x.map,R.clipShadows=x.clipShadows,R.clippingPlanes=x.clippingPlanes,R.clipIntersection=x.clipIntersection,R.displacementMap=x.displacementMap,R.displacementScale=x.displacementScale,R.displacementBias=x.displacementBias,R.wireframeLinewidth=x.wireframeLinewidth,R.linewidth=x.linewidth,b.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const O=i.properties.get(R);O.light=b}return R}function _(y,x,b,A,R,D){if(y.visible===!1)return;if(y.layers.test(R)&&(y.isMesh||y.isLine||y.isPoints)&&(y.castShadow||y.receiveShadow&&D===js)&&(!y.frustumCulled||y.intersectsFrustum(n))){y.modelViewMatrix.multiplyMatrices(b.matrixWorldInverse,y.matrixWorld);const k=e.update(y),P=y.material;if(Array.isArray(P)){const F=k.groups;for(let G=0,se=F.length;G<se;G++){const Y=F[G],ae=P[Y.materialIndex];if(ae&&ae.visible){const le=M(y,ae,A,D);y.onBeforeShadow(i,y,x,b,k,le,Y),i.renderBufferDirect(b,null,k,le,y,Y),y.onAfterShadow(i,y,x,b,k,le,Y)}}}else if(P.visible){const F=M(y,P,A,D);y.onBeforeShadow(i,y,x,b,k,F,null),i.renderBufferDirect(b,null,k,F,y,null),y.onAfterShadow(i,y,x,b,k,F,null)}}const X=y.children;for(let k=0,P=X.length;k<P;k++)_(X[k],x,b,A,R,D)}function E(y){y.target.removeEventListener("dispose",E);for(const b in c){const A=c[b],R=y.target.uuid;R in A&&(A[R].dispose(),delete A[R])}}}function ZS(i,e){function t(){let I=!1;const re=new Gt;let ee=null;const ve=new Gt(0,0,0,0);return{setMask:function(fe){ee!==fe&&!I&&(i.colorMask(fe,fe,fe,fe),ee=fe)},setLocked:function(fe){I=fe},setClear:function(fe,me,Oe,tt,ue){ue===!0&&(fe*=tt,me*=tt,Oe*=tt),re.set(fe,me,Oe,tt),ve.equals(re)===!1&&(i.clearColor(fe,me,Oe,tt),ve.copy(re))},reset:function(){I=!1,ee=null,ve.set(-1,0,0,0)}}}function n(){let I=!1,re=!1,ee=null,ve=null,fe=null;return{setReversed:function(me){if(re!==me){const Oe=e.get("EXT_clip_control");me?Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.ZERO_TO_ONE_EXT):Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.NEGATIVE_ONE_TO_ONE_EXT),re=me;const tt=fe;fe=null,this.setClear(tt)}},getReversed:function(){return re},setTest:function(me){me?Ee(i.DEPTH_TEST):Je(i.DEPTH_TEST)},setMask:function(me){ee!==me&&!I&&(i.depthMask(me),ee=me)},setFunc:function(me){if(re&&(me=Ap[me]),ve!==me){switch(me){case Io:i.depthFunc(i.NEVER);break;case Uo:i.depthFunc(i.ALWAYS);break;case No:i.depthFunc(i.LESS);break;case or:i.depthFunc(i.LEQUAL);break;case Bo:i.depthFunc(i.EQUAL);break;case Fo:i.depthFunc(i.GEQUAL);break;case Oo:i.depthFunc(i.GREATER);break;case Ho:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ve=me}},setLocked:function(me){I=me},setClear:function(me){fe!==me&&(fe=me,re&&(me=1-me),i.clearDepth(me))},reset:function(){I=!1,ee=null,ve=null,fe=null,re=!1}}}function s(){let I=!1,re=null,ee=null,ve=null,fe=null,me=null,Oe=null,tt=null,ue=null;return{setTest:function(Ge){I||(Ge?Ee(i.STENCIL_TEST):Je(i.STENCIL_TEST))},setMask:function(Ge){re!==Ge&&!I&&(i.stencilMask(Ge),re=Ge)},setFunc:function(Ge,je,Te){(ee!==Ge||ve!==je||fe!==Te)&&(i.stencilFunc(Ge,je,Te),ee=Ge,ve=je,fe=Te)},setOp:function(Ge,je,Te){(me!==Ge||Oe!==je||tt!==Te)&&(i.stencilOp(Ge,je,Te),me=Ge,Oe=je,tt=Te)},setLocked:function(Ge){I=Ge},setClear:function(Ge){ue!==Ge&&(i.clearStencil(Ge),ue=Ge)},reset:function(){I=!1,re=null,ee=null,ve=null,fe=null,me=null,Oe=null,tt=null,ue=null}}}const r=new t,a=new n,o=new s;let l={};const c=new WeakMap;let d={},p={},u={},h=new WeakMap,v=[],f=null,m=!1,g=null,S=null,M=null,_=null,E=null,y=null,x=null,b=new et(0,0,0),A=0,R=!1,D=null,O=null,X=null,k=null,P=null;const F=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let G=!1,se=0;const Y=i.getParameter(i.VERSION);Y.indexOf("WebGL")!==-1?(se=parseFloat(/^WebGL (\d)/.exec(Y)[1]),G=se>=1):Y.indexOf("OpenGL ES")!==-1&&(se=parseFloat(/^OpenGL ES (\d)/.exec(Y)[1]),G=se>=2);let ae=null,le={};const ce=i.getParameter(i.SCISSOR_BOX),xe=i.getParameter(i.VIEWPORT),Z=new Gt().fromArray(ce),be=new Gt().fromArray(xe);function we(I,re,ee,ve){const fe=new Uint8Array(4),me=i.createTexture();i.bindTexture(I,me),i.texParameteri(I,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(I,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Oe=0;Oe<ee;Oe++)I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY?i.texImage3D(re,0,i.RGBA,1,1,ve,0,i.RGBA,i.UNSIGNED_BYTE,fe):i.texImage2D(re+Oe,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,fe);return me}const Fe={};Fe[i.TEXTURE_2D]=we(i.TEXTURE_2D,i.TEXTURE_2D,1),Fe[i.TEXTURE_CUBE_MAP]=we(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Fe[i.TEXTURE_2D_ARRAY]=we(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Fe[i.TEXTURE_3D]=we(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),Ee(i.DEPTH_TEST),a.setFunc(or),Cn(!1),Ut(_c),Ee(i.CULL_FACE),un(As);function Ee(I){d[I]!==!0&&(i.enable(I),d[I]=!0)}function Je(I){d[I]!==!1&&(i.disable(I),d[I]=!1)}function Xt(I,re){return u[I]!==re?(i.bindFramebuffer(I,re),u[I]=re,I===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=re),I===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=re),!0):!1}function $e(I,re){let ee=v,ve=!1;if(I){ee=h.get(re),ee===void 0&&(ee=[],h.set(re,ee));const fe=I.textures;if(ee.length!==fe.length||ee[0]!==i.COLOR_ATTACHMENT0){for(let me=0,Oe=fe.length;me<Oe;me++)ee[me]=i.COLOR_ATTACHMENT0+me;ee.length=fe.length,ve=!0}}else ee[0]!==i.BACK&&(ee[0]=i.BACK,ve=!0);ve&&i.drawBuffers(ee)}function vt(I){return f!==I?(i.useProgram(I),f=I,!0):!1}const bt={[bs]:i.FUNC_ADD,[Jf]:i.FUNC_SUBTRACT,[Qf]:i.FUNC_REVERSE_SUBTRACT};bt[jf]=i.MIN,bt[ep]=i.MAX;const rt={[tp]:i.ZERO,[np]:i.ONE,[ip]:i.SRC_COLOR,[Pu]:i.SRC_ALPHA,[cp]:i.SRC_ALPHA_SATURATE,[op]:i.DST_COLOR,[rp]:i.DST_ALPHA,[sp]:i.ONE_MINUS_SRC_COLOR,[Du]:i.ONE_MINUS_SRC_ALPHA,[lp]:i.ONE_MINUS_DST_COLOR,[ap]:i.ONE_MINUS_DST_ALPHA,[dp]:i.CONSTANT_COLOR,[up]:i.ONE_MINUS_CONSTANT_COLOR,[hp]:i.CONSTANT_ALPHA,[fp]:i.ONE_MINUS_CONSTANT_ALPHA};function un(I,re,ee,ve,fe,me,Oe,tt,ue,Ge){if(I===As){m===!0&&(Je(i.BLEND),m=!1);return}if(m===!1&&(Ee(i.BLEND),m=!0),I!==Zf){if(I!==g||Ge!==R){if((S!==bs||E!==bs)&&(i.blendEquation(i.FUNC_ADD),S=bs,E=bs),Ge)switch(I){case ir:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case yc:i.blendFunc(i.ONE,i.ONE);break;case Mc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case bc:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:pt("WebGLState: Invalid blending: ",I);break}else switch(I){case ir:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case yc:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Mc:pt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case bc:pt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:pt("WebGLState: Invalid blending: ",I);break}M=null,_=null,y=null,x=null,b.set(0,0,0),A=0,g=I,R=Ge}return}fe=fe||re,me=me||ee,Oe=Oe||ve,(re!==S||fe!==E)&&(i.blendEquationSeparate(bt[re],bt[fe]),S=re,E=fe),(ee!==M||ve!==_||me!==y||Oe!==x)&&(i.blendFuncSeparate(rt[ee],rt[ve],rt[me],rt[Oe]),M=ee,_=ve,y=me,x=Oe),(tt.equals(b)===!1||ue!==A)&&(i.blendColor(tt.r,tt.g,tt.b,ue),b.copy(tt),A=ue),g=I,R=!1}function Jt(I,re){I.side===Hn?Je(i.CULL_FACE):Ee(i.CULL_FACE);let ee=I.side===In;re&&(ee=!ee),Cn(ee),I.blending===ir&&I.transparent===!1?un(As):un(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),a.setFunc(I.depthFunc),a.setTest(I.depthTest),a.setMask(I.depthWrite),r.setMask(I.colorWrite);const ve=I.stencilWrite;o.setTest(ve),ve&&(o.setMask(I.stencilWriteMask),o.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),o.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),sn(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?Ee(i.SAMPLE_ALPHA_TO_COVERAGE):Je(i.SAMPLE_ALPHA_TO_COVERAGE)}function Cn(I){D!==I&&(I?i.frontFace(i.CW):i.frontFace(i.CCW),D=I)}function Ut(I){I!==Yf?(Ee(i.CULL_FACE),I!==O&&(I===_c?i.cullFace(i.BACK):I===Kf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Je(i.CULL_FACE),O=I}function oi(I){I!==X&&(G&&i.lineWidth(I),X=I)}function sn(I,re,ee){I?(Ee(i.POLYGON_OFFSET_FILL),(k!==re||P!==ee)&&(k=re,P=ee,a.getReversed()&&(re=-re,ee=-ee),i.polygonOffset(re,ee))):Je(i.POLYGON_OFFSET_FILL)}function zn(I){I?Ee(i.SCISSOR_TEST):Je(i.SCISSOR_TEST)}function Vn(I){I===void 0&&(I=i.TEXTURE0+F-1),ae!==I&&(i.activeTexture(I),ae=I)}function Wn(I,re,ee){ee===void 0&&(ae===null?ee=i.TEXTURE0+F-1:ee=ae);let ve=le[ee];ve===void 0&&(ve={type:void 0,texture:void 0},le[ee]=ve),(ve.type!==I||ve.texture!==re)&&(ae!==ee&&(i.activeTexture(ee),ae=ee),i.bindTexture(I,re||Fe[I]),ve.type=I,ve.texture=re)}function H(){const I=le[ae];I!==void 0&&I.type!==void 0&&(i.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function $n(){try{i.compressedTexImage2D(...arguments)}catch(I){pt("WebGLState:",I)}}function At(){try{i.compressedTexImage3D(...arguments)}catch(I){pt("WebGLState:",I)}}function Rt(){try{i.texSubImage2D(...arguments)}catch(I){pt("WebGLState:",I)}}function ke(){try{i.texSubImage3D(...arguments)}catch(I){pt("WebGLState:",I)}}function Qt(){try{i.compressedTexSubImage2D(...arguments)}catch(I){pt("WebGLState:",I)}}function ze(){try{i.compressedTexSubImage3D(...arguments)}catch(I){pt("WebGLState:",I)}}function Xe(){try{i.texStorage2D(...arguments)}catch(I){pt("WebGLState:",I)}}function C(){try{i.texStorage3D(...arguments)}catch(I){pt("WebGLState:",I)}}function w(){try{i.texImage2D(...arguments)}catch(I){pt("WebGLState:",I)}}function $(){try{i.texImage3D(...arguments)}catch(I){pt("WebGLState:",I)}}function de(I){return p[I]!==void 0?p[I]:i.getParameter(I)}function oe(I,re){p[I]!==re&&(i.pixelStorei(I,re),p[I]=re)}function pe(I){Z.equals(I)===!1&&(i.scissor(I.x,I.y,I.z,I.w),Z.copy(I))}function ye(I){be.equals(I)===!1&&(i.viewport(I.x,I.y,I.z,I.w),be.copy(I))}function te(I,re){let ee=c.get(re);ee===void 0&&(ee=new WeakMap,c.set(re,ee));let ve=ee.get(I);ve===void 0&&(ve=i.getUniformBlockIndex(re,I.name),i.uniformBlockBinding(re,ve,ve),ee.set(I,ve))}function ie(I,re,ee){const fe=c.get(re).get(I);l[fe]!==ee&&(i.bindBufferBase(i.UNIFORM_BUFFER,fe,ee),l[fe]=ee)}function ge(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),d={},p={},ae=null,le={},u={},l={},h=new WeakMap,v=[],f=null,m=!1,g=null,S=null,M=null,_=null,E=null,y=null,x=null,b=new et(0,0,0),A=0,R=!1,D=null,O=null,X=null,k=null,P=null,Z.set(0,0,i.canvas.width,i.canvas.height),be.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:Ee,disable:Je,bindFramebuffer:Xt,drawBuffers:$e,useProgram:vt,setBlending:un,setMaterial:Jt,setFlipSided:Cn,setCullFace:Ut,setLineWidth:oi,setPolygonOffset:sn,setScissorTest:zn,activeTexture:Vn,bindTexture:Wn,unbindTexture:H,compressedTexImage2D:$n,compressedTexImage3D:At,texImage2D:w,texImage3D:$,pixelStorei:oe,getParameter:de,updateUBOMapping:te,uniformBlockBinding:ie,texStorage2D:Xe,texStorage3D:C,texSubImage2D:Rt,texSubImage3D:ke,compressedTexSubImage2D:Qt,compressedTexSubImage3D:ze,scissor:pe,viewport:ye,reset:ge}}function JS(i,e,t,n,s,r,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new it,d=new WeakMap,p=new Set;let u;const h=new WeakMap,v=new Set,f=new FinalizationRegistry(C=>v.delete(C));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(C,w){return m?new OffscreenCanvas(C,w):ya("canvas")}function S(C,w,$){let de=1;const oe=Xe(C);if((oe.width>$||oe.height>$)&&(de=$/Math.max(oe.width,oe.height)),de<1)if(typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&C instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&C instanceof ImageBitmap||typeof VideoFrame<"u"&&C instanceof VideoFrame){const pe=Math.floor(de*oe.width),ye=Math.floor(de*oe.height);u===void 0&&(u=g(pe,ye));const te=w?g(pe,ye):u;return te.width=pe,te.height=ye,te.getContext("2d").drawImage(C,0,0,pe,ye),qe("WebGLRenderer: Texture has been resized from ("+oe.width+"x"+oe.height+") to ("+pe+"x"+ye+")."),te}else return"data"in C&&qe("WebGLRenderer: Image in DataTexture is too big ("+oe.width+"x"+oe.height+")."),C;return C}function M(C){return C.generateMipmaps}function _(C){i.generateMipmap(C)}function E(C){return C.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:C.isWebGL3DRenderTarget?i.TEXTURE_3D:C.isWebGLArrayRenderTarget||C.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function y(C,w,$,de,oe,pe=!1){if(C!==null){if(i[C]!==void 0)return i[C];qe("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+C+"'")}let ye;de&&(ye=e.get("EXT_texture_norm16"),ye||qe("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let te=w;if(w===i.RED&&($===i.FLOAT&&(te=i.R32F),$===i.HALF_FLOAT&&(te=i.R16F),$===i.UNSIGNED_BYTE&&(te=i.R8),$===i.UNSIGNED_SHORT&&ye&&(te=ye.R16_EXT),$===i.SHORT&&ye&&(te=ye.R16_SNORM_EXT)),w===i.RED_INTEGER&&($===i.UNSIGNED_BYTE&&(te=i.R8UI),$===i.UNSIGNED_SHORT&&(te=i.R16UI),$===i.UNSIGNED_INT&&(te=i.R32UI),$===i.BYTE&&(te=i.R8I),$===i.SHORT&&(te=i.R16I),$===i.INT&&(te=i.R32I)),w===i.RG&&($===i.FLOAT&&(te=i.RG32F),$===i.HALF_FLOAT&&(te=i.RG16F),$===i.UNSIGNED_BYTE&&(te=i.RG8),$===i.UNSIGNED_SHORT&&ye&&(te=ye.RG16_EXT),$===i.SHORT&&ye&&(te=ye.RG16_SNORM_EXT)),w===i.RG_INTEGER&&($===i.UNSIGNED_BYTE&&(te=i.RG8UI),$===i.UNSIGNED_SHORT&&(te=i.RG16UI),$===i.UNSIGNED_INT&&(te=i.RG32UI),$===i.BYTE&&(te=i.RG8I),$===i.SHORT&&(te=i.RG16I),$===i.INT&&(te=i.RG32I)),w===i.RGB_INTEGER&&($===i.UNSIGNED_BYTE&&(te=i.RGB8UI),$===i.UNSIGNED_SHORT&&(te=i.RGB16UI),$===i.UNSIGNED_INT&&(te=i.RGB32UI),$===i.BYTE&&(te=i.RGB8I),$===i.SHORT&&(te=i.RGB16I),$===i.INT&&(te=i.RGB32I)),w===i.RGBA_INTEGER&&($===i.UNSIGNED_BYTE&&(te=i.RGBA8UI),$===i.UNSIGNED_SHORT&&(te=i.RGBA16UI),$===i.UNSIGNED_INT&&(te=i.RGBA32UI),$===i.BYTE&&(te=i.RGBA8I),$===i.SHORT&&(te=i.RGBA16I),$===i.INT&&(te=i.RGBA32I)),w===i.RGB&&($===i.UNSIGNED_SHORT&&ye&&(te=ye.RGB16_EXT),$===i.SHORT&&ye&&(te=ye.RGB16_SNORM_EXT),$===i.UNSIGNED_INT_5_9_9_9_REV&&(te=i.RGB9_E5),$===i.UNSIGNED_INT_10F_11F_11F_REV&&(te=i.R11F_G11F_B10F)),w===i.RGBA){const ie=pe?_a:dt.getTransfer(oe);$===i.FLOAT&&(te=i.RGBA32F),$===i.HALF_FLOAT&&(te=i.RGBA16F),$===i.UNSIGNED_BYTE&&(te=ie===xt?i.SRGB8_ALPHA8:i.RGBA8),$===i.UNSIGNED_SHORT&&ye&&(te=ye.RGBA16_EXT),$===i.SHORT&&ye&&(te=ye.RGBA16_SNORM_EXT),$===i.UNSIGNED_SHORT_4_4_4_4&&(te=i.RGBA4),$===i.UNSIGNED_SHORT_5_5_5_1&&(te=i.RGB5_A1)}return(te===i.R16F||te===i.R32F||te===i.RG16F||te===i.RG32F||te===i.RGBA16F||te===i.RGBA32F)&&e.get("EXT_color_buffer_float"),te}function x(C,w){let $;return C?w===null||w===pi||w===Ps?$=i.DEPTH24_STENCIL8:w===ri?$=i.DEPTH32F_STENCIL8:w===dr&&($=i.DEPTH24_STENCIL8,qe("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):w===null||w===pi||w===Ps?$=i.DEPTH_COMPONENT24:w===ri?$=i.DEPTH_COMPONENT32F:w===dr&&($=i.DEPTH_COMPONENT16),$}function b(C,w){return M(C)===!0||C.isFramebufferTexture&&C.minFilter!==cn&&C.minFilter!==Pn?Math.log2(Math.max(w.width,w.height))+1:C.mipmaps.length>0?C.mipmaps.length:C.isCompressedTexture&&Array.isArray(C.image)?w.mipmaps.length:1}function A(C){const w=new WeakRef(C);n.get(C).__ref=w,v.add(w),f.register(C,w,w)}function R(C){const w=n.get(C).__ref;w!==void 0&&(v.delete(w),f.unregister(w))}function D(C){X(C.target)}function O(C){k(C.target)}function X(C){C.removeEventListener("dispose",D),R(C),F(C),C.isVideoTexture&&d.delete(C),C.isHTMLTexture&&p.delete(C)}function k(C){C.removeEventListener("dispose",O),R(C),se(C)}function P(){for(const C of v){const w=C.deref();w!==void 0&&(w.isRenderTarget===!0?k(w):X(w))}v.clear(),p.clear()}function F(C){const w=n.get(C);if(w.__webglInit===void 0)return;const $=C.source,de=h.get($);if(de){const oe=de[w.__cacheKey];oe.usedTimes--,oe.usedTimes===0&&G(C),Object.keys(de).length===0&&h.delete($)}n.remove(C)}function G(C){const w=n.get(C);i.deleteTexture(w.__webglTexture);const $=C.source,de=h.get($);delete de[w.__cacheKey],a.memory.textures--}function se(C){const w=n.get(C);w.__depthDisposeCallback&&w.__depthDisposeCallback();const $=C.depthTexture;if($&&$.renderTarget===C&&X($),C.isWebGLCubeRenderTarget)for(let oe=0;oe<6;oe++){if(Array.isArray(w.__webglFramebuffer[oe]))for(let pe=0;pe<w.__webglFramebuffer[oe].length;pe++)i.deleteFramebuffer(w.__webglFramebuffer[oe][pe]);else i.deleteFramebuffer(w.__webglFramebuffer[oe]);w.__webglDepthbuffer&&i.deleteRenderbuffer(w.__webglDepthbuffer[oe])}else{if(Array.isArray(w.__webglFramebuffer))for(let oe=0;oe<w.__webglFramebuffer.length;oe++)i.deleteFramebuffer(w.__webglFramebuffer[oe]);else i.deleteFramebuffer(w.__webglFramebuffer);if(w.__webglDepthbuffer&&i.deleteRenderbuffer(w.__webglDepthbuffer),w.__webglMultisampledFramebuffer&&i.deleteFramebuffer(w.__webglMultisampledFramebuffer),w.__webglColorRenderbuffer)for(let oe=0;oe<w.__webglColorRenderbuffer.length;oe++)w.__webglColorRenderbuffer[oe]&&i.deleteRenderbuffer(w.__webglColorRenderbuffer[oe]);w.__webglDepthRenderbuffer&&i.deleteRenderbuffer(w.__webglDepthRenderbuffer)}const de=C.textures;for(let oe=0,pe=de.length;oe<pe;oe++){const ye=n.get(de[oe]);ye.__webglTexture&&(i.deleteTexture(ye.__webglTexture),a.memory.textures--),n.remove(de[oe])}n.remove(C)}let Y=0;function ae(){Y=0}function le(){return Y}function ce(C){Y=C}function xe(){const C=Y;return C>=s.maxTextures&&qe("WebGLTextures: Trying to use "+(C+1)+" texture units while this GPU supports only "+s.maxTextures),Y+=1,C}function Z(C){const w=[];return w.push(C.wrapS),w.push(C.wrapT),w.push(C.wrapR||0),w.push(C.magFilter),w.push(C.minFilter),w.push(C.anisotropy),w.push(C.internalFormat),w.push(C.format),w.push(C.type),w.push(C.generateMipmaps),w.push(C.mipmapsAutoUpdate),w.push(C.premultiplyAlpha),w.push(C.flipY),w.push(C.unpackAlignment),w.push(C.colorSpace),w.join()}function be(C,w){const $=n.get(C);if(C.isVideoTexture&&Qt(C),C.isRenderTargetTexture===!1&&C.isExternalTexture!==!0&&C.version>0&&$.__version!==C.version){const de=C.image;if(de===null)qe("WebGLRenderer: Texture marked for update but no image data found.");else if(de.complete===!1)qe("WebGLRenderer: Texture marked for update but image is incomplete");else{Jt($,C,w);return}}else C.isExternalTexture&&($.__webglTexture=C.sourceTexture?C.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,$.__webglTexture,i.TEXTURE0+w)}function we(C,w){const $=n.get(C);if(C.isRenderTargetTexture===!1&&C.version>0&&$.__version!==C.version){Jt($,C,w);return}else C.isExternalTexture&&($.__webglTexture=C.sourceTexture?C.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,$.__webglTexture,i.TEXTURE0+w)}function Fe(C,w){const $=n.get(C);if(C.isRenderTargetTexture===!1&&C.version>0&&$.__version!==C.version){Jt($,C,w);return}t.bindTexture(i.TEXTURE_3D,$.__webglTexture,i.TEXTURE0+w)}function Ee(C,w){const $=n.get(C);if(C.version>0&&$.__version!==C.version){Cn($,C,w);return}t.bindTexture(i.TEXTURE_CUBE_MAP,$.__webglTexture,i.TEXTURE0+w)}const Je={[cr]:i.REPEAT,[Ti]:i.CLAMP_TO_EDGE,[Go]:i.MIRRORED_REPEAT},Xt={[cn]:i.NEAREST,[gp]:i.NEAREST_MIPMAP_NEAREST,[br]:i.NEAREST_MIPMAP_LINEAR,[Pn]:i.LINEAR,[Ya]:i.LINEAR_MIPMAP_NEAREST,[Ci]:i.LINEAR_MIPMAP_LINEAR},$e={[_p]:i.NEVER,[Zu]:i.ALWAYS,[yp]:i.LESS,[Yu]:i.LEQUAL,[Mp]:i.EQUAL,[Ku]:i.GEQUAL,[bp]:i.GREATER,[kp]:i.NOTEQUAL};function vt(C,w){if(w.type===ri&&e.has("OES_texture_float_linear")===!1&&(w.magFilter===Pn||w.magFilter===Ya||w.magFilter===br||w.magFilter===Ci||w.minFilter===Pn||w.minFilter===Ya||w.minFilter===br||w.minFilter===Ci)&&qe("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(C,i.TEXTURE_WRAP_S,Je[w.wrapS]),i.texParameteri(C,i.TEXTURE_WRAP_T,Je[w.wrapT]),(C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY)&&i.texParameteri(C,i.TEXTURE_WRAP_R,Je[w.wrapR]),i.texParameteri(C,i.TEXTURE_MAG_FILTER,Xt[w.magFilter]),i.texParameteri(C,i.TEXTURE_MIN_FILTER,Xt[w.minFilter]),w.compareFunction&&(i.texParameteri(C,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(C,i.TEXTURE_COMPARE_FUNC,$e[w.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(w.magFilter===cn||w.minFilter!==br&&w.minFilter!==Ci||w.type===ri&&e.has("OES_texture_float_linear")===!1)return;if(w.anisotropy>1||n.get(w).__currentAnisotropy){const $=e.get("EXT_texture_filter_anisotropic");i.texParameterf(C,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(w.anisotropy,s.getMaxAnisotropy())),n.get(w).__currentAnisotropy=w.anisotropy}}}function bt(C,w){let $=!1;C.__webglInit===void 0&&(C.__webglInit=!0,w.addEventListener("dispose",D),A(w));const de=w.source;let oe=h.get(de);oe===void 0&&(oe={},h.set(de,oe));const pe=Z(w);if(pe!==C.__cacheKey){oe[pe]===void 0&&(oe[pe]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,$=!0),oe[pe].usedTimes++;const ye=oe[C.__cacheKey];ye!==void 0&&(oe[C.__cacheKey].usedTimes--,ye.usedTimes===0&&G(w)),C.__cacheKey=pe,C.__webglTexture=oe[pe].texture}return $}function rt(C,w,$){return Math.floor(Math.floor(C/$)/w)}function un(C,w,$,de){const pe=C.updateRanges;if(pe.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,w.width,w.height,$,de,w.data);else{pe.sort((I,re)=>I.start-re.start);let ye=0;for(let I=1;I<pe.length;I++){const re=pe[ye],ee=pe[I],ve=re.start+re.count,fe=rt(ee.start,w.width,4),me=rt(re.start,w.width,4);ee.start<=ve+1&&fe===me&&rt(ee.start+ee.count-1,w.width,4)===fe?re.count=Math.max(re.count,ee.start+ee.count-re.start):(++ye,pe[ye]=ee)}pe.length=ye+1;const te=t.getParameter(i.UNPACK_ROW_LENGTH),ie=t.getParameter(i.UNPACK_SKIP_PIXELS),ge=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,w.width);for(let I=0,re=pe.length;I<re;I++){const ee=pe[I],ve=Math.floor(ee.start/4),fe=Math.ceil(ee.count/4),me=ve%w.width,Oe=Math.floor(ve/w.width),tt=fe,ue=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,me),t.pixelStorei(i.UNPACK_SKIP_ROWS,Oe),t.texSubImage2D(i.TEXTURE_2D,0,me,Oe,tt,ue,$,de,w.data)}C.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,te),t.pixelStorei(i.UNPACK_SKIP_PIXELS,ie),t.pixelStorei(i.UNPACK_SKIP_ROWS,ge)}}function Jt(C,w,$){let de=i.TEXTURE_2D;(w.isDataArrayTexture||w.isCompressedArrayTexture)&&(de=i.TEXTURE_2D_ARRAY),w.isData3DTexture&&(de=i.TEXTURE_3D);const oe=bt(C,w),pe=w.source;t.bindTexture(de,C.__webglTexture,i.TEXTURE0+$);const ye=n.get(pe);if(pe.version!==ye.__version||oe===!0){if(t.activeTexture(i.TEXTURE0+$),(typeof ImageBitmap<"u"&&w.image instanceof ImageBitmap)===!1){const ue=dt.getPrimaries(dt.workingColorSpace),Ge=w.colorSpace===Oi?null:dt.getPrimaries(w.colorSpace),je=w.colorSpace===Oi||ue===Ge?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,je)}t.pixelStorei(i.UNPACK_ALIGNMENT,w.unpackAlignment);let ie=S(w.image,!1,s.maxTextureSize);ie=ze(w,ie);const ge=r.convert(w.format,w.colorSpace),I=r.convert(w.type);let re=y(w.internalFormat,ge,I,w.normalized,w.colorSpace,w.isVideoTexture);vt(de,w);let ee;const ve=w.mipmaps,fe=w.isVideoTexture!==!0,me=ye.__version===void 0||oe===!0,Oe=pe.dataReady,tt=b(w,ie);if(w.isDepthTexture)re=x(w.format===Hi,w.type),me&&(fe?t.texStorage2D(i.TEXTURE_2D,1,re,ie.width,ie.height):t.texImage2D(i.TEXTURE_2D,0,re,ie.width,ie.height,0,ge,I,null));else if(w.isDataTexture)if(ve.length>0){fe&&me&&t.texStorage2D(i.TEXTURE_2D,tt,re,ve[0].width,ve[0].height);for(let ue=0,Ge=ve.length;ue<Ge;ue++)ee=ve[ue],fe?Oe&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,ee.width,ee.height,ge,I,ee.data):t.texImage2D(i.TEXTURE_2D,ue,re,ee.width,ee.height,0,ge,I,ee.data);w.generateMipmaps=!1}else fe?(me&&t.texStorage2D(i.TEXTURE_2D,tt,re,ie.width,ie.height),Oe&&un(w,ie,ge,I)):t.texImage2D(i.TEXTURE_2D,0,re,ie.width,ie.height,0,ge,I,ie.data);else if(w.isCompressedTexture)if(w.isCompressedArrayTexture){fe&&me&&t.texStorage3D(i.TEXTURE_2D_ARRAY,tt,re,ve[0].width,ve[0].height,ie.depth);for(let ue=0,Ge=ve.length;ue<Ge;ue++)if(ee=ve[ue],w.format!==hi)if(ge!==null)if(fe){if(Oe)if(w.layerUpdates.size>0){const je=ld(ee.width,ee.height,w.format,w.type);for(const Te of w.layerUpdates){const St=ee.data.subarray(Te*je/ee.data.BYTES_PER_ELEMENT,(Te+1)*je/ee.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,Te,ee.width,ee.height,1,ge,St)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,0,ee.width,ee.height,ie.depth,ge,ee.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ue,re,ee.width,ee.height,ie.depth,0,ee.data,0,0);else qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else fe?Oe&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,0,ee.width,ee.height,ie.depth,ge,I,ee.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ue,re,ee.width,ee.height,ie.depth,0,ge,I,ee.data);w.layerUpdates.size>0&&w.clearLayerUpdates()}else{fe&&me&&t.texStorage2D(i.TEXTURE_2D,tt,re,ve[0].width,ve[0].height);for(let ue=0,Ge=ve.length;ue<Ge;ue++)ee=ve[ue],w.format!==hi?ge!==null?fe?Oe&&t.compressedTexSubImage2D(i.TEXTURE_2D,ue,0,0,ee.width,ee.height,ge,ee.data):t.compressedTexImage2D(i.TEXTURE_2D,ue,re,ee.width,ee.height,0,ee.data):qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):fe?Oe&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,ee.width,ee.height,ge,I,ee.data):t.texImage2D(i.TEXTURE_2D,ue,re,ee.width,ee.height,0,ge,I,ee.data)}else if(w.isDataArrayTexture)if(fe){if(me&&t.texStorage3D(i.TEXTURE_2D_ARRAY,tt,re,ie.width,ie.height,ie.depth),Oe)if(w.layerUpdates.size>0){const ue=ld(ie.width,ie.height,w.format,w.type);for(const Ge of w.layerUpdates){const je=ie.data.subarray(Ge*ue/ie.data.BYTES_PER_ELEMENT,(Ge+1)*ue/ie.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Ge,ie.width,ie.height,1,ge,I,je)}w.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ie.width,ie.height,ie.depth,ge,I,ie.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,re,ie.width,ie.height,ie.depth,0,ge,I,ie.data);else if(w.isData3DTexture)fe?(me&&t.texStorage3D(i.TEXTURE_3D,tt,re,ie.width,ie.height,ie.depth),Oe&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ie.width,ie.height,ie.depth,ge,I,ie.data)):t.texImage3D(i.TEXTURE_3D,0,re,ie.width,ie.height,ie.depth,0,ge,I,ie.data);else if(w.isFramebufferTexture){if(me)if(fe)t.texStorage2D(i.TEXTURE_2D,tt,re,ie.width,ie.height);else{let ue=ie.width,Ge=ie.height;for(let je=0;je<tt;je++)t.texImage2D(i.TEXTURE_2D,je,re,ue,Ge,0,ge,I,null),ue>>=1,Ge>>=1}}else if(w.isHTMLTexture){if("texElementImage2D"in i){const ue=i.canvas;if(ue.hasAttribute("layoutsubtree")||ue.setAttribute("layoutsubtree","true"),ie.parentNode!==ue){ue.appendChild(ie),p.add(w),ue.onpaint=Ge=>{const je=Ge.changedElements;for(const Te of p)je.includes(Te.image)&&(Te.needsUpdate=!0)},ue.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,ie);else{const je=i.RGBA,Te=i.RGBA,St=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,je,Te,St,ie)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(ve.length>0){if(fe&&me){const ue=Xe(ve[0]);t.texStorage2D(i.TEXTURE_2D,tt,re,ue.width,ue.height)}for(let ue=0,Ge=ve.length;ue<Ge;ue++)ee=ve[ue],fe?Oe&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,ge,I,ee):t.texImage2D(i.TEXTURE_2D,ue,re,ge,I,ee);w.generateMipmaps=!1}else if(fe){if(me){const ue=Xe(ie);t.texStorage2D(i.TEXTURE_2D,tt,re,ue.width,ue.height)}Oe&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,ge,I,ie)}else t.texImage2D(i.TEXTURE_2D,0,re,ge,I,ie);M(w)&&w.mipmapsAutoUpdate===!0&&_(de),ye.__version=pe.version,w.onUpdate&&w.onUpdate(w)}C.__version=w.version}function Cn(C,w,$){if(w.image.length!==6)return;const de=bt(C,w),oe=w.source;t.bindTexture(i.TEXTURE_CUBE_MAP,C.__webglTexture,i.TEXTURE0+$);const pe=n.get(oe);if(oe.version!==pe.__version||de===!0){t.activeTexture(i.TEXTURE0+$);const ye=dt.getPrimaries(dt.workingColorSpace),te=w.colorSpace===Oi?null:dt.getPrimaries(w.colorSpace),ie=w.colorSpace===Oi||ye===te?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,w.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,w.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,w.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ie);const ge=w.isCompressedTexture||w.image[0].isCompressedTexture,I=w.image[0]&&w.image[0].isDataTexture,re=[];for(let Te=0;Te<6;Te++)!ge&&!I?re[Te]=S(w.image[Te],!0,s.maxCubemapSize):re[Te]=I?w.image[Te].image:w.image[Te],re[Te]=ze(w,re[Te]);const ee=re[0],ve=r.convert(w.format,w.colorSpace),fe=r.convert(w.type);let me=y(w.internalFormat,ve,fe,w.normalized,w.colorSpace);const Oe=w.isVideoTexture!==!0,tt=pe.__version===void 0||de===!0,ue=oe.dataReady;let Ge=b(w,ee);vt(i.TEXTURE_CUBE_MAP,w);let je;if(w.isDepthTexture){if(me=x(w.format===Hi,w.type),tt)if(Oe)t.texStorage2D(i.TEXTURE_CUBE_MAP,1,me,ee.width,ee.height);else for(let Te=0;Te<6;Te++)t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,me,ee.width,ee.height,0,ve,fe,null)}else if(ge){Oe&&tt&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Ge,me,ee.width,ee.height);for(let Te=0;Te<6;Te++){je=re[Te].mipmaps;for(let St=0;St<je.length;St++){const rn=je[St];w.format!==hi?ve!==null?Oe?ue&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St,0,0,rn.width,rn.height,ve,rn.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St,me,rn.width,rn.height,0,rn.data):qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Oe?ue&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St,0,0,rn.width,rn.height,ve,fe,rn.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St,me,rn.width,rn.height,0,ve,fe,rn.data)}}}else{if(je=w.mipmaps,Oe&&tt){je.length>0&&Ge++;const Te=Xe(re[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Ge,me,Te.width,Te.height)}for(let Te=0;Te<6;Te++)if(I){Oe?ue&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,re[Te].width,re[Te].height,ve,fe,re[Te].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,me,re[Te].width,re[Te].height,0,ve,fe,re[Te].data);for(let St=0;St<je.length;St++){const Pi=je[St].image[Te].image;Oe?ue&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St+1,0,0,Pi.width,Pi.height,ve,fe,Pi.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St+1,me,Pi.width,Pi.height,0,ve,fe,Pi.data)}}else{Oe?ue&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,ve,fe,re[Te]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,me,ve,fe,re[Te]);for(let St=0;St<je.length;St++){const rn=je[St];Oe?ue&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St+1,0,0,ve,fe,rn.image[Te]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,St+1,me,ve,fe,rn.image[Te])}}}M(w)&&w.mipmapsAutoUpdate===!0&&_(i.TEXTURE_CUBE_MAP),pe.__version=oe.version,w.onUpdate&&w.onUpdate(w)}C.__version=w.version}function Ut(C,w,$,de,oe,pe){const ye=r.convert($.format,$.colorSpace),te=r.convert($.type),ie=y($.internalFormat,ye,te,$.normalized,$.colorSpace),ge=n.get(w),I=n.get($);if(I.__renderTarget=w,!ge.__hasExternalTextures){const re=Math.max(1,w.width>>pe),ee=Math.max(1,w.height>>pe);oe===i.TEXTURE_3D||oe===i.TEXTURE_2D_ARRAY?t.texImage3D(oe,pe,ie,re,ee,w.depth,0,ye,te,null):t.texImage2D(oe,pe,ie,re,ee,0,ye,te,null)}t.bindFramebuffer(i.FRAMEBUFFER,C),ke(w)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,de,oe,I.__webglTexture,0,Rt(w)):(oe===i.TEXTURE_2D||oe>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&oe<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,de,oe,I.__webglTexture,pe),t.bindFramebuffer(i.FRAMEBUFFER,null)}function oi(C,w,$){if(i.bindRenderbuffer(i.RENDERBUFFER,C),w.depthBuffer){const de=w.depthTexture,oe=de&&de.isDepthTexture?de.type:null,pe=x(w.stencilBuffer,oe),ye=w.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;ke(w)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Rt(w),pe,w.width,w.height):$?i.renderbufferStorageMultisample(i.RENDERBUFFER,Rt(w),pe,w.width,w.height):i.renderbufferStorage(i.RENDERBUFFER,pe,w.width,w.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ye,i.RENDERBUFFER,C)}else{const de=w.textures;for(let oe=0;oe<de.length;oe++){const pe=de[oe],ye=r.convert(pe.format,pe.colorSpace),te=r.convert(pe.type),ie=y(pe.internalFormat,ye,te,pe.normalized,pe.colorSpace);ke(w)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Rt(w),ie,w.width,w.height):$?i.renderbufferStorageMultisample(i.RENDERBUFFER,Rt(w),ie,w.width,w.height):i.renderbufferStorage(i.RENDERBUFFER,ie,w.width,w.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function sn(C,w,$){const de=w.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,C),!(w.depthTexture&&w.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const oe=n.get(w.depthTexture);oe.__renderTarget=w;const pe=de?w.depthTexture.image[0]:w.depthTexture.image;(!oe.__webglTexture||pe.width!==w.width||pe.height!==w.height)&&(pe.width=w.width,pe.height=w.height,w.depthTexture.needsUpdate=!0),de?Ee(w.depthTexture,0):be(w.depthTexture,0);const ye=oe.__webglTexture,te=Rt(w),ie=de?i.TEXTURE_CUBE_MAP_POSITIVE_X+$:i.TEXTURE_2D,ge=w.depthTexture.format===Hi?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(w.depthTexture.format===zi)ke(w)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ge,ie,ye,0,te):i.framebufferTexture2D(i.FRAMEBUFFER,ge,ie,ye,0);else if(w.depthTexture.format===Hi)ke(w)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ge,ie,ye,0,te):i.framebufferTexture2D(i.FRAMEBUFFER,ge,ie,ye,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function zn(C){const w=n.get(C),$=C.isWebGLCubeRenderTarget===!0;if(w.__boundDepthTexture!==C.depthTexture){const de=C.depthTexture;if(w.__depthDisposeCallback&&w.__depthDisposeCallback(),de){const oe=()=>{delete w.__boundDepthTexture,delete w.__depthDisposeCallback,de.removeEventListener("dispose",oe)};de.addEventListener("dispose",oe),w.__depthDisposeCallback=oe}w.__boundDepthTexture=de}if(C.depthTexture&&!w.__autoAllocateDepthBuffer)if($)for(let de=0;de<6;de++)sn(w.__webglFramebuffer[de],C,de);else C.texture.mipmaps.length>0?sn(w.__webglFramebuffer[0],C,0):sn(w.__webglFramebuffer,C,0);else if($){w.__webglDepthbuffer=[];for(let de=0;de<6;de++)if(t.bindFramebuffer(i.FRAMEBUFFER,w.__webglFramebuffer[de]),w.__webglDepthbuffer[de]===void 0)w.__webglDepthbuffer[de]=i.createRenderbuffer(),oi(w.__webglDepthbuffer[de],C,!1);else{const oe=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,pe=w.__webglDepthbuffer[de];i.bindRenderbuffer(i.RENDERBUFFER,pe),i.framebufferRenderbuffer(i.FRAMEBUFFER,oe,i.RENDERBUFFER,pe)}}else if(C.texture.mipmaps.length>0?t.bindFramebuffer(i.FRAMEBUFFER,w.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,w.__webglFramebuffer),w.__webglDepthbuffer===void 0)w.__webglDepthbuffer=i.createRenderbuffer(),oi(w.__webglDepthbuffer,C,!1);else{const oe=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,pe=w.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,pe),i.framebufferRenderbuffer(i.FRAMEBUFFER,oe,i.RENDERBUFFER,pe)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Vn(C,w,$){const de=n.get(C);w!==void 0&&Ut(de.__webglFramebuffer,C,C.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),$!==void 0&&zn(C)}function Wn(C){const w=C.texture,$=n.get(C),de=n.get(w);C.addEventListener("dispose",O),A(C);const oe=C.textures,pe=C.isWebGLCubeRenderTarget===!0,ye=oe.length>1;if(ye||(de.__webglTexture===void 0&&(de.__webglTexture=i.createTexture()),de.__version=w.version,a.memory.textures++),pe){$.__webglFramebuffer=[];for(let te=0;te<6;te++)if(w.mipmaps.length>0){$.__webglFramebuffer[te]=[];for(let ie=0;ie<w.mipmaps.length;ie++)$.__webglFramebuffer[te][ie]=i.createFramebuffer()}else $.__webglFramebuffer[te]=i.createFramebuffer()}else{if(w.mipmaps.length>0){$.__webglFramebuffer=[];for(let te=0;te<w.mipmaps.length;te++)$.__webglFramebuffer[te]=i.createFramebuffer()}else $.__webglFramebuffer=i.createFramebuffer();if(ye)for(let te=0,ie=oe.length;te<ie;te++){const ge=n.get(oe[te]);ge.__webglTexture===void 0&&(ge.__webglTexture=i.createTexture(),a.memory.textures++)}if(C.samples>0&&ke(C)===!1){$.__webglMultisampledFramebuffer=i.createFramebuffer(),$.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let te=0;te<oe.length;te++){const ie=oe[te];$.__webglColorRenderbuffer[te]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,$.__webglColorRenderbuffer[te]);const ge=r.convert(ie.format,ie.colorSpace),I=r.convert(ie.type),re=y(ie.internalFormat,ge,I,ie.normalized,ie.colorSpace,C.isXRRenderTarget===!0),ee=Rt(C);i.renderbufferStorageMultisample(i.RENDERBUFFER,ee,re,C.width,C.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+te,i.RENDERBUFFER,$.__webglColorRenderbuffer[te])}i.bindRenderbuffer(i.RENDERBUFFER,null),C.depthBuffer&&($.__webglDepthRenderbuffer=i.createRenderbuffer(),oi($.__webglDepthRenderbuffer,C,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(pe){t.bindTexture(i.TEXTURE_CUBE_MAP,de.__webglTexture),vt(i.TEXTURE_CUBE_MAP,w);for(let te=0;te<6;te++)if(w.mipmaps.length>0)for(let ie=0;ie<w.mipmaps.length;ie++)Ut($.__webglFramebuffer[te][ie],C,w,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+te,ie);else Ut($.__webglFramebuffer[te],C,w,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+te,0);M(w)?_(i.TEXTURE_CUBE_MAP):w.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,w.mipmaps.length-1),t.unbindTexture()}else if(ye){for(let te=0,ie=oe.length;te<ie;te++){const ge=oe[te],I=n.get(ge);let re=i.TEXTURE_2D;(C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(re=C.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(re,I.__webglTexture),vt(re,ge),Ut($.__webglFramebuffer,C,ge,i.COLOR_ATTACHMENT0+te,re,0),M(ge)&&_(re)}t.unbindTexture()}else{let te=i.TEXTURE_2D;if((C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(te=C.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(te,de.__webglTexture),vt(te,w),w.mipmaps.length>0)for(let ie=0;ie<w.mipmaps.length;ie++)Ut($.__webglFramebuffer[ie],C,w,i.COLOR_ATTACHMENT0,te,ie);else Ut($.__webglFramebuffer,C,w,i.COLOR_ATTACHMENT0,te,0);M(w)?_(te):w.mipmaps.length>0&&i.texParameteri(te,i.TEXTURE_MAX_LEVEL,w.mipmaps.length-1),t.unbindTexture()}C.depthBuffer&&zn(C)}function H(C){const w=C.textures;for(let $=0,de=w.length;$<de;$++){const oe=w[$];if(M(oe)&&oe.mipmapsAutoUpdate===!0){const pe=E(C),ye=n.get(oe).__webglTexture;t.bindTexture(pe,ye),_(pe),t.unbindTexture()}}}const $n=[];function At(C){if(C.samples>0){if(ke(C)===!1){const w=C.textures,$=C.width,de=C.height;let oe=i.COLOR_BUFFER_BIT;const pe=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ye=n.get(C),te=w.length>1;if(te)for(let ge=0;ge<w.length;ge++)t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,ye.__webglMultisampledFramebuffer),C.texture.mipmaps.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer);for(let ge=0;ge<w.length;ge++){if(C.resolveDepthBuffer&&(C.depthBuffer&&(oe|=i.DEPTH_BUFFER_BIT),C.stencilBuffer&&C.resolveStencilBuffer&&(oe|=i.STENCIL_BUFFER_BIT)),te){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ye.__webglColorRenderbuffer[ge]);const I=n.get(w[ge]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,I,0)}i.blitFramebuffer(0,0,$,de,0,0,$,de,oe,i.NEAREST),l===!0&&($n.length=0,$n.push(i.COLOR_ATTACHMENT0+ge),C.depthBuffer&&C.storeMultisampledDepthBuffer===!1&&$n.push(pe),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,$n))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),te)for(let ge=0;ge<w.length;ge++){t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,ye.__webglColorRenderbuffer[ge]);const I=n.get(w[ge]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.TEXTURE_2D,I,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglMultisampledFramebuffer)}else if(C.depthBuffer&&C.storeMultisampledDepthBuffer===!1&&l){const w=C.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[w])}}}function Rt(C){return Math.min(s.maxSamples,C.samples)}function ke(C){const w=n.get(C);return C.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&w.__useRenderToTexture!==!1}function Qt(C){const w=a.render.frame;d.get(C)!==w&&(d.set(C,w),C.update())}function ze(C,w){const $=C.colorSpace,de=C.format,oe=C.type;return C.isCompressedTexture===!0||C.isVideoTexture===!0||$!==xa&&$!==Oi&&(dt.getTransfer($)===xt?(de!==hi||oe!==Gn)&&qe("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):pt("WebGLTextures: Unsupported texture color space:",$)),w}function Xe(C){return typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement?(c.width=C.naturalWidth||C.width,c.height=C.naturalHeight||C.height):typeof VideoFrame<"u"&&C instanceof VideoFrame?(c.width=C.displayWidth,c.height=C.displayHeight):(c.width=C.width,c.height=C.height),c}this.allocateTextureUnit=xe,this.resetTextureUnits=ae,this.getTextureUnits=le,this.setTextureUnits=ce,this.setTexture2D=be,this.setTexture2DArray=we,this.setTexture3D=Fe,this.setTextureCube=Ee,this.rebindTextures=Vn,this.setupRenderTarget=Wn,this.updateRenderTargetMipmap=H,this.updateMultisampleRenderTarget=At,this.setupDepthRenderbuffer=zn,this.setupFrameBufferTexture=Ut,this.useMultisampledRTT=ke,this.dispose=P}function QS(i,e){function t(n,s=Oi){let r;const a=dt.getTransfer(s);if(n===Gn)return i.UNSIGNED_BYTE;if(n===Nl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Bl)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Wu)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===$u)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===zu)return i.BYTE;if(n===Vu)return i.SHORT;if(n===dr)return i.UNSIGNED_SHORT;if(n===Ul)return i.INT;if(n===pi)return i.UNSIGNED_INT;if(n===ri)return i.FLOAT;if(n===mi)return i.HALF_FLOAT;if(n===qu)return i.ALPHA;if(n===Xu)return i.RGB;if(n===hi)return i.RGBA;if(n===zi)return i.DEPTH_COMPONENT;if(n===Hi)return i.DEPTH_STENCIL;if(n===Fl)return i.RED;if(n===Ol)return i.RED_INTEGER;if(n===ss)return i.RG;if(n===Hl)return i.RG_INTEGER;if(n===Gl)return i.RGBA_INTEGER;if(n===ta||n===na||n===ia||n===sa)if(a===xt)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===ta)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===na)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ia)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===sa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===ta)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===na)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ia)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===sa)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===zo||n===Vo||n===Wo||n===$o)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===zo)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Vo)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Wo)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===$o)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===qo||n===Xo||n===Yo||n===Ko||n===Zo||n===va||n===Jo)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===qo||n===Xo)return a===xt?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Yo)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===Ko)return r.COMPRESSED_R11_EAC;if(n===Zo)return r.COMPRESSED_SIGNED_R11_EAC;if(n===va)return r.COMPRESSED_RG11_EAC;if(n===Jo)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===Qo||n===jo||n===el||n===tl||n===nl||n===il||n===sl||n===rl||n===al||n===ol||n===ll||n===cl||n===dl||n===ul)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Qo)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===jo)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===el)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===tl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===nl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===il)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===sl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===rl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===al)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===ol)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ll)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===cl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===dl)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ul)return a===xt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===hl||n===fl||n===pl)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===hl)return a===xt?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===fl)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===pl)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===ml||n===gl||n===Sa||n===vl)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===ml)return r.COMPRESSED_RED_RGTC1_EXT;if(n===gl)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Sa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===vl)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ps?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const jS=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ex=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class tx{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new rh(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new rs({vertexShader:jS,fragmentShader:ex,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ct(new Ei(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class nx extends as{constructor(e,t){super();const n=this;let s=null,r=1,a=null,o="local-floor",l=1,c=null,d=null,p=null,u=null,h=null,v=null;const f=typeof XRWebGLBinding<"u",m=new tx,g={},S=t.getContextAttributes();let M=null,_=null;const E=[],y=[],x=new it;let b=null,A=null;const R=new Xn;R.viewport=new Gt;const D=new Xn;D.viewport=new Gt;const O=[R,D],X=new fm;let k=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let be=E[Z];return be===void 0&&(be=new io,E[Z]=be),be.getTargetRaySpace()},this.getControllerGrip=function(Z){let be=E[Z];return be===void 0&&(be=new io,E[Z]=be),be.getGripSpace()},this.getHand=function(Z){let be=E[Z];return be===void 0&&(be=new io,E[Z]=be),be.getHandSpace()};function F(Z){const be=y.indexOf(Z.inputSource);if(be===-1)return;const we=E[be];we!==void 0&&(we.update(Z.inputSource,Z.frame,c||a),we.dispatchEvent({type:Z.type,data:Z.inputSource}))}function G(){s.removeEventListener("select",F),s.removeEventListener("selectstart",F),s.removeEventListener("selectend",F),s.removeEventListener("squeeze",F),s.removeEventListener("squeezestart",F),s.removeEventListener("squeezeend",F),s.removeEventListener("end",G),s.removeEventListener("inputsourceschange",se);for(let Z=0;Z<E.length;Z++){const be=y[Z];be!==null&&(y[Z]=null,E[Z].disconnect(be))}k=null,P=null,m.reset();for(const Z in g)delete g[Z];if(e.setRenderTarget(M),h=null,u=null,p=null,s=null,_=null,xe.stop(),n.isPresenting=!1,e.setPixelRatio(b),e.setSize(x.width,x.height,!1),A!==null){const Z=A.camera;Z.fov=A.fov,Z.zoom=A.zoom,Z.updateProjectionMatrix(),A=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){r=Z,n.isPresenting===!0&&qe("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){o=Z,n.isPresenting===!0&&qe("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return u!==null?u:h},this.getBinding=function(){return p===null&&f&&(p=new XRWebGLBinding(s,t)),p},this.getFrame=function(){return v},this.getSession=function(){return s},this.setSession=async function(Z){if(s=Z,s!==null){if(M=e.getRenderTarget(),s.addEventListener("select",F),s.addEventListener("selectstart",F),s.addEventListener("selectend",F),s.addEventListener("squeeze",F),s.addEventListener("squeezestart",F),s.addEventListener("squeezeend",F),s.addEventListener("end",G),s.addEventListener("inputsourceschange",se),S.xrCompatible!==!0&&await t.makeXRCompatible(),b=e.getPixelRatio(),e.getSize(x),f&&"createProjectionLayer"in XRWebGLBinding.prototype){let we=null,Fe=null,Ee=null;S.depth&&(Ee=S.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,we=S.stencil?Hi:zi,Fe=S.stencil?Ps:pi);const Je={colorFormat:t.RGBA8,depthFormat:Ee,scaleFactor:r};p=this.getBinding(),u=p.createProjectionLayer(Je),s.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),_=new fi(u.textureWidth,u.textureHeight,{format:hi,type:Gn,depthTexture:new Ds(u.textureWidth,u.textureHeight,Fe,void 0,void 0,void 0,void 0,void 0,void 0,we),stencilBuffer:S.stencil,colorSpace:e.outputColorSpace,samples:S.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const we={antialias:S.antialias,alpha:!0,depth:S.depth,stencil:S.stencil,framebufferScaleFactor:r};h=new XRWebGLLayer(s,t,we),s.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),_=new fi(h.framebufferWidth,h.framebufferHeight,{format:hi,type:Gn,colorSpace:e.outputColorSpace,stencilBuffer:S.stencil,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1,storeMultisampledDepthBuffer:h.ignoreDepthValues===!1,storeMultisampledStencilBuffer:h.ignoreDepthValues===!1})}_.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await s.requestReferenceSpace(o),xe.setContext(s),xe.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function se(Z){for(let be=0;be<Z.removed.length;be++){const we=Z.removed[be],Fe=y.indexOf(we);Fe>=0&&(y[Fe]=null,E[Fe].disconnect(we))}for(let be=0;be<Z.added.length;be++){const we=Z.added[be];let Fe=y.indexOf(we);if(Fe===-1){for(let Je=0;Je<E.length;Je++)if(Je>=y.length){y.push(we),Fe=Je;break}else if(y[Je]===null){y[Je]=we,Fe=Je;break}if(Fe===-1)break}const Ee=E[Fe];Ee&&Ee.connect(we)}}function Y(Z,be){be===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(be.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(s===null)return;let be=Z.near,we=Z.far;m.texture!==null&&(m.depthNear>0&&(be=m.depthNear),m.depthFar>0&&(we=m.depthFar)),X.near=D.near=R.near=be,X.far=D.far=R.far=we,(k!==X.near||P!==X.far)&&(s.updateRenderState({depthNear:X.near,depthFar:X.far}),k=X.near,P=X.far),X.layers.mask=Z.layers.mask|6,R.layers.mask=X.layers.mask&-5,D.layers.mask=X.layers.mask&-3;const Fe=Z.parent,Ee=X.cameras;Y(X,Fe);for(let Je=0;Je<Ee.length;Je++)Y(Ee[Je],Fe);X.projectionMatrix.copy(R.projectionMatrix),X.projectionMatrixInverse.copy(R.projectionMatrixInverse),A===null&&Z.isPerspectiveCamera&&(A={camera:Z,fov:Z.fov,zoom:Z.zoom}),ae(Z,X,Fe)};function ae(Z,be,we){we===null?Z.matrix.copy(be.matrixWorld):(Z.matrix.copy(we.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(be.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(be.projectionMatrix),Z.projectionMatrixInverse.copy(be.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=xl*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return X},this.getFoveation=function(){if(!(u===null&&h===null))return l},this.setFoveation=function(Z){l=Z,u!==null&&(u.fixedFoveation=Z),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=Z)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(X)},this.getCameraTexture=function(Z){return g[Z]};let le=null;function ce(Z,be){if(d=be.getViewerPose(c||a),v=be,d!==null){const we=d.views;h!==null&&(e.setRenderTargetFramebuffer(_,h.framebuffer),e.setRenderTarget(_));let Fe=!1;we.length!==X.cameras.length&&(X.cameras.length=0,Fe=!0);for(let $e=0;$e<we.length;$e++){const vt=we[$e];let bt=null;if(h!==null)bt=h.getViewport(vt);else{const un=p.getViewSubImage(u,vt);bt=un.viewport,$e===0&&(e.setRenderTargetTextures(_,un.colorTexture,un.depthStencilTexture),e.setRenderTarget(_))}let rt=O[$e];rt===void 0&&(rt=new Xn,rt.layers.enable($e),rt.viewport=new Gt,O[$e]=rt),rt.matrix.fromArray(vt.transform.matrix),rt.matrix.decompose(rt.position,rt.quaternion,rt.scale),rt.projectionMatrix.fromArray(vt.projectionMatrix),rt.projectionMatrixInverse.copy(rt.projectionMatrix).invert(),rt.viewport.set(bt.x,bt.y,bt.width,bt.height),$e===0&&(X.matrix.copy(rt.matrix),X.matrix.decompose(X.position,X.quaternion,X.scale)),Fe===!0&&X.cameras.push(rt)}const Ee=s.enabledFeatures;if(Ee&&Ee.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&f){p=n.getBinding();const $e=p.getDepthInformation(we[0]);$e&&$e.isValid&&$e.texture&&m.init($e,s.renderState)}if(Ee&&Ee.includes("camera-access")&&f){e.state.unbindTexture(),p=n.getBinding();for(let $e=0;$e<we.length;$e++){const vt=we[$e].camera;if(vt){let bt=g[vt];bt||(bt=new rh,g[vt]=bt);const rt=p.getCameraImage(vt);bt.sourceTexture=rt}}}}for(let we=0;we<E.length;we++){const Fe=y[we],Ee=E[we];Fe!==null&&Ee!==void 0&&Ee.update(Fe,be,c||a)}le&&le(Z,be),be.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:be}),v=null}const xe=new dh;xe.setAnimationLoop(ce),this.setAnimationLoop=function(Z){le=Z},this.dispose=function(){}}}const ix=new yt,_h=new Ye;_h.set(-1,0,0,0,1,0,0,0,1);function sx(i,e){function t(m,g){m.matrixAutoUpdate===!0&&m.updateMatrix(),g.value.copy(m.matrix)}function n(m,g){g.color.getRGB(m.fogColor.value,ah(i)),g.isFog?(m.fogNear.value=g.near,m.fogFar.value=g.far):g.isFogExp2&&(m.fogDensity.value=g.density)}function s(m,g,S,M,_){g.isNodeMaterial?g.uniformsNeedUpdate=!1:g.isMeshBasicMaterial?r(m,g):g.isMeshLambertMaterial?(r(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshToonMaterial?(r(m,g),p(m,g)):g.isMeshPhongMaterial?(r(m,g),d(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshStandardMaterial?(r(m,g),u(m,g),g.isMeshPhysicalMaterial&&h(m,g,_)):g.isMeshMatcapMaterial?(r(m,g),v(m,g)):g.isMeshDepthMaterial?r(m,g):g.isMeshDistanceMaterial?(r(m,g),f(m,g)):g.isMeshNormalMaterial?r(m,g):g.isLineBasicMaterial?(a(m,g),g.isLineDashedMaterial&&o(m,g)):g.isPointsMaterial?l(m,g,S,M):g.isSpriteMaterial?c(m,g):g.isShadowMaterial?(m.color.value.copy(g.color),m.opacity.value=g.opacity):g.isShaderMaterial&&(g.uniformsNeedUpdate=!1)}function r(m,g){m.opacity.value=g.opacity,g.color&&m.diffuse.value.copy(g.color),g.emissive&&m.emissive.value.copy(g.emissive).multiplyScalar(g.emissiveIntensity),g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.bumpMap&&(m.bumpMap.value=g.bumpMap,t(g.bumpMap,m.bumpMapTransform),m.bumpScale.value=g.bumpScale,g.side===In&&(m.bumpScale.value*=-1)),g.normalMap&&(m.normalMap.value=g.normalMap,t(g.normalMap,m.normalMapTransform),m.normalScale.value.copy(g.normalScale),g.side===In&&m.normalScale.value.negate()),g.displacementMap&&(m.displacementMap.value=g.displacementMap,t(g.displacementMap,m.displacementMapTransform),m.displacementScale.value=g.displacementScale,m.displacementBias.value=g.displacementBias),g.emissiveMap&&(m.emissiveMap.value=g.emissiveMap,t(g.emissiveMap,m.emissiveMapTransform)),g.specularMap&&(m.specularMap.value=g.specularMap,t(g.specularMap,m.specularMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest);const S=e.get(g),M=S.envMap,_=S.envMapRotation;M&&(m.envMap.value=M,m.envMapRotation.value.setFromMatrix4(ix.makeRotationFromEuler(_)).transpose(),M.isCubeTexture&&M.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(_h),m.reflectivity.value=g.reflectivity,m.ior.value=g.ior,m.refractionRatio.value=g.refractionRatio),g.lightMap&&(m.lightMap.value=g.lightMap,m.lightMapIntensity.value=g.lightMapIntensity,t(g.lightMap,m.lightMapTransform)),g.aoMap&&(m.aoMap.value=g.aoMap,m.aoMapIntensity.value=g.aoMapIntensity,t(g.aoMap,m.aoMapTransform))}function a(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform))}function o(m,g){m.dashSize.value=g.dashSize,m.totalSize.value=g.dashSize+g.gapSize,m.scale.value=g.scale}function l(m,g,S,M){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.size.value=g.size*S,m.scale.value=M*.5,g.map&&(m.map.value=g.map,t(g.map,m.uvTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function c(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.rotation.value=g.rotation,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function d(m,g){m.specular.value.copy(g.specular),m.shininess.value=Math.max(g.shininess,1e-4)}function p(m,g){g.gradientMap&&(m.gradientMap.value=g.gradientMap)}function u(m,g){m.metalness.value=g.metalness,g.metalnessMap&&(m.metalnessMap.value=g.metalnessMap,t(g.metalnessMap,m.metalnessMapTransform)),m.roughness.value=g.roughness,g.roughnessMap&&(m.roughnessMap.value=g.roughnessMap,t(g.roughnessMap,m.roughnessMapTransform)),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)}function h(m,g,S){m.ior.value=g.ior,g.diffuseRoughness>0&&(m.diffuseRoughness.value=g.diffuseRoughness,g.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=g.diffuseRoughnessMap,t(g.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),g.sheen>0&&(m.sheenColor.value.copy(g.sheenColor).multiplyScalar(g.sheen),m.sheenRoughness.value=g.sheenRoughness,g.sheenColorMap&&(m.sheenColorMap.value=g.sheenColorMap,t(g.sheenColorMap,m.sheenColorMapTransform)),g.sheenRoughnessMap&&(m.sheenRoughnessMap.value=g.sheenRoughnessMap,t(g.sheenRoughnessMap,m.sheenRoughnessMapTransform))),g.clearcoat>0&&(m.clearcoat.value=g.clearcoat,m.clearcoatRoughness.value=g.clearcoatRoughness,g.clearcoatMap&&(m.clearcoatMap.value=g.clearcoatMap,t(g.clearcoatMap,m.clearcoatMapTransform)),g.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=g.clearcoatRoughnessMap,t(g.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),g.clearcoatNormalMap&&(m.clearcoatNormalMap.value=g.clearcoatNormalMap,t(g.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(g.clearcoatNormalScale),g.side===In&&m.clearcoatNormalScale.value.negate())),g.dispersion>0&&(m.dispersion.value=g.dispersion),g.retroreflectivity>0&&(m.retroreflectivity.value=g.retroreflectivity),g.iridescence>0&&(m.iridescence.value=g.iridescence,m.iridescenceIOR.value=g.iridescenceIOR,m.iridescenceThicknessMinimum.value=g.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=g.iridescenceThicknessMaximum,g.iridescenceMap&&(m.iridescenceMap.value=g.iridescenceMap,t(g.iridescenceMap,m.iridescenceMapTransform)),g.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=g.iridescenceThicknessMap,t(g.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),g.transmission>0&&(m.transmission.value=g.transmission,m.transmissionSamplerMap.value=S.texture,m.transmissionSamplerSize.value.set(S.width,S.height),g.transmissionMap&&(m.transmissionMap.value=g.transmissionMap,t(g.transmissionMap,m.transmissionMapTransform)),m.thickness.value=g.thickness,g.thicknessMap&&(m.thicknessMap.value=g.thicknessMap,t(g.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=g.attenuationDistance,m.attenuationColor.value.copy(g.attenuationColor)),g.anisotropy>0&&(m.anisotropyVector.value.set(g.anisotropy*Math.cos(g.anisotropyRotation),g.anisotropy*Math.sin(g.anisotropyRotation)),g.anisotropyMap&&(m.anisotropyMap.value=g.anisotropyMap,t(g.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=g.specularIntensity,m.specularColor.value.copy(g.specularColor),g.specularColorMap&&(m.specularColorMap.value=g.specularColorMap,t(g.specularColorMap,m.specularColorMapTransform)),g.specularIntensityMap&&(m.specularIntensityMap.value=g.specularIntensityMap,t(g.specularIntensityMap,m.specularIntensityMapTransform))}function v(m,g){g.matcap&&(m.matcap.value=g.matcap)}function f(m,g){const S=e.get(g).light;m.referencePosition.value.setFromMatrixPosition(S.matrixWorld),m.nearDistance.value=S.shadow.camera.near,m.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function rx(i,e,t,n){let s={},r={};function a(S,M){const _=M.program;n.uniformBlockBinding(S,_,s[S.id])}function o(S,M){let _=s[S.id];_===void 0&&(v(S),_=l(S),s[S.id]=_,S.addEventListener("dispose",m));const E=M.program;n.updateUBOMapping(S,E);const y=e.render.frame;r[S.id]!==y&&(c(S),r[S.id]=y)}function l(S){const M=i.createBuffer(),_=S.__size,E=S.usage;return i.bindBuffer(i.UNIFORM_BUFFER,M),i.bufferData(i.UNIFORM_BUFFER,_,E),i.bindBuffer(i.UNIFORM_BUFFER,null),M}function c(S){const M=s[S.id],_=S.uniforms,E=S.__cache;i.bindBuffer(i.UNIFORM_BUFFER,M);for(let y=0,x=_.length;y<x;y++){const b=_[y];if(Array.isArray(b))for(let A=0,R=b.length;A<R;A++)d(b[A],y,A,E);else d(b,y,0,E)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function d(S,M,_,E){if(u(S,M,_,E)===!0){const y=S.__offset,x=S.value;if(Array.isArray(x)){let b=0;for(let A=0;A<x.length;A++){const R=x[A],D=f(R,!0);p(R,S.__data,b),b+=D.storage/Float32Array.BYTES_PER_ELEMENT}}else p(x,S.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,y,S.__data)}}function p(S,M,_){typeof S=="number"||typeof S=="boolean"?M[_]=S:S.isMatrix3?(M[_]=S.elements[0],M[_+1]=S.elements[1],M[_+2]=S.elements[2],M[_+3]=0,M[_+4]=S.elements[3],M[_+5]=S.elements[4],M[_+6]=S.elements[5],M[_+7]=0,M[_+8]=S.elements[6],M[_+9]=S.elements[7],M[_+10]=S.elements[8],M[_+11]=0):ArrayBuffer.isView(S)?M.set(S.subarray(0,M.length-_),_):S.toArray(M,_)}function u(S,M,_,E){const y=S.value,x=M+"_"+_;if(Array.isArray(y)){E[x]===void 0&&(E[x]=[]);const b=E[x];let A=!1;for(let R=0;R<y.length;R++)h(y[R],b,R)===!0&&(A=!0);return A}return h(y,E,x)}function h(S,M,_){if(M[_]===void 0)return typeof S=="number"||typeof S=="boolean"?M[_]=S:ArrayBuffer.isView(S)?M[_]=S.slice():M[_]=S.clone(),!0;{const E=M[_];if(typeof S=="number"||typeof S=="boolean"){if(E!==S)return M[_]=S,!0}else{if(ArrayBuffer.isView(S))return!0;if(E.equals(S)===!1)return E.copy(S),!0}}return!1}function v(S){const M=S.uniforms;let _=0;const E=16;for(let x=0,b=M.length;x<b;x++){const A=Array.isArray(M[x])?M[x]:[M[x]];for(let R=0,D=A.length;R<D;R++){const O=A[R],X=Array.isArray(O.value)?O.value:[O.value],k=Array.isArray(M[x])||Array.isArray(O.value);let P=_;for(let G=0,se=X.length;G<se;G++){const Y=X[G],ae=f(Y,k),le=_%E,ce=le%ae.boundary,xe=le+ce;_+=ce,xe!==0&&E-xe<ae.storage&&(_+=E-xe),G===0&&(P=_),_+=ae.storage}const F=O.type==="int"?Int32Array:O.type==="uint"?Uint32Array:Float32Array;O.__data=new F((_-P)/Float32Array.BYTES_PER_ELEMENT),O.__offset=P}}const y=_%E;return y>0&&(_+=E-y),S.__size=_,S.__cache={},this}function f(S,M){const _={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(_.boundary=4,_.storage=4):S.isVector2?(_.boundary=8,_.storage=8):S.isVector3||S.isColor?(_.boundary=16,_.storage=12):S.isVector4?(_.boundary=16,_.storage=16):S.isMatrix3?(_.boundary=16,_.storage=48):S.isMatrix4?(_.boundary=16,_.storage=64):S.isTexture?qe("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(S)?(_.boundary=16,_.storage=S.byteLength):qe("WebGLRenderer: Unsupported uniform value type.",S),M===!0&&(_.boundary=16,_.storage=Math.ceil(_.storage/16)*16),_}function m(S){const M=S.target;M.removeEventListener("dispose",m),i.deleteBuffer(s[M.id]),delete s[M.id],delete r[M.id]}function g(){for(const S in s)i.deleteBuffer(s[S]);s={},r={}}return{bind:a,update:o,dispose:g}}const ax=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ci=null;function ox(){return ci===null&&(ci=new nh(ax,16,16,ss,mi),ci.name="DFG_LUT",ci.minFilter=Pn,ci.magFilter=Pn,ci.wrapS=Ti,ci.wrapT=Ti,ci.generateMipmaps=!1,ci.needsUpdate=!0),ci}class lx{constructor(e={}){const{canvas:t=Tp(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:p=!1,reversedDepthBuffer:u=!1,outputBufferType:h=Gn}=e;this.isWebGLRenderer=!0;let v;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");v=n.getContextAttributes().alpha}else v=a;const f=h,m=new Set([Gl,Hl,Ol]),g=new Set([Gn,pi,dr,Ps,Nl,Bl]),S=new Uint32Array(4),M=new Int32Array(4),_={textures:[],min:[],max:[],resolution:[]};let E=null,y=null;const x=[],b=[];let A=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ai,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let D=!1,O=null,X=null,k=null,P=null;this._outputColorSpace=Ln;let F=0,G=0,se=null,Y=-1,ae=null;const le=new Gt,ce=new Gt;let xe=null;const Z=new et(0);let be=0,we=t.width,Fe=t.height,Ee=1,Je=null,Xt=null;const $e=new Gt(0,0,we,Fe),vt=new Gt(0,0,we,Fe);let bt=!1;const rt=new hr,un=new ql;let Jt=!1,Cn=!1;const Ut=new yt,oi=new z,sn=new Gt,zn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Vn=!1;function Wn(){return se===null?Ee:1}let H=n;function $n(T,B){return t.getContext(T,B)}let At,Rt,ke,Qt,ze,Xe,C,w,$,de,oe,pe,ye,te,ie,ge,I,re,ee,ve,fe,me,Oe;try{const T={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:p};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Dl}`),t.addEventListener("webglcontextlost",Ge,!1),t.addEventListener("webglcontextrestored",je,!1),t.addEventListener("webglcontextcreationerror",Te,!1),H===null){const B="webgl2";if(H=$n(B,T),H===null)throw $n(B)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}tt()}catch(T){throw t.removeEventListener("webglcontextlost",Ge,!1),t.removeEventListener("webglcontextrestored",je,!1),t.removeEventListener("webglcontextcreationerror",Te,!1),pt("WebGLRenderer: "+T.message),T}function tt(){At=new uv(H),At.init(),fe=new QS(H,At),Rt=new ev(H,At,e,fe),ke=new ZS(H,At),Rt.reversedDepthBuffer&&u&&ke.buffers.depth.setReversed(!0),X=H.createFramebuffer(),k=H.createFramebuffer(),P=H.createFramebuffer(),Qt=new pv(H),ze=new NS,Xe=new JS(H,At,ke,ze,Rt,fe,Qt),C=new dv(R),w=new gm(H),me=new Qg(H,w),$=new hv(H,w,Qt,me),de=new gv(H,$,w,me,Qt),re=new mv(H,Rt,Xe),ie=new tv(ze),oe=new US(R,C,At,Rt,me,ie),pe=new sx(R,ze),ye=new FS,te=new WS(At),I=new Jg(R,C,ke,de,v,l),ge=new KS(R,de,Rt),Oe=new rx(H,Qt,Rt,ke),ee=new jg(H,At,Qt),ve=new fv(H,At,Qt),Qt.programs=oe.programs,R.capabilities=Rt,R.extensions=At,R.properties=ze,R.renderLists=ye,R.shadowMap=ge,R.state=ke,R.info=Qt}f!==Gn&&(A=new Sv(f,t.width,t.height,o,s,r));const ue=new nx(R,H);this.xr=ue,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){const T=At.get("WEBGL_lose_context");T&&T.loseContext()},this.forceContextRestore=function(){const T=At.get("WEBGL_lose_context");T&&T.restoreContext()},this.getPixelRatio=function(){return Ee},this.setPixelRatio=function(T){T!==void 0&&(Ee=T,this.setSize(we,Fe,!1))},this.getSize=function(T){return T.set(we,Fe)},this.setSize=function(T,B,K=!0){if(ue.isPresenting){qe("WebGLRenderer: Can't change size while VR device is presenting.");return}we=T,Fe=B,t.width=Math.floor(T*Ee),t.height=Math.floor(B*Ee),K===!0&&(t.style.width=T+"px",t.style.height=B+"px"),A!==null&&A.setSize(t.width,t.height),this.setViewport(0,0,T,B)},this.getDrawingBufferSize=function(T){return T.set(we*Ee,Fe*Ee).floor()},this.setDrawingBufferSize=function(T,B,K){we=T,Fe=B,Ee=K,t.width=Math.floor(T*K),t.height=Math.floor(B*K),this.setViewport(0,0,T,B)},this.setEffects=function(T){if(f===Gn){pt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(T){for(let B=0;B<T.length;B++)if(T[B].isOutputPass===!0){qe("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}A.setEffects(T||[])},this.getCurrentViewport=function(T){return T.copy(le)},this.getViewport=function(T){return T.copy($e)},this.setViewport=function(T,B,K,V){T.isVector4?$e.set(T.x,T.y,T.z,T.w):$e.set(T,B,K,V),ke.viewport(le.copy($e).multiplyScalar(Wn()).round())},this.getScissor=function(T){return T.copy(vt)},this.setScissor=function(T,B,K,V){T.isVector4?vt.set(T.x,T.y,T.z,T.w):vt.set(T,B,K,V),ke.scissor(ce.copy(vt).multiplyScalar(Wn()).round())},this.getScissorTest=function(){return bt},this.setScissorTest=function(T){ke.setScissorTest(bt=T)},this.setOpaqueSort=function(T){Je=T},this.setTransparentSort=function(T){Xt=T},this.getClearColor=function(T){return T.copy(I.getClearColor())},this.setClearColor=function(){I.setClearColor(...arguments)},this.getClearAlpha=function(){return I.getClearAlpha()},this.setClearAlpha=function(){I.setClearAlpha(...arguments)},this.clear=function(T=!0,B=!0,K=!0){let V=0;if(T){let q=!1;if(se!==null){const Me=se.texture.format;q=m.has(Me)}if(q){const Me=se.texture.type,De=g.has(Me),_e=I.getClearColor(),Ae=I.getClearAlpha(),Ne=_e.r,Ze=_e.g,at=_e.b;De?(S[0]=Ne,S[1]=Ze,S[2]=at,S[3]=Ae,H.clearBufferuiv(H.COLOR,0,S)):(M[0]=Ne,M[1]=Ze,M[2]=at,M[3]=Ae,H.clearBufferiv(H.COLOR,0,M))}else V|=H.COLOR_BUFFER_BIT}B&&(V|=H.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),K&&(V|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),V!==0&&H.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(T){T.setRenderer(this),O=T},this.dispose=function(){t.removeEventListener("webglcontextlost",Ge,!1),t.removeEventListener("webglcontextrestored",je,!1),t.removeEventListener("webglcontextcreationerror",Te,!1),I.dispose(),ye.dispose(),te.dispose(),Xe.dispose(),ze.dispose(),C.dispose(),de.dispose(),$.dispose(),me.dispose(),Oe.dispose(),oe.dispose(),ue.dispose(),ue.removeEventListener("sessionstart",rc),ue.removeEventListener("sessionend",ac),Wi.stop()};function Ge(T){T.preventDefault(),Tc("WebGLRenderer: Context Lost."),D=!0}function je(){Tc("WebGLRenderer: Context Restored."),D=!1;const T=Qt.autoReset,B=ge.enabled,K=ge.autoUpdate,V=ge.needsUpdate,q=ge.type;tt(),Qt.autoReset=T,ge.enabled=B,ge.autoUpdate=K,ge.needsUpdate=V,ge.type=q}function Te(T){pt("WebGLRenderer: A WebGL context could not be created. Reason: ",T.statusMessage)}function St(T){const B=T.target;B.removeEventListener("dispose",St),rn(B)}function rn(T){Pi(T),ze.remove(T)}function Pi(T){const B=ze.get(T).programs;B!==void 0&&(B.forEach(function(K){oe.releaseProgram(K)}),T.isShaderMaterial&&oe.releaseShaderCache(T))}this.renderBufferDirect=function(T,B,K,V,q,Me){B===null&&(B=zn);const De=q.isMesh&&q.matrixWorld.determinantAffine()<0,_e=Eh(T,B,K,V,q);ke.setMaterial(V,De);let Ae=K.index,Ne=1;if(V.wireframe===!0){if(Ae=$.getWireframeAttribute(K),Ae===void 0)return;Ne=2}const Ze=K.drawRange,at=K.attributes.position;let Ie=Ze.start*Ne,ot=(Ze.start+Ze.count)*Ne;Me!==null&&(Ie=Math.max(Ie,Me.start*Ne),ot=Math.min(ot,(Me.start+Me.count)*Ne)),Ae!==null?(Ie=Math.max(Ie,0),ot=Math.min(ot,Ae.count)):at!=null&&(Ie=Math.max(Ie,0),ot=Math.min(ot,at.count));const Yt=ot-Ie;if(Yt<0||Yt===1/0)return;me.setup(q,V,_e,K,Ae);let Tt,kt=ee;if(Ae!==null&&(Tt=w.get(Ae),kt=ve,kt.setIndex(Tt)),q.isMesh)V.wireframe===!0?(ke.setLineWidth(V.wireframeLinewidth*Wn()),kt.setMode(H.LINES)):kt.setMode(H.TRIANGLES);else if(q.isLine){let mn=V.linewidth;mn===void 0&&(mn=1),ke.setLineWidth(mn*Wn()),q.isLineSegments?kt.setMode(H.LINES):q.isLineLoop?kt.setMode(H.LINE_LOOP):kt.setMode(H.LINE_STRIP)}else q.isPoints?kt.setMode(H.POINTS):q.isSprite&&kt.setMode(H.TRIANGLES);if(q.isBatchedMesh)if(At.get("WEBGL_multi_draw"))kt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{const mn=q._multiDrawStarts,Ue=q._multiDrawCounts,kn=q._multiDrawCount,mt=Ae?w.get(Ae).bytesPerElement:1,$i=ze.get(V).currentProgram.getUniforms();for(let gn=0;gn<kn;gn++)$i.setValue(H,"_gl_DrawID",gn),kt.render(mn[gn]/mt,Ue[gn])}else if(q.isInstancedMesh)kt.renderInstances(Ie,Yt,q.count);else if(K.isInstancedBufferGeometry){const mn=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,Ue=Math.min(K.instanceCount,mn);kt.renderInstances(Ie,Yt,Ue)}else kt.render(Ie,Yt)};function sc(T,B,K,V){O!==null&&T.isNodeMaterial&&O.setObject(V,T),Jt===!0&&ie.setState(T,K,!1),T.transparent===!0&&T.side===Hn&&T.forceSinglePass===!1?(T.side=In,T.needsUpdate=!0,Os(T,B,V),T.side=Li,T.needsUpdate=!0,Os(T,B,V),T.side=Hn):Os(T,B,V)}this.compile=function(T,B,K=null){K===null&&(K=T),O!==null&&O.renderStart(T,B,K),y=te.get(K),y.init(B),b.push(y),K.traverseVisible(function(q){q.isLight&&q.layers.test(B.layers)&&(y.pushLight(q),q.castShadow&&y.pushShadow(q))}),T!==K&&T.traverseVisible(function(q){q.isLight&&q.layers.test(B.layers)&&(y.pushLight(q),q.castShadow&&y.pushShadow(q))}),y.setupLights(),O!==null&&O.updateLights(y.state.lightsArray),Cn=this.localClippingEnabled,Jt=ie.init(this.clippingPlanes,Cn),Jt===!0&&ie.setGlobalState(this.clippingPlanes,B),O!==null&&ge.render(y.state.shadowsArray,K,B);const V=new Set;return T.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;const Me=q.material;if(Me)if(Array.isArray(Me))for(let De=0;De<Me.length;De++){const _e=Me[De];sc(_e,K,B,q),V.add(_e)}else sc(Me,K,B,q),V.add(Me)}),y=b.pop(),O!==null&&O.renderEnd(),V},this.compileAsync=function(T,B,K=null){const V=this.compile(T,B,K);return new Promise(q=>{function Me(){if(V.forEach(function(De){const Ae=ze.get(De).currentProgram;(Ae===void 0||Ae.isReady())&&V.delete(De)}),V.size===0){q(T);return}setTimeout(Me,10)}At.get("KHR_parallel_shader_compile")!==null?Me():setTimeout(Me,10)})};let Fa=null;function bh(T){Fa&&Fa(T)}function rc(){Wi.stop()}function ac(){Wi.start()}const Wi=new dh;Wi.setAnimationLoop(bh),typeof self<"u"&&Wi.setContext(self),this.setAnimationLoop=function(T){Fa=T,ue.setAnimationLoop(T),T===null?Wi.stop():Wi.start()},ue.addEventListener("sessionstart",rc),ue.addEventListener("sessionend",ac),this.render=function(T,B){if(B!==void 0&&B.isCamera!==!0){pt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;O!==null&&O.renderStart(T,B);const K=ue.enabled===!0&&ue.isPresenting===!0,V=A!==null&&(se===null||K)&&A.begin(R,se);if(T.matrixWorldAutoUpdate===!0&&T.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),ue.enabled===!0&&ue.isPresenting===!0&&(A===null||A.isCompositing()===!1)&&(ue.cameraAutoUpdate===!0&&ue.updateCamera(B),B=ue.getCamera()),T.isScene===!0&&T.onBeforeRender(R,T,B,se),y=te.get(T,b.length),y.init(B),y.state.textureUnits=Xe.getTextureUnits(),b.push(y),Ut.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),B.isArrayCamera?un.setFromArrayCamera(B):rt.setFromProjectionMatrix(Ut,ai,B.reversedDepth),Cn=this.localClippingEnabled,Jt=ie.init(this.clippingPlanes,Cn),E=ye.get(T,x.length),E.init(),x.push(E),this.info.render.frame++,ue.enabled===!0&&ue.isPresenting===!0){const De=R.xr.getDepthSensingMesh();De!==null&&Oa(De,B,-1/0,R.sortObjects)}Oa(T,B,0,R.sortObjects),E.finish(),O!==null&&O.updateLights(y.state.lightsArray),R.sortObjects===!0&&E.sort(Je,Xt),Vn=ue.enabled===!1||ue.isPresenting===!1||ue.hasDepthSensing()===!1,Vn&&I.addToRenderList(E,T),this.info.autoReset===!0&&this.info.reset(),Jt===!0&&ie.beginShadows();const q=y.state.shadowsArray;if(ge.render(q,T,B),Jt===!0&&ie.endShadows(),(V&&A.hasRenderPass())===!1){const De=E.opaque,_e=E.transmissive;if(y.setupLights(),B.isArrayCamera){const Ae=B.cameras;if(_e.length>0)for(let Ne=0,Ze=Ae.length;Ne<Ze;Ne++){const at=Ae[Ne];lc(De,_e,T,at)}Vn&&I.render(T);for(let Ne=0,Ze=Ae.length;Ne<Ze;Ne++){const at=Ae[Ne];oc(E,T,at,at.viewport)}}else _e.length>0&&lc(De,_e,T,B),Vn&&I.render(T),oc(E,T,B)}se!==null&&G===0&&(Xe.updateMultisampleRenderTarget(se),Xe.updateRenderTargetMipmap(se)),V&&A.end(R),T.isScene===!0&&T.onAfterRender(R,T,B),me.resetDefaultState(),Y=-1,ae=null,b.pop(),b.length>0?(y=b[b.length-1],Xe.setTextureUnits(y.state.textureUnits),Jt===!0&&ie.setGlobalState(R.clippingPlanes,y.state.camera)):y=null,x.pop(),x.length>0?E=x[x.length-1]:E=null,O!==null&&O.renderEnd()};function Oa(T,B,K,V){if(T.visible===!1)return;if(T.layers.test(B.layers)){if(T.isGroup)K=T.renderOrder;else if(T.isLOD)T.autoUpdate===!0&&T.update(B);else if(T.isLight)y.pushLight(T),T.castShadow&&y.pushShadow(T);else if(T.isSprite){const De=B.isArrayCamera?un:rt;if(!T.frustumCulled||T.intersectsFrustum(De)){V&&sn.setFromMatrixPosition(T.matrixWorld).applyMatrix4(Ut);const _e=de.update(T),Ae=T.material;Ae.visible&&E.push(T,_e,Ae,K,sn.z,null,B)}}else if(T.isMesh||T.isLine||T.isPoints){const De=B.isArrayCamera?un:rt;if(!T.frustumCulled||T.intersectsFrustum(De)){const _e=de.update(T),Ae=T.material;if(V&&(T.boundingSphere!==void 0?(T.boundingSphere===null&&T.computeBoundingSphere(),sn.copy(T.boundingSphere.center)):(_e.boundingSphere===null&&_e.computeBoundingSphere(),sn.copy(_e.boundingSphere.center)),sn.applyMatrix4(T.matrixWorld).applyMatrix4(Ut)),Array.isArray(Ae)){const Ne=_e.groups;for(let Ze=0,at=Ne.length;Ze<at;Ze++){const Ie=Ne[Ze],ot=Ae[Ie.materialIndex];ot&&ot.visible&&E.push(T,_e,ot,K,sn.z,Ie,B)}}else Ae.visible&&E.push(T,_e,Ae,K,sn.z,null,B)}}}const Me=T.children;for(let De=0,_e=Me.length;De<_e;De++)Oa(Me[De],B,K,V)}function oc(T,B,K,V){const{opaque:q,transmissive:Me,transparent:De}=T;y.setupLightsView(K),Jt===!0&&ie.setGlobalState(R.clippingPlanes,K),V&&ke.viewport(le.copy(V)),q.length>0&&vr(q,B,K),Me.length>0&&vr(Me,B,K),De.length>0&&vr(De,B,K),ke.buffers.depth.setTest(!0),ke.buffers.depth.setMask(!0),ke.buffers.color.setMask(!0),ke.setPolygonOffset(!1)}function lc(T,B,K,V){if((K.isScene===!0?K.overrideMaterial:null)!==null)return;if(y.state.transmissionRenderTarget[V.id]===void 0){const Ie=At.has("EXT_color_buffer_half_float")||At.has("EXT_color_buffer_float");y.state.transmissionRenderTarget[V.id]=new fi(1,1,{generateMipmaps:!0,type:Ie?mi:Gn,minFilter:Ci,samples:Math.max(4,Rt.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:dt.workingColorSpace})}const Me=y.state.transmissionRenderTarget[V.id],De=V.viewport||le;Me.setSize(De.z*R.transmissionResolutionScale,De.w*R.transmissionResolutionScale);const _e=R.getRenderTarget(),Ae=R.getActiveCubeFace(),Ne=R.getActiveMipmapLevel();R.setRenderTarget(Me),R.getClearColor(Z),be=R.getClearAlpha(),be<1&&R.setClearColor(16777215,.5),R.clear(),Vn&&I.render(K);const Ze=R.toneMapping;R.toneMapping=Ai;const at=V.viewport;if(V.viewport!==void 0&&(V.viewport=void 0),y.setupLightsView(V),Jt===!0&&ie.setGlobalState(R.clippingPlanes,V),vr(T,K,V),Xe.updateMultisampleRenderTarget(Me),Xe.updateRenderTargetMipmap(Me),At.has("WEBGL_multisampled_render_to_texture")===!1){let Ie=!1;for(let ot=0,Yt=B.length;ot<Yt;ot++){const Tt=B[ot],{object:kt,geometry:mn,material:Ue,group:kn}=Tt;if(Ue.side===Hn&&kt.layers.test(V.layers)){const mt=Ue.side;Ue.side=In,Ue.needsUpdate=!0,cc(kt,K,V,mn,Ue,kn),Ue.side=mt,Ue.needsUpdate=!0,Ie=!0}}Ie===!0&&(Xe.updateMultisampleRenderTarget(Me),Xe.updateRenderTargetMipmap(Me))}R.setRenderTarget(_e,Ae,Ne),R.setClearColor(Z,be),at!==void 0&&(V.viewport=at),R.toneMapping=Ze}function vr(T,B,K){const V=B.isScene===!0?B.overrideMaterial:null;for(let q=0,Me=T.length;q<Me;q++){const De=T[q],{object:_e,geometry:Ae,group:Ne}=De;let Ze=De.material;Ze.allowOverride===!0&&V!==null&&(Ze=V),_e.layers.test(K.layers)&&cc(_e,B,K,Ae,Ze,Ne)}}function cc(T,B,K,V,q,Me){O!==null&&q.isNodeMaterial&&O.setObject(T,q),T.onBeforeRender(R,B,K,V,q,Me),T.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,T.matrixWorld),T.normalMatrix.getNormalMatrix(T.modelViewMatrix),q.onBeforeRender(R,B,K,V,T,Me),q.transparent===!0&&q.side===Hn&&q.forceSinglePass===!1?(q.side=In,q.needsUpdate=!0,R.renderBufferDirect(K,B,V,q,T,Me),q.side=Li,q.needsUpdate=!0,R.renderBufferDirect(K,B,V,q,T,Me),q.side=Hn):R.renderBufferDirect(K,B,V,q,T,Me),T.onAfterRender(R,B,K,V,q,Me)}function dc(T){let B=0;for(const K of T)K.texture!==null&&B++;return B}function Os(T,B,K){B.isScene!==!0&&(B=zn);const V=ze.get(T),q=y.state.lights,Me=y.state.shadowsArray,De=q.state.version,_e=oe.getParameters(T,q.state,Me,B,K,y.state.lightProbeGridArray),Ae=oe.getProgramCacheKey(_e);let Ne=V.programs;V.environment=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?B.environment:null,V.fog=B.fog;const Ze=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap;V.envMap=C.get(T.envMap||V.environment,Ze),V.envMapRotation=V.environment!==null&&T.envMap===null?B.environmentRotation:T.envMapRotation,Ne===void 0&&(T.addEventListener("dispose",St),Ne=new Map,V.programs=Ne,V.programVariants=new Map);let at=Ne.get(Ae);if(at!==void 0){if(V.currentProgram===at&&V.lightsStateVersion===De)return hc(T,_e),at}else _e.uniforms=oe.getUniforms(T),O!==null&&T.isNodeMaterial&&O.build(T,K,_e),T.onBeforeCompile(_e,R),at=oe.acquireProgram(_e,Ae),Ne.set(Ae,at),V.uniforms=_e.uniforms;const Ie=V.uniforms;return(!T.isShaderMaterial&&!T.isRawShaderMaterial||T.clipping===!0)&&(Ie.clippingPlanes=ie.uniform),hc(T,_e),V.needsLights=Th(T),V.lightsStateVersion=De,V.needsLights&&(Ie.ambientLightColor.value=q.state.ambient,Ie.lightProbe.value=q.state.probe,Ie.sunLights.value=q.state.sun,Ie.sunLightShadows.value=q.state.sunShadow,Ie.directionalLights.value=q.state.directional,Ie.directionalLightShadows.value=q.state.directionalShadow,Ie.spotLights.value=q.state.spot,Ie.spotLightShadows.value=q.state.spotShadow,Ie.rectAreaLights.value=q.state.rectArea,Ie.ltc_1.value=q.state.rectAreaLTC1,Ie.ltc_2.value=q.state.rectAreaLTC2,Ie.pointLights.value=q.state.point,Ie.pointLightShadows.value=q.state.pointShadow,Ie.hemisphereLights.value=q.state.hemi,Ie.sunShadowMatrix.value=q.state.sunShadowMatrix,Ie.sunShadowCascade.value=q.state.sunShadowCascade,Ie.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Ie.spotLightMatrix.value=q.state.spotLightMatrix,Ie.spotLightMap.value=q.state.spotLightMap,Ie.pointShadowMatrix.value=q.state.pointShadowMatrix),V.numLightProbeGrids=dc(y.state.lightProbeGridArray),V.currentProgram=at,V.uniformsList=null,at}function kh(T,B,K,V,q){const Me=ze.get(T),De=Me.currentProgram.id+","+V+","+q;let _e=Me.programVariants.get(De);return _e===void 0?(_e=Os(T,B,K),Me.programVariants.set(De,_e)):(Me.currentProgram=_e,Me.uniformsList=null,Me.outputColorSpace=V,Me.toneMapping=q),_e}function uc(T){if(T.uniformsList===null){const B=T.currentProgram.getUniforms();T.uniformsList=oa.seqWithValue(B.seq,T.uniforms)}return T.uniformsList}function hc(T,B){const K=ze.get(T);K.outputColorSpace=B.outputColorSpace,K.batching=B.batching,K.batchingColor=B.batchingColor,K.instancing=B.instancing,K.instancingColor=B.instancingColor,K.instancingMorph=B.instancingMorph,K.skinning=B.skinning,K.morphTargets=B.morphTargets,K.morphNormals=B.morphNormals,K.morphColors=B.morphColors,K.morphTargetsCount=B.morphTargetsCount,K.numClippingPlanes=B.numClippingPlanes,K.numIntersection=B.numClipIntersection,K.vertexAlphas=B.vertexAlphas,K.vertexTangents=B.vertexTangents,K.toneMapping=B.toneMapping}function Eh(T,B,K,V,q){B.isScene!==!0&&(B=zn),Xe.resetTextureUnits();const Me=B.fog,De=V.isMeshStandardMaterial||V.isMeshLambertMaterial||V.isMeshPhongMaterial?B.environment:null,_e=se===null?R.outputColorSpace:se.isXRRenderTarget===!0?se.texture.colorSpace:dt.workingColorSpace,Ae=V.isMeshStandardMaterial||V.isMeshLambertMaterial&&!V.envMap||V.isMeshPhongMaterial&&!V.envMap,Ne=C.get(V.envMap||De,Ae),Ze=V.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,at=!!K.attributes.tangent&&(!!V.normalMap||V.anisotropy>0),Ie=!!K.morphAttributes.position,ot=!!K.morphAttributes.normal,Yt=!!K.morphAttributes.color;let Tt=Ai;V.toneMapped&&(se===null||se.isXRRenderTarget===!0)&&(Tt=R.toneMapping);const kt=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,mn=kt!==void 0?kt.length:0,Ue=ze.get(V),kn=y.state.lights;if(Jt===!0&&(Cn===!0||T!==ae)){const Nt=T===ae&&V.id===Y;ie.setState(V,T,Nt)}let mt=!1,$i=!1;V.version===Ue.__version?Ue.needsLights&&Ue.lightsStateVersion!==kn.state.version||q.isBatchedMesh&&Ue.batching===!1||!q.isBatchedMesh&&Ue.batching===!0||q.isBatchedMesh&&Ue.batchingColor===!0&&q._colorsTexture===null||q.isBatchedMesh&&Ue.batchingColor===!1&&q._colorsTexture!==null||q.isInstancedMesh&&Ue.instancing===!1||!q.isInstancedMesh&&Ue.instancing===!0||q.isSkinnedMesh&&Ue.skinning===!1||!q.isSkinnedMesh&&Ue.skinning===!0||q.isInstancedMesh&&Ue.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ue.instancingColor===!1&&q.instanceColor!==null||q.isInstancedMesh&&Ue.instancingMorph===!0&&q.morphTexture===null||q.isInstancedMesh&&Ue.instancingMorph===!1&&q.morphTexture!==null||Ue.envMap!==Ne||V.fog===!0&&Ue.fog!==Me||Ue.numClippingPlanes!==void 0&&(Ue.numClippingPlanes!==ie.numPlanes||Ue.numIntersection!==ie.numIntersection)||Ue.vertexAlphas!==Ze||Ue.vertexTangents!==at||Ue.morphTargets!==Ie||Ue.morphNormals!==ot||Ue.morphColors!==Yt||Ue.morphTargetsCount!==mn||Ue.numLightProbeGrids!==dc(y.state.lightProbeGridArray)?mt=!0:(Ue.outputColorSpace!==_e||Ue.toneMapping!==Tt)&&($i=!0):(mt=!0,Ue.__version=V.version);let gn=Ue.currentProgram;(mt===!0||$i===!0)&&(gn=$i===!0?kh(V,B,q,_e,Tt):Os(V,B,q),O&&V.isNodeMaterial&&O.onUpdateProgram(V,gn,Ue));let Sr=!1,Di=!1,qi=!1;const ft=gn.getUniforms(),hn=Ue.uniforms;if(ke.useProgram(gn.program)&&(Sr=!0,Di=!0,qi=!0),V.id!==Y&&(Y=V.id,Di=!0),Sr||ae!==T){ke.buffers.depth.getReversed()&&T.reversedDepth!==!0&&(T._reversedDepth=!0,T.updateProjectionMatrix()),ft.setValue(H,"projectionMatrix",T.projectionMatrix),ft.setValue(H,"viewMatrix",T.matrixWorldInverse);const an=ft.map.cameraPosition;an!==void 0&&an.setValue(H,oi.setFromMatrixPosition(T.matrixWorld)),Rt.logarithmicDepthBuffer&&ft.setValue(H,"logDepthBufFC",2/(Math.log(T.far+1)/Math.LN2)),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&ft.setValue(H,"isOrthographic",T.isOrthographicCamera===!0),ae!==T&&(ae=T,Di=!0,qi=!0)}if(Ue.needsLights&&(kn.state.sunShadowMap.length>0&&ft.setValue(H,"sunShadowMap",kn.state.sunShadowMap,Xe),kn.state.directionalShadowMap.length>0&&ft.setValue(H,"directionalShadowMap",kn.state.directionalShadowMap,Xe),kn.state.spotShadowMap.length>0&&ft.setValue(H,"spotShadowMap",kn.state.spotShadowMap,Xe),kn.state.pointShadowMap.length>0&&ft.setValue(H,"pointShadowMap",kn.state.pointShadowMap,Xe)),q.isSkinnedMesh){ft.setOptional(H,q,"bindMatrix"),ft.setOptional(H,q,"bindMatrixInverse");const Nt=q.skeleton;Nt&&(Nt.boneTexture===null&&Nt.computeBoneTexture(),ft.setValue(H,"boneTexture",Nt.boneTexture,Xe))}q.isBatchedMesh&&(ft.setOptional(H,q,"batchingTexture"),ft.setValue(H,"batchingTexture",q._matricesTexture,Xe),ft.setOptional(H,q,"batchingIdTexture"),ft.setValue(H,"batchingIdTexture",q._indirectTexture,Xe),ft.setOptional(H,q,"batchingColorTexture"),q._colorsTexture!==null&&ft.setValue(H,"batchingColorTexture",q._colorsTexture,Xe));const Jn=K.morphAttributes;if((Jn.position!==void 0||Jn.normal!==void 0||Jn.color!==void 0)&&re.update(q,K,gn),(Di||Ue.receiveShadow!==q.receiveShadow)&&(Ue.receiveShadow=q.receiveShadow,ft.setValue(H,"receiveShadow",q.receiveShadow)),(V.isMeshStandardMaterial||V.isMeshLambertMaterial||V.isMeshPhongMaterial)&&V.envMap===null&&B.environment!==null&&(hn.envMapIntensity.value=B.environmentIntensity),hn.dfgLUT!==void 0&&(hn.dfgLUT.value=ox()),Di){if(ft.setValue(H,"toneMappingExposure",R.toneMappingExposure),Ue.needsLights&&wh(hn,qi),Me&&V.fog===!0&&pe.refreshFogUniforms(hn,Me),pe.refreshMaterialUniforms(hn,V,Ee,Fe,y.state.transmissionRenderTarget[T.id]),Ue.needsLights&&Ue.numLightProbeGrids>0){const Nt=_;let an=0;for(const gi of y.state.lightProbeGridArray)gi.texture!==null&&(Nt.textures[an]=gi.texture,Nt.min[an]=gi.boundingBox.min,Nt.max[an]=gi.boundingBox.max,Nt.resolution[an]=gi.resolution,an++);for(const gi in Nt)Nt[gi].length=an;hn.probesSH.value=Nt.textures,hn.probesMin.value=Nt.min,hn.probesMax.value=Nt.max,hn.probesResolution.value=Nt.resolution}oa.upload(H,uc(Ue),hn,Xe)}if(V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(oa.upload(H,uc(Ue),hn,Xe),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&ft.setValue(H,"center",q.center),ft.setValue(H,"modelViewMatrix",q.modelViewMatrix),ft.setValue(H,"normalMatrix",q.normalMatrix),ft.setValue(H,"modelMatrix",q.matrixWorld),V.uniformsGroups!==void 0){const Nt=V.uniformsGroups;for(let an=0,gi=Nt.length;an<gi;an++){const pc=Nt[an];Oe.update(pc,gn),Oe.bind(pc,gn)}}return gn}function wh(T,B){T.ambientLightColor.needsUpdate=B,T.lightProbe.needsUpdate=B,T.sunLights.needsUpdate=B,T.sunLightShadows.needsUpdate=B,T.directionalLights.needsUpdate=B,T.directionalLightShadows.needsUpdate=B,T.pointLights.needsUpdate=B,T.pointLightShadows.needsUpdate=B,T.spotLights.needsUpdate=B,T.spotLightShadows.needsUpdate=B,T.rectAreaLights.needsUpdate=B,T.hemisphereLights.needsUpdate=B}function Th(T){return T.isMeshLambertMaterial||T.isMeshToonMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isShadowMaterial||T.isShaderMaterial&&T.lights===!0}this.getActiveCubeFace=function(){return F},this.getActiveMipmapLevel=function(){return G},this.getRenderTarget=function(){return se},this.setRenderTargetTextures=function(T,B,K){const V=ze.get(T);V.__autoAllocateDepthBuffer=T.resolveDepthBuffer===!1,V.__autoAllocateDepthBuffer===!1&&(V.__useRenderToTexture=!1),ze.get(T.texture).__webglTexture=B,ze.get(T.depthTexture).__webglTexture=V.__autoAllocateDepthBuffer?void 0:K,V.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(T,B){const K=ze.get(T);K.__webglFramebuffer=B,K.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(T,B=0,K=0){se=T,F=B,G=K;let V=null,q=!1,Me=!1;if(T){const _e=ze.get(T);if(_e.__useDefaultFramebuffer!==void 0){ke.bindFramebuffer(H.FRAMEBUFFER,_e.__webglFramebuffer),le.copy(T.viewport),ce.copy(T.scissor),xe=T.scissorTest,ke.viewport(le),ke.scissor(ce),ke.setScissorTest(xe),Y=-1;return}else if(_e.__webglFramebuffer===void 0)Xe.setupRenderTarget(T);else if(_e.__hasExternalTextures)Xe.rebindTextures(T,ze.get(T.texture).__webglTexture,ze.get(T.depthTexture).__webglTexture);else if(T.depthBuffer){const Ze=T.depthTexture;if(_e.__boundDepthTexture!==Ze){if(Ze!==null&&ze.has(Ze)&&(T.width!==Ze.image.width||T.height!==Ze.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Xe.setupDepthRenderbuffer(T)}}const Ae=T.texture;(Ae.isData3DTexture||Ae.isDataArrayTexture||Ae.isCompressedArrayTexture)&&(Me=!0);const Ne=ze.get(T).__webglFramebuffer;T.isWebGLCubeRenderTarget?(Array.isArray(Ne[B])?V=Ne[B][K]:V=Ne[B],q=!0):T.samples>0&&Xe.useMultisampledRTT(T)===!1?V=ze.get(T).__webglMultisampledFramebuffer:Array.isArray(Ne)?V=Ne[K]:V=Ne,le.copy(T.viewport),ce.copy(T.scissor),xe=T.scissorTest}else le.copy($e).multiplyScalar(Ee).floor(),ce.copy(vt).multiplyScalar(Ee).floor(),xe=bt;if(K!==0&&(V=X),ke.bindFramebuffer(H.FRAMEBUFFER,V)&&ke.drawBuffers(T,V),ke.viewport(le),ke.scissor(ce),ke.setScissorTest(xe),q){const _e=ze.get(T.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+B,_e.__webglTexture,K)}else if(Me){const _e=B;for(let Ae=0;Ae<T.textures.length;Ae++){const Ne=ze.get(T.textures[Ae]);H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0+Ae,Ne.__webglTexture,K,_e)}}else if(T!==null&&K!==0){const _e=ze.get(T.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,_e.__webglTexture,K)}Y=-1};function fc(T){const B=ze.get(T);return(B.__readFormat!==T.format||B.__readType!==T.type)&&(B.__readFormat=T.format,B.__readType=T.type,B.__formatReadable=Rt.textureFormatReadable(T.format),B.__typeReadable=Rt.textureTypeReadable(T.type)),B}this.readRenderTargetPixels=function(T,B,K,V,q,Me,De,_e=0){if(!(T&&T.isWebGLRenderTarget)){pt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ae=ze.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&De!==void 0&&(Ae=Ae[De],Array.isArray(Ae)&&(Ae=Ae[0])),Ae){ke.bindFramebuffer(H.FRAMEBUFFER,Ae);try{const Ne=T.textures[_e],Ze=Ne.format,at=Ne.type;T.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+_e);const Ie=fc(Ne);if(Ie.__formatReadable===!1){pt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ie.__typeReadable===!1){pt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=T.width-V&&K>=0&&K<=T.height-q&&H.readPixels(B,K,V,q,fe.convert(Ze),fe.convert(at),Me)}finally{const Ne=se!==null?ze.get(se).__webglFramebuffer:null;ke.bindFramebuffer(H.FRAMEBUFFER,Ne)}}},this.readRenderTargetPixelsAsync=async function(T,B,K,V,q,Me,De,_e=0){if(!(T&&T.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ae=ze.get(T).__webglFramebuffer;if(T.isWebGLCubeRenderTarget&&De!==void 0&&(Ae=Ae[De],Array.isArray(Ae)&&(Ae=Ae[0])),Ae)if(B>=0&&B<=T.width-V&&K>=0&&K<=T.height-q){ke.bindFramebuffer(H.FRAMEBUFFER,Ae);const Ne=T.textures[_e],Ze=Ne.format,at=Ne.type;T.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+_e);const Ie=fc(Ne);if(Ie.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ie.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const ot=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,ot),H.bufferData(H.PIXEL_PACK_BUFFER,Me.byteLength,H.STREAM_READ),H.readPixels(B,K,V,q,fe.convert(Ze),fe.convert(at),0),H.bindBuffer(H.PIXEL_PACK_BUFFER,null);const Yt=se!==null?ze.get(se).__webglFramebuffer:null;ke.bindFramebuffer(H.FRAMEBUFFER,Yt);const Tt=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await Cp(H,Tt,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,ot),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,Me),H.bindBuffer(H.PIXEL_PACK_BUFFER,null),H.deleteBuffer(ot),H.deleteSync(Tt),Me}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(T,B=null,K=0){const V=Math.pow(2,-K),q=Math.floor(T.image.width*V),Me=Math.floor(T.image.height*V),De=B!==null?B.x:0,_e=B!==null?B.y:0;Xe.setTexture2D(T,0),H.copyTexSubImage2D(H.TEXTURE_2D,K,0,0,De,_e,q,Me),ke.unbindTexture()},this.copyTextureToTexture=function(T,B,K=null,V=null,q=0,Me=0){let De,_e,Ae,Ne,Ze,at,Ie,ot,Yt;const Tt=T.isCompressedTexture?T.mipmaps[Me]:T.image;if(K!==null)De=K.max.x-K.min.x,_e=K.max.y-K.min.y,Ae=K.isBox3?K.max.z-K.min.z:1,Ne=K.min.x,Ze=K.min.y,at=K.isBox3?K.min.z:0;else{const ft=Math.pow(2,-q);De=Math.floor(Tt.width*ft),_e=Math.floor(Tt.height*ft),T.isDataArrayTexture?Ae=Tt.depth:T.isData3DTexture?Ae=Math.floor(Tt.depth*ft):Ae=1,Ne=0,Ze=0,at=0}V!==null?(Ie=V.x,ot=V.y,Yt=V.z):(Ie=0,ot=0,Yt=0);const kt=fe.convert(B.format),mn=fe.convert(B.type);let Ue;B.isData3DTexture?(Xe.setTexture3D(B,0),Ue=H.TEXTURE_3D):B.isDataArrayTexture||B.isCompressedArrayTexture?(Xe.setTexture2DArray(B,0),Ue=H.TEXTURE_2D_ARRAY):(Xe.setTexture2D(B,0),Ue=H.TEXTURE_2D),ke.activeTexture(H.TEXTURE0),ke.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,B.flipY),ke.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,B.premultiplyAlpha),ke.pixelStorei(H.UNPACK_ALIGNMENT,B.unpackAlignment);const kn=ke.getParameter(H.UNPACK_ROW_LENGTH),mt=ke.getParameter(H.UNPACK_IMAGE_HEIGHT),$i=ke.getParameter(H.UNPACK_SKIP_PIXELS),gn=ke.getParameter(H.UNPACK_SKIP_ROWS),Sr=ke.getParameter(H.UNPACK_SKIP_IMAGES);ke.pixelStorei(H.UNPACK_ROW_LENGTH,Tt.width),ke.pixelStorei(H.UNPACK_IMAGE_HEIGHT,Tt.height),ke.pixelStorei(H.UNPACK_SKIP_PIXELS,Ne),ke.pixelStorei(H.UNPACK_SKIP_ROWS,Ze),ke.pixelStorei(H.UNPACK_SKIP_IMAGES,at);const Di=T.isDataArrayTexture||T.isData3DTexture,qi=B.isDataArrayTexture||B.isData3DTexture;if(T.isDepthTexture){const ft=ze.get(T),hn=ze.get(B),Jn=ze.get(ft.__renderTarget),Nt=ze.get(hn.__renderTarget);ke.bindFramebuffer(H.READ_FRAMEBUFFER,Jn.__webglFramebuffer),ke.bindFramebuffer(H.DRAW_FRAMEBUFFER,Nt.__webglFramebuffer);for(let an=0;an<Ae;an++)Di&&(H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,ze.get(T).__webglTexture,q,at+an),H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,ze.get(B).__webglTexture,Me,Yt+an)),H.blitFramebuffer(Ne,Ze,Ne+De,Ze+_e,Ie,ot,Ie+De,ot+_e,H.DEPTH_BUFFER_BIT,H.NEAREST);ke.bindFramebuffer(H.READ_FRAMEBUFFER,null),ke.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else if(q!==0||T.isRenderTargetTexture||ze.has(T)){const ft=ze.get(T),hn=ze.get(B);ke.bindFramebuffer(H.READ_FRAMEBUFFER,k),ke.bindFramebuffer(H.DRAW_FRAMEBUFFER,P);for(let Jn=0;Jn<Ae;Jn++)Di?H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,ft.__webglTexture,q,at+Jn):H.framebufferTexture2D(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,ft.__webglTexture,q),qi?H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,hn.__webglTexture,Me,Yt+Jn):H.framebufferTexture2D(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,hn.__webglTexture,Me),q!==0?H.blitFramebuffer(Ne,Ze,Ne+De,Ze+_e,Ie,ot,Ie+De,ot+_e,H.COLOR_BUFFER_BIT,H.NEAREST):qi?H.copyTexSubImage3D(Ue,Me,Ie,ot,Yt+Jn,Ne,Ze,De,_e):H.copyTexSubImage2D(Ue,Me,Ie,ot,Ne,Ze,De,_e);ke.bindFramebuffer(H.READ_FRAMEBUFFER,null),ke.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else qi?T.isDataTexture||T.isData3DTexture?H.texSubImage3D(Ue,Me,Ie,ot,Yt,De,_e,Ae,kt,mn,Tt.data):B.isCompressedArrayTexture?H.compressedTexSubImage3D(Ue,Me,Ie,ot,Yt,De,_e,Ae,kt,Tt.data):H.texSubImage3D(Ue,Me,Ie,ot,Yt,De,_e,Ae,kt,mn,Tt):T.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,Me,Ie,ot,De,_e,kt,mn,Tt.data):T.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,Me,Ie,ot,Tt.width,Tt.height,kt,Tt.data):H.texSubImage2D(H.TEXTURE_2D,Me,Ie,ot,De,_e,kt,mn,Tt);ke.pixelStorei(H.UNPACK_ROW_LENGTH,kn),ke.pixelStorei(H.UNPACK_IMAGE_HEIGHT,mt),ke.pixelStorei(H.UNPACK_SKIP_PIXELS,$i),ke.pixelStorei(H.UNPACK_SKIP_ROWS,gn),ke.pixelStorei(H.UNPACK_SKIP_IMAGES,Sr),Me===0&&B.generateMipmaps===!0&&B.mipmapsAutoUpdate===!0&&H.generateMipmap(Ue),ke.unbindTexture()},this.initRenderTarget=function(T){ze.get(T).__webglFramebuffer===void 0&&Xe.setupRenderTarget(T)},this.initTexture=function(T){T.isCubeTexture?Xe.setTextureCube(T,0):T.isData3DTexture?Xe.setTexture3D(T,0):T.isDataArrayTexture||T.isCompressedArrayTexture?Xe.setTexture2DArray(T,0):Xe.setTexture2D(T,0),ke.unbindTexture()},this.resetState=function(){F=0,G=0,se=null,ke.reset(),me.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ai}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=dt._getDrawingBufferColorSpace(e),t.unpackColorSpace=dt._getUnpackColorSpace()}}const Rd=new Map,Ld=new Map;function cx(i){let e=i|0;return()=>(e=e*1664525+1013904223|0,(e>>>0)%1e4/1e4)}function Bn(i,e,t,n=1,s=1){const r=document.createElement("canvas");r.width=i,r.height=i;const a=r.getContext("2d");a.imageSmoothingEnabled=!1,e(a,i,cx(t));const o=new im(r);return o.colorSpace=Ln,o.magFilter=cn,o.minFilter=Ci,o.generateMipmaps=!0,o.wrapS=cr,o.wrapT=cr,(n!==1||s!==1)&&o.repeat.set(n,s),o.needsUpdate=!0,o}function yh(i){const e=Rd.get(i);if(e)return e;let t;switch(i){case"grass":t=Bn(32,(n,s,r)=>{n.fillStyle="#244230",n.fillRect(0,0,s,s);const a=["#1f3a2a","#284a35","#2e543b","#1b3324","#335d42"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)r()<.62&&(n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2));n.fillStyle="rgba(10, 18, 14, 0.22)",n.fillRect(0,0,s,1),n.fillRect(0,0,1,s),n.fillStyle="#3f7351";for(let o=0;o<10;o++){const l=Math.floor(r()*(s-2)),c=Math.floor(r()*(s-2));n.fillRect(l,c,1,2)}},101);break;case"courtyard":t=Bn(32,(n,s,r)=>{n.fillStyle="#394657",n.fillRect(0,0,s,s);const a=["#3e4c5e","#344050","#445368","#2f3a49"];for(let o=0;o<4;o++){const l=o%2*4;for(let c=-1;c<4;c++)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(c*8+l+1,o*8+1,6,6),n.fillStyle="rgba(255,255,255,0.06)",n.fillRect(c*8+l+1,o*8+1,6,1)}n.fillStyle="rgba(78, 242, 232, 0.08)",n.fillRect(0,0,s,1),n.fillRect(0,0,1,s)},202);break;case"border":t=Bn(32,(n,s,r)=>{n.fillStyle="#182223",n.fillRect(0,0,s,s);const a=["#1d292a","#141c1d","#223031","#111718"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2)},303);break;case"stone":t=Bn(16,(n,s,r)=>{n.fillStyle="#7b8a9e",n.fillRect(0,0,s,s);const a=["#8c9bb0","#6d7c90","#96a6ba","#617083"];for(let o=0;o<4;o++){const l=o%2*4;for(let c=-1;c<3;c++)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(c*8+l+1,o*4+1,7,3)}n.fillStyle="rgba(15, 23, 38, 0.35)";for(let o=0;o<4;o++)n.fillRect(0,o*4,s,1)},404);break;case"stoneDark":t=Bn(16,(n,s,r)=>{n.fillStyle="#475569",n.fillRect(0,0,s,s);const a=["#526278","#3c495b","#5e6f86","#334050"];for(let o=0;o<4;o++){const l=o%2*4;for(let c=-1;c<3;c++)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(c*8+l+1,o*4+1,7,3)}n.fillStyle="rgba(8, 12, 20, 0.45)";for(let o=0;o<4;o++)n.fillRect(0,o*4,s,1)},505);break;case"wood":t=Bn(16,(n,s,r)=>{n.fillStyle="#8b5e34",n.fillRect(0,0,s,s);const a=["#9c6b3d","#7a512b","#a87646","#694423"];for(let o=0;o<s;o+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(0,o,s,2),n.fillStyle="rgba(20, 10, 4, 0.22)",n.fillRect(0,o,s,1)},606);break;case"obsidian":t=Bn(16,(n,s,r)=>{n.fillStyle="#271e3d",n.fillRect(0,0,s,s);const a=["#342852","#1e1630","#443269","#161024"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2);n.fillStyle="#a855f7",n.fillRect(4,3,2,10),n.fillRect(6,7,5,2),n.fillRect(10,4,2,5)},707);break;case"crystal":t=Bn(16,(n,s,r)=>{n.fillStyle="#38d9d4",n.fillRect(0,0,s,s);const a=["#4ef2e8","#89fff8","#22b8cf","#bdfcff"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2);n.fillStyle="rgba(255,255,255,0.5)",n.fillRect(2,2,3,8)},808);break;case"gold":t=Bn(16,(n,s,r)=>{n.fillStyle="#eab308",n.fillRect(0,0,s,s);const a=["#facc15","#ca8a04","#fde047","#b45309"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2)},909);break;case"ice":t=Bn(16,(n,s,r)=>{n.fillStyle="#7ce8ff",n.fillRect(0,0,s,s);const a=["#bae6fd","#38bdf8","#e0f2fe","#0284c7"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2)},1010);break;case"acid":t=Bn(16,(n,s,r)=>{n.fillStyle="#65a30d",n.fillRect(0,0,s,s);const a=["#84cc16","#a3e635","#4d7c0f","#bef264"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2)},1111);break;case"iron":t=Bn(16,(n,s,r)=>{n.fillStyle="#334155",n.fillRect(0,0,s,s);const a=["#475569","#1e293b","#64748b"];for(let o=0;o<s;o+=2)for(let l=0;l<s;l+=2)n.fillStyle=a[Math.floor(r()*a.length)],n.fillRect(l,o,2,2)},1212);break;case"banner":t=Bn(16,(n,s)=>{n.fillStyle="#dc2626",n.fillRect(0,0,s,s),n.fillStyle="#ffbe3b",n.fillRect(0,0,s,2),n.fillRect(0,s-2,s,2),n.fillRect(6,4,4,8),n.fillRect(4,6,8,4)},1313);break}return Rd.set(i,t),t}function Pe(i,e){const t=JSON.stringify({c:i,t:(e==null?void 0:e.tex)||"",r:(e==null?void 0:e.roughness)??.78,m:(e==null?void 0:e.metalness)??.08,e:(e==null?void 0:e.emissive)??0,ei:(e==null?void 0:e.emissiveIntensity)??0,tr:!!(e!=null&&e.transparent),o:(e==null?void 0:e.opacity)??1,f:!!(e!=null&&e.flatShading),s:(e==null?void 0:e.side)??Li}),n=Ld.get(t);if(n)return n;const s=new Ea({color:i,map:e!=null&&e.tex?yh(e.tex):void 0,roughness:(e==null?void 0:e.roughness)??.78,metalness:(e==null?void 0:e.metalness)??.08,emissive:(e==null?void 0:e.emissive)!==void 0?new et(e.emissive):new et(0),emissiveIntensity:(e==null?void 0:e.emissiveIntensity)??0,transparent:!!(e!=null&&e.transparent),opacity:(e==null?void 0:e.opacity)??1,flatShading:!!(e!=null&&e.flatShading),side:(e==null?void 0:e.side)??Li});return Ld.set(t,s),s}function Ks(i,e,t,n="#ffffff"){const r=yh(i).clone();return r.repeat.set(e,t),r.needsUpdate=!0,new Ea({color:n,map:r,roughness:.92,metalness:.02})}const Pd=new Map,Dd=new Map,Id=new Map,Ud=new Map,Nd=new Map,Bd=new Map;function Q(i,e,t){const n=`${i.toFixed(3)}_${e.toFixed(3)}_${t.toFixed(3)}`;let s=Pd.get(n);return s||(s=new Bs(i,e,t),Pd.set(n,s)),s}function Et(i,e,t,n=8){const s=`${i.toFixed(3)}_${e.toFixed(3)}_${t.toFixed(3)}_${n}`;let r=Dd.get(s);return r||(r=new Ua(i,e,t,n),Dd.set(s,r)),r}function qt(i,e,t=6){const n=`${i.toFixed(3)}_${e.toFixed(3)}_${t}`;let s=Id.get(n);return s||(s=new Xl(i,e,t),Id.set(n,s)),s}function en(i,e=0){const t=`${i.toFixed(3)}_${e}`;let n=Ud.get(t);return n||(n=new Kl(i,e),Ud.set(t,n)),n}function ji(i,e=10){const t=`${i.toFixed(3)}_${e}`;let n=Nd.get(t);return n||(n=new Zl(i,e,Math.max(6,Math.round(e*.75))),Nd.set(t,n)),n}function jt(i,e,t=16){const n=`${i.toFixed(3)}_${e.toFixed(3)}_${t}`;let s=Bd.get(n);return s||(s=new Jl(i,e,6,t),Bd.set(n,s)),s}function N(i,e,t,n,s,r,a=!0,o=!0){const l=new ct(e,t);return l.position.set(n,s,r),l.castShadow=a,l.receiveShadow=o,i.add(l),l}function Fd(){const i=new wt,e=Pe("#94a3b8",{tex:"stone",roughness:.85}),t=Pe("#5a6b82",{tex:"stoneDark",roughness:.88}),n=Pe("#ffbe3b",{tex:"gold",roughness:.35,metalness:.65}),s=Pe("#4ef2e8",{tex:"crystal",emissive:"#22d3ee",emissiveIntensity:.9,roughness:.2,metalness:.15}),r=Pe("#ffffff",{tex:"banner",roughness:.7});N(i,Q(2.86,.38,2.86),t,0,.19,0),N(i,Q(2.5,.25,2.5),e,0,.5,0),N(i,Q(1.9,1.55,1.9),e,0,1.38,0),N(i,Q(1.98,.14,1.98),n,0,2.1,0),N(i,Q(1.75,.24,1.75),t,0,2.28,0);const a=[[-1.08,-1.08],[1.08,-1.08],[-1.08,1.08],[1.08,1.08]];for(const[u,h]of a)N(i,Q(.68,2.1,.68),e,u,1.22,h),N(i,Q(.76,.18,.76),t,u,2.32,h),N(i,qt(.46,.72,4),n,u,2.75,h);N(i,Q(.45,.85,.08),r,0,1.35,.98),N(i,Q(.45,.85,.08),r,0,1.35,-.98);const o=new wt;o.position.set(0,3.35,0),N(o,en(.46,0),s,0,0,0,!0,!1).scale.set(.85,1.6,.85),i.add(o);const c=N(i,jt(.78,.055,18),n,0,3.25,0,!1,!1);c.rotation.x=Math.PI*.5;const d=[];for(let u=0;u<4;u++){const h=N(i,jt(1.22+u*.14,.04,16),s,0,.7+u*.42,0,!1,!1);h.rotation.x=Math.PI*.5,h.visible=!1,d.push(h)}const p=N(i,ji(2.05,16),Pe("#38bdf8",{emissive:"#38bdf8",emissiveIntensity:.55,transparent:!0,opacity:.24,roughness:.15,side:Hn}),0,1.15,0,!1,!1);return p.visible=!1,{root:i,crystal:o,ring:c,shieldDome:p,tierRings:d}}function Zs(i,e=!1){const t=new wt,n=We[i],s=n.w,r=n.h,a=Pe("#8d9cb0",{tex:"stone",roughness:.86}),o=Pe("#526278",{tex:"stoneDark",roughness:.88}),l=Pe("#a47141",{tex:"wood",roughness:.88}),c=Pe("#475569",{tex:"iron",roughness:.5,metalness:.6}),d=Pe("#ffbe3b",{tex:"gold",roughness:.35,metalness:.65}),p=Pe("#5b4191",{tex:"obsidian",emissive:"#581c87",emissiveIntensity:.3,roughness:.45}),u=Pe(n.color,{emissive:n.color,emissiveIntensity:.45,roughness:.35});let h,v,f;switch(i){case"wall":{N(t,Q(.92,.84,.92),a,0,.42,0),N(t,Q(.98,.14,.98),o,0,.88,0);const y=[[-.32,-.32],[.32,-.32],[-.32,.32],[.32,.32]];for(const[x,b]of y)N(t,Q(.24,.2,.24),a,x,1.05,b);v=N(t,Q(.4,.78,.66),a,.5,.39,0),f=N(t,Q(.66,.78,.4),a,0,.39,.5),v.visible=!1,f.visible=!1;break}case"obsidian_wall":{N(t,Q(.94,1.02,.94),p,0,.51,0),N(t,Q(1,.16,1),o,0,1.06,0),N(t,qt(.16,.38,4),u,-.32,1.28,-.32),N(t,qt(.16,.38,4),u,.32,1.28,-.32),N(t,qt(.16,.38,4),u,-.32,1.28,.32),N(t,qt(.16,.38,4),u,.32,1.28,.32),v=N(t,Q(.4,.92,.68),p,.5,.46,0),f=N(t,Q(.68,.92,.4),p,0,.46,.5),v.visible=!1,f.visible=!1;break}case"gate":{N(t,Q(.24,1.05,.9),a,-.36,.525,0),N(t,Q(.24,1.05,.9),a,.36,.525,0),N(t,Q(.96,.24,.94),o,0,1.08,0),N(t,Q(.54,.52,.16),l,0,.72,0),N(t,Q(.56,.08,.22),c,0,.48,0),v=N(t,Q(.35,.8,.64),a,.5,.4,0),f=N(t,Q(.64,.8,.35),a,0,.4,.5),v.visible=!1,f.visible=!1;break}case"sky_wall":{N(t,Q(.84,.22,.84),o,0,.11,0),N(t,Et(.1,.14,1.75,6),c,-.32,.95,0),N(t,Et(.1,.14,1.75,6),c,.32,.95,0);const y=Pe("#38bdf8",{emissive:"#38bdf8",emissiveIntensity:.75,transparent:!0,opacity:.42,side:Hn});N(t,Q(.66,1.55,.12),y,0,1.05,0,!1,!1),N(t,en(.15,0),u,-.32,1.92,0,!1,!1),N(t,en(.15,0),u,.32,1.92,0,!1,!1);break}case"spike_trap":{N(t,Q(.88,.08,.88),c,0,.04,0,!1,!0);const y=[[-.25,-.25],[.25,-.25],[0,0],[-.25,.25],[.25,.25]];for(const[x,b]of y)N(t,qt(.09,.3,4),Pe("#cbd5e1",{metalness:.75,roughness:.28}),x,.2,b,!0,!1);break}case"rune_mine":{N(t,Et(.38,.44,.12,8),o,0,.06,0,!1,!0),h=N(t,en(.2,0),u,0,.2,0,!1,!1);break}case"archer_tower":{N(t,Q(.84,1.15,.84),a,0,.58,0),N(t,Q(.94,.26,.94),l,0,1.25,0),N(t,Q(.14,.48,.14),l,-.36,1.58,-.36),N(t,Q(.14,.48,.14),l,.36,1.58,-.36),N(t,Q(.14,.48,.14),l,-.36,1.58,.36),N(t,Q(.14,.48,.14),l,.36,1.58,.36),N(t,qt(.76,.55,4),Pe("#2f7d52",{roughness:.72}),0,2.02,0).rotation.y=Math.PI*.25,N(t,Q(.18,.18,.18),u,0,2.34,0,!1,!1);break}case"ballista":{N(t,Q(.86,.92,.86),a,0,.46,0),N(t,Q(.94,.14,.94),o,0,.98,0);const y=new wt;y.position.set(0,1.24,0),N(y,Q(.24,.22,.88),l,0,0,0),N(y,Q(.96,.12,.16),d,0,.04,-.24),N(y,Q(.12,.12,.98),c,0,.14,-.08),t.add(y),h=y;break}case"flak_tower":{N(t,Et(.4,.48,.95,8),o,0,.48,0),N(t,Et(.46,.46,.16,8),c,0,1,0);const y=new wt;y.position.set(0,1.22,0),N(y,Q(.48,.3,.48),c,0,0,0);const x=N(y,Et(.08,.1,.82,6),u,-.14,.28,-.22),b=N(y,Et(.08,.1,.82,6),u,.14,.28,-.22);x.rotation.x=-.68,b.rotation.x=-.68,t.add(y),h=y;break}case"arcane_tower":{N(t,Et(.32,.46,1.45,6),o,0,.72,0),N(t,Et(.42,.36,.18,6),d,0,1.5,0),h=N(t,en(.32,0),u,0,2.02,0,!0,!1);break}case"frost_tower":{N(t,Q(.84,.34,.84),o,0,.17,0);const y=Pe("#7ce8ff",{tex:"ice",emissive:"#38bdf8",emissiveIntensity:.55,roughness:.2}),x=N(t,qt(.38,1.65,5),y,0,1.15,0);x.castShadow=!0;const b=N(t,jt(.46,.05,12),y,0,1.32,0,!1,!1);b.rotation.x=Math.PI*.42,h=b;break}case"alch_mortar":{N(t,Et(.42,.48,.72,8),a,0,.36,0),N(t,Et(.38,.34,.48,8),c,0,.92,0);const y=Pe("#a3e635",{tex:"acid",emissive:"#84cc16",emissiveIntensity:.85,roughness:.2});N(t,Et(.32,.32,.14,8),y,0,1.18,0,!1,!1),h=N(t,ji(.16,8),y,0,1.38,0,!1,!1);break}case"solar_tower":{N(t,Et(.34,.48,1.35,8),d,0,.68,0),N(t,Q(.68,.16,.68),o,0,1.4,0);const y=Pe("#ffe066",{emissive:"#fbbf24",emissiveIntensity:1.1,roughness:.15}),x=new wt;x.position.set(0,1.98,0),N(x,en(.3,0),y,0,0,0,!1,!1);const b=N(x,jt(.44,.045,14),d,0,0,0,!1,!1);b.rotation.y=Math.PI*.25,t.add(x),h=x;break}case"tesla_spire":{N(t,Et(.28,.46,.85,8),o,0,.42,0),N(t,Et(.12,.16,1.1,8),c,0,1.35,0);for(let y=0;y<3;y++){const x=N(t,jt(.34-y*.05,.045,12),u,0,1.08+y*.28,0,!1,!1);x.rotation.x=Math.PI*.5}h=N(t,ji(.22,10),u,0,2.02,0,!1,!1);break}case"catapult":{N(t,Q(1.78,.26,1.78),o,0,.13,0),N(t,Q(1.5,.2,1.5),l,0,.34,0),N(t,Q(.2,1.25,.24),l,-.52,.98,0),N(t,Q(.2,1.25,.24),l,.52,.98,0),N(t,Et(.1,.1,1.3,8),c,0,1.45,0).rotation.z=Math.PI*.5;const y=new wt;y.position.set(0,1.45,0);const x=N(y,Q(.18,.18,1.75),l,0,.12,.15);x.rotation.x=-.35,N(y,ji(.28,8),u,0,.48,.85),N(y,Q(.45,.4,.42),a,0,-.32,-.58),t.add(y),h=y;break}case"chrono_obelisk":{N(t,Q(1.72,.34,1.72),p,0,.17,0),N(t,Q(1.36,.24,1.36),o,0,.46,0);const y=new wt;y.position.set(0,1.65,0),N(y,en(.55,0),u,0,0,0).scale.set(.85,1.9,.85);const b=N(y,jt(.85,.055,16),d,0,0,0,!1,!1);b.rotation.x=Math.PI*.35;const A=N(y,jt(.85,.055,16),d,0,0,0,!1,!1);A.rotation.y=Math.PI*.35,t.add(y),h=y;break}case"quarry":{N(t,Q(.88,.26,.88),o,0,.13,0),N(t,Q(.45,.42,.42),a,-.18,.46,.16),N(t,Q(.28,.28,.28),a,.22,.38,.22),N(t,Q(.14,1.15,.14),l,-.24,.78,-.24);const y=N(t,Q(.12,.12,.85),l,-.02,1.24,.02);y.rotation.y=.55;break}case"crystal_rig":{N(t,Q(.88,.26,.88),o,0,.13,0),N(t,Q(.14,1,.14),c,-.32,.68,-.32),N(t,Q(.14,1,.14),c,.32,.68,.32),N(t,Q(.76,.14,.76),c,0,1.2,0);const y=N(t,qt(.24,.86,6),Pe("#4ef2e8",{tex:"crystal",emissive:"#22d3ee",emissiveIntensity:.7}),0,.76,0);y.rotation.x=Math.PI,h=y;break}case"ether_forge":{N(t,Q(1.82,.3,1.82),o,0,.15,0),N(t,Q(1.4,.95,1.15),a,0,.76,-.18),N(t,Q(.76,.5,.2),d,0,.64,.38,!1,!1),N(t,Q(.36,1.05,.36),o,-.46,1.65,-.45),N(t,Q(.36,1.05,.36),o,.46,1.65,-.45),h=N(t,en(.28,0),Pe("#4ef2e8",{emissive:"#22d3ee",emissiveIntensity:.9}),0,1.62,.2,!1,!1);break}case"sanctuary":{N(t,Q(1.82,.28,1.82),a,0,.14,0);const y=[[-.68,-.68],[.68,-.68],[-.68,.68],[.68,.68]];for(const[b,A]of y)N(t,Et(.14,.16,1.15,8),a,b,.84,A);N(t,Q(1.68,.22,1.68),d,0,1.5,0),N(t,qt(1.08,.62,4),o,0,1.92,0).rotation.y=Math.PI*.25;const x=N(t,jt(.55,.06,14),u,0,.92,0,!1,!1);x.rotation.x=Math.PI*.5,h=x;break}case"shield_gen":{N(t,Et(.84,.92,.34,8),o,0,.17,0),N(t,Et(.44,.62,.72,8),c,0,.68,0);const y=new wt;y.position.set(0,1.48,0),N(y,ji(.32,10),u,0,0,0,!1,!1);const x=N(y,jt(.62,.05,16),u,0,0,0,!1,!1);x.rotation.x=Math.PI*.45,t.add(y),h=y;break}case"war_banner":{N(t,Q(.66,.26,.66),o,0,.13,0),N(t,Et(.06,.08,1.95,6),d,0,1.15,0),h=N(t,Q(.72,.62,.08),Pe("#ffffff",{tex:"banner",emissive:"#ff7e33",emissiveIntensity:.25}),.36,1.65,0);break}}const m=new wt,g=Pe("#38bdf8",{emissive:"#38bdf8",emissiveIntensity:.85,transparent:!0,opacity:.45,side:Hn});N(m,Q(.86,1,.12),g,0,1.55,0,!1,!1),N(m,en(.14,0),g,0,2.15,0,!1,!1),m.visible=!1,t.add(m);const S=Math.max(s,r)*.68,M=N(t,ji(S,12),Pe("#38bdf8",{emissive:"#38bdf8",emissiveIntensity:.5,transparent:!0,opacity:.22,side:Hn}),0,.85,0,!1,!1);M.visible=!1;const _=N(t,jt(Math.max(s,r)*.52,.045,16),d,0,.09,0,!1,!1);_.rotation.x=Math.PI*.5,_.visible=!1;const E=N(t,jt(Math.max(s,r)*.58,.055,16),Pe("#ffbe3b",{emissive:"#ffbe3b",emissiveIntensity:1}),0,.16,0,!1,!1);return E.rotation.x=Math.PI*.5,E.visible=!1,e&&t.traverse(y=>{if(y.isMesh){const x=y;x.castShadow=!1,x.receiveShadow=!1}}),{root:t,spinPart:h,antiAirOverlay:m,shieldShell:M,levelRing:_,overclockGlow:E,wallConnE:v,wallConnS:f}}function bo(i,e){const t=new wt,n=Mt[i]||Mt.guardian,s=e||n.color,r=new wt;t.add(r);const a=Pe("#1e293b",{tex:"iron",roughness:.55,metalness:.45}),o=Pe("#334155",{tex:"stoneDark",roughness:.65}),l=Pe(s,{emissive:s,emissiveIntensity:.55,roughness:.3}),c=Pe("#f1c29b",{roughness:.8}),d=Pe("#ffbe3b",{tex:"gold",roughness:.35,metalness:.6}),p=N(r,Q(.18,.36,.2),a,-.14,.18,0),u=N(r,Q(.18,.36,.2),a,.14,.18,0);N(r,Q(.5,.48,.32),o,0,.58,0),N(r,Q(.24,.26,.35),l,0,.6,0),i==="engineer"?N(r,Q(.42,.42,.22),d,0,.62,.24):N(r,Q(.46,.56,.08),l,0,.46,.2),N(r,Q(.36,.34,.34),c,0,.98,0),i==="archmage"||i==="ranger"||i==="summoner"?(N(r,Q(.42,.38,.42),a,0,1.02,.02),N(r,qt(.32,.36,4),l,0,1.32,.04)):(N(r,Q(.42,.24,.4),a,0,1.08,0),N(r,Q(.1,.2,.44),l,0,1.24,0)),N(r,Q(.22,.07,.06),l,0,.99,-.18,!1,!1);const h=new wt;h.position.set(-.34,.68,0),N(h,Q(.16,.38,.16),o,0,-.12,0);const v=new wt;v.position.set(.34,.68,0),N(v,Q(.16,.38,.16),o,0,-.12,0),i==="guardian"?(N(h,Q(.1,.48,.36),l,-.1,-.14,-.1),N(v,Q(.08,.72,.12),l,.04,.12,-.28).rotation.x=-.9):i==="engineer"?(N(v,Q(.1,.68,.1),d,.04,.04,-.24).rotation.x=-.8,N(v,Q(.28,.2,.22),a,.04,.28,-.46)):i==="archmage"||i==="summoner"?(N(v,Et(.045,.055,1.05,6),Pe("#6b4423",{tex:"wood"}),.06,.1,-.18),N(v,en(.16,0),l,.06,.72,-.18,!1,!1)):i==="ranger"&&(N(h,Q(.08,.68,.1),d,-.06,-.02,-.22),N(v,Q(.06,.06,.56),l,.02,-.06,-.32)),r.add(h),r.add(v);const f=N(t,jt(.54,.045,18),Pe(s,{emissive:s,emissiveIntensity:.85,transparent:!0,opacity:.75}),0,.04,0,!1,!1);f.rotation.x=Math.PI*.5;const m=N(t,jt(1.05,.06,20),Pe("#ffbe3b",{emissive:"#ffbe3b",emissiveIntensity:1,transparent:!0,opacity:.75}),0,.1,0,!1,!1);return m.rotation.x=Math.PI*.5,m.visible=!1,{root:t,body:r,leftLeg:p,rightLeg:u,leftArm:h,rightArm:v,rallyRing:m,groundRing:f}}function ko(i,e,t,n){const s=new wt,r=new wt;s.add(r);const a=Pe(e,{roughness:.72}),o=Pe("#1e293b",{tex:"iron",roughness:.65}),l=Pe("#ff4f6d",{emissive:"#ff4f6d",emissiveIntensity:1}),c=Pe("#ffbe3b",{tex:"gold",roughness:.4,metalness:.5});let d,p=n?1.85:0;if(i==="boss_dragon"){p=2.4;const h=Pe("#2a1c3b",{tex:"obsidian",emissive:"#7f1d1d",emissiveIntensity:.35}),v=Pe("#ff4f6d",{emissive:"#ff4f6d",emissiveIntensity:1.1});N(r,Q(1.1,.85,1.9),h,0,.4,0),N(r,Q(.72,.62,.95),h,0,.75,-1.25),N(r,Q(.35,.25,1.35),h,0,.25,1.45),N(r,qt(.16,.55,4),v,-.26,1.18,-1.1),N(r,qt(.16,.55,4),v,.26,1.18,-1.1),N(r,Q(.45,.12,.1),v,0,.82,-1.72,!1,!1);const f=N(r,Q(1.85,.1,1.05),v,-1.35,.65,-.1),m=N(r,Q(1.85,.1,1.05),v,1.35,.65,-.1);d=[f,m]}else if(i==="boss_troll"||i==="boss_behemoth"){const h=i==="boss_behemoth"?1.2:1;N(r,Q(.42*h,.6*h,.42*h),o,-.32*h,.3*h,0),N(r,Q(.42*h,.6*h,.42*h),o,.32*h,.3*h,0),N(r,Q(1.25*h,1.15*h,.85*h),a,0,1.12*h,0),N(r,Q(.68*h,.62*h,.65*h),o,0,1.92*h,-.05),N(r,Q(.42*h,.14*h,.1),l,0,1.96*h,-.38*h,!1,!1),N(r,Q(.46*h,.46*h,.56*h),c,-.78*h,1.52*h,0),N(r,Q(.46*h,.46*h,.56*h),c,.78*h,1.52*h,0),N(r,qt(.14*h,.5*h,4),c,-.35*h,2.32*h,0),N(r,qt(.14*h,.5*h,4),c,.35*h,2.32*h,0),N(r,Q(.18*h,1.3*h,.18*h),o,.88*h,.9*h,-.45*h),N(r,Q(.6*h,.48*h,.48*h),c,.88*h,1.55*h,-.58*h)}else if(i==="harpy"||i==="wyvern_swarm"){p=i==="wyvern_swarm"?2:1.75,N(r,Q(.42,.38,.66),a,0,.15,0),N(r,Q(.3,.28,.34),o,0,.3,-.42),N(r,Q(.18,.07,.08),l,0,.32,-.6,!1,!1);const h=N(r,Q(.78,.08,.44),a,-.56,.26,0),v=N(r,Q(.78,.08,.44),a,.56,.26,0);d=[h,v]}else if(i==="shadow_wolf")N(r,Q(.38,.3,.72),o,0,.32,0),N(r,Q(.3,.26,.34),a,0,.46,-.42),N(r,Q(.18,.07,.06),l,0,.48,-.6,!1,!1),N(r,Q(.1,.22,.1),o,-.12,.11,-.24),N(r,Q(.1,.22,.1),o,.12,.11,-.24),N(r,Q(.1,.22,.1),o,-.12,.11,.24),N(r,Q(.1,.22,.1),o,.12,.11,.24);else if(i==="siege_golem"||i==="rune_colossus"||i==="ram_brute"){const h=i==="rune_colossus"?1.05:i==="siege_golem"?.92:.78,v=Pe(e,{tex:"stoneDark",roughness:.78});N(r,Q(.32*h,.42*h,.32*h),o,-.24*h,.21*h,0),N(r,Q(.32*h,.42*h,.32*h),o,.24*h,.21*h,0),N(r,Q(.92*h,.88*h,.66*h),v,0,.84*h,0),N(r,Q(.46*h,.42*h,.44*h),v,0,1.44*h,0),N(r,Q(.3*h,.1*h,.08),l,0,1.46*h,-.24*h,!1,!1),i==="ram_brute"?N(r,Et(.14,.14,.95,6),Pe("#a47141",{tex:"wood"}),0,.7,-.45).rotation.x=Math.PI*.5:i==="rune_colossus"&&N(r,en(.24,0),Pe("#4ef2e8",{emissive:"#4ef2e8",emissiveIntensity:.9}),0,.88*h,-.36*h,!1,!1)}else if(i==="sapper"){N(r,Q(.38,.42,.3),o,0,.36,0),N(r,Q(.28,.26,.28),o,0,.7,0);const h=Pe("#ff4f6d",{emissive:"#ff4f6d",emissiveIntensity:.95});N(r,Et(.22,.22,.38,8),h,0,.54,-.28)}else{const h=i==="goblin"?.76:i==="orc"?1.05:.92;N(r,Q(.16*h,.3*h,.16*h),o,-.12*h,.15*h,0),N(r,Q(.16*h,.3*h,.16*h),o,.12*h,.15*h,0),N(r,Q(.46*h,.46*h,.3*h),a,0,.52*h,0),N(r,Q(.32*h,.32*h,.32*h),a,0,.9*h,0),N(r,Q(.2*h,.07*h,.06),l,0,.92*h,-.17*h,!1,!1),i==="pyro_mage"||i==="necromancer"?(N(r,qt(.26*h,.38*h,4),o,0,1.2*h,0),N(r,en(.14*h,0),Pe(e,{emissive:e,emissiveIntensity:.9}),.32*h,.95*h,-.2*h,!1,!1)):i==="bastion_assassin"?(N(r,Q(.08,.44,.08),l,-.3,.55,-.22).rotation.x=-1.1,N(r,Q(.08,.44,.08),l,.3,.55,-.22).rotation.x=-1.1):N(r,Q(.1*h,.46*h,.1*h),o,.3*h,.56*h,-.18*h).rotation.x=-.8}const u=N(s,jt(t?1.15:.48,.055,16),Pe("#7ce8ff",{emissive:"#7ce8ff",emissiveIntensity:.85,transparent:!0,opacity:.85}),0,.05,0,!1,!1);return u.rotation.x=Math.PI*.5,u.visible=!1,{root:s,body:r,wings:d,statusRing:u,baseHeight:p}}function Eo(i){const e=new wt;if(i==="stone"){const t=Pe("#94a3b8",{tex:"stone",roughness:.9,flatShading:!0}),n=Pe("#64748b",{tex:"stoneDark",roughness:.92,flatShading:!0});N(e,en(.42,0),t,-.1,.3,.05).scale.set(1.1,.8,1),N(e,en(.32,0),n,.25,.22,-.14).scale.set(.95,.72,.95),N(e,Q(.32,.22,.3),t,.04,.11,.28)}else{const t=Pe("#4ef2e8",{tex:"crystal",emissive:"#22d3ee",emissiveIntensity:.8,roughness:.2}),n=Pe("#334155",{tex:"stoneDark",roughness:.9});N(e,Q(.7,.18,.7),n,0,.09,0);const s=N(e,qt(.2,.92,5),t,0,.56,0);s.rotation.z=.1;const r=N(e,qt(.15,.66,5),t,-.22,.42,.14);r.rotation.z=.32;const a=N(e,qt(.14,.58,5),t,.22,.38,-.12);a.rotation.z=-.28}return e}function dx(){const i=new wt,e=Pe("#38bdf8",{emissive:"#38bdf8",emissiveIntensity:.9,roughness:.2}),t=Pe("#ffbe3b",{tex:"gold",roughness:.35,metalness:.6});N(i,en(.28,0),e,0,.95,0,!0,!1);const n=N(i,jt(.42,.04,14),t,0,.95,0,!1,!1);return n.rotation.x=Math.PI*.5,i}function ux(i){return i==="stone"?new ct(Q(.22,.22,.22),Pe("#cbd5e1",{tex:"stone"})):i==="crystal"?new ct(en(.2,0),Pe("#4ef2e8",{emissive:"#22d3ee",emissiveIntensity:.9,roughness:.2})):new ct(en(.2,0),Pe("#5ef28c",{emissive:"#22c55e",emissiveIntensity:.9,roughness:.2}))}const Be=1/U,Ji=[{label:"3E PERS.",dist:10.5,pitch:.54},{label:"PROCHE",dist:6.8,pitch:.36},{label:"TACTIQUE",dist:17.5,pitch:.96}];class hx{constructor(e,t){j(this,"renderer");j(this,"scene");j(this,"menuScene");j(this,"camera");j(this,"hudCtx");j(this,"sunLight");j(this,"hemiLight");j(this,"citPointLight");j(this,"fog");j(this,"presetIdx",0);j(this,"camYaw",0);j(this,"targetYaw",0);j(this,"camPitch",Ji[0].pitch);j(this,"targetPitch",Ji[0].pitch);j(this,"camDist",Ji[0].dist);j(this,"targetDist",Ji[0].dist);j(this,"focusX",Ft*.5*Be);j(this,"focusZ",Ot*.5*Be);j(this,"heroFaceYaw",0);j(this,"lastHeroX",0);j(this,"lastHeroY",0);j(this,"raycaster",new pm);j(this,"groundPlane",new ki(new z(0,1,0),0));j(this,"tmpVec2",new it);j(this,"tmpVec3",new z);j(this,"tmpVec3B",new z);j(this,"tmpMat4",new yt);j(this,"tmpQuat",new os);j(this,"tmpScale",new z);j(this,"tmpColor",new et);j(this,"citadelRig");j(this,"gridOverlay");j(this,"heroRig",null);j(this,"heroRigClass",null);j(this,"buildingRigs",new Map);j(this,"enemyRigs",new Map);j(this,"nodeMeshes",new Map);j(this,"summonMeshes",new Map);j(this,"pickupMeshes",new Map);j(this,"coopRigs",new Map);j(this,"projInst");j(this,"partInst");j(this,"MAX_PROJ",320);j(this,"MAX_PART",500);j(this,"fxGroup",new wt);j(this,"transientGeos",[]);j(this,"pathGroup",new wt);j(this,"cachedPathKey","");j(this,"pathGeos",[]);j(this,"ghostGroup",new wt);j(this,"ghostBuildingId",null);j(this,"ghostRig",null);j(this,"ghostMatOk",new Ea({color:"#5ef28c",emissive:"#22c55e",emissiveIntensity:.45,transparent:!0,opacity:.5}));j(this,"ghostMatBad",new Ea({color:"#ff4f6d",emissive:"#ef4444",emissiveIntensity:.45,transparent:!0,opacity:.5}));j(this,"rangeCircle");j(this,"selectRing");j(this,"dragBoxMesh");j(this,"bpGroup",new wt);j(this,"bpCachedKey","");j(this,"menuHeroRig",null);j(this,"menuHeroClass",null);j(this,"menuCitadel");j(this,"menuGoblin");j(this,"menuOrc");j(this,"active",!1);j(this,"viewW",window.innerWidth);j(this,"viewH",window.innerHeight);j(this,"dpr",1);this.glCanvas=e,this.hudCanvas=t,this.hudCtx=t.getContext("2d"),this.renderer=new lx({canvas:e,antialias:!0,powerPreference:"high-performance"}),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=Lu,this.renderer.toneMapping=Il,this.renderer.toneMappingExposure=1.12,this.renderer.outputColorSpace=Ln,this.camera=new Xn(48,16/9,.25,160),this.scene=new Fc,this.scene.background=new et("#0c1724"),this.fog=new Ma("#0c1724",.0155),this.scene.fog=this.fog,this.hemiLight=new jc("#9ec5ff","#1c2b21",.92),this.scene.add(this.hemiLight),this.sunLight=new rd("#fff2d6",1.65),this.sunLight.position.set(34,28,28),this.sunLight.castShadow=!0,this.sunLight.shadow.mapSize.set(2048,2048),this.sunLight.shadow.camera.near=2,this.sunLight.shadow.camera.far=95;const n=24;this.sunLight.shadow.camera.left=-n,this.sunLight.shadow.camera.right=n,this.sunLight.shadow.camera.top=n,this.sunLight.shadow.camera.bottom=-n,this.sunLight.shadow.bias=-6e-4,this.scene.add(this.sunLight),this.scene.add(this.sunLight.target),this.citPointLight=new sd("#4ef2e8",2.6,14,1.5),this.citPointLight.position.set(_n+ht*.5,3.8,ln+ht*.5),this.scene.add(this.citPointLight),this.buildTerrain(this.scene),this.gridOverlay=this.createGridLines(),this.gridOverlay.visible=!1,this.scene.add(this.gridOverlay),this.citadelRig=Fd(),this.citadelRig.root.position.set(_n+ht*.5,0,ln+ht*.5),this.scene.add(this.citadelRig.root);const s=ji(.16,7),r=new ks({color:"#ffffff"});this.projInst=new qc(s,r,this.MAX_PROJ),this.projInst.instanceMatrix.setUsage(kc),this.projInst.frustumCulled=!1,this.projInst.count=0,this.scene.add(this.projInst);const a=Q(.16,.16,.16),o=new ks({color:"#ffffff"});this.partInst=new qc(a,o,this.MAX_PART),this.partInst.instanceMatrix.setUsage(kc),this.partInst.frustumCulled=!1,this.partInst.count=0,this.scene.add(this.partInst),this.scene.add(this.pathGroup),this.scene.add(this.fxGroup),this.scene.add(this.ghostGroup),this.scene.add(this.bpGroup),this.rangeCircle=new ct(jt(1,.03,44),new ks({color:"#4ef2e8",transparent:!0,opacity:.72})),this.rangeCircle.rotation.x=Math.PI*.5,this.rangeCircle.position.y=.08,this.rangeCircle.visible=!1,this.scene.add(this.rangeCircle),this.selectRing=new ct(jt(.75,.06,24),new ks({color:"#ffe066",transparent:!0,opacity:.9})),this.selectRing.rotation.x=Math.PI*.5,this.selectRing.position.y=.09,this.selectRing.visible=!1,this.scene.add(this.selectRing),this.dragBoxMesh=new ct(Q(1,.12,1),new ks({color:"#4ef2e8",transparent:!0,opacity:.34})),this.dragBoxMesh.visible=!1,this.scene.add(this.dragBoxMesh),this.menuScene=new Fc,this.buildMenuDiorama(),this.resize()}setActive(e){this.active=e,this.glCanvas.hidden=!e,this.hudCanvas.hidden=!e,e&&this.resize()}getCameraYaw(){return this.camYaw}getCameraPresetLabel(){return Ji[this.presetIdx].label}cycleCameraPreset(){this.presetIdx=(this.presetIdx+1)%Ji.length;const e=Ji[this.presetIdx];return this.targetDist=e.dist,this.targetPitch=e.pitch,e.label}adjustCameraOrbit(e,t){this.targetYaw-=e*.0068,this.targetPitch=Se(this.targetPitch+t*.0052,.24,1.24)}adjustCameraZoom(e){const t=Math.sign(e)*1.25;this.targetDist=Se(this.targetDist+t,5.4,24);const s=.32+Se((this.targetDist-6.5)/15,0,1)*.32;this.targetPitch<s&&(this.targetPitch=s)}resize(){this.viewW=Math.max(320,window.innerWidth),this.viewH=Math.max(240,window.innerHeight),this.dpr=Math.min(2,window.devicePixelRatio||1),this.renderer.setPixelRatio(this.dpr),this.renderer.setSize(this.viewW,this.viewH,!1),this.camera.aspect=this.viewW/this.viewH,this.camera.updateProjectionMatrix(),this.hudCanvas.width=Math.round(this.viewW*this.dpr),this.hudCanvas.height=Math.round(this.viewH*this.dpr)}screenToGrid(e,t,n){const s=this.glCanvas.getBoundingClientRect(),r=(e-s.left)/Math.max(1,s.width)*2-1,a=-((t-s.top)/Math.max(1,s.height))*2+1;this.tmpVec2.set(r,a),this.raycaster.setFromCamera(this.tmpVec2,this.camera);const o=this.raycaster.ray.intersectPlane(this.groundPlane,this.tmpVec3);if(!o)return{gx:-1,gy:-1,wx:0,wy:0};const l=o.x*U,c=o.z*U;return{gx:Math.floor(o.x),gy:Math.floor(o.z),wx:l,wy:c}}buildTerrain(e){const t=Ks("border",38,38,"#9aa8a8"),n=new ct(new Ei(160,160),t);n.rotation.x=-Math.PI*.5,n.position.set(Le*.5,-.06,He*.5),n.receiveShadow=!0,e.add(n);const s=Ks("grass",Le,He),r=new ct(new Ei(Le,He),s);r.rotation.x=-Math.PI*.5,r.position.set(Le*.5,0,He*.5),r.receiveShadow=!0,e.add(r);const a=Pe("#334155",{tex:"stoneDark",roughness:.9}),o=Le-2,l=He-2,c=new ct(Q(o+.3,.14,.2),a);c.position.set(Le*.5,.05,1);const d=c.clone();d.position.set(Le*.5,.05,He-1);const p=new ct(Q(.2,.14,l+.3),a);p.position.set(1,.05,He*.5);const u=p.clone();u.position.set(Le-1,.05,He*.5),e.add(c,d,p,u);const h=Ks("courtyard",ht+2,ht+2),v=new ct(new Ei(ht+2,ht+2),h);v.rotation.x=-Math.PI*.5,v.position.set(_n+ht*.5,.015,ln+ht*.5),v.receiveShadow=!0,e.add(v);const f=Pe("#6b4423",{tex:"wood",roughness:.9}),m=Pe("#1f5136",{roughness:.85,flatShading:!0}),g=Pe("#286442",{roughness:.85,flatShading:!0}),S=Pe("#475569",{tex:"stoneDark",roughness:.92,flatShading:!0});let M=4219;const _=()=>(M=M*1664525+1013904223|0,(M>>>0)%1e4/1e4);for(let E=0;E<95;E++){let y=-14+_()*(Le+28),x=-14+_()*(He+28);if(!(y>-1.2&&y<Le+1.2&&x>-1.2&&x<He+1.2))if(_()<.72){const b=new wt,A=.85+_()*.85,R=new ct(Et(.16,.22,.9,6),f);R.position.y=.45;const D=new ct(qt(.75,1.45,6),m);D.position.y=1.45;const O=new ct(qt(.55,1.2,6),g);O.position.y=2.25,R.castShadow=!0,D.castShadow=!0,O.castShadow=!0,b.add(R,D,O),b.position.set(y,-.05,x),b.scale.setScalar(A),e.add(b)}else{const b=new ct(en(.6+_()*.9,0),S);b.position.set(y,.2,x),b.scale.set(1.2,.65+_()*.6,1),b.rotation.y=_()*zt,b.castShadow=!0,b.receiveShadow=!0,e.add(b)}}}createGridLines(){const e=[];for(let r=1;r<=Le-1;r++)e.push(r,.03,1,r,.03,He-1);for(let r=1;r<=He-1;r++)e.push(1,.03,r,Le-1,.03,r);const n=new yn;n.setAttribute("position",new It(e,3));const s=new er({color:"#e2e8f0",transparent:!0,opacity:.24});return new nm(n,s)}buildMenuDiorama(){this.menuScene.background=new et("#0c1724"),this.menuScene.fog=new Ma("#0c1724",.024);const e=new jc("#a5d8ff","#1b2c22",.95);this.menuScene.add(e);const t=new rd("#ffeec9",1.75);t.position.set(12,18,12),t.castShadow=!0,t.shadow.mapSize.set(1024,1024);const n=12;t.shadow.camera.left=-n,t.shadow.camera.right=n,t.shadow.camera.top=n,t.shadow.camera.bottom=-n,this.menuScene.add(t);const s=new sd("#4ef2e8",2.8,14,1.5);s.position.set(0,4,0),this.menuScene.add(s);const r=new ct(Q(18,1.2,16),Pe("#2d3748",{tex:"stoneDark",roughness:.92}));r.position.set(0,-.62,0),r.receiveShadow=!0,this.menuScene.add(r);const a=new ct(new Ei(17.6,15.6),Ks("grass",17,15));a.rotation.x=-Math.PI*.5,a.position.y=0,a.receiveShadow=!0,this.menuScene.add(a);const o=new ct(new Ei(5.5,5.5),Ks("courtyard",5,5));o.rotation.x=-Math.PI*.5,o.position.y=.015,o.receiveShadow=!0,this.menuScene.add(o),this.menuCitadel=Fd(),this.menuScene.add(this.menuCitadel.root);for(let p=-3;p<=3;p++){const u=Zs(p===0?"gate":"wall");u.root.position.set(p,0,-3),u.wallConnE&&p<3&&(u.wallConnE.visible=!0),this.menuScene.add(u.root);const h=Zs(p===0?"gate":"wall");h.root.position.set(p,0,3),h.wallConnE&&p<3&&(h.wallConnE.visible=!0),this.menuScene.add(h.root)}const l=[["archer_tower",-3.5,-3.5],["arcane_tower",3.5,-3.5],["ballista",-3.5,3.5],["frost_tower",3.5,3.5]];for(const[p,u,h]of l){const v=Zs(p);v.root.position.set(u,0,h),this.menuScene.add(v.root)}const c=Eo("crystal");c.position.set(5.8,0,-1.5),this.menuScene.add(c);const d=Eo("stone");d.position.set(-5.8,0,1.5),this.menuScene.add(d),this.menuGoblin=ko("goblin","#5ef28c",!1,!1),this.menuScene.add(this.menuGoblin.root),this.menuOrc=ko("orc","#a3d977",!1,!1),this.menuScene.add(this.menuOrc.root)}renderMenuScene(e,t="guardian"){if(!this.active)return;if(this.menuHeroClass!==t&&(this.menuHeroRig&&this.menuScene.remove(this.menuHeroRig.root),this.menuHeroRig=bo(t),this.menuHeroClass=t,this.menuScene.add(this.menuHeroRig.root)),this.menuCitadel.crystal.rotation.y=e*1.4,this.menuCitadel.crystal.position.y=3.35+Math.sin(e*2.5)*.14,this.menuCitadel.ring.rotation.z=e*.9,this.menuHeroRig){const s=Math.cos(e*1.1)*2.4;this.menuHeroRig.root.position.set(s,0,4.4),this.menuHeroRig.body.rotation.y=Math.sin(e*1.1)>0?Math.PI*.5:-Math.PI*.5;const a=Math.sin(e*10)*.45;this.menuHeroRig.leftLeg.rotation.x=a,this.menuHeroRig.rightLeg.rotation.x=-a}this.menuGoblin.root.position.set(-5.6,0,Math.sin(e*1.6)*2.6),this.menuGoblin.body.rotation.y=Math.cos(e*1.6)>0?Math.PI:0,this.menuOrc.root.position.set(5.6,0,Math.cos(e*1.3)*2.6),this.menuOrc.body.rotation.y=-Math.sin(e*1.3)>0?Math.PI:0;const n=e*.16+.35;this.camera.position.set(Math.sin(n)*14.5-2.2,8.2,Math.cos(n)*14.5),this.camera.lookAt(-1.4,1.3,0),this.renderer.render(this.menuScene,this.camera),this.hudCtx.clearRect(0,0,this.hudCanvas.width,this.hudCanvas.height)}clearTransientFx(){for(;this.fxGroup.children.length>0;)this.fxGroup.remove(this.fxGroup.children[0]);for(const e of this.transientGeos)e.dispose();this.transientGeos.length=0}syncHeroMesh(e,t,n,s,r,a,o,l,c,d,p){if(e.root.visible=d,!d)return;e.root.position.set(t*Be,0,n*Be);const u=Math.hypot(s,r);let h=p?this.heroFaceYaw:-a-Math.PI*.5;u>4?(h=Math.atan2(-s,-r),p&&(this.heroFaceYaw=h)):p&&(Math.hypot(t-this.lastHeroX,n-this.lastHeroY)>.05?(h=Math.atan2(-(t-this.lastHeroX),-(n-this.lastHeroY)),this.heroFaceYaw=h):h=this.camYaw);let v=h-e.body.rotation.y;for(;v>Math.PI;)v-=zt;for(;v<-Math.PI;)v+=zt;e.body.rotation.y+=v*.25;const f=u>4||c>0,m=f?Math.sin(o*2.2)*.55:0;e.leftLeg.rotation.x=m,e.rightLeg.rotation.x=-m,e.leftArm.rotation.x=-m*.7,e.rightArm.rotation.x=m*.7,e.body.position.y=c>0?.25:f?Math.abs(Math.sin(o*2.2))*.08:0,e.rallyRing.visible=l>0,l>0&&(e.rallyRing.rotation.z=o*.8)}syncPaths(e,t){const n=e.pathPreview==="on"||e.pathPreview==="auto"&&e.phase==="prep";if(this.pathGroup.visible=n,!n)return;const s=e.phase==="prep"?e.nextWavePlan.flanks:Array.from(new Set(e.activeWaves.flatMap(l=>l.flanks))),r=`${t.version}|${s.join(",")}`;if(r===this.cachedPathKey)return;for(this.cachedPathKey=r;this.pathGroup.children.length>0;)this.pathGroup.remove(this.pathGroup.children[0]);for(const l of this.pathGeos)l.dispose();this.pathGeos.length=0;const a=new er({color:"#ff6b57",transparent:!0,opacity:.85}),o=new er({color:"#b87aff",transparent:!0,opacity:.65});for(const l of s){const c=l==="N"?[{gx:Math.round(Le*.35),gy:1},{gx:Math.round(Le*.65),gy:1}]:l==="S"?[{gx:Math.round(Le*.35),gy:He-2},{gx:Math.round(Le*.65),gy:He-2}]:l==="W"?[{gx:1,gy:Math.round(He*.35)},{gx:1,gy:Math.round(He*.65)}]:[{gx:Le-2,gy:Math.round(He*.35)},{gx:Le-2,gy:Math.round(He*.65)}];for(const d of c){const p=t.tracePath(d.gx,d.gy,!1),u=t.tracePath(d.gx,d.gy,!0);if(p.length>=2){const v=p.map(g=>new z(g.x*Be,.08,g.y*Be)),f=new yn().setFromPoints(v);this.pathGeos.push(f),this.pathGroup.add(new aa(f,a));const m=new ct(en(.24,0),Pe("#ff6b57",{emissive:"#ff4f6d",emissiveIntensity:.9}));m.position.set(p[0].x*Be,.36,p[0].y*Be),this.pathGroup.add(m)}if((u.length!==p.length||u.some((v,f)=>{var m,g;return v.x!==((m=p[f])==null?void 0:m.x)||v.y!==((g=p[f])==null?void 0:g.y)}))&&u.length>=2){const v=u.map(m=>new z(m.x*Be,.06,m.y*Be)),f=new yn().setFromPoints(v);this.pathGeos.push(f),this.pathGroup.add(new aa(f,o))}}}}syncBuildOverlays(e,t){if(this.gridOverlay.visible=e.toolMode!=="none",this.rangeCircle.visible=!1,this.selectRing.visible=!1,this.dragBoxMesh.visible=!1,this.ghostGroup.visible=!1,this.bpGroup.visible=!1,e.toolMode==="none"&&e.selectedBuildingUid){const n=e.buildings.find(s=>s.uid===e.selectedBuildingUid);if(n){const s=Math.max(n.w,n.h)*.68;this.selectRing.visible=!0,this.selectRing.position.set(n.x*Be,.1,n.y*Be),this.selectRing.scale.setScalar(s/.75);const r=di(n);r>0&&(this.rangeCircle.visible=!0,this.rangeCircle.position.set(n.x*Be,.08,n.y*Be),this.rangeCircle.scale.setScalar(r*Be),this.rangeCircle.material.color.set("#4ef2e8"))}}if(e.toolMode==="build"&&e.buildMode&&e.hoverGx>=0&&e.hoverGy>=0){const n=We[e.buildMode],s=Rl(e,t,e.buildMode,e.hoverGx,e.hoverGy);if(this.ghostBuildingId!==e.buildMode){for(;this.ghostGroup.children.length>0;)this.ghostGroup.remove(this.ghostGroup.children[0]);this.ghostRig=Zs(e.buildMode,!0),this.ghostBuildingId=e.buildMode,this.ghostGroup.add(this.ghostRig.root)}if(this.ghostRig){this.ghostGroup.visible=!0;const r=e.hoverGx+n.w*.5,a=e.hoverGy+n.h*.5;this.ghostGroup.position.set(r,.04,a);const o=s.ok?this.ghostMatOk:this.ghostMatBad;this.ghostRig.root.traverse(l=>{l.isMesh&&(l.material=o)})}n.range>0&&(this.rangeCircle.visible=!0,this.rangeCircle.position.set(e.hoverGx+n.w*.5,.08,e.hoverGy+n.h*.5),this.rangeCircle.scale.setScalar(n.range*Be),this.rangeCircle.material.color.set(s.ok?"#5ef28c":"#ff4f6d"))}if((e.toolMode==="demolish"||e.toolMode==="batch_upgrade"||e.toolMode==="copy_select")&&e.dragStart){const n=e.dragEnd||e.dragStart,s=Math.min(e.dragStart.gx,n.gx),r=Math.min(e.dragStart.gy,n.gy),a=Math.max(e.dragStart.gx,n.gx),o=Math.max(e.dragStart.gy,n.gy),l=a-s+1,c=o-r+1;this.dragBoxMesh.visible=!0,this.dragBoxMesh.position.set(s+l*.5,.08,r+c*.5),this.dragBoxMesh.scale.set(l,1,c);const d=e.toolMode==="demolish"?"#ff4f6d":e.toolMode==="batch_upgrade"?"#ffbe3b":"#4ef2e8";this.dragBoxMesh.material.color.set(d)}if(e.toolMode==="paste"&&e.blueprint&&e.hoverGx>=0&&e.hoverGy>=0){const n=e.hoverGx-Math.floor(e.blueprint.w/2),s=e.hoverGy-Math.floor(e.blueprint.h/2),r=Ll(e,t,e.blueprint,n,s),a=`${n},${s}|${e.blueprint.w}x${e.blueprint.h}|${e.blueprint.items.map(o=>`${o.id}:${o.rx},${o.ry}`).join(";")}|${r.entries.map(o=>o.status).join(",")}`;if(this.bpGroup.visible=!0,a!==this.bpCachedKey){for(this.bpCachedKey=a;this.bpGroup.children.length>0;)this.bpGroup.remove(this.bpGroup.children[0]);for(const o of r.entries){const l=new ct(Q(o.item.w*.9,.85,o.item.h*.9),o.status==="valid"?this.ghostMatOk:this.ghostMatBad);l.position.set(o.gx+o.item.w*.5,.45,o.gy+o.item.h*.5),this.bpGroup.add(l)}}}}renderGame(e,t){var X;if(!this.active)return;const n=e.time;let s="#0c1724";e.phase==="wave"&&(e.activeWaves.some(k=>k.event==="blood_moon")?s="#230d16":e.activeWaves.some(k=>k.event==="ether_storm")?s="#19102a":e.activeWaves.some(k=>k.event==="crystal_rain")&&(s="#0b1e28")),this.tmpColor.set(s),this.scene.background.lerp(this.tmpColor,.08),this.fog.color.copy(this.scene.background);const r=e.tacticalPause?e.camX*Be:e.hero.alive?e.hero.x*Be:e.citadel.x*Be,a=e.tacticalPause?e.camY*Be:e.hero.alive?e.hero.y*Be:e.citadel.y*Be;Math.hypot(r-this.focusX,a-this.focusZ)>16?(this.focusX=r,this.focusZ=a):(this.focusX+=(r-this.focusX)*.16,this.focusZ+=(a-this.focusZ)*.16);const o=e.tacticalPause?Math.max(this.targetDist,16):this.targetDist,l=e.tacticalPause?Math.max(this.targetPitch,.88):this.targetPitch;this.camDist+=(o-this.camDist)*.14,this.camPitch+=(l-this.camPitch)*.14,this.camYaw+=(this.targetYaw-this.camYaw)*.18;const c=J.settings.shake&&e.shake>0?e.shake*.045:0,d=c>0?(Math.random()-.5)*c:0,p=c>0?(Math.random()-.5)*c:0,u=c>0?(Math.random()-.5)*c:0,h=e.tacticalPause?0:Math.min(1.8,this.camDist*.16),v=this.focusX-Math.sin(this.camYaw)*h,f=this.focusZ-Math.cos(this.camYaw)*h,m=e.tacticalPause?.2:.88,g=Math.cos(this.camPitch)*this.camDist,S=this.focusX+Math.sin(this.camYaw)*g+d,M=m+Math.sin(this.camPitch)*this.camDist+p,_=this.focusZ+Math.cos(this.camYaw)*g+u;this.camera.position.set(S,Math.max(1.8,M),_),this.camera.lookAt(v,m,f),this.sunLight.position.set(this.focusX+16,26,this.focusZ+14),this.sunLight.target.position.set(this.focusX,0,this.focusZ),this.sunLight.target.updateMatrixWorld(),this.citadelRig.crystal.rotation.y=n*1.4,this.citadelRig.crystal.position.y=3.35+Math.sin(n*2.6)*.14,this.citadelRig.ring.rotation.z=n*.9,this.citadelRig.shieldDome.visible=e.citadel.shield>0;for(let k=0;k<this.citadelRig.tierRings.length;k++)this.citadelRig.tierRings[k].visible=e.citadel.lvl>k+1;const E=new Set;for(const k of e.nodes){if(k.amount<=0)continue;E.add(k.uid);let P=this.nodeMeshes.get(k.uid);if(!P||P.kind!==k.kind){P&&this.scene.remove(P.mesh);const G=Eo(k.kind);this.scene.add(G),P={mesh:G,kind:k.kind},this.nodeMeshes.set(k.uid,P)}P.mesh.position.set(k.x*Be,0,k.y*Be);const F=Se(.45+.55*(k.amount/Math.max(1,k.maxAmount)),.45,1);P.mesh.scale.setScalar(F)}for(const[k,P]of this.nodeMeshes)E.has(k)||(this.scene.remove(P.mesh),this.nodeMeshes.delete(k));const y=new Set;for(const k of e.buildings){y.add(k.uid);let P=this.buildingRigs.get(k.uid);if(!P||P.id!==k.id){P&&this.scene.remove(P.rig.root);const se=Zs(k.id);this.scene.add(se.root),P={rig:se,id:k.id},this.buildingRigs.set(k.uid,P)}const F=P.rig;F.root.position.set(k.x*Be,0,k.y*Be);const G=1+Math.min(.18,(k.lvl-1)*.035);if(F.root.scale.set(1,G,1),F.antiAirOverlay.visible=!!k.antiAir,F.shieldShell.visible=k.shield>0,F.levelRing.visible=k.lvl>=2,F.overclockGlow.visible=k.overclockTimer>0,k.spec){const se=(X=rr[k.id])==null?void 0:X[k.spec];se&&(F.levelRing.visible=!0,F.levelRing.material=Pe(se.color,{emissive:se.color,emissiveIntensity:.9}))}if(k.id==="rune_mine"&&F.root.scale.setScalar(k.armed?1:.65),F.spinPart&&(k.id==="war_banner"?F.spinPart.rotation.y=Math.sin(n*4+k.uid)*.25:F.spinPart.rotation.y=n*(k.overclockTimer>0?3.2:1.5)+k.uid),Dn(k.id)){const se=t.getBuildingAtGrid(k.gx+1,k.gy),Y=t.getBuildingAtGrid(k.gx,k.gy+1);F.wallConnE&&(F.wallConnE.visible=!!(se&&Dn(se.id))),F.wallConnS&&(F.wallConnS.visible=!!(Y&&Dn(Y.id)))}}for(const[k,P]of this.buildingRigs)y.has(k)||(this.scene.remove(P.rig.root),this.buildingRigs.delete(k));if(this.heroRigClass!==e.heroClass&&(this.heroRig&&this.scene.remove(this.heroRig.root),this.heroRig=bo(e.heroClass),this.heroRigClass=e.heroClass,this.scene.add(this.heroRig.root)),this.heroRig){const k=e.hero;this.syncHeroMesh(this.heroRig,k.x,k.y,k.vx,k.vy,k.ang,k.animPhase,k.rallyDur,k.dashTime,k.alive,!0),this.lastHeroX=k.x,this.lastHeroY=k.y}const x=new Set;if(e.coopPlayers)for(const k of e.coopPlayers){x.add(k.id);let P=this.coopRigs.get(k.id);if(!P||P.cls!==k.heroClass){P&&this.scene.remove(P.rig.root);const G=bo(k.heroClass,k.color);this.scene.add(G.root),P={rig:G,cls:k.heroClass},this.coopRigs.set(k.id,P)}const F=k.hero;this.syncHeroMesh(P.rig,F.x,F.y,F.vx,F.vy,F.ang,F.animPhase,F.rallyDur,F.dashTime,F.alive,!1)}for(const[k,P]of this.coopRigs)x.has(k)||(this.scene.remove(P.rig.root),this.coopRigs.delete(k));const b=new Set;for(const k of e.summonedTurrets){b.add(k.uid);let P=this.summonMeshes.get(k.uid);P||(P=dx(),this.scene.add(P),this.summonMeshes.set(k.uid,P)),P.position.set(k.x*Be,Math.sin(n*4+k.uid)*.12,k.y*Be),P.rotation.y=n*2.4+k.uid}for(const[k,P]of this.summonMeshes)b.has(k)||(this.scene.remove(P),this.summonMeshes.delete(k));const A=new Set;for(const k of e.enemies){A.add(k.uid);let P=this.enemyRigs.get(k.uid);if(!P||P.art!==k.art){P&&this.scene.remove(P.rig.root);const se=ko(k.art,k.col,k.isBoss,k.flying);this.scene.add(se.root),P={rig:se,art:k.art},this.enemyRigs.set(k.uid,P)}const F=P.rig;if(F.root.position.set(k.x*Be,0,k.y*Be),Math.hypot(k.vx,k.vy)>1.5&&(F.body.rotation.y=Math.atan2(-k.vx,-k.vy)),k.flying){if(F.body.position.y=F.baseHeight+Math.sin(n*5.5+k.uid)*.22,F.wings){const se=Math.sin(n*12+k.uid)*.45;F.wings[0].rotation.z=se,F.wings[1].rotation.z=-se}}else{const se=k.stun>0?0:Math.abs(Math.sin(k.animPhase*2.5))*.1;F.body.position.y=se}const G=k.flash>0?1.12:1;F.body.scale.setScalar(G),k.stun>0?(F.statusRing.visible=!0,F.statusRing.material=Pe("#ffe066",{emissive:"#ffe066",emissiveIntensity:.9})):k.slow>0?(F.statusRing.visible=!0,F.statusRing.material=Pe("#7ce8ff",{emissive:"#38bdf8",emissiveIntensity:.9})):k.poisonTimer>0?(F.statusRing.visible=!0,F.statusRing.material=Pe("#a3e635",{emissive:"#84cc16",emissiveIntensity:.9})):F.statusRing.visible=!1}for(const[k,P]of this.enemyRigs)A.has(k)||(this.scene.remove(P.rig.root),this.enemyRigs.delete(k));const R=new Set;for(const k of e.pickups){R.add(k.uid);let P=this.pickupMeshes.get(k.uid);if(!P||P.kind!==k.kind){P&&this.scene.remove(P.mesh);const F=ux(k.kind);this.scene.add(F),P={mesh:F,kind:k.kind},this.pickupMeshes.set(k.uid,P)}P.mesh.position.set(k.x*Be,.28+Math.sin(n*5+k.uid)*.1,k.y*Be),P.mesh.rotation.y=n*3+k.uid}for(const[k,P]of this.pickupMeshes)R.has(k)||(this.scene.remove(P.mesh),this.pickupMeshes.delete(k));const D=Math.min(this.MAX_PROJ,e.projectiles.length);this.projInst.count=D;for(let k=0;k<D;k++){const P=e.projectiles[k],F=P.kind==="boulder"||P.kind==="acid_flask"?.9+Math.sin(Se(P.life/Math.max(.01,P.maxLife),0,1)*Math.PI)*1.4:P.kind==="flak_shell"?1.7:.95,G=Se(P.r*.36,.45,2.2);this.tmpVec3.set(P.x*Be,F,P.y*Be),this.tmpScale.set(G,G,G),this.tmpMat4.compose(this.tmpVec3,this.tmpQuat.identity(),this.tmpScale),this.projInst.setMatrixAt(k,this.tmpMat4),this.tmpColor.set(P.color),this.projInst.setColorAt(k,this.tmpColor)}this.projInst.instanceMatrix.needsUpdate=!0,this.projInst.instanceColor&&(this.projInst.instanceColor.needsUpdate=!0);const O=Math.min(this.MAX_PART,e.particles.length);this.partInst.count=O;for(let k=0;k<O;k++){const P=e.particles[k],F=Se(P.life/Math.max(.01,P.maxLife),0,1),G=Se((P.size2+(P.size-P.size2)*F)*.3,.2,1.8);this.tmpVec3.set(P.x*Be,.45+(1-F)*.9,P.y*Be),this.tmpScale.set(G,G,G),this.tmpMat4.compose(this.tmpVec3,this.tmpQuat.identity(),this.tmpScale),this.partInst.setMatrixAt(k,this.tmpMat4),this.tmpColor.set(P.color),this.partInst.setColorAt(k,this.tmpColor)}this.partInst.instanceMatrix.needsUpdate=!0,this.partInst.instanceColor&&(this.partInst.instanceColor.needsUpdate=!0),this.clearTransientFx();for(const k of e.arcs){if(k.pts.length<2)continue;const P=k.pts.map((se,Y)=>new z(se.x*Be,1.15+Math.sin(Y*1.9+n*20)*.25,se.y*Be)),F=new yn().setFromPoints(P);this.transientGeos.push(F);const G=new er({color:k.color,transparent:!0,opacity:Se(k.life/Math.max(.01,k.maxLife),0,1)});this.fxGroup.add(new aa(F,G))}for(const k of e.buildings){if(k.id!=="solar_tower"||k.beamTargetUid<=0)continue;const P=e.enemies.find(Y=>Y.uid===k.beamTargetUid&&Y.hp>0);if(!P)continue;const F=this.tmpVec3.set(k.x*Be,1.98,k.y*Be),G=this.tmpVec3B.set(P.x*Be,P.flying?2:.75,P.y*Be),se=F.distanceTo(G);if(se>.05){const Y=.05+k.beamCharge*.09,ae=new ct(Et(Y,Y,1,6),Pe(k.beamCharge>.65?"#ff7e33":"#ffe066",{emissive:k.beamCharge>.65?"#ff7e33":"#ffe066",emissiveIntensity:1.4,transparent:!0,opacity:.9}));ae.position.copy(F).add(G).multiplyScalar(.5),ae.scale.set(1,se,1),ae.quaternion.setFromUnitVectors(new z(0,1,0),G.clone().sub(F).normalize()),this.fxGroup.add(ae)}}for(const k of e.zonesFx){const P=Se(k.life/Math.max(.01,k.maxLife),0,1),F=Math.max(.3,k.r*Be);if(k.kind==="acid_pool"){const G=new ct(Et(F,F,.06,18),Pe("#84cc16",{emissive:"#65a30d",emissiveIntensity:.7,transparent:!0,opacity:Math.min(.5,P*.8)}));G.position.set(k.x*Be,.04,k.y*Be),this.fxGroup.add(G)}else{const G=k.kind==="ult_strike"?1:1-P*.4,se=new ct(jt(Math.max(.2,F*G),.07,22),Pe(k.color,{emissive:k.color,emissiveIntensity:1.1,transparent:!0,opacity:P*.9}));if(se.rotation.x=Math.PI*.5,se.position.set(k.x*Be,.14,k.y*Be),this.fxGroup.add(se),k.kind==="ult_strike"){const Y=new ct(Et(F*.32,F*.48,8.5,10),Pe(k.color,{emissive:k.color,emissiveIntensity:1.4,transparent:!0,opacity:P*.55}));Y.position.set(k.x*Be,4.25,k.y*Be),this.fxGroup.add(Y)}}}for(const k of e.enemies)if(k.telegraph>0&&k.telegraphR>0){const P=new ct(jt(k.telegraphR*Be,.08,22),Pe("#ff4f6d",{emissive:"#ff4f6d",emissiveIntensity:1.2,transparent:!0,opacity:.78}));P.rotation.x=Math.PI*.5,P.position.set(k.telegraphX*Be,.12,k.telegraphY*Be),this.fxGroup.add(P)}this.syncPaths(e,t),this.syncBuildOverlays(e,t),this.renderer.render(this.scene,this.camera),this.renderOverlayHud(e,t)}projectToScreen(e,t,n){this.tmpVec3.set(e,t,n),this.tmpVec3.project(this.camera);const s=this.tmpVec3.z>=-1&&this.tmpVec3.z<=1&&this.tmpVec3.x>=-1.15&&this.tmpVec3.x<=1.15&&this.tmpVec3.y>=-1.15&&this.tmpVec3.y<=1.15;return{x:(this.tmpVec3.x*.5+.5)*this.viewW,y:(-this.tmpVec3.y*.5+.5)*this.viewH,visible:s}}renderOverlayHud(e,t){const n=this.hudCtx;n.save(),n.setTransform(this.dpr,0,0,this.dpr,0,0),n.clearRect(0,0,this.viewW,this.viewH);for(const r of e.buildings)if(r.hp<r.maxHp||r.shield>0){const a=this.projectToScreen(r.x*Be,1.85,r.y*Be);if(!a.visible)continue;const o=r.w>1?42:28,l=Math.round(a.x-o*.5),c=Math.round(a.y);n.fillStyle="rgba(9, 13, 22, 0.85)",n.fillRect(l-1,c-1,o+2,6);const d=Se(r.hp/Math.max(1,r.maxHp),0,1);n.fillStyle=d>.5?"#5ef28c":d>.25?"#ffbe3b":"#ff4f6d",n.fillRect(l,c,Math.round(o*d),4),r.shield>0&&r.maxShield>0&&(n.fillStyle="#38bdf8",n.fillRect(l,c-3,Math.round(o*Se(r.shield/r.maxShield,0,1)),2))}for(const r of e.enemies)if(r.hp<r.maxHp||r.isBoss){const a=r.flying?3.2:r.isBoss?2.9:1.55,o=this.projectToScreen(r.x*Be,a,r.y*Be);if(!o.visible)continue;const l=r.isBoss?56:26,c=Math.round(o.x-l*.5),d=Math.round(o.y);n.fillStyle="rgba(9, 13, 22, 0.85)",n.fillRect(c-1,d-1,l+2,r.isBoss?7:5);const p=Se(r.hp/Math.max(1,r.maxHp),0,1);n.fillStyle=r.isBoss?"#ffbe3b":"#ff4f6d",n.fillRect(c,d,Math.round(l*p),r.isBoss?5:3)}if(e.coopPlayers)for(const r of e.coopPlayers){if(!r.hero.alive)continue;const a=this.projectToScreen(r.hero.x*Be,1.75,r.hero.y*Be);if(!a.visible)continue;this.drawStrokeText(n,r.name,a.x,a.y-8,r.color,11,!0);const o=34,l=Math.round(a.x-o*.5);n.fillStyle="rgba(9, 13, 22, 0.85)",n.fillRect(l-1,a.y-1,o+2,5),n.fillStyle=r.color,n.fillRect(l,a.y,Math.round(o*Se(r.hero.hp/Math.max(1,r.hero.maxHp),0,1)),3)}for(const r of e.texts){const a=Se(r.life/Math.max(.01,r.maxLife),0,1),o=this.projectToScreen(r.x*Be,1.45+(1-a)*.9,r.y*Be);o.visible&&(n.globalAlpha=Se(a*1.4,0,1),this.drawStrokeText(n,r.text,o.x,o.y,r.color,r.crit?14:11,r.crit))}n.globalAlpha=1;const s=new Set;if(e.phase==="prep")for(const r of e.nextWavePlan.flanks)s.add(r);else for(const r of e.activeWaves)for(const a of r.flanks)s.add(a);if(Math.floor(e.time*4)%2===0)for(const r of s){const a=r==="W"?1.5:r==="E"?Le-1.5:Le*.5,o=r==="N"?1.5:r==="S"?He-1.5:He*.5,l=this.projectToScreen(a,1.8,o);l.visible&&this.drawStrokeText(n,"▲ ASSAUT",l.x,l.y,"#ff4f6d",13,!0)}if(e.toolMode==="demolish"&&e.dragStart){const r=e.dragEnd||e.dragStart,a=Math.min(e.dragStart.gx,r.gx),o=Math.min(e.dragStart.gy,r.gy),l=Math.max(e.dragStart.gx,r.gx),c=Math.max(e.dragStart.gy,r.gy),d=e.buildings.filter(p=>p.gx<l+1&&p.gx+p.w>a&&p.gy<c+1&&p.gy+p.h>o);if(d.length>0){let p=0,u=0;for(const v of d){const f=pr(v);p+=f.stone,u+=f.crystal}const h=this.projectToScreen((a+l+1)*.5,1.3,(o+c+1)*.5);h.visible&&this.drawStrokeText(n,`DÉMOLIR ${d.length} (+${p}🪨${u>0?` +${u}💎`:""})`,h.x,h.y,"#ff4f6d",12,!0)}}e.tacticalPause&&(n.strokeStyle="rgba(78, 242, 232, 0.72)",n.lineWidth=4,n.strokeRect(2,2,this.viewW-4,this.viewH-4)),e.screenFlash>0&&(n.fillStyle=e.screenFlashCol,n.globalAlpha=e.screenFlash*.3,n.fillRect(0,0,this.viewW,this.viewH),n.globalAlpha=1),n.restore()}drawStrokeText(e,t,n,s,r,a,o){e.font=`${o?"700":"600"} ${a}px "Inter", "Segoe UI", system-ui, sans-serif`,e.textAlign="center",e.textBaseline="middle",e.lineWidth=3.2,e.lineJoin="round",e.strokeStyle="rgba(9, 13, 22, 0.92)",e.strokeText(t,n,s),e.fillStyle=r,e.fillText(t,n,s)}}const L=i=>document.getElementById(i),Od={N:"NORD",E:"EST",S:"SUD",W:"OUEST"},Yr=[{title:"1. Déplace-toi & Récolte",body:"Utilise Z Q S D (ou les flèches) pour déplacer ton Gardien. Approche-toi des filons de Pierre 🪨 ou de Cristaux 💎 pour les récolter automatiquement.",goal:"Objectif : Déplace ton Gardien"},{title:"2. Construis tes défenses",body:"Sélectionne une structure dans la barre en bas (ex. Mur, Tour d’Archers ou Carrière) puis fais Clic Gauche sur la carte pour la poser. Pose une Carrière près d’un filon de pierre pour un bonus ×2 !",goal:"Objectif : Pose ton 1er bâtiment"},{title:"3. Améliore ta Citadelle",body:"Appuie sur [U] (ou clique sur AMÉLIORER en haut à droite) pour débloquer de nouvelles tours et renforcer ton héros. Clique sur un bâtiment posé pour l’améliorer ou le réparer.",goal:"Objectif : Ouvre [U] ou clique Suivant"},{title:"4. Combat & Pouvoirs",body:"Ton Gardien attaque automatiquement les ennemis proches ! Utilise Espace (Ruée), [E] (Cri de Bastion), [R] (Ultime) et maintiens [F] pour réparer tes murs au contact.",goal:"Astuce : Clique Suivant quand tu es prêt"},{title:"5. Repousse la 1ère vague !",body:"Appuie sur [G] (ou clique sur LANCER VAGUE en haut) dès que tes défenses sont prêtes. Survivre jusqu’à la vague 5 et vaincre les Boss te rapporte des Essences ✨ pour les Arbres Permanents !",goal:"Objectif : Lance la Vague 1 [G]"}];class fx{constructor(e){j(this,"currentScreen","s-menu");j(this,"upgTab","base");j(this,"metaTab","defense");j(this,"bindexTab","all");j(this,"advChapter",1);j(this,"advSelectedLevel",1);j(this,"advBringStone",0);j(this,"advBringCrystal",0);j(this,"previewClass",null);j(this,"buildTab","all");j(this,"tutorialStep",null);j(this,"tutoStartX",0);j(this,"tutoStartY",0);j(this,"lastTutoStep",-1);j(this,"hintTimer",0);j(this,"lastBannerKey","");j(this,"lastBuildKey","");j(this,"lastInspKey","");j(this,"lastBatchKey","");j(this,"lastClassKey","");j(this,"lastCoopHudKey","");j(this,"lastUpgSyncKey","");j(this,"mpName",typeof localStorage<"u"&&localStorage.getItem("bastion_lan_name")||`Gardien${Math.floor(10+Math.random()*89)}`);j(this,"mpCreateDiff",J.selectedDifficulty);this.cb=e,this.advSelectedLevel=J.adventure.highestUnlocked,this.advChapter=Math.ceil(this.advSelectedLevel/10),this.bindEvents(),this.applySettingsDom(),this.refreshMenu(),Rh(t=>{const n=L("toasts"),s=document.createElement("div");s.className="toast",t.col&&(s.style.borderColor=t.col),s.innerHTML=`<b>${t.title}</b><span>${t.sub}</span>`,n.appendChild(s),setTimeout(()=>s.remove(),4600)}),ne.listeners.onLobbyChange=()=>{this.currentScreen==="s-multi"&&this.refreshMultiScreen()},ne.listeners.onError=t=>{W("error"),Rn({title:"Multijoueur LAN",sub:t,col:"#ff4f6d"})}}getVisibleBuildings(e){const t=(e==null?void 0:e.mode)==="adventure"?xr.filter(n=>pa(e,n).ok):xr;return this.buildTab==="all"?t:this.buildTab==="defense"?t.filter(n=>We[n].category==="defense"||We[n].category==="trap"):this.buildTab==="turret"?t.filter(n=>We[n].category==="turret"):t.filter(n=>We[n].category==="economy"||We[n].category==="support")}showScreen(e){this.currentScreen=e,document.querySelectorAll(".screen").forEach(t=>t.classList.remove("on")),e&&L(e).classList.add("on"),e==="s-menu"?this.refreshMenu():e==="s-adventure"?this.refreshAdventureScreen():e==="s-meta"?this.refreshMetaScreen():e==="s-buildings"?this.refreshBuildingIndex():e==="s-multi"?(ne.connect(),ne.connected&&ne.requestRooms(),this.refreshMultiScreen()):e==="s-bestiary"?this.refreshBestiary():e==="s-archives"?this.refreshArchives():e==="s-settings"&&this.refreshSettings()}bindEvents(){document.querySelectorAll("[data-nav]").forEach(n=>{n.addEventListener("click",()=>{Qe(),W("click");const s=n.dataset.nav;this.cb.getState()&&this.cb.onAbandonGame(),this.showScreen(s)})}),L("class-selector").addEventListener("click",n=>{const s=n.target.closest("[data-hclass]");if(!s)return;Qe(),W("click");const r=s.dataset.hclass;ti(r)?(this.previewClass=null,J.selectedClass=r,Vt()):this.previewClass=r,this.refreshMenu()}),L("btn-unlock-class").addEventListener("click",()=>{this.previewClass&&(Qe(),Co(this.previewClass,!0)?(J.selectedClass=this.previewClass,this.previewClass=null,Vt(),W("upgrade"),this.refreshMenu()):W("error"))}),L("insp-prio").addEventListener("click",n=>{const s=n.target.closest("[data-prio]");if(!s)return;const r=this.cb.getState();if(!r||!r.selectedBuildingUid)return;const a=r.buildings.find(l=>l.uid===r.selectedBuildingUid);if(!a)return;const o=s.dataset.prio;if(ne.role==="client"&&ne.isMultiplayer){W("click"),ne.sendCmd({kind:"prio",uid:a.uid,prio:o});return}xu(a,o),this.lastInspKey="",this.syncInspector(r)}),L("insp-spec").addEventListener("click",n=>{const s=n.target.closest("[data-spec]");if(!s)return;const r=this.cb.getState();if(!r||!r.selectedBuildingUid)return;const a=r.buildings.find(l=>l.uid===r.selectedBuildingUid);if(!a)return;const o=s.dataset.spec;if(ne.role==="client"&&ne.isMultiplayer){W("upgrade"),ne.sendCmd({kind:"spec",uid:a.uid,branch:o});return}_u(r,a,o)&&(this.lastInspKey="",this.syncInspector(r))}),L("diff-selector").addEventListener("click",n=>{const s=n.target.closest("[data-diff]");s&&(Qe(),W("click"),J.selectedDifficulty=s.dataset.diff,Vt(),this.refreshMenu())}),L("meta-tabs").addEventListener("click",n=>{const s=n.target.closest("[data-mtab]");s&&(Qe(),W("click"),this.metaTab=s.dataset.mtab,this.refreshMetaScreen())}),L("bindex-tabs").addEventListener("click",n=>{const s=n.target.closest("[data-bitab]");s&&(Qe(),W("click"),this.bindexTab=s.dataset.bitab,this.refreshBuildingIndex())}),L("adv-ch-tabs").addEventListener("click",n=>{const s=n.target.closest("[data-ch]");if(!s)return;Qe(),W("click"),this.advChapter=Number(s.dataset.ch)||1;const r=Js[this.advChapter-1];if(r){const a=Math.min(r.endLevel,Math.max(r.startLevel,J.adventure.highestUnlocked));this.advSelectedLevel=a}this.refreshAdventureScreen()}),L("adv-levels-grid").addEventListener("click",n=>{const s=n.target.closest("[data-adv-lvl]");if(!s)return;const r=Number(s.dataset.advLvl);r&&(Qe(),W("click"),this.advSelectedLevel=r,this.refreshAdventureScreen())}),L("adv-bring-stone").addEventListener("input",n=>{this.advBringStone=Number(n.target.value)||0,this.updateAdventureLoadoutUi()}),L("adv-bring-crystal").addEventListener("input",n=>{this.advBringCrystal=Number(n.target.value)||0,this.updateAdventureLoadoutUi()}),document.querySelectorAll(".adv-pct-btns").forEach(n=>{n.addEventListener("click",s=>{const r=s.target.closest("[data-pct]");if(!r)return;Qe(),W("click");const a=Number(r.dataset.pct)||0,o=n.dataset.res;o==="stone"?(this.advBringStone=Math.round(J.adventure.vaultStone*a/100),L("adv-bring-stone").value=String(this.advBringStone)):o==="crystal"&&(this.advBringCrystal=Math.round(J.adventure.vaultCrystal*a/100),L("adv-bring-crystal").value=String(this.advBringCrystal)),this.updateAdventureLoadoutUi()})}),L("btn-adv-launch").addEventListener("click",()=>{if(this.advSelectedLevel>J.adventure.highestUnlocked){W("error");return}Qe(),W("click"),this.cb.onStartAdventure(this.advSelectedLevel,this.advBringStone,this.advBringCrystal)}),L("btn-vic-next").addEventListener("click",()=>{var a;Qe(),W("click");const n=this.cb.getState(),s=((a=n==null?void 0:n.adventure)==null?void 0:a.level)||this.advSelectedLevel,r=Math.min(100,s+1);this.cb.onAbandonGame(),this.advSelectedLevel=r,this.advChapter=Math.ceil(r/10),this.showScreen("s-adventure")}),L("btn-vic-map").addEventListener("click",()=>{var r;Qe(),W("click");const n=this.cb.getState(),s=((r=n==null?void 0:n.adventure)==null?void 0:r.level)||this.advSelectedLevel;this.cb.onAbandonGame(),this.advSelectedLevel=Math.min(100,J.adventure.highestUnlocked||s),this.advChapter=Math.ceil(this.advSelectedLevel/10),this.showScreen("s-adventure")}),L("btn-over-adv").addEventListener("click",()=>{var r;Qe(),W("click");const n=this.cb.getState(),s=((r=n==null?void 0:n.adventure)==null?void 0:r.level)||this.advSelectedLevel;this.cb.onAbandonGame(),this.advSelectedLevel=s,this.advChapter=Math.ceil(s/10),this.showScreen("s-adventure")}),L("btn-meta-respec").addEventListener("click",()=>{Qe();const n=Xh();n>0&&(Rn({title:"Arbres réinitialisés",sub:`+${n} ✨ Essences d’Éther remboursées à 100 %.`,col:"#b87aff"}),this.refreshMetaScreen())}),L("btn-tuto-next").addEventListener("click",()=>{Qe(),W("click"),this.tutorialStep!==null&&(this.tutorialStep>=Yr.length-1?this.completeTutorial(!1):(this.tutorialStep+=1,this.renderTutorialCard()))}),L("btn-tuto-skip").addEventListener("click",()=>{Qe(),W("click"),this.completeTutorial(!0)}),L("btn-replay-tuto").addEventListener("click",()=>{Qe(),W("click"),J.tutorialDone=!1,Vt(),Rn({title:"Tutoriel réactivé",sub:"Il s’affichera automatiquement à ta prochaine nouvelle partie.",col:"#4ef2e8"})}),L("btn-continue").addEventListener("click",()=>{Qe(),W("click"),this.cb.onContinueSavedRun()}),L("btn-play").addEventListener("click",()=>{Qe(),W("click"),this.cb.onStartGame()}),L("btn-start-wave").addEventListener("click",()=>{const n=this.cb.getState();if(n&&n.modal==="none"){if(ne.role==="client"&&ne.isMultiplayer){W("click"),ne.sendCmd({kind:"start_wave"});return}Da(n,!0)}}),L("btn-auto-wave").addEventListener("click",()=>{const n=this.cb.getState();if(!(!n||n.modal!=="none")){if(W("click"),ne.role==="client"&&ne.isMultiplayer){ne.sendCmd({kind:"auto_wave"});return}n.autoWave=!n.autoWave,n.autoWave&&n.phase==="prep"&&n.prepTimer>3&&(n.prepTimer=3)}}),L("build-tabs").addEventListener("click",n=>{const s=n.target.closest("[data-btab]");s&&(W("click"),this.buildTab=s.dataset.btab,L("build-tabs").querySelectorAll("button").forEach(r=>r.classList.toggle("on",r===s)),this.lastBuildKey="")}),L("btn-batch").addEventListener("click",()=>{const n=this.cb.getState();!n||n.modal!=="none"||(W("click"),xn(n,n.toolMode==="batch_upgrade"?"none":"batch_upgrade"),this.lastBuildKey="",this.lastBatchKey="")}),L("btn-copy").addEventListener("click",()=>{const n=this.cb.getState();!n||n.modal!=="none"||(W("click"),xn(n,n.toolMode==="copy_select"?"none":"copy_select"),this.lastBuildKey="")}),L("btn-demolish").addEventListener("click",()=>{const n=this.cb.getState();!n||n.modal!=="none"||(W("click"),xn(n,n.toolMode==="demolish"?"none":"demolish"),this.lastBuildKey="")}),L("btn-repair-all").addEventListener("click",()=>{const n=this.cb.getState();if(!(!n||n.modal!=="none")){if(ne.role==="client"&&ne.isMultiplayer){W("repair"),ne.sendCmd({kind:"repair_all"});return}pu(n),this.lastInspKey=""}}),[1,2,3].forEach(n=>{L(`btn-spd-${n}`).addEventListener("click",()=>{const s=this.cb.getState();if(!(!s||s.modal!=="none")){if(W("click"),ne.role==="client"&&ne.isMultiplayer){ne.sendCmd({kind:"speed",speed:n});return}s.gameSpeed=n}})}),L("btn-tact-pause").addEventListener("click",()=>{const n=this.cb.getState();if(!(!n||n.modal!=="none")){if(W("click"),ne.role==="client"&&ne.isMultiplayer){ne.sendCmd({kind:"tact_pause"});return}n.tacticalPause=!n.tacticalPause}}),L("btn-paths").addEventListener("click",()=>{const n=this.cb.getState();!n||n.modal!=="none"||(W("click"),n.pathPreview=n.pathPreview==="auto"?"on":n.pathPreview==="on"?"off":"auto")}),L("btn-hud-theme").addEventListener("click",()=>{Qe(),W("click"),this.toggleTheme()}),L("btn-hud-cam").addEventListener("click",()=>{var s,r;Qe(),W("click");const n=(r=(s=this.cb).onCycleCamera)==null?void 0:r.call(s);n&&(L("btn-hud-cam").textContent=`CAM: ${n}`)}),L("btn-menu-theme").addEventListener("click",()=>{Qe(),W("click"),this.toggleTheme()}),L("opt-theme").addEventListener("click",()=>{Qe(),W("click"),this.toggleTheme()}),L("batch-close").addEventListener("click",()=>{const n=this.cb.getState();n&&(W("click"),xn(n,"none"),this.lastBatchKey="",this.lastBuildKey="")}),L("batch-filters").addEventListener("click",n=>{const s=n.target.closest("[data-bfilt]");if(!s)return;const r=this.cb.getState();r&&(W("click"),r.batchFilterId=s.dataset.bfilt,this.lastBatchKey="")}),L("batch-up-btn").addEventListener("click",()=>{const n=this.cb.getState();if(n){if(ne.role==="client"&&ne.isMultiplayer){W("upgrade"),ne.sendCmd({kind:"upgrade_batch",uids:[...n.batchSelectedUids],filterId:n.batchFilterId}),this.lastBatchKey="";return}gu(n),this.lastBatchKey=""}}),L("bp-rot").addEventListener("click",()=>{const n=this.cb.getState();!n||!n.blueprint||(W("click"),n.blueprint=yu(n.blueprint))}),L("bp-recopy").addEventListener("click",()=>{const n=this.cb.getState();n&&(W("click"),xn(n,"copy_select"))}),L("bp-close").addEventListener("click",()=>{const n=this.cb.getState();n&&(W("click"),xn(n,"none"))}),L("btn-upgrades").addEventListener("click",()=>{const n=this.cb.getState();n&&n.modal==="none"&&this.openUpgradesModal(n)}),L("btn-upg-close").addEventListener("click",()=>{const n=this.cb.getState();n&&n.modal==="upgrades"&&(W("click"),this.closeModal(n))}),L("upg-tabs").addEventListener("click",n=>{const s=n.target.closest("[data-utab]");if(!s)return;W("click"),this.upgTab=s.dataset.utab,L("upg-tabs").querySelectorAll("button").forEach(a=>a.classList.toggle("on",a===s));const r=this.cb.getState();r&&this.renderUpgradesGrid(r)}),L("btn-resume").addEventListener("click",()=>{W("click"),this.cb.onResumeGame()}),L("btn-pause-upg").addEventListener("click",()=>{const n=this.cb.getState();n&&this.openUpgradesModal(n)}),L("btn-save-quit").addEventListener("click",()=>{W("click"),this.cb.onSaveAndQuit()}),L("btn-abandon").addEventListener("click",()=>{if(W("click"),ne.isMultiplayer){this.cb.onAbandonGame(),this.showScreen("s-multi");return}const n=this.cb.getState();n&&(n.paused=!0,n.modal="over",El(n),ns(),this.openOverModal(n),this.showScreen("s-over"))}),L("btn-retry").addEventListener("click",()=>{W("click"),this.cb.onStartGame()}),L("insp-close").addEventListener("click",()=>{const n=this.cb.getState();n&&(n.selectedBuildingUid=null,this.lastInspKey="",L("inspector").hidden=!0)}),L("insp-up").addEventListener("click",()=>{const n=this.cb.getState();if(!n||!n.selectedBuildingUid)return;const s=n.buildings.find(r=>r.uid===n.selectedBuildingUid);if(s){if(ne.role==="client"&&ne.isMultiplayer){W("upgrade"),ne.sendCmd({kind:"upgrade",uid:s.uid});return}hu(n,s)&&(this.lastInspKey="")}}),L("insp-rep").addEventListener("click",()=>{const n=this.cb.getState();if(!n||!n.selectedBuildingUid)return;const s=n.buildings.find(r=>r.uid===n.selectedBuildingUid);if(s){if(ne.role==="client"&&ne.isMultiplayer){W("repair"),ne.sendCmd({kind:"repair",uid:s.uid});return}fu(n,s)&&(this.lastInspKey="")}}),L("insp-sell").addEventListener("click",()=>{const n=this.cb.getState();if(!n||!n.selectedBuildingUid)return;const s=n.buildings.find(r=>r.uid===n.selectedBuildingUid);if(s){if(ne.role==="client"&&ne.isMultiplayer){W("click"),ne.sendCmd({kind:"sell",uid:s.uid}),n.selectedBuildingUid=null,this.lastInspKey="";return}vu(n,this.cb.getPathField(),s),this.lastInspKey=""}}),L("btn-mp-back").addEventListener("click",()=>{Qe(),W("click"),ne.room&&ne.leaveRoom(),this.showScreen("s-menu")}),L("btn-mp-copy-url").addEventListener("click",()=>{var s;Qe(),W("click");const n=ne.lanUrls[0]||location.origin;(s=navigator.clipboard)==null||s.writeText(n).catch(()=>{}),Rn({title:"Lien LAN copié !",sub:n,col:"#38bdf8"})});const e=L("mp-name");e.value=this.mpName,e.addEventListener("input",()=>{const n=e.value.trim().slice(0,16)||"Gardien";this.mpName=n;try{localStorage.setItem("bastion_lan_name",n)}catch{}ne.room&&ne.updatePlayer(this.mpName,J.selectedClass)}),L("mp-class-selector").addEventListener("click",n=>{const s=n.target.closest("[data-mphclass]");if(!s)return;Qe();const r=s.dataset.mphclass;if(!ti(r)){W("error"),Rn({title:"Classe verrouillée",sub:"Débloque cette classe dans le menu principal ou en Mode Aventure.",col:"#ffbe3b"});return}W("click"),J.selectedClass=r,Vt(),ne.room&&ne.updatePlayer(this.mpName,r),this.refreshMultiScreen()}),L("mp-create-diff").addEventListener("click",n=>{const s=n.target.closest("[data-mpdiff]");s&&(Qe(),W("click"),this.mpCreateDiff=s.dataset.mpdiff,this.refreshMultiScreen())}),L("btn-mp-create").addEventListener("click",()=>{if(Qe(),W("click"),!ne.connected){ne.connect(),Rn({title:"Connexion au serveur LAN…",sub:"Réessaie dans 1 seconde ou lance le jeu via npm run dev.",col:"#ffbe3b"});return}ne.createRoom(this.mpName,J.selectedClass,this.mpCreateDiff)}),L("btn-mp-refresh").addEventListener("click",()=>{Qe(),W("click"),ne.connected?ne.requestRooms():ne.connect()}),L("mp-rooms-list").addEventListener("click",n=>{const s=n.target.closest("[data-join-room]");s&&(Qe(),W("click"),ne.joinRoom(s.dataset.joinRoom,this.mpName,J.selectedClass))});const t=()=>{const s=L("mp-join-code").value.trim().toUpperCase();if(!s){W("error");return}Qe(),W("click"),ne.joinRoom(s,this.mpName,J.selectedClass)};L("btn-mp-join").addEventListener("click",t),L("mp-join-code").addEventListener("keydown",n=>{n.key==="Enter"&&t()}),L("btn-mp-copy-code").addEventListener("click",()=>{var n;ne.room&&(Qe(),W("click"),(n=navigator.clipboard)==null||n.writeText(ne.room.code).catch(()=>{}),Rn({title:"Code salon copié !",sub:`Code : ${ne.room.code}`,col:"#4ef2e8"}))}),L("btn-mp-leave").addEventListener("click",()=>{Qe(),W("click"),ne.leaveRoom(),this.refreshMultiScreen()}),L("mp-lobby-diff").addEventListener("click",n=>{if(ne.role!=="host")return;const s=n.target.closest("[data-mpldiff]");s&&(Qe(),W("click"),ne.updateRoomDifficulty(s.dataset.mpldiff))}),L("btn-mp-start").addEventListener("click",()=>{ne.role==="host"&&(Qe(),W("click"),ne.startGame())}),L("opt-sfx").addEventListener("input",n=>{J.settings.sfx=parseFloat(n.target.value),Ao(),Vt()}),L("opt-music").addEventListener("input",n=>{J.settings.music=parseFloat(n.target.value),Ao(),Vt()}),L("opt-crt").addEventListener("click",()=>{J.settings.crt=!J.settings.crt,Vt(),this.applySettingsDom(),this.refreshSettings()}),L("opt-shake").addEventListener("click",()=>{J.settings.shake=!J.settings.shake,Vt(),this.refreshSettings()}),L("btn-reset-save").addEventListener("click",()=>{confirm("Effacer tes records, ton bestiaire et tes succès ?")&&(Dh(),this.applySettingsDom(),this.refreshSettings(),this.refreshMenu())})}toggleTheme(){J.settings.theme=J.settings.theme==="textured"?"3d":J.settings.theme==="3d"?"pixel":"textured",Vt(),this.applySettingsDom(),this.refreshSettings(),this.currentScreen==="s-menu"?this.refreshMenu():this.currentScreen==="s-multi"?this.refreshMultiScreen():this.currentScreen==="s-buildings"?this.refreshBuildingIndex():this.currentScreen==="s-bestiary"&&this.refreshBestiary()}applySettingsDom(){const e=J.settings.theme,t=e!=="pixel",n=e==="3d";document.body.classList.toggle("theme-hd",t),document.body.classList.toggle("theme-3d",n),L("fx-crt").classList.toggle("off",!J.settings.crt||t),this.lastBuildKey="";const s=L("btn-hud-theme");s.textContent=n?"THÈME: 3D":t?"THÈME: HD":"THÈME: PIXEL",s.classList.toggle("on",t),L("btn-hud-cam").hidden=!n,L("cam3d-hint").hidden=!n;const r=L("btn-menu-theme");r.textContent=n?"THÈME : MODE 3D":t?"THÈME : TEXTURES HD":"THÈME : PIXEL 16-BIT";const a=L("opt-theme");a.textContent=n?"MODE 3D (3E PERS.)":t?"TEXTURES HD":"PIXEL 16-BIT",a.classList.toggle("on",t)}setCameraLabel(e){L("btn-hud-cam").textContent=`CAM: ${e}`}refreshMenu(){L("hud").hidden=!0;const e=J.settings.theme!=="pixel";ti(J.selectedClass)||(J.selectedClass="guardian");const t=this.previewClass&&!ti(this.previewClass)?this.previewClass:J.selectedClass,n=L("class-selector");n.innerHTML=sr.map(v=>{const f=Mt[v],m=ti(v),g=t===v;return`<button type="button" data-hclass="${v}" class="class-card ${g?"on":""} ${m?"":"locked"}" style="${g?`border-color:${f.color};color:${f.color}`:""}"><img src="${cs(f.spriteKey,2,!m,e)}" alt="" /><span>${m?f.name:`🔒 ${f.short}`}</span></button>`}).join("");const s=Mt[t],r=L("class-desc");r.textContent=s.desc,r.style.color=s.color;const a=L("class-unlock-row");if(ti(t))a.hidden=!0;else{a.hidden=!1;const v=s.unlockEssenceCost||0,f=s.unlockAdvLevel?`Aventure Niv.${s.unlockAdvLevel}`:"";L("class-unlock-info").textContent=`🔒 Verrouillé · Gratuit en terminant ${f} ou achat direct :`;const m=L("btn-unlock-class");m.textContent=`✨ DÉBLOQUER (${v} ✨)`,m.disabled=J.essence<v}const o=L("diff-selector");o.innerHTML=Es.map(v=>{const f=Wt[v],m=J.selectedDifficulty===v;return`<button type="button" data-diff="${v}" class="${m?"on":""}" style="${m?`border-color:${f.color};color:${f.color}`:""}">${f.label}</button>`}).join("");const l=Wt[J.selectedDifficulty],c=L("diff-desc");c.textContent=l.desc,c.style.color=l.color;const d=Ih(),p=L("btn-continue");if(d)if(p.hidden=!1,d.mode==="adventure"&&d.adventureLevel)p.textContent=`REPRENDRE (AVENTURE NIV.${d.adventureLevel} · V.${d.wave})`;else{const v=Wt[d.difficulty].label;p.textContent=`REPRENDRE (V.${d.wave} · ${v})`}else p.hidden=!0;L("menu-essence").textContent=`${J.essence}`,L("menu-adv-prog").textContent=`${J.adventure.completedLevels.length}/100`;const u=L("menu-records"),h=J.bestWaveByDiff[J.selectedDifficulty]||0;J.totalGames>0||J.adventure.completedLevels.length>0?u.innerHTML=`
        <span>Aventure <b style="color:#5ef28c">${J.adventure.completedLevels.length}/100</b></span>
        <span>Record Survie (${l.label}) <b>V.${h}</b></span>
        <span>Essences <b style="color:#d8b4fe">${J.essence} ✨</b></span>
        <span>Succès <b>${J.achs.length}/${Zr.length}</b></span>
      `:u.innerHTML=`<span>Nouvelle forteresse prête à être érigée · Essences : <b style="color:#d8b4fe">${J.essence} ✨</b></span>`}refreshMultiScreen(){L("hud").hidden=!0;const e=J.settings.theme!=="pixel",t=L("mp-status");ne.connected?(t.textContent="● SERVEUR LAN EN LIGNE",t.className="mp-status-pill ok"):ne.connecting?(t.textContent="○ CONNEXION LAN…",t.className="mp-status-pill"):(t.textContent="✕ SERVEUR LAN HORS LIGNE",t.className="mp-status-pill err");const n=ne.lanUrls,s=L("mp-lan-urls");n.length>0?s.innerHTML=n.map(S=>`<code>${S}</code>`).join(""):ne.connected?s.innerHTML=`<code>${location.origin}</code>`:s.innerHTML="<span>Lance <code>npm run dev</code> (ou <code>npm run dev:lan</code>) pour héberger le serveur LAN.</span>",ti(J.selectedClass)||(J.selectedClass="guardian"),L("mp-class-selector").innerHTML=sr.map(S=>{const M=Mt[S],_=ti(S),E=J.selectedClass===S;return`<button type="button" data-mphclass="${S}" class="class-card ${E?"on":""} ${_?"":"locked"}" style="${E?`border-color:${M.color};color:${M.color}`:""}"><img src="${cs(M.spriteKey,2,!_,e)}" alt="" /><span>${_?M.short:`🔒 ${M.short}`}</span></button>`}).join("");const r=L("mp-browser"),a=L("mp-lobby");if(!ne.room){r.hidden=!1,a.hidden=!0,L("mp-create-diff").innerHTML=Es.map(_=>{const E=Wt[_],y=this.mpCreateDiff===_;return`<button type="button" data-mpdiff="${_}" class="${y?"on":""}" style="${y?`border-color:${E.color};color:${E.color}`:""}">${E.label}</button>`}).join("");const S=L("mp-rooms-list"),M=ne.rooms.filter(_=>!_.inGame);M.length===0?S.innerHTML=`<div class="mp-empty">${ne.connected?"Aucun salon ouvert sur le réseau pour l’instant. Crée un salon ou entre un code.":"En attente de connexion au serveur LAN…"}</div>`:S.innerHTML=M.map(_=>{var b;const E=_.players.find(A=>A.isHost)||_.players[0],y=((b=Wt[_.difficulty])==null?void 0:b.label)||_.difficulty,x=_.players.length>=4;return`
              <div class="mp-room-row">
                <div class="mp-room-meta">
                  <b>Salon ${_.code} · ${(E==null?void 0:E.name)||"Hôte"}</b>
                  <small>${y} · ${_.players.length} / 4 joueurs</small>
                </div>
                <button class="btn primary mp-mini-btn" type="button" data-join-room="${_.code}" ${x?"disabled":""}>${x?"COMPLET":"REJOINDRE"}</button>
              </div>
            `}).join("");return}r.hidden=!0,a.hidden=!1;const o=ne.room,l=ne.role==="host",c=o.players.length,d=(1+(c-1)*.42).toFixed(2),p=(1+(c-1)*.35).toFixed(2),u=(c-1)*35,h=(c-1)*10;L("mp-room-code").textContent=o.code,L("mp-scaling-info").textContent=c>1?`${c} joueurs · PV ennemis ×${d} · Effectifs ×${p} · Bonus départ +${u}🪨 +${h}💎`:"1 joueur (en attente d’alliés sur le même Wi-Fi / LAN…)",L("mp-lobby-diff").innerHTML=Es.map(S=>{const M=Wt[S],_=o.difficulty===S;return`<button type="button" data-mpldiff="${S}" class="${_?"on":""}" ${l?"":"disabled"} style="${_?`border-color:${M.color};color:${M.color}`:""}">${M.label}</button>`}).join("");const v=L("mp-roster");let f="";for(let S=0;S<4;S++){const M=o.players[S];if(M){const _=Mt[M.heroClass]||Mt.guardian,E=M.id===ne.myId;f+=`
          <div class="mp-slot filled" style="--slot-col:${M.color}">
            <img src="${cs(_.spriteKey,2,!1,e)}" alt="" />
            <div class="mp-slot-name" style="color:${M.color}">${M.name}${E?" (Toi)":""}</div>
            <div class="mp-slot-role">${_.name}</div>
            ${M.isHost?'<span class="mp-slot-tag">★ HÔTE</span>':'<span class="mp-slot-role">Prêt</span>'}
          </div>
        `}else f+=`<div class="mp-slot empty"><span>Emplacement ${S+1}<br/>En attente…</span></div>`}v.innerHTML=f;const m=L("btn-mp-start"),g=L("mp-lobby-tip");l?(m.disabled=!1,m.textContent=c>=2?`▶ LANCER LA PARTIE CO-OP (${c} J.)`:"▶ LANCER QUAND MÊME (SOLO)",g.textContent=c>=2?`${c} Gardiens prêts ! Tout le monde partage les ressources et défend la même Citadelle.`:"Partage le lien LAN ci-dessus à tes amis sur le même Wi-Fi, puis lance la partie !"):(m.disabled=!0,m.textContent="EN ATTENTE DE L'HÔTE…",g.textContent="Tu peux changer ton pseudo ou ta classe pendant que l'hôte lance la partie.")}refreshAdventureScreen(){L("hud").hidden=!0;const e=J.adventure,t=Object.values(e.levelStars||{}).reduce((y,x)=>y+(x||0),0);L("adv-vault-stone").textContent=`${e.vaultStone}`,L("adv-vault-crystal").textContent=`${e.vaultCrystal}`,L("adv-progress").textContent=`Niveaux : ${e.completedLevels.length}/100 · ★ ${t}/300 · Max : Niv.${e.highestUnlocked}`;const n=L("adv-ch-tabs");n.innerHTML=Js.map(y=>{const x=e.highestUnlocked>=y.startLevel;let b=0;for(let R=y.startLevel;R<=y.endLevel;R++)b+=e.levelStars[R]||0;const A=y.id===this.advChapter;return`<button type="button" data-ch="${y.id}" class="${A?"on":""} ${x?"":"ch-locked"}" style="${A?`border-color:${y.color};color:${y.color}`:""}">CH.${y.id}${x?b>0?` ★${b}`:"":" 🔒"}</button>`}).join("");const s=Js[this.advChapter-1]||Js[0],r=L("adv-ch-banner");r.style.borderColor=s.color,r.innerHTML=`<b style="color:${s.color}">CHAPITRE ${s.id} — ${s.name.toUpperCase()} (Niv.${s.startLevel}–${s.endLevel})</b><span>${s.subtitle}</span>`;const a=L("adv-levels-grid"),o=Ro.filter(y=>y.chapter===s.id);a.innerHTML=o.map(y=>{const x=e.completedLevels.includes(y.level),b=e.levelStars[y.level]||(x?1:0),A=y.level<=e.highestUnlocked,R=y.level===this.advSelectedLevel,D=["adv-lvl-tile",R?"selected":"",x?"done":"",A?"":"locked",y.bossId?"boss":""].filter(Boolean).join(" "),O=x?`<span class="adv-tile-stars">${"★".repeat(b)}${"☆".repeat(3-b)}</span>`:`<span class="adv-tile-ico">${A?y.bossId?"☠":"▶":"🔒"}</span>`;return`
          <button type="button" class="${D}" data-adv-lvl="${y.level}" style="${R?`border-color:${s.color}`:""}">
            <div class="adv-tile-top">
              <span class="adv-tile-num">NIV.${y.level}</span>
              ${O}
            </div>
            <div class="adv-tile-name">${y.name}</div>
            <div class="adv-tile-meta">${y.targetWaves} vagues${y.newUnlocks.length>0?" · ✨":""}</div>
          </button>
        `}).join("");const l=Kn(this.advSelectedLevel),c=l.level<=e.highestUnlocked,d=e.completedLevels.includes(l.level),p=e.levelStars[l.level]||(d?1:0);L("adv-brief-tag").textContent=`CHAPITRE ${l.chapter} · NIVEAU ${l.level} / 100`;const u=L("adv-brief-status");u.textContent=d?`${"★".repeat(p)}${"☆".repeat(3-p)} RÉUSSI`:c?"DÉBLOQUÉ":`🔒 TERMINE NIV.${l.level-1}`,u.style.color=p===3?"#ffbe3b":d?"#5ef28c":c?"#4ef2e8":"#ff4f6d",L("adv-brief-title").textContent=l.name,L("adv-brief-desc").textContent=l.desc;const h=l.allowedEnemies.slice(-4).map(y=>{var x;return((x=Zn[y])==null?void 0:x.name)||y}).join(", "),v=Math.round(l.rewardStone*.8),f=Math.round(l.rewardCrystal*.8);L("adv-brief-stats").innerHTML=`
      <span>Vagues : <b>${l.targetWaves}</b></span>
      <span>Flancs : <b>${l.flanks}</b></span>
      <span>Citadelle max : <b>Niv.${l.maxCitadelLvl}</b></span>
      <span>Force ennemis : <b>×${l.hpMult} PV</b></span>
      <span>Prime victoire : <b>+${l.rewardStone}🪨${l.rewardCrystal>0?` +${l.rewardCrystal}💎`:""}${d?"":" (×1,5 1ère fois !)"}</b></span>
      <span style="color:#ffbe3b">Prime 3★ (0 dégât Citadelle) : <b>${p>=3?"✓ Déjà obtenue":`+${v}🪨${f>0?` +${f}💎`:""}`}</b></span>
      ${l.bossId?`<span style="color:#ff4f6d">Boss final : <b>${l.doubleBoss?"DOUBLE ":""}${Zn[l.bossId].name}</b></span>`:""}
      <span>Ennemis : <b>${h}</b></span>
    `;const m=L("adv-brief-unlocks");l.newUnlocks.length>0?(m.hidden=!1,m.innerHTML=`<b>✨ Débloqué à ce niveau :</b> ${l.newUnlocks.map(y=>`<span>${y}</span>`).join("")}`):m.hidden=!0;const g=e.vaultStone,S=e.vaultCrystal;this.advBringStone=Se(this.advBringStone,0,g),this.advBringCrystal=Se(this.advBringCrystal,0,S);const M=L("adv-bring-stone"),_=L("adv-bring-crystal");M.max=String(g),M.value=String(this.advBringStone),M.disabled=g===0,_.max=String(S),_.value=String(this.advBringCrystal),_.disabled=S===0,L("adv-bring-stone-max").textContent=String(g),L("adv-bring-crystal-max").textContent=String(S);const E=L("btn-adv-launch");E.disabled=!c,E.textContent=c?`▶ LANCER LE NIVEAU ${l.level}`:`🔒 VERROUILLÉ (TERMINE NIV.${l.level-1})`,this.updateAdventureLoadoutUi()}updateAdventureLoadoutUi(){const e=Kn(this.advSelectedLevel),t=J.adventure;this.advBringStone=Se(this.advBringStone,0,t.vaultStone),this.advBringCrystal=Se(this.advBringCrystal,0,t.vaultCrystal),L("adv-bring-stone-val").textContent=String(this.advBringStone),L("adv-bring-crystal-val").textContent=String(this.advBringCrystal);const n=e.baseFreeStone+this.advBringStone,s=e.baseFreeCrystal+this.advBringCrystal,r=t.vaultStone-this.advBringStone,a=t.vaultCrystal-this.advBringCrystal;L("adv-loadout-summary").innerHTML=`
      <div><span>Dotation gratuite :</span><b>+${e.baseFreeStone}🪨 +${e.baseFreeCrystal}💎</b></div>
      <div><span>Départ du niveau :</span><b style="color:#5ef28c">${n}🪨 · ${s}💎</b></div>
      <div><span>En sécurité au Coffre :</span><b style="color:#4ef2e8">${r}🪨 · ${a}💎</b></div>
    `}refreshMetaScreen(){L("hud").hidden=!0,L("meta-essence").textContent=`${J.essence}`;const e=su(),t=L("btn-meta-respec");t.disabled=e===0,t.textContent=e>0?`↺ RÉINITIALISER (+${e} ✨)`:"↺ RÉINITIALISER (0 ✨)";const n=yr[this.metaTab];document.querySelectorAll("#meta-tabs button").forEach(u=>{const h=u.dataset.mtab,v=h===this.metaTab;u.classList.toggle("on",v),v?(u.style.borderColor=yr[h].color,u.style.color=yr[h].color):(u.style.borderColor="",u.style.color="")});const s=L("meta-tree-desc");s.textContent=`${n.name.toUpperCase()} — ${n.desc}`,s.style.borderColor=n.color,s.style.color=n.color;const r=wl.filter(u=>u.tree===this.metaTab),a=L("meta-tree-svg"),o=L("meta-tree-grid"),l=u=>u*300+150,c=u=>u*140+70;let d="";for(const u of r){const h=si(u.id),v=l(u.col),f=c(u.row);for(const m of u.requires){const g=is(m.id);if(!g)continue;const M=si(g.id)>=m.rank,_=M&&h>0,E=l(g.col),y=c(g.row),x=_?n.color:M?`${n.color}99`:"rgba(148, 163, 184, 0.28)";d+=`<line x1="${E}" y1="${y}" x2="${v}" y2="${f}" stroke="${x}" stroke-width="${_?4:M?3:2}" ${M?"":'stroke-dasharray="7 6"'} stroke-linecap="round" />`}}a.innerHTML=d;const p=["RACINE","BRANCHE","AVANCÉ","ULTIME"];o.innerHTML="";for(const u of r){const h=si(u.id),v=h>=u.maxRank,f=nu(u),m=iu(u.id),g=Aa(u,h),S=document.createElement("div"),M=v?"maxed":f?m.ok?"available":h>0?"invested":"unlocked":"locked";S.className=`meta-node ${M}${u.row===3?" ult":""}`,S.style.gridColumn=`${u.col+1}`,S.style.gridRow=`${u.row+1}`,(h>0||m.ok)&&S.style.setProperty("--tree-col",n.color);const _=f?h>0?`<div class="meta-active">Actif : ${u.effectLabel(h)}</div>`:`<div class="meta-active muted">Rang 1 : ${u.effectLabel(1)}</div>`:`<div class="meta-req">🔒 ${u.requires.map(y=>{const x=is(y.id);return`${x?x.name:y.id} (${si(y.id)}/${y.rank})`}).join(" + ")}</div>`,E=u.unlocksBuilding?`<div class="meta-unlock ${h>=1?"done":""}">🏛 ${h>=1?"Débloqué":"Débloque (Rang 1)"} : <b>${We[u.unlocksBuilding].name}</b></div>`:"";S.innerHTML=`
        <div class="meta-node-head">
          <span class="meta-tier">${p[u.row]||"PALIER"}</span>
          <span class="meta-rank">${h} / ${u.maxRank}</span>
        </div>
        <h3>${u.name}</h3>
        <p>${u.desc}</p>
        ${E}
        ${_}
        <button class="buy meta-buy" type="button" ${m.ok?"":"disabled"}>
          ${v?"MAX":f?`${g} ✨`:"VERROUILLÉ"}
        </button>
      `,S.querySelector("button").addEventListener("click",()=>{qh(u.id)&&this.refreshMetaScreen()}),o.appendChild(S)}}refreshBuildingIndex(){L("hud").hidden=!0;const e=J.settings.theme!=="pixel",t={defense:"Défense",trap:"Piège",turret:"Tourelle",economy:"Économie",support:"Soutien"};document.querySelectorAll("#bindex-tabs button").forEach(r=>{r.classList.toggle("on",r.dataset.bitab===this.bindexTab)});const n=xr.filter(r=>{const a=We[r];return this.bindexTab==="all"?!0:this.bindexTab==="defense"?a.category==="defense"||a.category==="trap":this.bindexTab==="turret"?a.category==="turret":this.bindexTab==="eco"?a.category==="economy"||a.category==="support":!!a.reqMetaNode});L("bindex-count").textContent=`${n.length} / ${xr.length}`;const s=L("buildings-grid");s.innerHTML="";for(const r of n){const a=We[r],o=tu(a.reqMetaNode),l=a.reqMetaNode?is(a.reqMetaNode):void 0,c=l?yr[l.tree]:void 0,d=document.createElement("div");d.className=`bindex-card ${a.reqMetaNode?"meta-b":""} ${o?"":"locked"}`;const p=cs(a.id,a.w>1?2:3,!1,e),u=[`<span>Coût : <b>${a.stoneCost}🪨${a.crystalCost>0?` ${a.crystalCost}💎`:""}</b></span>`,`<span>PV : <b>${a.hp}</b> · Arm. <b>${a.armor}</b></span>`];if(a.dmg>0&&u.push(`<span>Dégâts : <b>${a.dmg}</b> (${a.fireRate}s)</span>`),a.range>0&&u.push(`<span>Portée : <b>${a.range}</b></span>`),a.prodInterval>0){const m=[a.prodStone>0?`+${a.prodStone}🪨`:"",a.prodCrystal>0?`+${a.prodCrystal}💎`:""].filter(Boolean).join(" ");u.push(`<span>Prod. : <b>${m} / ${a.prodInterval}s</b></span>`)}let h=`<span class="bi-badge cit">Citadelle Niv.${a.reqCitadel}</span>`,v="";l&&c&&(o?h=`<span class="bi-badge ok">✨ DÉBLOQUÉ (${c.short}) · Cit.N${a.reqCitadel}</span>`:(h=`<span class="bi-badge lock">🔒 Arbre ${c.short} : ${l.name}</span>`,v=`<button class="btn ghost bi-goto" type="button" data-goto-tree="${l.tree}">VOIR DANS L'ARBRE ✨</button>`)),d.innerHTML=`
        <div class="bi-top">
          <div class="bi-art" style="border-color:${a.color}">
            <img src="${p}" alt="${a.name}" />
          </div>
          <div class="bi-head">
            <div class="bi-title-row">
              <h3>${a.name}</h3>
              <span class="bi-size">${a.w}×${a.h} · ${t[a.category]||a.category}</span>
            </div>
            ${h}
          </div>
        </div>
        <p class="bi-desc">${a.desc}</p>
        <div class="bi-stats">${u.join("")}</div>
        ${v}
      `;const f=d.querySelector("[data-goto-tree]");f&&f.addEventListener("click",()=>{Qe(),W("click"),this.metaTab=f.dataset.gotoTree,this.showScreen("s-meta")}),s.appendChild(d)}}refreshBestiary(){const e={classic:"Troupe",breaker:"Brise-Murs",flanker:"Contourneur",flyer:"Volant",ranged:"À distance",sapper:"Anti-Tourelles",assassin:"Anti-Artillerie",summoner:"Invocateur",juggernaut:"Colosse Blindé",boss:"Seigneur de Siège"},t=L("bestiary-enemies");t.innerHTML="";const n=L("bestiary-bosses");n.innerHTML="";const s=J.settings.theme!=="pixel";for(const r of Object.values(Zn)){const a=J.seenEnemies.includes(r.id),o=J.killedEnemies[r.id]||0,l=document.createElement("div");l.className="beast",l.innerHTML=`
        <img src="${cs(r.art,r.role==="boss"?3:4,!a,s)}" alt="${a?r.name:"???"}" />
        <h4>${a?r.name:"ENNEMI INCONNU"}</h4>
        <small>${e[r.role]||r.role} · Vague ${r.minWave}+</small>
        <p>${a?r.desc:"Affronte cette créature en défense pour débloquer sa fiche."}</p>
        <small>${a?`Vaincus : ${o}`:"Non analysé"}</small>
      `,r.role==="boss"?n.appendChild(l):t.appendChild(l)}}refreshArchives(){const e=Es.map(n=>`${Wt[n].label.slice(0,3)}:V${J.bestWaveByDiff[n]||0}`).join(" · ");L("arch-facts").innerHTML=`
      <div><dt>MEILLEURE VAGUE</dt><dd>${J.bestWave}</dd></div>
      <div><dt>RECORDS PAR MODE</dt><dd style="font-size:11px;line-height:1.45">${e}</dd></div>
      <div><dt>MEILLEUR SCORE</dt><dd>${J.bestKills}</dd></div>
      <div><dt>TOTAL ÉLIMINATIONS</dt><dd>${J.totalKills.toLocaleString("fr-FR")}</dd></div>
      <div><dt>STRUCTURES POSÉES</dt><dd>${J.totalBuilt.toLocaleString("fr-FR")}</dd></div>
      <div><dt>BATAILLES</dt><dd>${J.totalGames}</dd></div>
    `,L("ach-count").textContent=`${J.achs.length} / ${Zr.length}`;const t=L("arch-achs");t.innerHTML="";for(const n of Zr){const s=J.achs.includes(n.id),r=document.createElement("div");r.className=`ach ${s?"on":""}`,r.innerHTML=`
        ${$a(s?"check":"lock")}
        <div>
          <h3>${n.name}</h3>
          <p>${n.desc}</p>
        </div>
      `,t.appendChild(r)}}refreshSettings(){L("opt-sfx").value=String(J.settings.sfx),L("opt-music").value=String(J.settings.music);const e=L("opt-crt");e.textContent=J.settings.crt?"ACTIF":"INACTIF",e.classList.toggle("on",J.settings.crt);const t=L("opt-shake");t.textContent=J.settings.shake?"ACTIF":"INACTIF",t.classList.toggle("on",J.settings.shake)}syncHud(e,t){var le;L("hud").hidden=e.modal!=="none";const n=e.citadel;L("hud-cit-lvl").textContent=`CITADELLE NIV.${n.lvl}`,L("hud-cit-hp").textContent=`${Math.ceil(n.hp)} / ${n.maxHp}`,L("hud-cit-fill").style.transform=`scaleX(${Se(n.hp/n.maxHp,0,1)})`;const s=e.hero,r=Mt[e.heroClass];if(L("hud-hero-lbl").textContent=s.alive?r.short:`${r.short} TOMBÉ`,L("hud-hero-hp").textContent=s.alive?`${Math.ceil(s.hp)} / ${s.maxHp}`:`${s.respawnTimer.toFixed(1)}s`,L("hud-hero-fill").style.transform=`scaleX(${s.alive?Se(s.hp/s.maxHp,0,1):0})`,e.heroClass!==this.lastClassKey){this.lastClassKey=e.heroClass;const ce=L("ab-dash");ce.title=r.dashTip,ce.querySelector(".ab-sym").textContent=r.dashSym;const xe=L("ab-rally");xe.title=r.rallyTip,xe.querySelector(".ab-sym").textContent=r.rallySym;const Z=L("ab-ult");Z.title=r.ultTip,Z.querySelector(".ab-sym").textContent=r.ultSym}const a=L("respawn-banner");a.hidden=s.alive,s.alive||(L("respawn-sec").textContent=s.respawnTimer.toFixed(1));let o=0,l=0;for(const ce of e.buildings){const xe=We[ce.id];if(xe.prodInterval>0){const Z=ou(e,ce);o+=xe.prodStone*Z*60/xe.prodInterval,l+=xe.prodCrystal*Z*60/xe.prodInterval}}L("hud-stone").textContent=String(e.stone),L("hud-stone-rate").textContent=o>0?`+${Math.round(o)}/m`:"",L("hud-crystal").textContent=String(e.crystal),L("hud-crystal-rate").textContent=l>0?`+${Math.round(l)}/m`:"";const c=L("coop-hud"),d=e.coopPlayers||[];if(d.length>0){c.hidden=!1;const ce=d.map(xe=>`${xe.id}:${xe.name}:${xe.heroClass}:${xe.hero.alive?Math.ceil(xe.hero.hp):xe.hero.respawnTimer.toFixed(1)}/${xe.hero.maxHp}`).join("|");ce!==this.lastCoopHudKey&&(this.lastCoopHudKey=ce,c.innerHTML=d.map(xe=>{var Fe;const Z=xe.hero.alive?Se(xe.hero.hp/Math.max(1,xe.hero.maxHp),0,1):0,be=((Fe=Mt[xe.heroClass])==null?void 0:Fe.short)||"ALLIÉ",we=xe.hero.alive?`${Math.ceil(xe.hero.hp)}/${xe.hero.maxHp}`:`☠ ${xe.hero.respawnTimer.toFixed(1)}s`;return`
              <div class="coop-row">
                <div class="coop-row-head">
                  <span style="color:${xe.color}"><i class="coop-dot" style="background:${xe.color}"></i>${xe.name} <small style="color:#96abc9">(${be})</small></span>
                  <b>${we}</b>
                </div>
                <div class="coop-track"><i style="background:${xe.color};transform:scaleX(${Z})"></i></div>
              </div>
            `}).join(""))}else c.hidden=!0,this.lastCoopHudKey="";const p=Wt[e.difficulty],u=L("hud-diff");e.mode==="adventure"&&e.adventure?(u.textContent=`AVENTURE N.${e.adventure.level}`,u.style.color="#5ef28c"):(e.playerCount||1)>1?(u.textContent=`CO-OP ${e.playerCount}J · ${p.label.toUpperCase()}`,u.style.color="#38bdf8"):(u.textContent=p.label.toUpperCase(),u.style.color=p.color);const h=Pt(e,"autoWave"),v=L("btn-auto-wave");v.hidden=!h,v.textContent=e.autoWave?"AUTO : ON":"AUTO : OFF",v.classList.toggle("on",e.autoWave);const f=L("btn-start-wave"),m=e.mode==="adventure"&&e.adventure?e.adventure.targetWaves:null;if(e.phase==="prep"){f.hidden=!1;const ce=e.nextWavePlan.flanks.map(Z=>Od[Z]).join(" · "),xe=m?`VAGUE ${e.wave}/${m}`:`VAGUE ${e.wave}`;L("hud-wave-title").textContent=`${xe} — PRÉPARATION ${$h(Math.ceil(e.prepTimer))}`,L("hud-wave-sub").textContent=`${e.nextWavePlan.isBossWave?"ALERTE BOSS · ":""}Flancs : ${ce}`,f.textContent="LANCER VAGUE [G]",f.classList.remove("stack"),f.disabled=!1}else{let ce=0;for(const we of e.activeWaves)ce+=Math.max(0,we.totalCount-we.spawnedCount);const xe=ce+e.enemies.length;if(e.activeWaves.length>1){const we=Math.min(...e.activeWaves.map(Ee=>Ee.wave)),Fe=Math.max(...e.activeWaves.map(Ee=>Ee.wave));L("hud-wave-title").textContent=`VAGUES ${we}–${Fe} (${e.activeWaves.length}×) — ASSAUT`}else{const we=e.activeWaves[0];L("hud-wave-title").textContent=`${(we==null?void 0:we.title)||`VAGUE ${e.wave}`} — ASSAUT`}const Z=!m||e.nextWavePlan.wave<=m,be=Z&&Pt(e,"waveStacking");if(Z){const we=e.nextWavePlan.flanks.map(Fe=>Od[Fe]).join("·");L("hud-wave-sub").textContent=`Ennemis : ${xe} · Suiv. V${e.nextWavePlan.wave} (${we})`}else L("hud-wave-sub").textContent=`VAGUE FINALE · Ennemis restants : ${xe}`;f.hidden=!be,f.textContent=`VAGUE ${e.nextWavePlan.wave} (+BONUS) [G]`,f.classList.add("stack"),f.disabled=e.activeWaves.length>=10||!be}const g=L("hud-wave-event"),S=e.phase==="wave"?e.activeWaves.find(ce=>ce.event):void 0,M=e.phase==="prep"?e.nextWavePlan.event:S==null?void 0:S.event;if(M&&To[M]){const ce=To[M];g.hidden=!1,g.style.borderColor=ce.color,g.style.color=ce.color,g.textContent=`${e.phase==="prep"?"À VENIR":"ACTIF"} · ${ce.icon} ${ce.short} — ${ce.desc}`}else g.hidden=!0;const _=e.enemies.find(ce=>ce.isBoss),E=L("bossbar");_?(E.hidden=!1,L("boss-name").textContent=`${_.name} (Phase ${_.bossPhase})`,L("boss-fill").style.transform=`scaleX(${Se(_.hp/_.maxHp,0,1)})`):E.hidden=!0;const y=Pt(e,"upgrades");L("btn-upgrades").hidden=!y,L("btn-pause-upg").hidden=!y;const x=y&&ha.some(ce=>!ce.repeatable&&Lo(e,ce.id).ok);if(L("btn-upgrades").classList.toggle("ready",x),L("fx-hurt").style.opacity=String(e.hurtFlash),e.pendingBanner){const ce=e.pendingBanner;e.pendingBanner=void 0;const xe=`${ce.title}|${ce.sub}`;if(xe!==this.lastBannerKey){this.lastBannerKey=xe;const Z=L("banner");Z.classList.remove("show","warn"),Z.offsetWidth,L("banner-h").textContent=ce.title,L("banner-p").textContent=ce.sub,ce.warn&&Z.classList.add("warn"),Z.classList.add("show")}}e.pendingHint?(L("hint").textContent=e.pendingHint,L("hint").classList.add("show"),this.hintTimer=7.5,e.pendingHint=void 0):this.hintTimer>0&&(this.hintTimer-=t,this.hintTimer<=0&&L("hint").classList.remove("show"));const b=Zt(e),A=L("ab-dash");A.hidden=!Pt(e,"abilityDash"),A.style.setProperty("--cd",String(Se(s.dashCd/Math.max(.1,s.dashMaxCd*b.skillCdrMult),0,1))),A.classList.toggle("ready",s.alive&&s.dashCd<=0);const R=L("ab-rally");R.hidden=!Pt(e,"abilityRally"),R.style.setProperty("--cd",String(Se(s.rallyCd/Math.max(.1,s.rallyMaxCd*b.skillCdrMult),0,1))),R.classList.toggle("ready",s.alive&&s.rallyCd<=0);const D=L("ab-ult");D.hidden=!Pt(e,"abilityUlt"),D.style.setProperty("--cd",String(Se(s.ultCd/Math.max(.1,s.ultMaxCd*b.skillCdrMult),0,1))),D.classList.toggle("ready",s.alive&&s.ultCd<=0);const O=document.querySelector(".spd-grp");O&&(O.hidden=!Pt(e,"speedControls")),L("btn-spd-1").classList.toggle("on",e.gameSpeed===1),L("btn-spd-2").classList.toggle("on",e.gameSpeed===2),L("btn-spd-3").classList.toggle("on",e.gameSpeed===3);const X=L("btn-tact-pause");X.hidden=!Pt(e,"tacticalPause"),X.textContent=e.tacticalPause?"▶ [P]":"❚❚ [P]",X.classList.toggle("warn",e.tacticalPause),L("tact-pause-banner").hidden=!e.tacticalPause;const k=L("btn-paths");k.hidden=!Pt(e,"pathPreview"),k.textContent=e.pathPreview==="auto"?"CHEMINS: AUTO":e.pathPreview==="on"?"CHEMINS: ON":"CHEMINS: OFF",k.classList.toggle("on",e.pathPreview!=="off"),L("btn-batch").hidden=!Pt(e,"toolBatch"),L("btn-copy").hidden=!Pt(e,"toolBlueprint"),L("btn-demolish").hidden=!Pt(e,"toolDemolish"),L("btn-batch").classList.toggle("on",e.toolMode==="batch_upgrade"),L("btn-copy").classList.toggle("on",e.toolMode==="copy_select"||e.toolMode==="paste"),L("btn-demolish").classList.toggle("on",e.toolMode==="demolish");const P=lf(e),F=L("btn-repair-all");P.damagedCount>0?(F.textContent=`⚒ RÉPARER (${P.totalStone}🪨)`,F.disabled=P.affordableCount===0):(F.textContent="⚒ RÉPARER",F.disabled=!0);const G=e.buildings.filter(ce=>ce.id==="quarry").length,se=e.buildings.filter(ce=>ce.id==="crystal_rig").length,Y=e.buildings.filter(ce=>ce.id==="ether_forge").length,ae=`${e.mode}|${((le=e.adventure)==null?void 0:le.level)||0}|${this.buildTab}|${e.toolMode}|${e.buildMode||""}|${n.lvl}|${e.stone}|${e.crystal}|${wi(e,"build_cost")}|${G}|${se}|${Y}`;if(ae!==this.lastBuildKey&&(this.lastBuildKey=ae,this.renderBuildBar(e)),this.syncBatchPanel(e),this.syncBlueprintBar(e),this.syncInspector(e),this.updateTutorial(e),e.modal==="upgrades"&&ne.isMultiplayer){const ce=`${e.stone}|${e.crystal}|${e.citadel.lvl}|${Object.values(e.upgrades).join(",")}`;ce!==this.lastUpgSyncKey&&(this.lastUpgSyncKey=ce,this.renderUpgradesModal(e))}}startTutorialIfNeeded(e){if(J.tutorialDone){this.tutorialStep=null,this.lastTutoStep=-1,L("tutorial-card").hidden=!0;return}this.tutorialStep=0,this.lastTutoStep=-1,this.tutoStartX=e.hero.x,this.tutoStartY=e.hero.y,this.renderTutorialCard()}completeTutorial(e){this.tutorialStep=null,this.lastTutoStep=-1,L("tutorial-card").hidden=!0,J.tutorialDone=!0,Vt(),e||Rn({title:"Tutoriel terminé !",sub:"Bonne chance pour défendre le Bastion d’Éther !",col:"#5ef28c"})}renderTutorialCard(){const e=L("tutorial-card");if(this.tutorialStep===null||this.tutorialStep>=Yr.length){e.hidden=!0;return}const t=Yr[this.tutorialStep],n=Yr.length;e.hidden=!1,L("tuto-step").textContent=`TUTORIEL · ${this.tutorialStep+1} / ${n}`,L("tuto-fill").style.width=`${(this.tutorialStep+1)/n*100}%`,L("tuto-title").textContent=t.title,L("tuto-body").textContent=t.body,L("tuto-goal").textContent=t.goal,L("btn-tuto-next").textContent=this.tutorialStep===n-1?"C'EST PARTI !":"SUIVANT ►",this.lastTutoStep=this.tutorialStep}updateTutorial(e){if(this.tutorialStep===null){L("tutorial-card").hidden=!0;return}if(e.modal==="over"||e.modal==="victory"){L("tutorial-card").hidden=!0;return}this.tutorialStep<4&&e.wave===1&&e.phase==="prep"&&e.prepTimer<20&&(e.prepTimer=20);let t=!1;if(this.tutorialStep===0)Math.hypot(e.hero.x-this.tutoStartX,e.hero.y-this.tutoStartY)>=24&&(this.tutorialStep=1,t=!0);else if(this.tutorialStep===1)e.stats.builtCount>=1&&(this.tutorialStep=2,t=!0);else if(this.tutorialStep===2)(e.modal==="upgrades"||e.stats.upgradesBought>=1)&&(this.tutorialStep=3,t=!0);else if(this.tutorialStep===3)(e.hero.dashCd>0||e.hero.rallyCd>0||e.hero.ultCd>0)&&(this.tutorialStep=4,t=!0);else if(this.tutorialStep===4&&e.phase==="wave"){this.completeTutorial(!1);return}t?(W("upgrade"),this.renderTutorialCard()):this.lastTutoStep!==this.tutorialStep&&this.renderTutorialCard()}syncBatchPanel(e){const t=L("batch-panel");if(e.toolMode!=="batch_upgrade"||e.batchSelectedUids.length===0){t.hidden=!0,this.lastBatchKey="";return}const n=new Set(e.batchSelectedUids),s=e.buildings.filter(u=>n.has(u.uid));if(s.length===0){t.hidden=!0,e.batchSelectedUids=[],this.lastBatchKey="";return}const r=s.map(u=>u.lvl).join(","),a=`${e.batchSelectedUids.length}|${e.batchFilterId}|${r}|${e.stone}|${e.crystal}|${wi(e,"build_cost")}`;if(a===this.lastBatchKey)return;this.lastBatchKey=a,t.hidden=!1;const o=new Map;for(const u of s)o.set(u.id,(o.get(u.id)||0)+1);e.batchFilterId!=="all"&&!o.has(e.batchFilterId)&&(e.batchFilterId="all");const l=L("batch-filters");let c=`<button type="button" data-bfilt="all" class="${e.batchFilterId==="all"?"on":""}">TOUT (${s.length})</button>`;for(const[u,h]of o.entries()){const v=e.batchFilterId===u;c+=`<button type="button" data-bfilt="${u}" class="${v?"on":""}">${We[u].short} (${h})</button>`}l.innerHTML=c;const d=cf(e);L("batch-title").textContent=`LOT : ${d.count} BÂTIMENT${d.count>1?"S":""}`;const p=L("batch-up-btn");d.affordableCount===d.count?(p.textContent=`AMÉLIORER +1 (${d.totalStone}🪨 ${d.totalCrystal}💎)`,p.disabled=d.count===0):d.affordableCount>0?(p.textContent=`AMÉLIORER ${d.affordableCount}/${d.count} (${d.affordableStone}🪨 ${d.affordableCrystal}💎)`,p.disabled=!1):(p.textContent=`COÛT : ${d.totalStone}🪨 ${d.totalCrystal}💎`,p.disabled=!0)}syncBlueprintBar(e){const t=L("blueprint-bar");if(e.toolMode!=="paste"||!e.blueprint){t.hidden=!0;return}t.hidden=!1,L("bp-info").textContent=`PLAN ${e.blueprint.w}×${e.blueprint.h} (${e.blueprint.items.length} BÂT.)`}renderBuildBar(e){const t=L("buildbar");t.innerHTML="";const n=this.getVisibleBuildings(e),s=["1","2","3","4","5","6","7","8","9","0","-","="];n.forEach((r,a)=>{const o=We[r],l=Cl(e,r),c=pa(e,r),d=!c.ok,p=e.citadel.lvl<o.reqCitadel,u=d||p,h=!u&&e.stone>=l.stone&&e.crystal>=l.crystal,v=e.buildMode===r,f=a<s.length?s[a]:"",m=document.createElement("button");m.type="button",m.className=`b-slot ${v?"on":""} ${u?"locked":""}`,m.title=d?`🔒 ${o.name} — ${c.reason||"Verrouillé"}`:`${o.name} — ${o.desc}`;const g=d?e.mode==="adventure"?c.reason||"Verrouillé":"Arbre ✨":p?`Cit.N${o.reqCitadel}`:`${l.stone}🪨${l.crystal>0?` ${l.crystal}💎`:""}`,M=J.settings.theme!=="pixel"?`<img class="b-hd-img" src="${cs(o.id,o.w>1?2:3,!1,!0)}" alt="" />`:$a(o.id);m.innerHTML=`
        ${f?`<span class="hk">${f}</span>`:""}
        ${M}
        <span class="bn">${o.short}</span>
        <span class="bc" style="color:${h?"#ffbe3b":u?"#ff4f6d":"#96abc9"}">${g}</span>
      `,m.addEventListener("click",()=>{W("click"),e.toolMode==="build"&&e.buildMode===r?xn(e,"none"):xn(e,"build",r),this.lastBuildKey=""}),t.appendChild(m)})}syncInspector(e){var f;const t=L("inspector");if(e.toolMode!=="none"||!e.selectedBuildingUid){t.hidden=!0,this.lastInspKey="";return}const n=e.buildings.find(m=>m.uid===e.selectedBuildingUid);if(!n){t.hidden=!0,e.selectedBuildingUid=null;return}const s=`${n.uid}|${n.lvl}|${n.antiAir?1:0}|${n.targetPriority||"auto"}|${n.spec||""}|${Math.ceil(n.hp)}|${Math.ceil(n.shield)}|${n.totalDmg}|${n.kills}|${e.stone}|${e.crystal}|${wi(e,"build_cost")}`;if(s===this.lastInspKey)return;this.lastInspKey=s,t.hidden=!1;const r=We[n.id],a=n.spec?(f=rr[n.id])==null?void 0:f[n.spec]:void 0;L("insp-name").textContent=r.name,L("insp-lvl").textContent=`Niv.${n.lvl}${a?` · ★ ${a.short}`:""}${n.antiAir?" · ✈ ANTI-AIR":""}${n.bonusNode?" · ★ BONUS ×2":""}${n.shield>0?` · 🛡️${Math.ceil(n.shield)}`:""}`,L("insp-hp").textContent=`${Math.ceil(n.hp)} / ${n.maxHp} PV`;const o=L("insp-prio");if(r.category==="turret"){o.hidden=!1;const m=n.targetPriority||"auto";o.querySelectorAll("[data-prio]").forEach(g=>{g.classList.toggle("on",g.dataset.prio===m)})}else o.hidden=!0;const l=L("insp-spec"),c=rr[n.id];r.category==="turret"&&c&&n.lvl>=5&&!n.spec?(l.hidden=!1,l.innerHTML=`
        <div class="insp-spec-title">★ SPÉCIALISATION NIV.5 DISPONIBLE (GRATUITE) :</div>
        <div class="insp-spec-btns">
          <button type="button" class="spec-choice" data-spec="A" style="border-color:${c.A.color}">
            <b style="color:${c.A.color}">★ ${c.A.name}</b>
            <span>${c.A.desc}</span>
          </button>
          <button type="button" class="spec-choice" data-spec="B" style="border-color:${c.B.color}">
            <b style="color:${c.B.color}">★ ${c.B.name}</b>
            <span>${c.B.desc}</span>
          </button>
        </div>
      `):l.hidden=!0;const d=[];if(r.dmg>0){const m=Math.round(Qr(e,n)),g=Qi(e,n);d.push(`Dégâts : ${m}${n.id==="solar_tower"?"–"+Math.round(m*(4.5+Math.min(4,(n.lvl-1)*.35))):""} (${g.toFixed(2)}s)`)}r.range>0&&d.push(`Portée : ${di(n)}`),(n.totalDmg>0||n.kills>0)&&d.push(`Dégâts : ${n.totalDmg.toLocaleString("fr-FR")} · Élim. : ${n.kills}`),L("insp-desc").textContent=d.length>0?`${d.join(" · ")} — ${r.desc}`:r.desc;const p=L("insp-up"),u=La(e,n);p.textContent=`AMÉLIORER → N${n.lvl+1} (${u.stone}🪨${u.crystal>0?` ${u.crystal}💎`:""})`,p.disabled=e.stone<u.stone||e.crystal<u.crystal;const h=L("insp-rep");if(n.hp>=n.maxHp)h.textContent="INTACT",h.disabled=!0;else{const m=Pa(n);h.textContent=`RÉPARER (${m}🪨)`,h.disabled=e.stone<m}const v=pr(n);L("insp-sell").textContent=`DÉMOLIR (+${v.stone}🪨${v.crystal>0?` +${v.crystal}💎`:""})`}syncModalScreen(e){const n={none:"",upgrades:"s-upgrades",pause:"s-pause",over:"s-over",victory:"s-victory"}[e.modal];if(n!==this.currentScreen){if(n==="s-upgrades")this.renderUpgradesModal(e);else if(n==="s-pause"){ne.isMultiplayer||fr(e),L("btn-save-quit").hidden=ne.isMultiplayer,L("btn-abandon").textContent=ne.isMultiplayer?"QUITTER LA PARTIE LAN":"ABANDONNER LA PARTIE";const s=e.mode==="adventure"&&e.adventure?`Aventure Niv.${e.adventure.level} · Vague ${e.wave}/${e.adventure.targetWaves}`:ne.isMultiplayer?`Co-op LAN (${e.playerCount||2} J.) · Vague ${e.wave}`:`Vague ${e.wave}`;L("pause-info").textContent=`${s} · Citadelle Niv.${e.citadel.lvl} (${Math.ceil(e.citadel.hp)}/${e.citadel.maxHp} PV) · ${e.stats.kills} ennemis abattus`}else n==="s-over"?this.openOverModal(e):n==="s-victory"&&this.openVictoryModal(e);this.showScreen(n)}}openUpgradesModal(e){ne.isMultiplayer||(e.paused=!0),e.modal="upgrades",this.lastUpgSyncKey="",this.renderUpgradesModal(e),this.showScreen("s-upgrades"),W("click")}renderUpgradesModal(e){L("upg-stone").textContent=String(e.stone),L("upg-crystal").textContent=String(e.crystal),L("upg-cit").textContent=`Citadelle Niv.${e.citadel.lvl}`,this.renderUpgradesGrid(e)}renderUpgradesGrid(e){L("upg-stone").textContent=String(e.stone),L("upg-crystal").textContent=String(e.crystal),L("upg-cit").textContent=`Citadelle Niv.${e.citadel.lvl}`;const t=ha.filter(s=>s.category===this.upgTab),n=L("upg-grid");n.innerHTML="";for(const s of t){const r=wi(e,s.id),a=Tl(e,s),o=Lo(e,s.id),l=!s.repeatable&&r>=s.maxLvl,c=e.citadel.lvl<s.reqCitadel,d=document.createElement("div");d.className=`upg-card ${o.ok?"ready":""} ${c?"locked":""}`,d.innerHTML=`
        <div class="upg-top">
          ${$a(s.icon)}
          <div>
            <h3>${s.name}</h3>
            <small>${s.repeatable?`Utilisé ${r}×`:`Rang ${r} / ${s.maxLvl}`}</small>
          </div>
        </div>
        <p>${s.desc}</p>
        <div class="upg-foot">
          <span class="upg-req">${c?`Requiert Citadelle Niv.${s.reqCitadel}`:l?"Terminé":""}</span>
          <button class="buy" type="button" ${o.ok?"":"disabled"}>
            ${l?"MAX":`${a.stone}🪨${a.crystal>0?` ${a.crystal}💎`:""}`}
          </button>
        </div>
      `,d.querySelector("button").addEventListener("click",()=>{if(ne.role==="client"&&ne.isMultiplayer){W("upgrade"),ne.sendCmd({kind:"buy_upg",id:s.id});return}lu(e,s.id)&&this.renderUpgradesModal(e)}),n.appendChild(d)}}openOverModal(e){const t=e.mode==="adventure"&&!!e.adventure,n=(e.playerCount||1)>1;if(L("btn-retry").hidden=t||n,L("btn-over-meta").hidden=t,L("btn-over-adv").hidden=!t,t&&e.adventure){const r=e.adventure,a=Kn(r.level);L("over-sub").textContent=`Échec au Niveau ${r.level} (${a.name}) — Vague ${e.wave}/${r.targetWaves}. Les ressources emportées du Coffre ont été perdues !`,L("over-facts").innerHTML=`
        <div><dt>NIVEAU AVENTURE</dt><dd>Niv.${r.level} · ${a.name}</dd></div>
        <div><dt>VAGUE ATTEINTE</dt><dd>${e.wave} / ${r.targetWaves}</dd></div>
        <div><dt>RESSOURCES PERDUES</dt><dd style="color:#ff4f6d">-${r.broughtStone}🪨 -${r.broughtCrystal}💎</dd></div>
        <div><dt>COFFRE RESTANT</dt><dd style="color:#4ef2e8">${J.adventure.vaultStone}🪨 · ${J.adventure.vaultCrystal}💎</dd></div>
        <div><dt>ENNEMIS VAINCUS</dt><dd>${e.stats.kills}</dd></div>
        <div><dt>STRUCTURES POSÉES</dt><dd>${e.stats.builtCount}</dd></div>
      `;return}const s=Wt[e.difficulty].label;L("over-sub").textContent=`Ta forteresse (${s}) a tenu jusqu'à la vague ${e.wave} (Citadelle Niv.${e.citadel.lvl}).`,L("over-facts").innerHTML=`
      <div><dt>DIFFICULTÉ</dt><dd>${s}</dd></div>
      <div><dt>VAGUE ATTEINTE</dt><dd>${e.wave}</dd></div>
      <div><dt>ENNEMIS VAINCUS</dt><dd>${e.stats.kills}</dd></div>
      <div><dt>BOSS TERRASSÉS</dt><dd>${e.stats.bossesKilled}</dd></div>
      <div><dt>ESSENCES GAGNÉES</dt><dd style="color:#d8b4fe">+${e.stats.essenceEarned} ✨ (Total : ${J.essence})</dd></div>
      <div><dt>STRUCTURES POSÉES</dt><dd>${e.stats.builtCount}</dd></div>
      <div><dt>AMÉLIORATIONS</dt><dd>${e.stats.upgradesBought}</dd></div>
    `}openVictoryModal(e){const t=e.adventure,n=t==null?void 0:t.victorySummary;if(!t||!n)return;const s=Kn(t.level),r=n.stars===3?"PARFAIT · Zéro dégât sur la Citadelle !":n.stars===2?"Citadelle ≥ 60 % PV (0 dégât requis pour 3 ★)":"Victoire (≥ 60 % PV pour 2 ★ · 0 dégât pour 3 ★)";L("vic-stars").innerHTML=`
      <div class="vic-stars-row">${'<span class="st on">★</span>'.repeat(n.stars)}${'<span class="st">☆</span>'.repeat(3-n.stars)}</div>
      <small>${r}</small>
    `,L("vic-sub").textContent=t.level>=100?"LÉGENDAIRE ! Tu as triomphé des 100 niveaux du Mode Aventure !":`Niveau ${t.level} (${s.name}) validé ! Tes ressources retournent dans le Coffre.`,L("vic-facts").innerHTML=`
      <div><dt>RESTE NON DÉPENSÉ</dt><dd>+${n.remainingStone}🪨 · +${n.remainingCrystal}💎</dd></div>
      <div><dt>RECYCLAGE BÂTIMENTS (50%)</dt><dd>+${n.recycledStone}🪨 · +${n.recycledCrystal}💎</dd></div>
      <div><dt>PRIME DE VICTOIRE${n.firstClear?" (1ÈRE FOIS ×1,5)":""}</dt><dd style="color:#ffbe3b">+${n.rewardStone}🪨 · +${n.rewardCrystal}💎</dd></div>
      ${n.newThreeStar?`<div><dt>★ PRIME 3 ÉTOILES PARFAITE</dt><dd style="color:#ffe066">+${n.threeStarStone}🪨 · +${n.threeStarCrystal}💎</dd></div>`:""}
      <div><dt>TOTAL RENTRÉ AU COFFRE</dt><dd style="color:#5ef28c">+${n.totalReturnedStone}🪨 · +${n.totalReturnedCrystal}💎</dd></div>
      <div><dt>NOUVEAU COFFRE</dt><dd style="color:#4ef2e8">${J.adventure.vaultStone}🪨 · ${J.adventure.vaultCrystal}💎</dd></div>
      <div><dt>ENNEMIS VAINCUS</dt><dd>${e.stats.kills}</dd></div>
    `;const a=L("vic-unlocks");n.nextLevelUnlocks.length>0&&t.level<100?(a.hidden=!1,a.innerHTML=`<b>✨ Débloqué pour le Niveau ${t.level+1} :</b> ${n.nextLevelUnlocks.map(l=>`<span>${l}</span>`).join("")}`):a.hidden=!0;const o=L("btn-vic-next");t.level>=100?o.hidden=!0:(o.hidden=!1,o.textContent=`PRÉPARER LE NIVEAU ${t.level+1} ►`)}closeModal(e){e.modal="none",e.paused=!1,this.showScreen("")}}function Kr(i,e){return!i.targetPriority||i.targetPriority==="auto"?e:i.targetPriority==="citadel"?"citadel_threat":i.targetPriority==="flying"?"anti_air":i.targetPriority}function ts(i,e,t,n,s){let r=null,a=-1e9;const o=n*n;for(const l of i.enemies){if(l.hp<=0||s==="ground_tough"&&l.flying)continue;const c=Wh(e,t,l.x,l.y);if(c>o)continue;const d=Math.sqrt(c);let p=-d;s==="flying"?p+=(l.flying?120:0)+(l.role==="flanker"?50:0):s==="anti_air"?p+=l.flying?450:0:s==="tough"?p+=l.hp*.15+(l.isBoss?150:0)+(l.role==="juggernaut"?90:0):s==="ground_tough"?p+=l.armor*14+l.hp*.08+(l.armorShred<=0?45:0):s==="citadel_threat"&&(p=-Re(l.x,l.y,i.citadel.x,i.citadel.y)*.8-d*.4+(l.role==="sapper"||l.role==="assassin"?40:0)),p>a&&(a=p,r=l)}return r}function Hd(i,e,t,n){if(!e.alive)return;const s=Zt(i),r=Mt[t]||Mt.guardian,a=Mt[i.heroClass]||Mt.guardian,o=s.heroDmg*(r.dmgMult/Math.max(.1,a.dmgMult)),l=s.heroRateMult*(r.rateMult/Math.max(.1,a.rateMult));if(e.attackCd-=n,e.attackCd>0)return;const c=ts(i,e.x,e.y,r.range,"citadel_threat");if(!c){e.attackCd=.12;return}const d=Math.atan2(c.y-e.y,c.x-e.x);e.ang=d,Math.abs(c.x-e.x)>3&&(e.faceX=c.x>e.x?1:-1),e.attackCd=.44*l;const p=wi(i,"hero_pierce");if(t==="archmage"){const E=2+p;let y=e.x,x=e.y;const b=new Set;let A=c;for(let R=0;R<E&&A;R++){b.add(A.uid),Jr(i,y,x,A.x,A.y,"#b87aff",1.6),Ht(i,A,o*Math.pow(.86,R),2),y=A.x,x=A.y;let D=null,O=76;for(const X of i.enemies){if(X.hp<=0||b.has(X.uid))continue;const k=Re(y,x,X.x,X.y);k<O&&(O=k,D=X)}A=D}W("arcane");return}const u=p>=2?3:1,h=t==="engineer",v=t==="ranger",f=t==="summoner",m=v&&Math.random()<.3,g=m?2.2:1;m&&Ke(i,e.x,e.y-12,"CRIT !","#ffe066",!0);const S=v?m?"#ffe066":"#5ef28c":f?"#38bdf8":h?"#ffbe3b":"#4ef2e8",M=v?310:f?245:235,_=v?.65:.56;for(let E=0;E<u;E++){const y=d+(E-(u-1)/2)*.16;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"hero_bolt",x:e.x+Math.cos(y)*6,y:e.y+Math.sin(y)*6,vx:Math.cos(y)*M,vy:Math.sin(y)*M,r:m?3.5:3,dmg:o*g*(E===0||u===1?1:.72),pierce:s.heroPierce+(v?1:0),life:_,maxLife:_,color:S,splash:0,slow:0,armorBonus:v||f||h?3:1,hitList:[]})}W(v?"bow":f?"arcane":"sword")}function px(i,e){if(Hd(i,i.hero,i.heroClass,e),i.coopPlayers&&i.coopPlayers.length>0)for(const t of i.coopPlayers)Hd(i,t.hero,t.heroClass,e)}function mx(i,e){for(let t=i.summonedTurrets.length-1;t>=0;t--){const n=i.summonedTurrets[t];if(n.life-=e,n.animPhase+=e*8,n.life<=0){_t(i,n.x,n.y,10,"#ffbe3b",50,.3,2),i.summonedTurrets.splice(t,1);continue}if(n.cd-=e,n.cd>0)continue;const s=ts(i,n.x,n.y,n.range,"nearest");if(!s){n.cd=.12;continue}n.cd=.28;const r=Math.atan2(s.y-n.y,s.x-n.x);i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"hero_bolt",x:n.x+Math.cos(r)*5,y:n.y+Math.sin(r)*5,vx:Math.cos(r)*260,vy:Math.sin(r)*260,r:2.5,dmg:n.dmg,pierce:1,life:.55,maxLife:.55,color:"#ffbe3b",splash:0,slow:0,armorBonus:2,hitList:[]}),W("bow")}}function gx(i,e){const t=i.citadel,n=Zt(i);if(t.cd-=e,t.cd>0)return;const s=115+n.citadelGuardLvl*15,r=ts(i,t.x,t.y,s,"nearest");if(!r){t.cd=.2;return}t.cd=Math.max(.45,1.35-n.citadelGuardLvl*.24-(t.lvl-1)*.12);const a=Math.atan2(r.y-t.y,r.x-t.x),o=18+(t.lvl-1)*8+n.citadelGuardLvl*12;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"citadel_bolt",x:t.x+Math.cos(a)*14,y:t.y+Math.sin(a)*14,vx:Math.cos(a)*220,vy:Math.sin(a)*220,r:3,dmg:o,pierce:1+Math.floor(n.citadelGuardLvl/2),life:.75,maxLife:.75,color:"#ffe066",splash:0,slow:0,armorBonus:2,hitList:[]}),W("arcane")}function vx(i,e){for(const t of i.buildings){const n=We[t.id];if(t.id==="sanctuary"){if(t.cd-=e,t.cd<=0){t.cd=1;const d=di(t),p=8+(t.lvl-1)*5;for(const u of i.buildings)u.uid!==t.uid&&Re(t.x,t.y,u.x,u.y)<=d&&(u.hp<u.maxHp&&u.sanctuaryHealCd<=0&&(u.hp=Math.min(u.maxHp,u.hp+p),u.healFlash=.18,u.sanctuaryHealCd=.9),u.overclockTimer=Math.max(u.overclockTimer,1.15))}continue}if(t.id==="shield_gen"){if(t.cd-=e,t.cd<=0){t.cd=1;const d=di(t),p=Math.round(90+(t.lvl-1)*55),u=Math.max(18,Math.round(p*.25));let h=!1;for(const v of i.buildings)Re(t.x,t.y,v.x,v.y)<=d&&(v.maxShield=Math.max(v.maxShield,p),v.shield<v.maxShield&&(v.shield=Math.min(v.maxShield,v.shield+u),h=!0),v.shieldTimer=Math.max(v.shieldTimer,1.8));if(Re(t.x,t.y,i.citadel.x,i.citadel.y)<=d+22){const v=Math.round(p*1.5);i.citadel.maxShield=Math.max(i.citadel.maxShield,v),i.citadel.shield<i.citadel.maxShield&&(i.citadel.shield=Math.min(i.citadel.maxShield,i.citadel.shield+Math.round(u*1.5)),h=!0),i.citadel.shieldTimer=Math.max(i.citadel.shieldTimer,1.8)}h&&W("shield")}continue}if(t.id==="war_banner"){if(t.cd-=e,t.cd<=0){t.cd=Math.max(1.2,n.fireRate/(1+(t.lvl-1)*.08));const d=di(t);let p=!1;for(const u of i.buildings)We[u.id].category==="turret"&&Re(t.x,t.y,u.x,u.y)<=d&&(u.overclockTimer=Math.max(u.overclockTimer,2.8),p=!0);if(i.hero.alive&&Re(t.x,t.y,i.hero.x,i.hero.y)<=d){const u=12+(t.lvl-1)*6;i.hero.hp<i.hero.maxHp&&(i.hero.hp=Math.min(i.hero.maxHp,i.hero.hp+u),p=!0)}p&&i.zonesFx.push({uid:i.nextUid++,kind:"rally_ring",x:t.x,y:t.y,r:d,dmg:0,life:.35,maxLife:.35,color:"#ff7e33",fromPlayer:!0,hitDone:!0})}continue}if(t.id==="spike_trap"){if(t.cd-=e,t.cd<=0){let d=!1;const p=Qr(i,t),u=di(t);for(const h of i.enemies)h.flying||h.hp<=0||Re(t.x,t.y,h.x,h.y)<=u+h.r&&(d=!0,h.slow=Math.max(h.slow,n.slow),Ht(i,h,p,0,t.uid));d&&(t.cd=Qi(i,t),t.flash=.1)}continue}if(t.id==="rune_mine"){if(!t.armed){t.cd-=e,t.cd<=0&&(t.armed=!0,t.flash=.2);continue}const d=di(t);if(i.enemies.find(u=>!u.flying&&u.hp>0&&Re(t.x,t.y,u.x,u.y)<=20+u.r)){t.armed=!1,t.cd=Math.max(5.5,n.fireRate-(t.lvl-1)*1.2);const u=Qr(i,t),h=Mr(t);pn(i,t.x,t.y,h,"#ff4f6d"),W("catapult");for(const v of i.enemies)!v.flying&&Re(t.x,t.y,v.x,v.y)<=Math.max(d,h)+v.r&&(v.slow=Math.max(v.slow,n.slow),Ht(i,v,u,3,t.uid,!0))}continue}if(n.category!=="turret")continue;const s=di(t),r=Qr(i,t);if(t.id==="solar_tower"){let d=i.enemies.find(u=>u.uid===t.beamTargetUid&&u.hp>0&&Re(t.x,t.y,u.x,u.y)<=s+u.r);if(d||(d=ts(i,t.x,t.y,s,Kr(t,"tough"))??void 0),!d){t.beamTargetUid=0,t.beamCharge=Math.max(0,t.beamCharge-e*1.5),t.cd=.05;continue}d.uid!==t.beamTargetUid&&(t.beamTargetUid=d.uid,t.beamCharge=0);const p=t.spec==="A"?1.9:3.8;if(t.beamCharge=Math.min(1,t.beamCharge+e/p),t.cd-=e,t.cd<=0){const u=Zt(i),h=t.overclockTimer>0?.68:1;t.cd=Math.max(.09,.15*u.turretRateMult*h);const v=1+t.beamCharge*(3.5+Math.min(4,(t.lvl-1)*.35)),f=Math.floor(d.armor*.6)+2;if(Ht(i,d,r*v,f,t.uid),t.spec==="B"){let m=null,g=96;for(const S of i.enemies){if(S.hp<=0||S.uid===d.uid)continue;const M=Re(d.x,d.y,S.x,S.y);M<g&&(g=M,m=S)}m&&(Jr(i,d.x,d.y,m.x,m.y,"#ffe066",1.6),Ht(i,m,r*v*.72,f,t.uid))}Math.random()<.35&&_t(i,d.x,d.y,2,"#ffe066",35,.18,2),W("laser")}continue}if(t.cd-=e,t.cd>0)continue;if(t.id==="frost_tower"){if(!i.enemies.some(u=>u.hp>0&&Re(t.x,t.y,u.x,u.y)<=s+u.r)){t.cd=.2;continue}t.cd=Qi(i,t),i.zonesFx.push({uid:i.nextUid++,kind:"frost_ring",x:t.x,y:t.y,r:s,dmg:0,life:.35,maxLife:.35,color:"#7ce8ff",fromPlayer:!0,hitDone:!0});const p=t.spec==="A"?2:0;for(const u of i.enemies)Re(t.x,t.y,u.x,u.y)<=s+u.r&&(u.slow=Math.max(u.slow,n.slow+Math.min(2.5,(t.lvl-1)*.4)+p),t.spec==="B"&&(u.armorShred=Math.max(u.armorShred,4)),Ht(i,u,r,t.spec==="B"?2:0,t.uid));W("frost");continue}if(t.id==="arcane_tower"){const d=ts(i,t.x,t.y,s,Kr(t,"nearest"));if(!d){t.cd=.2;continue}t.cd=Qi(i,t);const p=t.spec==="A"?4:0,u=Math.min(13,n.chains+Math.floor((t.lvl-1)*.6)+p),h=t.spec==="B"?6:2;let v=t.x,f=t.y;const m=new Set;let g=d;for(let S=0;S<u&&g;S++){m.add(g.uid),Jr(i,v,f,g.x,g.y,"#b87aff",1.6),Ht(i,g,r*Math.pow(.88,S),h,t.uid),v=g.x,f=g.y;let M=null,_=72;for(const E of i.enemies){if(E.hp<=0||m.has(E.uid))continue;const y=Re(v,f,E.x,E.y);y<_&&(_=y,M=E)}g=M}W("arcane");continue}if(t.id==="tesla_spire"){const d=ts(i,t.x,t.y,s,Kr(t,"nearest"));if(!d){t.cd=.2;continue}t.cd=Qi(i,t);const p=t.spec==="A"?3:0,u=Math.min(13,n.chains+Math.floor((t.lvl-1)*.5)+p),h=t.spec==="A"?1.6:1,v=t.spec==="B"?6:2;let f=t.x,m=t.y;const g=new Set;let S=d;for(let M=0;M<u&&S;M++){g.add(S.uid),Jr(i,f,m,S.x,S.y,"#38bdf8",1.8),S.stun=Math.max(S.stun,(S.isBoss?.08:.25)*h),Ht(i,S,r*Math.pow(.9,M),v,t.uid),f=S.x,m=S.y;let _=null,E=82;for(const y of i.enemies){if(y.hp<=0||g.has(y.uid))continue;const x=Re(f,m,y.x,y.y);x<E&&(E=x,_=y)}S=_}W("arcane");continue}if(t.id==="chrono_obelisk"){if(!i.enemies.some(u=>u.hp>0&&Re(t.x,t.y,u.x,u.y)<=s+u.r)){t.cd=.25;continue}t.cd=Qi(i,t),i.zonesFx.push({uid:i.nextUid++,kind:"stasis_ring",x:t.x,y:t.y,r:s,dmg:0,life:.42,maxLife:.42,color:"#b87aff",fromPlayer:!0,hitDone:!0});const p=t.spec==="A"?2.5:0;for(const u of i.enemies)u.hp>0&&Re(t.x,t.y,u.x,u.y)<=s+u.r&&(u.slow=Math.max(u.slow,n.slow+Math.min(2.5,(t.lvl-1)*.4)+p),u.armorShred=Math.max(u.armorShred,3.5),t.spec==="B"&&(u.stun=Math.max(u.stun,u.isBoss?.15:.45)),Ht(i,u,r,3,t.uid));W("frost");continue}const a=t.id==="flak_tower"?"anti_air":t.id==="alch_mortar"?"ground_tough":t.id==="archer_tower"?"flying":t.id==="ballista"||t.id==="catapult"?"tough":"nearest",o=Kr(t,a),l=ts(i,t.x,t.y,s,o);if(!l){t.cd=.15;continue}t.cd=Qi(i,t);const c=Math.atan2(l.y-t.y,l.x-t.x);if(t.id==="archer_tower"){const d=t.spec==="A"?3:1;for(let p=0;p<d;p++){const u=c+(p-(d-1)/2)*.16;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"arrow",x:t.x,y:t.y-4,vx:Math.cos(u)*(t.spec==="B"?295:235),vy:Math.sin(u)*(t.spec==="B"?295:235),r:t.spec==="B"?2.5:2,dmg:d>1?r*.78:r,pierce:t.spec==="B"?2:1,life:t.spec==="B"?.85:.75,maxLife:t.spec==="B"?.85:.75,color:t.spec==="B"?"#ffbe3b":"#5ef28c",splash:0,slow:0,armorBonus:t.spec==="B"?4:0,hitList:[],sourceBuildingUid:t.uid})}W("bow")}else if(t.id==="ballista")i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"ballista",x:t.x,y:t.y-4,vx:Math.cos(c)*265,vy:Math.sin(c)*265,r:3,dmg:r,pierce:Math.min(13,3+Math.floor((t.lvl-1)*.7)+(t.spec==="A"?3:0)),life:.8,maxLife:.8,color:"#ffbe3b",splash:0,slow:0,armorBonus:4+Math.floor((t.lvl-1)*.5)+(t.spec==="A"?4:0),hitList:[],sourceBuildingUid:t.uid}),W("bow");else if(t.id==="flak_tower"){const d=Re(t.x,t.y,l.x,l.y)/280;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"flak_shell",x:t.x,y:t.y-5,vx:Math.cos(c)*280,vy:Math.sin(c)*280,r:3,dmg:r,pierce:1,life:d+.03,maxLife:1,color:"#7ce8ff",splash:Mr(t),slow:0,armorBonus:1,antiAirMult:2.4,hitList:[],sourceBuildingUid:t.uid}),W("flak")}else if(t.id==="alch_mortar"){const d=Re(t.x,t.y,l.x,l.y)/155;i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"acid_flask",x:t.x,y:t.y-5,vx:Math.cos(c)*155,vy:Math.sin(c)*155,r:3.5,dmg:r,pierce:1,life:d+.04,maxLife:1.4,color:"#a3e635",splash:Mr(t),slow:0,armorBonus:2,hitList:[],sourceBuildingUid:t.uid}),W("acid")}else t.id==="catapult"&&(i.projectiles.push({uid:i.nextUid++,fromPlayer:!0,kind:"boulder",x:t.x,y:t.y-6,vx:Math.cos(c)*145,vy:Math.sin(c)*145,r:4.5,dmg:r,pierce:1,life:Re(t.x,t.y,l.x,l.y)/145+.05,maxLife:1.6,color:"#ff7e33",splash:Mr(t),slow:0,armorBonus:4,hitList:[],sourceBuildingUid:t.uid}),W("catapult"))}}function Sx(i,e,t){px(i,t),mx(i,t),gx(i,t),vx(i,t);for(let n=i.projectiles.length-1;n>=0;n--){const s=i.projectiles[n];if(s.life-=t,s.life<=0){s.fromPlayer&&s.splash>0&&Gd(i,s),i.projectiles.splice(n,1);continue}if(s.x+=s.vx*t,s.y+=s.vy*t,s.fromPlayer){let r=!1;for(const a of i.enemies)if(!(a.hp<=0||s.hitList.includes(a.uid))&&!(s.kind==="flak_shell"&&!a.flying)&&!(s.kind==="acid_flask"&&a.flying)&&Re(s.x,s.y,a.x,a.y)<=s.r+a.r){if(s.hitList.push(a.uid),s.splash>0){Gd(i,s),r=!0;break}if(Ht(i,a,s.dmg,s.armorBonus,s.sourceBuildingUid),s.pierce-=1,s.pierce<=0){r=!0;break}}r&&i.projectiles.splice(n,1)}else{let r=!1;if(i.hero.alive&&Re(s.x,s.y,i.hero.x,i.hero.y)<=s.r+i.hero.r&&(ws(i,s.dmg,i.hero),r=!0),!r&&i.coopPlayers){for(const a of i.coopPlayers)if(a.hero.alive&&Re(s.x,s.y,a.hero.x,a.hero.y)<=s.r+a.hero.r){ws(i,s.dmg,a.hero),r=!0;break}}if(!r){for(const a of i.buildings)if(We[a.id].blocksEnemies&&Re(s.x,s.y,a.x,a.y)<=s.r+a.w*7){if(s.splash>0){pn(i,s.x,s.y,s.splash,s.color);for(const l of i.buildings)Re(s.x,s.y,l.x,l.y)<=s.splash+8&&es(i,e,l,s.dmg)}else es(i,e,a,s.dmg);r=!0;break}}!r&&Re(s.x,s.y,i.citadel.x,i.citadel.y)<=s.r+22&&(bu(i,s.dmg),r=!0),r&&(_t(i,s.x,s.y,4,s.color,40,.2,2),i.projectiles.splice(n,1))}}for(let n=i.zonesFx.length-1;n>=0;n--){const s=i.zonesFx[n];if(s.life-=t,s.kind==="acid_pool"&&s.life>0)for(const r of i.enemies)r.flying||r.hp<=0||Re(s.x,s.y,r.x,r.y)<=s.r+r.r&&(r.armorShred=Math.max(r.armorShred,2.5),r.poisonTimer=Math.max(r.poisonTimer,2),r.poisonDps=Math.max(r.poisonDps,s.dmg));if(s.life<=0){if(!s.hitDone){if(s.hitDone=!0,s.kind==="ult_strike"){pn(i,s.x,s.y,s.r,"#b87aff");const r=i.heroClass==="archmage";for(const a of i.enemies)Re(s.x,s.y,a.x,a.y)<=s.r+a.r&&(a.stun=Math.max(a.stun,r?1.2:.8),r&&(a.armorShred=Math.max(a.armorShred,4)),Ht(i,a,s.dmg,r?6:3))}else if(s.kind==="boss_slam"){if(pn(i,s.x,s.y,s.r,"#ff4f6d"),i.hero.alive&&Re(s.x,s.y,i.hero.x,i.hero.y)<=s.r+i.hero.r&&ws(i,s.dmg,i.hero),i.coopPlayers)for(const r of i.coopPlayers)r.hero.alive&&Re(s.x,s.y,r.hero.x,r.hero.y)<=s.r+r.hero.r&&ws(i,s.dmg,r.hero);for(const r of[...i.buildings])Re(s.x,s.y,r.x,r.y)<=s.r+10&&es(i,e,r,s.dmg,1.5)}}i.zonesFx.splice(n,1)}}}function Gd(i,e){e.kind==="flak_shell"?xx(i,e.x,e.y,e.splash,e.dmg,e.antiAirMult||2.4,e.armorBonus,e.sourceBuildingUid):e.kind==="acid_flask"?_x(i,e.x,e.y,e.splash,e.dmg,e.armorBonus,e.sourceBuildingUid):yx(i,e.x,e.y,e.splash,e.dmg,e.armorBonus,e.sourceBuildingUid)}function xx(i,e,t,n,s,r,a,o){pn(i,e,t,n,"#7ce8ff"),W("flak");for(const l of i.enemies)if(!(l.hp<=0)&&Re(e,t,l.x,l.y)<=n+l.r){const c=l.flying?r:.65;Ht(i,l,s*c,a,o,!l.flying)}}function _x(i,e,t,n,s,r,a){pn(i,e,t,n,"#a3e635"),W("acid");for(const c of i.enemies)c.flying||c.hp<=0||Re(e,t,c.x,c.y)<=n+c.r&&(c.armorShred=Math.max(c.armorShred,2.5),c.poisonTimer=Math.max(c.poisonTimer,2),c.poisonDps=Math.max(c.poisonDps,s*.55),Ht(i,c,s,r,a,!0));const o=a?i.buildings.find(c=>c.uid===a):void 0,l=o&&o.id==="alch_mortar"&&o.spec==="A"?6.5:4.5;i.zonesFx.push({uid:i.nextUid++,kind:"acid_pool",x:e,y:t,r:n,dmg:s*.55,life:l,maxLife:l,color:"#a3e635",fromPlayer:!0,hitDone:!0,sourceBuildingUid:a})}function yx(i,e,t,n,s,r,a){pn(i,e,t,n,"#ff7e33"),W("catapult");for(const o of i.enemies)Re(e,t,o.x,o.y)<=n+o.r&&Ht(i,o,s,r,a,!0)}Pl();const Mx=document.getElementById("stage"),Mh=document.getElementById("cv"),bx=document.getElementById("cv3d"),kx=document.getElementById("cv3d-hud"),Ts=new Xf(Mh);let $t=null;try{$t=new hx(bx,kx)}catch(i){console.warn("WebGL 3D indisponible, repli sur le rendu 2D :",i)}const Dt=new kf,fn=new Mf(Mx,document.getElementById("stick"),document.getElementById("knob"));let zd=null;function Ex(){return J.settings.theme==="3d"&&$t!==null}function wx(){const i=Ex();return i!==zd&&(zd=i,Mh.hidden=i,$t==null||$t.setActive(i),i||Ts.resize()),i}let Ve=null,wo=0,la=0,ca=0,bl="",da="";const Bt=new fx({onStartGame:()=>{Qe(),ne.room&&ne.leaveRoom(),ns(),Ve=ar(Dt,J.selectedDifficulty,J.selectedClass),Bt.showScreen(""),Bt.startTutorialIfNeeded(Ve),Bt.syncHud(Ve,0)},onStartAdventure:(i,e,t)=>{Qe(),ne.room&&ne.leaveRoom(),ns(),Ve=uf(Dt,i,e,t,J.selectedClass),Bt.showScreen(""),Bt.startTutorialIfNeeded(Ve),Bt.syncHud(Ve,0)},onContinueSavedRun:()=>{Qe(),ne.room&&ne.leaveRoom(),Ve=Uh(Dt)??ar(Dt,J.selectedDifficulty,J.selectedClass),Cs(Ve.mode!=="adventure"),Bt.showScreen(""),Bt.syncHud(Ve,0)},onResumeGame:()=>{Ve&&Ve.modal==="pause"&&Bt.closeModal(Ve)},onSaveAndQuit:()=>{Ve&&!ne.isMultiplayer&&fr(Ve),ne.room&&ne.leaveRoom(),Ve=null,Cs(!0),Bt.showScreen("s-menu"),Bt.refreshMenu()},onAbandonGame:()=>{ne.isMultiplayer||ns(),ne.room&&ne.leaveRoom(),Ve=null,Cs(!0),Bt.refreshMenu()},onCycleCamera:()=>$t?$t.cycleCameraPreset():"3E PERS.",getState:()=>Ve,getPathField:()=>Dt});ne.listeners.onGameStart=i=>{Qe();const e=i.players.find(t=>t.id===ne.myId)||i.players[0];if(la=0,ca=0,bl="",da="",ne.role==="host"){const t=i.players.filter(n=>n.id!==ne.myId);Ve=hf(Dt,i.difficulty,e,t),ne.sendSnapshot(Ve)}else Ve=ar(Dt,i.difficulty,e.heroClass,!0),Ve.playerCount=i.players.length,Ve.localPlayerId=e.id,Ve.localPlayerName=e.name,Ve.localPlayerColor=e.color,Ve.pendingBanner={title:`COOP LAN (${i.players.length} JOUEURS)`,sub:"Pot commun partagé · Connecté à la partie de l’hôte !"};Bt.showScreen(""),Bt.syncHud(Ve,0)};ne.listeners.onRemoteInput=(i,e)=>{if(!Ve||ne.role!=="host"||!Ve.coopPlayers)return;const t=Ve.coopPlayers.find(n=>n.id===i);t&&(t.moveX=Se(Number(e.moveX)||0,-1,1),t.moveY=Se(Number(e.moveY)||0,-1,1),t.repairHeld=!!e.repairHeld)};ne.listeners.onRemoteCmd=(i,e)=>{var s;if(!Ve||ne.role!=="host")return;const t=Ve,n=(s=t.coopPlayers)==null?void 0:s.find(r=>r.id===i);switch(e.kind){case"dash":n&&!t.tacticalPause&&ku(t,Dt,e.moveX,e.moveY,e.mouseWx,e.mouseWy,n.hero,n.heroClass);break;case"rally":n&&!t.tacticalPause&&Eu(t,n.hero,n.heroClass);break;case"ult":n&&!t.tacticalPause&&wu(t,n.hero,n.heroClass);break;case"place":uu(t,Dt,e.id,e.gx,e.gy);break;case"upgrade":{const r=t.buildings.find(a=>a.uid===e.uid);r&&hu(t,r);break}case"repair":{const r=t.buildings.find(a=>a.uid===e.uid);r&&fu(t,r);break}case"sell":{const r=t.buildings.find(a=>a.uid===e.uid);r&&vu(t,Dt,r);break}case"sell_batch":{const r=new Set(e.uids),a=t.buildings.filter(o=>r.has(o.uid));a.length>0&&Su(t,Dt,a);break}case"upgrade_batch":{const r=t.batchSelectedUids,a=t.batchFilterId;t.batchSelectedUids=e.uids,t.batchFilterId=e.filterId,gu(t),t.batchSelectedUids=r,t.batchFilterId=a;break}case"paste_bp":Mu(t,Dt,e.bp,e.gx,e.gy);break;case"repair_all":pu(t);break;case"buy_upg":lu(t,e.id);break;case"prio":{const r=t.buildings.find(a=>a.uid===e.uid);r&&xu(r,e.prio);break}case"spec":{const r=t.buildings.find(a=>a.uid===e.uid);r&&_u(t,r,e.branch);break}case"start_wave":Da(t,!0);break;case"auto_wave":t.autoWave=!t.autoWave,t.autoWave&&t.phase==="prep"&&t.prepTimer>3&&(t.prepTimer=3);break;case"speed":(e.speed===1||e.speed===2||e.speed===3)&&(t.gameSpeed=e.speed);break;case"tact_pause":t.tacticalPause=!t.tacticalPause;break}};ne.listeners.onPlayerLeft=i=>{if(!Ve||ne.role!=="host"||!Ve.coopPlayers)return;const e=Ve.coopPlayers.findIndex(t=>t.id===i);if(e>=0){const[t]=Ve.coopPlayers.splice(e,1);Ve.playerCount=1+Ve.coopPlayers.length,Rn({title:`${t.name} a quitté la partie`,sub:`Co-op ajusté à ${Ve.playerCount} joueur${Ve.playerCount>1?"s":""}.`,col:"#ffbe3b"})}};ne.listeners.onHostDisconnected=i=>{Ve=null,Cs(!0),Bt.showScreen("s-multi"),Rn({title:"Session LAN interrompue",sub:i,col:"#ff4f6d"})};ne.listeners.onSnapshot=i=>{!Ve||ne.role!=="client"||ne.applySnapshot(Ve,i,Dt)};window.addEventListener("beforeunload",()=>{Ve&&!ne.isMultiplayer&&Ve.active&&Ve.modal!=="over"&&Ve.modal!=="victory"&&fr(Ve)});var Wd;(Wd=document.getElementById("ab-dash"))==null||Wd.addEventListener("click",()=>fn.trigger("dash"));var $d;($d=document.getElementById("ab-rally"))==null||$d.addEventListener("click",()=>fn.trigger("rally"));var qd;(qd=document.getElementById("ab-ult"))==null||qd.addEventListener("click",()=>fn.trigger("ult"));var Xd;(Xd=document.getElementById("ab-repair"))==null||Xd.addEventListener("click",()=>fn.pulseRepair());var Yd;(Yd=document.getElementById("btn-pause"))==null||Yd.addEventListener("click",()=>fn.trigger("pause"));window.addEventListener("resize",()=>{Ts.resize(),$t==null||$t.resize()});let Vd=performance.now();function kl(i){const e=Math.min(.05,Math.max(.001,(i-Vd)/1e3));Vd=i;const t=wx(),n=fn.consumeActions(),s=fn.getMoveVector();let r=s;if(t&&$t){(n.orbitDeltaX!==0||n.orbitDeltaY!==0)&&$t.adjustCameraOrbit(n.orbitDeltaX,n.orbitDeltaY),n.wheelDeltaY!==0&&(!Ve||Ve.toolMode!=="paste")&&$t.adjustCameraZoom(n.wheelDeltaY),n.cycleCamera&&(W("click"),Bt.setCameraLabel($t.cycleCameraPreset()));const h=$t.getCameraYaw(),v=Math.cos(h),f=Math.sin(h);r={x:s.x*v+s.y*f,y:s.y*v-s.x*f}}if(!Ve){wo+=e,mc({mode:"menu",ducked:!0}),t&&$t?$t.renderMenuScene(wo,J.selectedClass):Ts.renderMenuScene(wo,J.selectedClass),requestAnimationFrame(kl);return}const a=Ve,o=ne.role==="client"&&ne.isMultiplayer,l=ne.role==="host"&&ne.isMultiplayer;let c,d;if(fn.mouseInside){const h=t&&$t?$t.screenToGrid(fn.mouseScreenX,fn.mouseScreenY,a):Ts.screenToGrid(fn.mouseScreenX,fn.mouseScreenY,a);a.hoverGx=h.gx,a.hoverGy=h.gy,c=h.wx,d=h.wy}if(a.modal==="upgrades")(n.upgrades||n.pause)&&(W("click"),Bt.closeModal(a));else if(a.modal==="pause")n.pause?(W("click"),Bt.closeModal(a)):n.upgrades&&Pt(a,"upgrades")&&Bt.openUpgradesModal(a);else if(a.modal==="none"){if(n.selectBuildSlot!==null){const v=Bt.getVisibleBuildings(a)[n.selectBuildSlot];v&&(W("click"),a.toolMode==="build"&&a.buildMode===v?xn(a,"none"):xn(a,"build",v))}if(n.demolish&&Pt(a,"toolDemolish")&&(W("click"),xn(a,a.toolMode==="demolish"?"none":"demolish")),n.batchUpgrade&&Pt(a,"toolBatch")&&(W("click"),xn(a,a.toolMode==="batch_upgrade"?"none":"batch_upgrade")),n.copyMode&&Pt(a,"toolBlueprint")&&(W("click"),xn(a,a.toolMode==="copy_select"?"none":"copy_select")),n.rotateBlueprint&&a.toolMode==="paste"&&a.blueprint&&(a.blueprint=yu(a.blueprint),W("click")),n.tacticalPause&&Pt(a,"tacticalPause")&&(W("click"),o?ne.sendCmd({kind:"tact_pause"}):a.tacticalPause=!a.tacticalPause),n.togglePaths&&Pt(a,"pathPreview")&&(a.pathPreview=a.pathPreview==="auto"?"on":a.pathPreview==="on"?"off":"auto",W("click")),n.autoWave&&Pt(a,"autoWave")&&(W("click"),o?ne.sendCmd({kind:"auto_wave"}):(a.autoWave=!a.autoWave,a.autoWave&&a.phase==="prep"&&a.prepTimer>3&&(a.prepTimer=3))),n.cancelBuild&&(a.toolMode!=="none"?(xn(a,"none"),W("click")):a.selectedBuildingUid&&(a.selectedBuildingUid=null,W("click"))),n.pause)a.toolMode!=="none"?(xn(a,"none"),W("click")):a.selectedBuildingUid?(a.selectedBuildingUid=null,W("click")):(W("click"),ne.isMultiplayer||(a.paused=!0),a.modal="pause");else if(n.upgrades&&Pt(a,"upgrades"))Bt.openUpgradesModal(a);else if(n.startWave&&(o?ne.sendCmd({kind:"start_wave"}):Da(a,!0)),a.tacticalPause||(n.dash&&Pt(a,"abilityDash")&&(o?ne.sendCmd({kind:"dash",moveX:r.x,moveY:r.y,mouseWx:c,mouseWy:d}):ku(a,Dt,r.x,r.y,c,d)),n.rally&&Pt(a,"abilityRally")&&(o?ne.sendCmd({kind:"rally"}):Eu(a)),n.ult&&Pt(a,"abilityUlt")&&(o?ne.sendCmd({kind:"ult"}):wu(a))),a.toolMode==="demolish"||a.toolMode==="batch_upgrade"||a.toolMode==="copy_select"){if(n.leftClick&&a.hoverGx>=0&&a.hoverGy>=0&&(a.dragStart={gx:a.hoverGx,gy:a.hoverGy},a.dragEnd={gx:a.hoverGx,gy:a.hoverGy}),fn.mouseDownLeft&&a.dragStart&&a.hoverGx>=0&&a.hoverGy>=0&&(a.dragEnd={gx:a.hoverGx,gy:a.hoverGy}),n.leftRelease&&a.dragStart){const h=a.dragEnd||a.dragStart,v=Math.min(a.dragStart.gx,h.gx),f=Math.min(a.dragStart.gy,h.gy),m=Math.max(a.dragStart.gx,h.gx),g=Math.max(a.dragStart.gy,h.gy);if(a.toolMode==="demolish"){const S=a.buildings.filter(M=>M.gx<m+1&&M.gx+M.w>v&&M.gy<g+1&&M.gy+M.h>f);S.length>0&&(o?ne.sendCmd({kind:"sell_batch",uids:S.map(M=>M.uid)}):Su(a,Dt,S))}else if(a.toolMode==="batch_upgrade"){const S=a.buildings.filter(M=>M.gx<m+1&&M.gx+M.w>v&&M.gy<g+1&&M.gy+M.h>f);a.batchSelectedUids=S.map(M=>M.uid),a.batchFilterId="all",W("click")}else if(a.toolMode==="copy_select"){const S=df(a,v,f,m,g);S&&(a.blueprint=S,xn(a,"paste"),W("click"))}a.dragStart=null,a.dragEnd=null}}else if(a.toolMode==="paste"){if(n.leftClick&&a.blueprint&&a.hoverGx>=0&&a.hoverGy>=0){const h=a.hoverGx-Math.floor(a.blueprint.w/2),v=a.hoverGy-Math.floor(a.blueprint.h/2);o?ne.sendCmd({kind:"paste_bp",bp:a.blueprint,gx:h,gy:v}):Mu(a,Dt,a.blueprint,h,v)}}else if(a.toolMode==="build"&&a.buildMode){const h=We[a.buildMode],v=h.id==="wall"||h.id==="obsidian_wall"||h.id==="sky_wall"||h.id==="spike_trap";if(fn.mouseDownLeft||(da=""),n.leftClick||v&&fn.mouseDownLeft)if(o){const f=`${a.buildMode}:${a.hoverGx},${a.hoverGy}`;(n.leftClick||f!==da)&&(da=f,ne.sendCmd({kind:"place",id:a.buildMode,gx:a.hoverGx,gy:a.hoverGy}))}else!uu(a,Dt,a.buildMode,a.hoverGx,a.hoverGy)&&n.leftClick&&W("error")}else if(n.leftClick){const h=Dt.getBuildingAtGrid(a.hoverGx,a.hoverGy);h?(a.selectedBuildingUid=h.uid,W("click")):a.selectedBuildingUid=null}}if(o){const h=a.modal==="none"?fn.isRepairHeld(e):!1,v=a.modal==="none"&&!a.tacticalPause?r.x:0,f=a.modal==="none"&&!a.tacticalPause?r.y:0,m=`${v.toFixed(2)},${f.toFixed(2)},${h?1:0}`;if(ca+=e,(m!==bl||ca>=.05)&&(ca=0,bl=m,ne.sendInput({moveX:v,moveY:f,repairHeld:h,mouseWx:c,mouseWy:d})),a.tacticalPause&&a.modal==="none")a.camX=Se(a.camX+r.x*240*e,60,Ft-60),a.camY=Se(a.camY+r.y*240*e,60,Ot-60);else{const g=a.hero.alive?a.hero.x:a.citadel.x,S=a.hero.alive?a.hero.y:a.citadel.y;a.camX+=(g-a.camX)*Math.min(1,e*8),a.camY+=(S-a.camY)*Math.min(1,e*8)}Ha(a,e)}else{if(!a.paused&&!a.tacticalPause&&(l?a.modal!=="over"&&a.modal!=="victory":a.modal==="none")){const v=a.modal==="none"?r.x:0,f=a.modal==="none"?r.y:0,m=a.modal==="none"?fn.isRepairHeld(e):!1;let g=e*a.gameSpeed;for(;g>0;){const S=Math.min(.025,g);g-=S,ff(a,Dt,S,v,f,m),Sx(a,Dt,S),yf(a,Dt,S),Ha(a,S)}}else a.tacticalPause&&!a.paused&&a.modal==="none"&&(a.camX=Se(a.camX+r.x*240*e,60,Ft-60),a.camY=Se(a.camY+r.y*240*e,60,Ot-60),a.pathDirty&&Dt.recompute(a),Ha(a,e));l&&(la+=e,(la>=.05||a.modal==="over")&&(la=0,ne.sendSnapshot(a)))}const p=a.enemies.some(h=>h.isBoss);mc({mode:p?"boss":a.phase==="wave"?"wave":"prep",ducked:a.modal!=="none"}),Bt.syncModalScreen(a),Bt.syncHud(a,e),t&&$t?$t.renderGame(a,Dt):Ts.renderGame(a,Dt);const u=document.getElementById("minimap");u&&Ts.renderMinimap(u,a),requestAnimationFrame(kl)}requestAnimationFrame(kl);
